$=["","qx.client","Boolean","auto","qx.event.type.Event","solid","Integer","undefined","string","String","border-dark-shadow","none","Number","left","right",';',"completed",",","mousedown","failed","mshtml","hidden","bottom","top","singleton","gecko","width","set","aborted","timeout","middle","pressed","height","=","Color","border-light","sending",'computed=this.',"object","mouseup","scroll","receiving","qx.event.type.DataEvent","default",")","keydown","px",".","style","(\\d\\d?)",":","function","center",'=value;',"number","abandoned","0","keypress",'this.',"0px","&","other","boolean","absolute","over","minWidth","maxWidth","interval","Function","outset","active","overflow","inset","white","effect",";","borderTopWidth","maximized","error","configured","100%"," ","abstract","borderLeftWidth","_","background","mouseover","1*","maxHeight","minHeight","position","on","init","frame","load","qx.event.type.MouseEvent","-","Object","CSS1Compat","click","(","div","off","qx.io.remote.Response","scrollY",'if(this.',"]","locationX",": ",'}',"Enter","shorthand","qx.ui.core.Widget","mouseout","reset","wide","Up","execute","abbreviated",'"',"|","no","scrollX","locationY","get","yes","PageUp","inherit","input",'auto','delete this.',"unstyle","Theme","fixed","change","mousemove","border-light-shadow","body","border-dark",'tr.status',"created","both","opera",'output','!==undefined)',"/","keyup","Left","Right","?","qx.ui.table.pane.CellEvent","translucent","dblclick","*","ie4+","Down","button","text-field","filter","refresh","webkit","gray","$","groove",'dark-shadow',"qx.ui.popup.ToolTipManager","qx.ui.menu.Manager","horizontal","marginTop","icon","narrow","normal","khtml","display","marginLeft","qx.ui.menu.Menu","disappear","PageDown","vertical","1px","label",'action',"qx.event.type.DragEvent","selected","qx.ui.popup.PopupManager","dotted","text","qx.event.type.FocusEvent","'","list","changeValue","double","NumLock","overflowX","overflowY","\n","contextmenu",'return this.','else if(this.',"}","long","qx.event.type.KeyEvent","_timer","dashed","static/image/blank.gif","A","outset-thin","black","inset-thin","text-selected","appear","ridge","+","queued","blur",'stopped',"Content-Type","hand","Bitstream Vera Sans","_applyResizable","field",'!==undefined){',"fontSize","50%","visibilityChanged","short","hour","Home","paddingTop","9","%","left-reversed","wildcard","this.","middle-reversed","transparent","widthChanged","Tahoma","mousewheel","literal","top-reversed","Liberation Sans","marginRight","minimized",'=true;',"Escape","qx.resourceUri","qx.event.type.ChangeEvent","Space","center-reversed",'old=this.',"Lucida Grande","paddingBottom","Tab",')',"button-abandoned","focus","marginBottom","border-box","opaque","dark-shadow","qx.ui.popup.ToolTip","safari2",'',"paddingLeft","_applyClip","End","paddingRight","window-captionbar-button","Verdana","_applyText","Insert","date-chooser-title","_element","100px","F2","focusin","ms","medium","down","list-view-content-cell-text","dragover","date-chooser","dragenter","Delete","qx.ui.embed.IframeManager",'go',"_applyIcon","widget","px;","HHmmss","static","qx.ui.table.selection.Model","Ready","changeShow","focusout","HH:mm:ss",'","',"#","qx.io.remote.XmlHttpTransport","-moz-scrollbars-vertical","  ",'100%',"qx.allowUrlSettings","bold","table-header-border","(\\d\\d?\\d?)","-moz-scrollbars-horizontal","changeLocale","visibility","n-resize","textarea","qx.io.remote.ScriptTransport","{","menu-button","g","changeState",'typeof value === "number" && isFinite(value)',"pointer",'execute',"qx.io.remote.IframeTransport","table-row"," }","text-disabled","color","_applyEnabled","qx.ui.form.Button","underline","qx.event.handler.DragAndDropHandler","orderChanged","qx.ui.core.Parent",'stop',"full","=''","iframe",'",value);',"html","qx.client.NativeWindow","blue","Classic","_applyState","changeSelection","e-resize","zIndex","Connection dropped","null","s","_childrenQueue","_labelObject","MozOutline","a","_compute","F1","resize","addAtEnd","table-row-background-focused-blur","checked","appearances","removeAll","cursor","beforeunload","_paneScroller","indexOf","_table","_applyShowCellFocusIndicator","cldr_day_","qx.application.Gui","table-header","col-resize","addAfter","1px dotted invert","application/x-www-form-urlencoded","nw-resize","ellipsis","columnVisibilityMenuCreateEnd","__init$","qx.restrictToPageBottom","qx.ui.table.columnmodel.Basic","fontStyle","value","table-row-background-selected","styleTop","_applyLabel","F12","dragleave","table-row-background-focused-selected","borderBottomWidth","onscroll","_applyValue",'SmokeTrace to ',"parent","qx.util.format.NumberFormat","qx.ui.table.columnmodel.resizebehavior.Abstract","list-view-content-cell","_layout",'">',"mshtml|webkit","F3","tab-view-border","Control",":content-box;","up","meta","gecko|opera|webkit","nocache","tabIndex","F11","opacity","qx.ui.embed.Flash","cldr_month_",'started',"_applyPosition","styleRight","KhtmlOpacity","!between","_resizeColumnData","outline","styleLeft",'delay',"justify","Windows","F4","add",":border-box;","table-focus-indicator-active","no-cache","MozUserSelect","F10",'handle',"clipHeight","changeScrollY","italic","_invalidate",'  </div>',"tableHasFocus","colorRight","Pragma","fontWeight",'if(old===computed)return value;',"KhtmlUserSelect","noComputed","F5","]);","table-row-background-even","remove","dragstart",'else ',"removeChild","colors","character",'#b0b0b0','";',"colorBottom","fri","F6","spinner-button","modelChanged","DOMMouseScroll","_applyWrap","widthBottom","qx.restrictToPageTop","addAt","<=","changeFocused",'undefined',"_statusBar","drag","Array","whiteSpace","first","qx.io.image.Preloader","toggle","colorTop",">","qx.jsonDebugging","disabled","_valueData","==","F7","changeCapture","-khtml-box-sizing","windowresize","]\n","borderRightWidth","MozOpacity","unload","page","0 none","Label","qx.theme.ClassicRoyale","table-row-background-odd","popup","qx.enableAspect","Cache-Control","ne-resize","static/image/dotted_white.gif",'starting',"margin","_recompute","warning","focused","!=","table-pane","dragdrop","F8","&#","toolbar","sec","(a[","backgroundImage","qx.io.remote.AbstractRemoteTransport","text/css","file:",'px;',"day","_applyTextAlign","F9","quoted_literal","hasComputed","tableWidthChanged",'Z','stopping',"min","styleBottom","widthRight","before","_applyMenu","verticalScrollBarChanged","dragexit","toString","qx.restrictToPageRight","clipTop",'tr.info',"lazyopaque",'" ',"boxSizing",'.$$properties.',"qx.log.appender.Native","addBefore","fonts",'if(computed===undefined)computed=null;',"textDecoration","draggesture","fontFamily",'a',"widthTop","Margin",'</div>',"v","button-view-pane","wed",":constructor","sat","_iconObject","event"," rows","Padding","icons","table-row-background-selected-blur","addAtBegin","Alt","Backspace","backgroundColor","visibilityChangedPre","row-resize","regex",'z',"editing","_blocker","1px 0","tooltip-text","innerText","concat","tooltip",'!(',"textContent","resizer",'run_tr',"</div>","_objects","PrintScreen","Z","menu","ignore",'(',"__user$","mon",'tr.cgi',"table-row-background-focused-selected-blur","Host","readonly","return this.","_frame","qx.ui.window.Window","head","qx.ui.window.Manager","table-row-selected","ss","thu","slice","table-row-background-focused","qx.io.remote.Exchange","between","table-header-cell","^","qx.event.handler.FocusHandler","[","qx.restrictToPageLeft","WebkitUserSelect","qx.ui.table.IRowRenderer","qx.io.remote.Request","removeAt","clipLeft",'@import "',"borders",'tr.cmd',"widgets","userSelect","tue","<","();","widthLeft","sun","clipWidth",'if(old===undefined)old=null;',"textAlign","widget/arrows/down.gif","qx.ui.table.ITableModel","colorLeft","qx.util.range.IRange","-1000px",">=","lastIndexOf","Shift","list-view-header-border","_applyDimension","table-focus-indicator"," row","qx.ui.table.pane.Model"," [","\r\n","qooxdoo-table-cell","content","menu-button-arrow","_applyTablePaneModel",'m',"Border",'    * { box-sizing: border-box; -moz-box-sizing: border-box; -webkit-box-sizing: border-box }',"_applyActive","_valueOriginalTarget","Pause","pre","_applyMaxColumnCount","_applyBgcolOdd","javascript:void(0)","qx.util.Normalization","Linux","_applyTimeoutInterval","borderBottomStyle","Font","Use proxy","font-size: 11px;","qx.ui.menu.CheckBox","resizableEast","qx.Interface","1px solid #CCC","qx.ui.table.model.Abstract",'value !== null && window.document',"orange","GMT",'    <input id="marker" type="button" value="Add divider"/> &#160; &#160; Filter: <input name="filter" id="filter" type="text" value="',"_colToXPosMap","qx.ui.form.TextField",')a[i].',"_applyFocusRoot","qx.ui.basic.Inline","?instanceId=","qx.ui.table.ICellRenderer","_applyAllowClose","Not implemented","localeCompare","px;overflow:hidden;white-space:nowrap'>","status",'{0,1}[0-9]{3}){0,})','    html, body, input, pre{ font-size: 11px; font-family: Tahoma, sans-serif; line-height : 1 }','var inherit=prop.$$inherit;',"CrystalClear","Not modified","_applyLocale",'Tr.ui.Cellrenderer',"_ScriptTransport_data","./resource","pixelBottom","menu-layout"," (nightly)","cldr_time_format_","font-style","_cachedVisibleChildren","_applyEditable","table-editor-textfield","nowrap","changeHeaderCellHeight","qx.html.Dimension","_applyFont","Use getValue() instead!","_applySpacing","Macintosh","_hideTimer","tab-view-pane"," - ","SmokeTrace is part of the SmokePing suite created by Tobi Oetiker, Copyright 2008.","yy","list-view-header","_sortMethods","Gray() Alpha(Opacity=30)","__inherit$","changeBorderTheme","Use removeHtmlProperty instead",'\\\\',"_applySize","border","_applyChecked","resizableNorth","this.removeStyleProperty('padding","unkown","Partial content","qx.application.IApplication","MacPPC","quote","qx.ui.table.columnmodel.resizebehavior.Default","changeTableModel","qx.application","_applyColorBottom"," &nbsp;",'cell',"qx.Class","columnVisibilityMenuCreateStart",'rounds',"qx.logAppender","qx.event.handler.EventHandler","Win32","qx.iconTheme","forEach","1.0","qx.ui.menu.Separator",'  <div id="control">',"autoComplete","_iframe",' is not (yet) ready!");',"9*","changeElement","(measure start) ","qooxdoo-table-cell qooxdoo-table-cell-right","progid:DXImageTransform.Microsoft.AlphaImageLoader(src='","Height","qx.version","qx.log.appender.Window",'y',"modal","win","(\\d\\d(\\d\\d)?)","form","changeParent","px; width:","_applyMarginBottom","_applySelectable","_applyPreloader","radio-view-button-checked","qx.bom.element.Dimension","HH","tab-view-button-checked","_topRightWidget","cursor:","extend","Pixel","_applyBackgroundImage","_applyColNormal","firefox","qx.ui.menu.MenuLayoutImpl","n",'M',"changeTextColor","borderBottom",'computed=value;',"qx.boxModelCorrection","scrollbars"," WARN:  ",'Does not allow any arguments!',"__states",'return value;',"_dataRowRenderer",'\\f'," DEBUG: ","complete",'left',"_columnVisibilityBt","changeAnonymous","qx.locale.Manager",", ","</span>","tab-view-button","_scrollerParent","_applyOpen",'k',"qx.io.image.Manager","OmniWeb","3px solid #134275","_applyMinHeight","[^\\.0-9]","qx.ui.table.ICellEditorFactory","green","See other",'!',"-webkit-box-sizing","_data_","_showTimer","line-through","..","_list",";position:relative;height:",'if(!clazz.$$propertiesAttached)qx.core.Property.attach(clazz);',"changeActiveChild","_columnIndexMap","cldr_number_group_separator","U",'SmokeTrace 2.4.2',"log",']._autoCloseWindow()}catch(e){}">',"_applyShowInterval","var a=arguments[0] instanceof Array?arguments[0]:arguments;","qx.theme.classic.color.Royale","mm","C","Bad gateway",'value !== null && value.$$type === "Mixin"',"qx.ui.table.cellrenderer.Number","_applyBoundToWidget","NaN","qx.dom.Element","script","split","qx.util.format.Format","Log window message: Starting error recording, any errors below this line will prevent the log window from closing",'=computed;',"qx.ui.popup.Popup","Type","list-view","_applyActiveWindow","qx.ui.table.rowrenderer.Default","qx.io.Alias","_captionBar","<hr/>","_applyBottom","qx_NativeWindow",'Tr.ui.TraceTable',"menubar","_valueRelatedTarget","changeResizeMethod",":constructor wrapper","_closeTimer","[object Object]","HTTP version not supported",'value !== null && value.$$type === "Interface"',"qx.Mixin","_applyBorder","beforeAppear","font-family: 'Segoe UI', Corbel, Calibri, Tahoma, 'Lucida Sans Unicode', sans-serif;","_applyFirstColumnX","changeText","_applyRight","Use qx.Class.define instead","__cache","_applyMax","_check","window-inactive-caption-text","o",'A',"_applyMetaColumnCounts","qx.ui.layout.BoxLayout","_applyMaxHeight","Galeon","3*","force","after","  position: absolute;","userFocus","widget/splitpane/knob-horizontal.png","widget/arrows/up.gif","parentPaddingBottom","qx.lang.Generics","_arrowObject","qx.ui.basic.ScrollBar","8",'D','  <div id="lines">',"6","client-document-blocker","changeBehavior","push","qx.log.DefaultFilter","hh","list-view-border",'middle',"Log window message: Stopping error recording, discarding ","hasOwnProperty","qx.ui.basic.Image","qx.ui.table.pane.Scroller","Unidentified","list-view-header-cell-hover","_atom","Request-URL too large","padding","_spacer","Not acceptable","toolbar-part-handle-line","radio-view-bar",'typeof value === "number" && isFinite(value) && value%1 === 0',"_applyNumberFormat","Infinity","SSS","_buttonlayout",'!(value instanceof ','value !== null && qx.theme.manager.Font.getInstance().isDynamic(value)',"qx.html.Scroll","_applyName","changeIcon","html,body { margin:0;border:0;padding:0; } ","Best [ms]","_applyMaxCacheLines","_applyMin","_applyStretchChildrenOrthogonalAxis","_openTimer","pixelHeight"," !important","-Infinity","_lastMouseDownDispatchTarget",'(backup);',"[Mixin ","__all","parseerror","_applyFocused","lines",'if(computed===inherit){',"qx.log.Filter","_scrollBar","Connection closed by server","native","borderTop",'http://oss.oetiker.ch/smokeping','<body onload="qx = opener.qx;" onunload="try{qx.log.WindowAppender._registeredAppenders[',"sort","verticalAlign",'  </style>',"safari","scrollbar-blocker","_applyPaddingTop","_tableModel","h","Delay","qx.ui.core.Font","qx.ui.layout.impl.LayoutImpl","_applyCheckValueFunction",';}',"qx.deprecationWarnings","qx.fontTheme","Starting","Server error","\\\"","X-Qooxdoo-Response-Type","menu-check-box",'!==undefined&&',"getFirstActiveChild","Null","changeFont","_applyOverflow","radio-view-pane",'<iframe name="','value instanceof Date',"/static","qx.ui.table.IHeaderRenderer","borderLeftStyle","_applyBehavior","7","__convertBoolean","window-captionbar-restore-button","qx.aspects",'Tr.Application','if((computed===undefined||computed===inherit)&&',":00","_applyHideInterval","_applyReadOnly","BODY","_applyIncrementAmount","Application error ","_applySource",'(value);',"Value",'left:',"qx.OO","changeColorTheme"," errors have been recorded, keeping log window open.</b>","a=qx.lang.Array.fromShortHand(qx.lang.Array.fromArguments(a));","(passed time: ","MacIntel","last","_resetRuntime",'\\u00',"_handle","qooxdoo","Moved temporarily","_paneClipper","qx.ui.table.Table","_columnDataArr",'    hr { border: 0 none; border-bottom: 1px solid #ccc; margin: 8px 0; padding: 0; height: 1px }',"Loss [%]",'\\r',"substring","#D6D5D9","[object Error]","match",'#',"UNEXPECTED origin ","https://",'width:',"S",'value !== null && value.$$type === "Class"',"qx.util.format.DateFormat","_applyAutoSync","<span style=\"text-decoration:underline\">","  at ","Scroll","qx.io.remote.Rpc",'typeof value === "string" && qx.util.ColorUtil.isValid(value)',"__",'var a=this.getChildren();if(a)for(var i=0,l=a.length;i<l;i++){',"qx.ui.layout.impl.VerticalBoxLayoutImpl","cellClick",'h',"debug","_applyAppearance","_styleProperties","_applyOpacity","qx.ui.toolbar.Part","qx.html.Offset","widget/window/restore.gif","reverseChildrenOrder",",height=","qxvariant",'if(mixins[i].$$constructor){mixins[i].$$constructor.apply(this,arguments);}}}',"Alpha(Opacity=","Moved permanently","check-box-group-box-legend",'Authorization',"<div style='float:left;width:","charAt","m","_applyBorderTheme","qx.ui.table.cellrenderer.Default","\\$1","parentPaddingRight","_applyZIndex","')","qx.locale.Number","tab-view-button-hover","_format","_aliases","check-box","_applyOpenInterval","This method call is no longer needed.","window",'var backup=computed;',"_applyPaddingLeft","qx.core.LegacyProperty","_lastUpDownType",'for(var i=0,l=mixins.length;i<l;i++){',"_applyFontTheme","Please use getKeyIdentifier() instead.","_applyTabIndex",'if(this.classname===',"changeAppearance","qx.debug"," error ","resizable",'if(value!==inherit)',"qx.net.Http",'if(a[i].',"_width","_applyColSelected","(!this.",';-moz-user-select:none;',"font-size:","single","qx.locale.LocalizedString","4","changeBackgroundColor","changeRight","[Interface ","please use getText() instead.","_translationCatalog","qx.theme.manager.Color","_restoreButton","_columnVisibilityMenu","00","borderTopStyle","stylesheet","__useinit$","changeModal",'Undefined value is not allowed!',"widget/arrows/up_small.gif","Interface","font-weight","window-statusbar","changeDataRowRenderer","qx.bom.element.Style","qx.ui.table.selection.Manager","Width",'Is invalid!',"colorInnerBottom","id","netnewswire","qx.ui.layout.HorizontalBoxLayout","qx.theme.classic.Widget","': ","client-document","borderRightStyle","changeMoveMethod","unshift","widget/cursors/copy.gif","Ranges:","widget/menu/checkbox.gif","ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=","_applyMaxLength","/.qxrpc","Firefox","-moz-box-sizing","img","_showTimeStamp","  text-overflow:ellipsis;","table-menubar-button","Last [ms]","qx.lang.Core","_htmlAttributes",'" style="','){',"button-view-bar","qx.minLogLevel","anonymous: ","MozBoxSizing"," (#","changeScrollX","changeSource","  padding : 0px 2px;","_columnIdArr","spinner-button-down","width: ","tree-element-label","0.0","info","__convertNumber","__onmouseevent","#FFFFE0","=((v==null)?0:v)+'px'","_valueDomEvent","qx.io.remote.RequestQueue","_applyColorInnerBottom","_applyVerticalScrollBarVisible","_applyLeft","window-captionbar"," qooxdoo-table-cell-bold",'style="',"_borderElement","tool-tip","[object ","_maximizeButton","qx.appearanceTheme","__onwindowblur","clip","Mozilla","Log window message: <b>Note: ","_applyCloseInterval","javascript:/","/widget/Windows",'var prop=qx.core.Property;',"changeBottom",'w',"widget/table/selectColumnOrder.png","bold-large","icon/16/actions/view-refresh.png","qx.ui.resizer.IResizable","beforeDisappear","cldr_number_percent_format",'if(clazz.$$includes){var mixins=clazz.$$flatIncludes;',"_layoutImpl","5","_cached",')prop.error(this,5,"',"qx.theme.manager.Icon",'<div class="',"Windows Royale","qx.core.Version","tree-folder-icon","toLocaleUpperCase",'\", "',"&nbsp;&nbsp;",'\\b',"qx.theme.manager.Border",'./resource',"widget/window/minimize.gif","pixelWidth","_applyVerticalChildrenAlign","qx.log.Logger","__convertObject","MMMM","pixelRight","Server timeout","  [not readable: ","2*","ae","explorer","_computed","_applyShowClose","_applyTheme","0x","Stop","_requestHeaders"," ms) ","omniweb","))",'!==inherit){',"qx.ui.table.celleditor.TextField","changeTheme","qx.eventMonitorNoListeners","StDev [ms]","Classic Royale",'X',"_applyHoverItem","CapsLock","1px 8px","getLastActiveChild","widget/menu/radiobutton.gif",'value !== null && (qx.locale.Manager.getInstance().isDynamic(value) || typeof value === "string")',"_applyIconWidth","_lastMouseEventDate","_queue","_applyGlobalCursor","_applyStyleBottom","MaxWidth","image","valueOf","_applyInterval","result","galeon","2147483647","_titles","join","removeDom","qx.ui.resizer.MResizable",'Tr.Server','d',"Courier New","qx.html.StyleSheet","_appenderArr","AppleWebKit","Legacy properties are deprecated","Use setHtmlProperty instead","_remappingChildTable","k","about:blank","qx.ui.core.ClientDocument","qx.util.manager.Object","qx.ui.table.pane.Header","right-reversed","toolbar-part-handle","other gecko","_layoutChanges","qx.util.Compare","KK","qx.ui.basic.Atom","Percent","window-captionbar-icon","_applyBackgroundColor","combo-box-button","_applyCaption","qx.colorTheme","http://",'.classname)this.$$initialized=true;',"_applyResponseType","widget/arrows/next.gif",'else{',"_focusIndicator","_selectedRangeArr","qx.core.Init","_applyHorizontalChildrenAlign","Ae","2","Conflict",'#lines { width: 100%; height: expression((document.body.offsetHeight - 30) + "px"); }',"map","O","__theme$","_applyShowMaximize","Bitstream Vera Sans Mono",'value !== null && value.nodeType !== undefined',"_filterArr","widget/window/close.gif","rgb(","Hop",'computed=undefined;delete this.',"RealPlayer","Apps","font-style:","_applyMarginTop","5*",'    html, body{ padding: 0; margin: 0; border : 0 none; }','return retval;',"red","_applyVisibility",'if(computed===undefined||computed===inherit){',"splice","_parseFeed","_applyMaxWidth",'typeof value === "string"',"resizableWest","divider-vertical","200px","static/history/helper.html","changeZIndex","qx.theme.classic.font.Default",'if(value!==null)',"background-color:","console",'>',"--- Object: ",'typeof value === "string" && value.length > 0',"  border-bottom:1px solid #eeeeee;","_hideTimeStamp","Unknown status code"," selected",'right','<div>',"MM","create","Not available","_inlineEvents",")+;)|[^&","_applyIconTheme","_applyWidthRight","qx.lang.Object","_window","_upbutton","  top: 0px;",'throw new Error("Property ',"_valueSender",'g',"_columnNameArr",'Tr.ui.Footer',"_applyStatus",'value !== null && qx.theme.manager.Border.getInstance().isDynamic(value)',"spinner-button-up","No content","changeMode","_applyFocusHandler","Top","_pane","__convertString","qx.ui.form.Spinner","request","</div><span style='float:left'>&hellip;</span>",".qooxdoo-table-cell-italic {","_applyMnemonic","This method is no longer needed since the event object is now an instance of the Response class.","_applyDisplay","_document","Meta","qx.event.message.Bus","windowblur","_attachedWidget","Local error ","_applyBgcolFocused","_applyTableModel","cldr_am",'http://johan.oetiker.ch/~oetiker/tr/',"_applyShowStatusbar","_header","mozBoxSizing","form_","qx.dom.String","_applyAllowMaximize","ue","Server error ",'INFO','MT',"unix","3","changeFontTheme","body {}","&nbsp;","search","qx.core.Aspect","window-active-caption"," errors.","mac","qx.ui.core.Border",'Requires exactly one argument!',"widget/window/maximize.gif","Win",'if(value===null)prop.error(this,4,"',"_widget","_applyStatusBarVisible","_applyManager","Parsed","qx.bom.Document",'H','Basic ',"qx.ui.toolbar.ToolBar","_applySelectionModel",'<html><body><div id="state">',"location","window-captionbar-maximize-button",'value !== null && value.$$type === "Theme"',"changeTableColumnModel",'    pre { margin: 0; padding: 4px 8px; font-family: Consolas, "Bitstream Vera Sans Mono", monospace; }',"MSIE","EE","Forbidden","qx.html.Entity","_applyCaptureWidget","anonymous","_lastMouseDown","cssFloat","toolbar-part",'Referer','!(value && qx.Class.hasInterface(value.constructor, ',"qx.ui.basic.Label","changeVerticalScrollBarVisible","qx.ui.basic.ScrollArea","[Theme ","_rowArr","Proxy authentication required","qx.ui.popup.PopupAtom","beforeInsertDom","_applyAutoCloseWithErrors","M","qx.io.image.PreloaderSystem","qx.locale.Date","qx.html.EventRegistration","_innerStyle","verticalChildrenAlign","qx.html.Window","please use setText() instead.",")+>)|(&([^;]|","qx.bom.element.Location","Ue","_applyStyleRight",'===value)return value;',"-1","Object is null","<html><head><title>","=[not readable: "," in method "," qooxdoo-table-cell-right","i","qx.ui.basic.Terminator","_applyColorRight","_applyWidthBottom",'stop_tr','if(value===undefined)prop.error(this,2,"',"_oldParent","_applyItalic","widget/splitpane/knob-vertical.png",'value=this.',"_statusText",'Tr.resourceUri',"_formFields","toolbar=no,scrollbars=no,resizable=yes,","widget/cursors/move.gif","_minimizeButton","_active","  text-align:right","MSXML2.XMLHTTP.3.0","_applyHideFocus","progid:DXImageTransform.Microsoft.Shadow(color='Gray', Direction=135, Strength=4)"," messages removed)","SS","bottom-reversed","_applyImplementation","qx.core.MUserData",'value instanceof RegExp',"qx.event.type.DomEvent","<pre>Could not execute json: \n","__ondragevent","_valueOldValue","changeEnabled","button-view","_applyLoaded","())","qx.util.range.Range","_applyParent","qx.core.Variant","qx.core.Target",'<div ','K',"qx.net.HttpRequest","/source/class/","_applyFirstVisibleRow","__listeners","beforeRemoveDom","frame_","_applyMarginLeft","Request entity too large","qx.html.Location","Gecko","qx.log.LogEventProcessor","_closeButton","pixelTop","_applyElement",' of an instance of ',"qx.theme.classic.Border","text-decoration:","_applyShow",'E',"_applyFocusedChild","changeWidth",'host',"Worst [ms]","HHmmsszz","widget/table/ascending.png","widget/cursors/alias.gif",'Tr.ui.ActionButton',"_parentLogger","resizer-frame",'    #lines{ top: 30px; left: 0; right: 0; bottom: 0; position: absolute; overflow: auto; }',"'>","dependent","qx.lang.Array","_applyColorLeft","close","toLocaleLowerCase","changeFocusedChild","KDE","_children","_horScrollBar","_applyMethod","_modify","</title></head>","every","\\\\","addChild","qx.ui.table.columnmodel.Resize","changeValidator",'again',"__font",'s',"qx.util.Mime","__convertFunction","kk","_change","box-sizing","_applyIconPosition","changeDisplay","Nuvola","_applyWidth","_applyColorInnerRight","changeMaxHeight","Consolas","qx.locale.MTranslation","changeMinHeight",'return null;',"unselectable","qx.ui.layout.CanvasLayout","spinner","_remappingChildTarget","1","_applyWidgetTheme",".qooxdoo-table-cell {","Avg [ms]","<br>","html { border:0 none; } ",'\\n',"_locale","_image","', ((v==null)?0:v)+'px')","atom","_value","qx.preloaderTimeout","shift","qx.theme.manager.Appearance","_editableColArr","parentPaddingLeft","org.w3c.dom.svg","Current stack trace",'Null value is not allowed!',"table-focus-statusbar","HH:mm:ss zz","pixelLeft","file://","qx.event.handler.KeyEventHandler","qx.client.History","Request time-out","Bad request"," with incoming value '","menu-separator","link",'Could not change or apply init value after constructing phase!',"new Date(Date.UTC(","__convertUndefined","qxsetting","orientation","changeOverflow",'point',"__stateMap","keyinput",'value instanceof Function',"_htmlProperties","_appender","...","__intervalHandler","qx.ui.menu.ButtonLayoutImpl","_req","qx.log.appender.FireBug","qx.jsonEncodeUndefined","K","_valueCurrentTarget","dragend","__oninput","_applySpellCheck","window-statusbar-text","width=","toLowerCase"," of class ","_tablePane","EndToStart","_applyMinWidth","qx.client.Command","Multiple choices","  -o-text-overflow: ellipsis;","Win64","Stopping","changeIconTheme","_applyCommand","/icon/Nuvola","menu-separator-line","w","qx.ui.menu.Button","qx.html.Iframe",".qooxdoo-table-cell-right {","_applySelectionMode","Payment required",'", computed, old);',"borderRight",",top=","widget/cursors/nodrop.gif","_resizeLine",'value !== null && typeof value === "object"',"changeSelectionModel",'value instanceof Array',"cellDblclick","changeWindowManager","__visible","qx.ui.layout.impl.HorizontalBoxLayoutImpl","  height: 100%;",'SLEEP',",left=","qx_log_","_applyTextColor","changeCaption","e","_applyColorInnerTop","_overallColumnArr","utf-8","_applyMaximum","} ","MozUserFocus","qx.theme.manager.Widget","qx.core.Object","_applyMarginRight","_applyStyleLeft",'</div></body></html>',"Flex",'request',"_applyHeaderCellHeight","cldr_date_format_","Aborted","font-family:",'var computed, old=this.',"_applyHeight","_applyKeepFirstVisibleRowComplete","qx.core.Log","_lastMouseEventType","qx.theme.icon.Nuvola","Microsoft.XMLHTTP","_modalNativeWindow","_isErroneous","[Class ","_applyWidthTop","_style","changeLeft","_valueDomTarget",'10px sans-serif',"changeTop","__onselectevent","font-weight:","qx.ui.resizer.ResizablePopup","this.setStyleProperty('padding","windowfocus",':',"BSD","qx.ui.menu.Layout","changeMoveable","_applyFocusCellOnMouseMove","qx.Theme","Date","_applyBgcolFocusedSelectedBlur","_tableColumnModel","_valueValue","_selectionManager","changeStatus","_applyScrollTimeout","qx.ui.toolbar.MenuButton"," qooxdoo-table-cell-italic","_captionIcon","H","_parameters","_applyColumnVisibilityButtonVisible","qx.util.Validation","qx.util.ColorUtil","_valueTarget","tree-folder","-resize","borderLeft","changeActive","horizontalChildrenAlign"," INFO:  ","_applyShowCaption","_applyTop","HHmm","changeGlobalCursor","()","cellContextmenu","MSHTML-specific HTTP status code","toUpperCase",'var pa=this.getParent();if(pa)computed=pa.',"_captionTitle","Ip","Local time-out expired","_dynamic",".qooxdoo-table-cell-bold {","reverse","cldr_date_time_format_","changeTablePaneModel","changeHeight","qx.ui.table.cellrenderer.Conditional","X-Requested-With","qx.theme","spinner-text-field","insertDom","oe","_applyFamily","qx.ui.table.model.Simple","changeRowHeight","stretchChildrenOrthogonalAxis","empty","tree-folder-label","_ScriptTransport_","window-captionbar-minimize-button","qx.borderTheme","refreshSession",'value !== null && value.type !== undefined',"Error: Could not get a reference to the sheet object",'value !== null && value.nodeType === 1 && value.attributes',"Not found",'value !== null && typeof value === "object" && !(value instanceof Array) && !(value instanceof qx.core.Object)',"_applyShowMinimize","EEE","_applyShowIcon",'20px bold sans-serif',"is","tree-element-icon",'value !== null && value.nodeType === 9 && value.documentElement',"Gone","replace","#FFEEEE","\n</pre>","Unauthorized","_applyPaddingBottom","_visibleColumnArr",".apply(this._remappingChildTarget, arguments)","_registry","EEEE","Sent","*{","_applyOrientation","qx.ui.toolbar.PartHandle","  font-weight:bold","qx.log.MLogging","(\\d\\d)",'old=computed=this.',"_applyAllowMinimize","_applyColorTheme","qx.core.Client","MSXML2.XMLHTTP","qx.theme.manager.Meta","changeSpacing","_applyIconHeight","shiira",'===undefined)return;',"/icon/CrystalClear","_applyBgcolSelectedBlur","_applyActiveChild","substr","MaxHeight",'\\t',"_modalWidgets",'([0-9]{1,3}(?:',"  cursor:default;","qx.dom.Node","_applyCursor","cldr_pm","changeVisibility","colorInnerTop","realplayer","other webkit",'Tr',"_lastMouseDownDomTarget","_isPng","Element","_applyUseAdvancedFlexAllocation","qx.ui.table.columnmodel.resizebehavior.ColumnData","_applyUrl"," ---\n","  overflow:hidden;","qx.html.String",'))',"button-hover","cldr_number_decimal_separator","qx.ui.table.headerrenderer.Default",'var retval=clazz.$$original.apply(this,arguments);',"lineHeight","camino",'    #control { top: 0; left: 0; right: 0; padding: 4px 8px; background: #eee; border-bottom: 1px solid #ccc; height: 30px }',"qx.ui.core.ClientDocumentBlocker"," ERROR: ","widget/arrows/down_small.gif","divider-horizontal",'class="',"_top","u","activeX","qx.client.Timer",'(computed, old);',"qx.lang.Function","Out of resources","qx.dev.StackTrace","qx.core.Setting","_applyBgcolFocusedSelected","_applyModal","_globalCursorStyleSheet","_line",'\\"',"widget/table/descending.png"," (","Oe","Method not allowed","line-height: ","_applyAppearanceTheme","content-box","Ok",'if(',"MMM",'value instanceof Error','anonymous',"Unsupported media type","qx.core.Property","_applyTableColumnModel","Precondition failed","changeMenu","overflow: hidden;","__borderObject","_form","qx.event.type.Data","Error in property ","_verScrollBar",' %',"toolbar-button","Reset column widths","_applyProhibitCaching","MinWidth","Transport error ","this._style.","MSXML2.XMLHTTP.4.0","_applyStyleTop","getFirstChild","marker",'"></iframe>',"window-captionbar-title"," (r","Gateway time-out","resizableSouth",'else if(computed===undefined)',"dd","qx.io.Json","qx.widgetTheme","__formatTree","spacing","X-Qooxdoo-Version","-moz-scrollbars-none",'else this.',"_textfield","visible","Bottom","Go","initial","colorInnerLeft","large","_applyOpenItem"," FATAL: ","Safari","hideFocus","<div style='","qx.event.message.Message","MSXML2.XMLHTTP.6.0","_applyDisabledIcon","_applyPaddingRight","changeBorder","en",'S',"__userData","_captionFlex","Length required","_applyWidthLeft","--- End of object ---","_applyVisibleRowCount",'var clazz=arguments.callee.constructor;',"_inputElement","__onwindowresize","window-active-caption-text","changeMinWidth","_applyHorizontalScrollBarVisible",'var computed, old;','white','}else{',"window-captionbar-close-button","_isCreated","_applyDataRowRenderer","window-inactive-caption","qx.util.manager.Value","qx.core.Bootstrap","toLocaleString","_shortcutObject","parentPaddingTop","horizontalAlign","qx.enableApplicationLayout","_jobQueue","some",'</body></html>',"qx.ui.toolbar.Button",'typeof value === "boolean"',"changeDirection","Mixin","charCodeAt","Rounds","qx.theme.classic.Appearance","])*)(","qx.lang.Number",'\\d+){0,1}',"',sizingMethod='scale')","[\xE4\xF6\xFC\xDF\xC4\xD6\xDC]","changeTabIndex","qx.lang.String","qx.ui.table.pane.Pane","_renderRuntime","_applyCapture",'10px normal Consolas, "Bitstream Vera Sans Mono", "Courier New", monospace','.checkMap[value]===undefined','.check.call(this, value)',"overline","getLastChild","qx.html.ScrollIntoView","_applyReverseChildrenOrder",'([-+]){0,1}',"  font-style:italic","_applyDecoration","!isNaN(value)&&value>=this.getMin()&&value<=this.getMax()","rect(","_applyBgcolSelected","colorInnerRight","_isLoaded","_downbutton","_applyCurrentToolTip","__onwindowfocus","qx.ui.layout.VerticalBoxLayout","_headerClipper","konqueror","Auto","table-header-cell-hover","pop","BackgroundImageCache","isPrototypeOf","X11","NetNewsWire","qx.compatibility","_applyColorInnerLeft","  border-right:1px solid #eeeeee;","d","^(((<([^>]|","qx.bom.Viewport","text-align","url(","qx.theme.icon.CrystalClear","img{","_commands","_applyBold","_applyBgcolEven","changeWidgetTheme",'1*','    <pre id="log" wrap="wrap"></pre>',';color:','this.createDispatchChangeEvent("',"_applyColorTop","html,body{width:100%;height:100%;overflow:hidden;}","changeOpenMenu","qx.log.appender.Abstract","qx.ui.table.cellrenderer.Abstract","qx.html.Style","_applyBgcolFocusedBlur","_scrollContent","styleFloat","qx.locale.Locale","_checkValue","useAdvancedFlexAllocation","return this._remappingChildTarget.","changeHorizontalScrollBarVisible","changeOrientation","HH:mm","__oninterval","qx.ui.basic.HorizontalSpacer"," of ","Shiira","qx.theme.manager.Font","changeMaxWidth","MinHeight","yyyy","qx.io.image.PreloaderManager","Camino","state","qx.ui.layout.impl.CanvasLayoutImpl","_ScriptTransport_id","_applyMode","tree-element",'  <style type="text/css">',"monospace","changeAppearanceTheme"];if(!window.qxsettings)qxsettings={};
if(qxsettings["qx.resourceUri"]==undefined)qxsettings["qx.resourceUri"]="./resource/qx";
if(qxsettings["Tr.resourceUri"]==undefined)qxsettings["Tr.resourceUri"]="./resource/Tr";
if(qxsettings["qx.theme"]==undefined)qxsettings["qx.theme"]="qx.theme.ClassicRoyale";
if(qxsettings["qx.iconTheme"]==undefined)qxsettings["qx.iconTheme"]="qx.theme.icon.CrystalClear";
if(qxsettings["qx.minLogLevel"]==undefined)qxsettings["qx.minLogLevel"]=1000;
if(qxsettings["qx.logAppender"]==undefined)qxsettings["qx.logAppender"]="qx.log.appender.Native";
if(qxsettings["qx.application"]==undefined)qxsettings["qx.application"]="Tr.Application";
if(qxsettings["qx.version"]==undefined)qxsettings["qx.version"]="0.7svn ";
if(qxsettings["qx.isSource"]==undefined)qxsettings["qx.isSource"]=false;
if(!window.qxvariants)qxvariants={};
qxvariants["qx.deprecationWarnings"]="off";
qxvariants["qx.debug"]="off";
qxvariants["qx.compatibility"]="on";
qxvariants["qx.aspects"]="off";



/* ID: qx.core.Bootstrap */
qx={Class:{createNamespace:function($0,
$1){var $2=$0.split($[47]);
var $3=window;
var $4=$2[0];
for(var $5=0,
$6=$2.length-1;$5<$6;$5++,
$4=$2[$5]){if(!$3[$4]){$3=$3[$4]={};
}else{$3=$3[$4];
}}$3[$4]=$1;
return $4;
},
define:function($0,
$1){if(!$1){var $1={statics:{}};
}this.createNamespace($0,
$1.statics);
if($1.defer){$1.defer($1.statics);
}qx.core.Bootstrap.__registry[$0]=$1.statics;
}}};
qx.Class.define($[1946],
{statics:{LOADSTART:new Date,
time:function(){return new Date().getTime();
},
since:function(){return this.time()-this.LOADSTART;
},
__registry:{}}});




/* ID: qx.lang.Core */
qx.Class.define($[1140]);
if(!Error.prototype.toString||Error.prototype.toString()==$[1018]){Error.prototype.toString=function(){return this.message;
};
}if(!Array.prototype.indexOf){Array.prototype.indexOf=function($0,
$1){if($1==null){$1=0;
}else if($1<0){$1=Math.max(0,
this.length+$1);
}
for(var $2=$1;$2<this.length;$2++){if(this[$2]===$0){return $2;
}}return -1;
};
}
if(!Array.prototype.lastIndexOf){Array.prototype.lastIndexOf=function($0,
$1){if($1==null){$1=this.length-1;
}else if($1<0){$1=Math.max(0,
this.length+$1);
}
for(var $2=$1;$2>=0;$2--){if(this[$2]===$0){return $2;
}}return -1;
};
}
if(!Array.prototype.forEach){Array.prototype.forEach=function($0,
$1){var $2=this.length;
for(var $3=0;$3<$2;$3++){$0.call($1,
this[$3],
$3,
this);
}};
}
if(!Array.prototype.filter){Array.prototype.filter=function($0,
$1){var $2=this.length;
var $3=[];
for(var $4=0;$4<$2;$4++){if($0.call($1,
this[$4],
$4,
this)){$3.push(this[$4]);
}}return $3;
};
}
if(!Array.prototype.map){Array.prototype.map=function($0,
$1){var $2=this.length;
var $3=[];
for(var $4=0;$4<$2;$4++){$3.push($0.call($1,
this[$4],
$4,
this));
}return $3;
};
}
if(!Array.prototype.some){Array.prototype.some=function($0,
$1){var $2=this.length;
for(var $3=0;$3<$2;$3++){if($0.call($1,
this[$3],
$3,
this)){return true;
}}return false;
};
}
if(!Array.prototype.every){Array.prototype.every=function($0,
$1){var $2=this.length;
for(var $3=0;$3<$2;$3++){if(!$0.call($1,
this[$3],
$3,
this)){return false;
}}return true;
};
}if(!String.prototype.quote){String.prototype.quote=function(){return $[119]+this.replace(/\\/g,
$[1546]).replace(/\"/g,
$[967])+$[119];
};
}




/* ID: qx.lang.Generics */
qx.Class.define($[889],
{statics:{__map:{"Array":[$[1254],
$[1747],
$[950],
$[898],
$[1995],
$[1585],
$[1126],
$[1318],
$[572],
$[599],
$[362],
$[632],
$[742],
$[1297],
$[158],
$[1953],
$[1545]],
"String":[$[728],
$[1016],
$[1628],
$[1740],
$[1054],
$[1959],
$[362],
$[632],
$[1537],
$[1201],
$[680],
$[1019],
$[1397],
$[1780],
$[840],
$[1809],
$[572],
$[599]]},
__wrap:function($0,
$1){return function($2){return $0.prototype[$1].apply($2,
Array.prototype.slice.call(arguments,
1));
};
},
__init:function(){var $0=qx.lang.Generics.__map;
for(var $1 in $0){var $2=window[$1];
var $3=$0[$1];
for(var $4=0,
$5=$3.length;$4<$5;$4++){var $6=$3[$4];
if(!$2[$6]){$2[$6]=qx.lang.Generics.__wrap($2,
$6);
}}}}},
defer:function($0){$0.__init();
}});




/* ID: qx.core.Log */
qx.Class.define($[1687],
{statics:{log:function($0){this._write(arguments,
$[0]);
},
debug:function($0){this._write(arguments,
$[1038]);
},
info:function($0){this._write(arguments,
$[1157]);
},
warn:function($0){this._write(arguments,
$[499]);
},
error:function($0){this._write(arguments,
$[78]);
},
clear:function(){if(this._frame){this._frame.innerHTML=$[0];
}},
open:function(){if(!this._frame){this._create();
}this._frame.style.display=$[0];
},
close:function(){if(!this._frame){this._create();
}this._frame.style.display=$[11];
},
emu:true,
_unsupported:function(){this.warn("This method is not supported.");
},
_map:{debug:$[338],
info:$[810],
warning:$[668],
error:$[1315]},
_cache:[],
_write:function($0,
$1){if(!this._frame){this._create();
}
if(!this._frame){this._cache.push(arguments);
return;
}var $2=$1==$[499]||$1==$[78];
var $3=document.createElement($[101]);
var $4=$3.style;
$4.borderBottom=$[665];
$4.padding=$[1237];
$4.margin=$[569];
$4.color=this._map[$1]||$[338];
if($2){$4.background=$[1160];
}
for(var $5=0,
$6=$0.length;$5<$6;$5++){$3.appendChild(document.createTextNode($0[$5]));
if($5<$6-1){$3.appendChild(document.createTextNode($[798]));
}}this._frame.appendChild($3);
this._frame.scrollTop=this._frame.scrollHeight;
if($2){this.open();
}},
_create:function(){if(!document.body){return;
}var $0=this._frame=document.createElement($[101]);
$0.className=$[1330];
var $1=$0.style;
$1.zIndex=$[1252];
$1.background=$[73];
$1.position=$[63];
$1.display=$[11];
$1.width=$[80];
$1.height=$[1324];
$1.left=$1.right=$1.bottom=0;
$1.borderTop=$[806];
$1.overflow=$[3];
$1.font=$[1972];
$1.color=$[338];
document.body.appendChild($0);
if(this._cache){for(var $2=0,
$3=this._cache,
$4=$3.length;$2<$4;$2++){this._write($3[$2][0],
$3[$2][1]);
}this._cache=null;
}}},
defer:function($0,
$1,
$2){$0.assert=$0.dir=$0.dirxml=$0.group=$0.groupEnd=$0.time=$0.timeEnd=$0.count=$0.trance=$0.profile=$0.profileEnd=$0._unsupported;
if(!window.console){window.console=$0;
}else if(window.console&&(!console.debug||!console.trace||!console.group)){window.console=$0;
}}});




/* ID: qx.core.Setting */
qx.Class.define($[1853],
{statics:{__settings:{},
define:function($0,
$1){if($1===undefined){throw new Error('Default value of setting "'+$0+'" must be defined!');
}
if(!this.__settings[$0]){this.__settings[$0]={};
}else if(this.__settings[$0].defaultValue!==undefined){throw new Error('Setting "'+$0+'" is already defined!');
}this.__settings[$0].defaultValue=$1;
},
get:function($0){var $1=this.__settings[$0];
if($1===undefined){throw new Error('Setting "'+$0+'" is not defined.');
}
if($1.defaultValue===undefined){throw new Error('Setting "'+$0+'" is not supported by API.');
}
if($1.value!==undefined){return $1.value;
}return $1.defaultValue;
},
__init:function(){if(window.qxsettings){for(var $0 in qxsettings){if(($0.split($[47])).length!==2){throw new Error('Malformed settings key "'+$0+'". Must be following the schema "namespace.key".');
}
if(!this.__settings[$0]){this.__settings[$0]={};
}this.__settings[$0].value=qxsettings[$0];
}window.qxsettings=undefined;
try{delete window.qxsettings;
}catch(ex){}this.__loadUrlSettings();
}},
__loadUrlSettings:function(){if(this.get($[303])!=true){return;
}var $0=document.location.search.slice(1).split($[60]);
for(var $1=0;$1<$0.length;$1++){var $2=$0[$1].split($[50]);
if($2.length!=3||$2[0]!=$[1606]){continue;
}var $3=$2[1];
if(!this.__settings[$3]){this.__settings[$3]={};
}this.__settings[$3].value=decodeURIComponent($2[2]);
}}},
defer:function($0){$0.define($[303],
true);
$0.__init();
}});




/* ID: qx.lang.Array */
qx.Class.define($[1534],
{statics:{fromArguments:function($0){return Array.prototype.slice.call($0,
0);
},
fromCollection:function($0){return Array.prototype.slice.call($0,
0);
},
fromShortHand:function($0){var $1=$0.length;
if($1>4||$1==0){this.error("Invalid number of arguments!");
}var $2=qx.lang.Array.copy($0);
switch($1){case 1:$2[1]=$2[2]=$2[3]=$2[0];
break;
case 2:$2[2]=$2[0];
case 3:$2[3]=$2[1];
}return $2;
},
copy:function($0){return $0.concat();
},
clone:function($0){return $0.concat();
},
getLast:function($0){return $0[$0.length-1];
},
getFirst:function($0){return $0[0];
},
insertAt:function($0,
$1,
$2){$0.splice($2,
0,
$1);
return $0;
},
insertBefore:function($0,
$1,
$2){var $3=$0.indexOf($2);
if($3==-1){$0.push($1);
}else{$0.splice($3,
0,
$1);
}return $0;
},
insertAfter:function($0,
$1,
$2){var $3=$0.indexOf($2);
if($3==-1||$3==($0.length-1)){$0.push($1);
}else{$0.splice($3+1,
0,
$1);
}return $0;
},
removeAt:function($0,
$1){return $0.splice($1,
1)[0];
},
removeAll:function($0){return $0.length=0;
},
append:function($0,
$1){{};
Array.prototype.push.apply($0,
$1);
return $0;
},
remove:function($0,
$1){var $2=$0.indexOf($1);
if($2!=-1){$0.splice($2,
1);
return $1;
}},
contains:function($0,
$1){return $0.indexOf($1)!=-1;
}}});




/* ID: qx.core.Variant */
qx.Class.define($[1498],
{statics:{__variants:{},
__cache:{},
compilerIsSet:function(){return true;
},
define:function($0,
$1,
$2){{};
if(!this.__variants[$0]){this.__variants[$0]={};
}else{}this.__variants[$0].allowedValues=$1;
this.__variants[$0].defaultValue=$2;
},
get:function($0){var $1=this.__variants[$0];
{};
if($1.value!==undefined){return $1.value;
}return $1.defaultValue;
},
__init:function(){if(window.qxvariants){for(var $0 in qxvariants){{};
if(!this.__variants[$0]){this.__variants[$0]={};
}this.__variants[$0].value=qxvariants[$0];
}window.qxvariants=undefined;
try{delete window.qxvariants;
}catch(ex){}this.__loadUrlVariants(this.__variants);
}},
__loadUrlVariants:function(){if(qx.core.Setting.get($[303])!=true){return;
}var $0=document.location.search.slice(1).split($[60]);
for(var $1=0;$1<$0.length;$1++){var $2=$0[$1].split($[50]);
if($2.length!=3||$2[0]!=$[1047]){continue;
}var $3=$2[1];
if(!this.__variants[$3]){this.__variants[$3]={};
}this.__variants[$3].value=decodeURIComponent($2[2]);
}},
select:function($0,
$1){{};
for(var $2 in $1){if(this.isSet($0,
$2)){return $1[$2];
}}
if($1[$[43]]!==undefined){return $1[$[43]];
}{};
},
isSet:function($0,
$1){var $2=$0+$[162]+$1;
if(this.__cache[$2]!==undefined){return this.__cache[$2];
}var $3=false;
if($1.indexOf($[120])<0){$3=this.get($0)===$1;
}else{var $4=$1.split($[120]);
for(var $5=0,
$6=$4.length;$5<$6;$5++){if(this.get($0)===$4[$5]){$3=true;
break;
}}}this.__cache[$2]=$3;
return $3;
},
__isValidArray:function($0){return typeof $0===$[38]&&$0!==null&&$0 instanceof Array;
},
__isValidObject:function($0){return typeof $0===$[38]&&$0!==null&&!($0 instanceof Array);
},
__arrayContains:function($0,
$1){for(var $2=0,
$3=$0.length;$2<$3;$2++){if($0[$2]==$1){return true;
}}return false;
}},
defer:function($0){$0.define($[1080],
[$[91],
$[102]],
$[91]);
$0.define($[2000],
[$[91],
$[102]],
$[91]);
$0.define($[1231],
[$[91],
$[102]],
$[102]);
$0.define($[985],
[$[91],
$[102]],
$[102]);
$0.define($[963],
[$[91],
$[102]],
$[91]);
$0.__init();
}});




/* ID: qx.core.Client */
qx.Class.define($[1799],
{statics:{__init:function(){var $0=window.location.protocol===$[512];
var $1=navigator.userAgent;
var $2=navigator.vendor;
var $3=navigator.product;
var $4=navigator.platform;
var $5=false;
var $6;
var $7=null;
var $8=null;
var $9=0;
var $a=0;
var $b=0;
var $c=0;
var $d=null;
var $e=null;
var $f;
if(window.opera&&/Opera[\s\/]([0-9\.]*)/.test($1)){$7=$[142];
$8=RegExp.$1;
$6=$[142];
$8=$8.substring(0,
3)+$[47]+$8.substring(3);
$d=$1.indexOf($[1422])!==-1?$[20]:$1.indexOf($[1177])!==-1?$[25]:null;
}else if(typeof $2===$[8]&&$2===$[1539]&&/KHTML\/([0-9-\.]*)/.test($1)){$7=$[172];
$6=$[1992];
$8=RegExp.$1;
}else if($1.indexOf($[1262])!=-1&&/AppleWebKit\/([^ ]+)/.test($1)){$7=$[160];
$8=RegExp.$1;
$e=$8.indexOf($[212])!=-1;
var $g=RegExp($[808]).exec($8);
if($g){$8=$8.slice(0,
$g.index);
}
if($1.indexOf($[1916])!=-1){$6=$[953];
}else if($1.indexOf($[805])!=-1){$6=$[1226];
}else if($1.indexOf($[2037])!=-1){$6=$[1804];
}else if($1.indexOf($[1999])!=-1){$6=$[1119];
}else if($1.indexOf($[1308])!=-1){$6=$[1820];
}else{$6=$[1821];
}
if($e){$6+=$[694];
}}else if(window.controllers&&typeof $3===$[8]&&$3===$[1511]&&/rv\:([^\);]+)(\)|;)/.test($1)){$7=$[25];
$8=RegExp.$1;
if($1.indexOf($[1133])!=-1){$6=$[777];
}else if($1.indexOf($[2043])!=-1){$6=$[1838];
}else if($1.indexOf($[880])!=-1){$6=$[1251];
}else{$6=$[1273];
}}else if(/MSIE\s+([^\);]+)(\)|;)/.test($1)){$7=$[20];
$8=RegExp.$1;
$6=$[1218];
$5=!window.external;
}
if($8){$f=$8.split($[47]);
$9=$f[0]||0;
$a=$f[1]||0;
$b=$f[2]||0;
$c=$f[3]||0;
}var $h=[];
switch($7){case $[25]:$h.push($[1134]);
break;
case $[172]:$h.push($[480]);
break;
case $[160]:$h.push($[480]);
$h.push($[813]);
break;
case $[20]:break;
default:break;
}$h.push($[1557]);
var $i=document.compatMode!==$[98];
var $j=$[1924];
var $k=($7==$[20]?navigator.userLanguage:navigator.language).toLowerCase();
var $l=null;
var $m=$k.indexOf($[96]);
if($m!=-1){$l=$k.substr($m+1);
$k=$k.substr(0,
$m);
}var $n=$[11];
var $o=false;
var $p=false;
var $q=false;
var $r=false;
if($4.indexOf($[420])!=-1||$4.indexOf($[740])!=-1||$4.indexOf($[1636])!=-1){$o=true;
$n=$[759];
}else if($4.indexOf($[706])!=-1||$4.indexOf($[727])!=-1||$4.indexOf($[1003])!=-1){$p=true;
$n=$[1401];
}else if($4.indexOf($[1998])!=-1||$4.indexOf($[656])!=-1||$4.indexOf($[1706])!=-1){$q=true;
$n=$[1392];
}else{$r=true;
$n=$[61];
}var $s=false;
var $t=false;
var $u=false;
var $v=false;
if($7==$[20]){$s=true;
}if(document.implementation&&document.implementation.hasFeature){if(document.implementation.hasFeature($[1589],
$[743])){$t=$u=true;
}}this._runsLocally=$0;
this._engineName=$7;
this._engineNameMshtml=$7===$[20];
this._engineNameGecko=$7===$[25];
this._engineNameOpera=$7===$[142];
this._engineNameKhtml=$7===$[172];
this._engineNameWebkit=$7===$[160];
this._engineVersion=parseFloat($8);
this._engineVersionMajor=parseInt($9);
this._engineVersionMinor=parseInt($a);
this._engineVersionRevision=parseInt($b);
this._engineVersionBuild=parseInt($c);
this._engineQuirksMode=$i;
this._engineBoxSizingAttributes=$h;
this._engineEmulation=$d;
this._browserName=$6;
this._defaultLocale=$j;
this._browserPlatform=$n;
this._browserPlatformWindows=$o;
this._browserPlatformMacintosh=$p;
this._browserPlatformUnix=$q;
this._browserPlatformOther=$r;
this._browserModeHta=$5;
this._browserLocale=$k;
this._browserLocaleVariant=$l;
this._gfxVml=$s;
this._gfxSvg=$t;
this._gfxSvgBuiltin=$u;
this._gfxSvgPlugin=$v;
this._fireBugActive=(window.console&&console.log&&console.debug&&console.assert);
this._supportsTextContent=(document.documentElement.textContent!==undefined);
this._supportsInnerText=(document.documentElement.innerText!==undefined);
this._supportsXPath=!!document.evaluate;
this._supportsElementExtensions=!!window.HTMLElement;
},
getRunsLocally:function(){return this._runsLocally;
},
getEngine:function(){return this._engineName;
},
getBrowser:function(){return this._browserName;
},
getVersion:function(){return this._engineVersion;
},
getMajor:function(){return this._engineVersionMajor;
},
getMinor:function(){return this._engineVersionMinor;
},
getRevision:function(){return this._engineVersionRevision;
},
getBuild:function(){return this._engineVersionBuild;
},
getEmulation:function(){return this._engineEmulation;
},
isMshtml:function(){return this._engineNameMshtml;
},
isGecko:function(){return this._engineNameGecko;
},
isOpera:function(){return this._engineNameOpera;
},
isKhtml:function(){return this._engineNameKhtml;
},
isWebkit:function(){return this._engineNameWebkit;
},
isSafari2:function(){return this._engineNameWebkit&&(this._engineVersion<420);
},
isInQuirksMode:function(){return this._engineQuirksMode;
},
getLocale:function(){return this._browserLocale;
},
getLocaleVariant:function(){return this._browserLocaleVariant;
},
getDefaultLocale:function(){return this._defaultLocale;
},
usesDefaultLocale:function(){return this._browserLocale===this._defaultLocale;
},
getEngineBoxSizingAttributes:function(){return this._engineBoxSizingAttributes;
},
getPlatform:function(){return this._browserPlatform;
},
runsOnWindows:function(){return this._browserPlatformWindows;
},
runsOnMacintosh:function(){return this._browserPlatformMacintosh;
},
runsOnUnix:function(){return this._browserPlatformUnix;
},
supportsVml:function(){return this._gfxVml;
},
supportsSvg:function(){return this._gfxSvg;
},
usesSvgBuiltin:function(){return this._gfxSvgBuiltin;
},
usesSvgPlugin:function(){return this._gfxSvgPlugin;
},
isFireBugActive:function(){return this._fireBugActive;
},
supportsTextContent:function(){return this._supportsTextContent;
},
supportsInnerText:function(){return this._supportsInnerText;
},
getInstance:function(){return this;
}},
defer:function($0,
$1,
$2){$0.__init();
qx.core.Variant.define($[1],
[$[25],
$[20],
$[142],
$[160],
$[172]],
qx.core.Client.getInstance().getEngine());
}});




/* ID: qx.lang.Object */
qx.Class.define($[1347],
{statics:{isEmpty:function($0){for(var $1 in $0){return false;
}return true;
},
hasMinLength:function($0,
$1){var $2=0;
for(var $3 in $0){if((++$2)>=$1){return true;
}}return false;
},
getLength:function($0){var $1=0;
for(var $2 in $0){$1++;
}return $1;
},
_shadowedKeys:[$[1997],
$[904],
$[1947],
$[529],
$[1248]],
getKeys:qx.core.Variant.select($[1],
{"mshtml":function($0){var $1=[];
for(var $2 in $0){$1.push($2);
}for(var $3=0,
$4=this._shadowedKeys,
$5=$4.length;$3<$5;$3++){if($0.hasOwnProperty($4[$3])){$1.push($4[$3]);
}}return $1;
},
"default":function($0){var $1=[];
for(var $2 in $0){$1.push($2);
}return $1;
}}),
getKeysAsString:function($0){var $1=qx.lang.Object.getKeys($0);
if($1.length==0){return $[0];
}return $[119]+$1.join($[1202])+$[119];
},
getValues:function($0){var $1=[];
for(var $2 in $0){$1.push($0[$2]);
}return $1;
},
mergeWith:function($0,
$1,
$2){if($2===undefined){$2=true;
}
for(var $3 in $1){if($2||$0[$3]===undefined){$0[$3]=$1[$3];
}}return $0;
},
carefullyMergeWith:function($0,
$1){qx.log.Logger.deprecatedMethodWarning(arguments.callee);
return qx.lang.Object.mergeWith($0,
$1,
false);
},
merge:function($0,
$1){var $2=arguments.length;
for(var $3=1;$3<$2;$3++){qx.lang.Object.mergeWith($0,
arguments[$3]);
}return $0;
},
copy:function($0){var $1={};
for(var $2 in $0){$1[$2]=$0[$2];
}return $1;
},
invert:function($0){var $1={};
for(var $2 in $0){$1[$0[$2].toString()]=$2;
}return $1;
},
getKeyFromValue:function($0,
$1){for(var $2 in $0){if($0[$2]===$1){return $2;
}}return null;
},
select:function($0,
$1){return $1[$0];
},
fromArray:function($0){var $1={};
for(var $2=0,
$3=$0.length;$2<$3;$2++){{};
$1[$0[$2].toString()]=true;
}return $1;
}}});




/* ID: qx.core.Aspect */
qx.Class.define($[1398],
{statics:{__registry:[],
wrap:function($0,
$1,
$2){if(!qx.core.Setting.get($[492])){return $1;
}var $3=[];
var $4=[];
for(var $5=0;$5<this.__registry.length;$5++){var $6=this.__registry[$5];
if($0.match($6.re)&&($2==$6.type||$6.type==$[153])){var $7=$6.pos;
if($7==$[525]){$3.push($6.fcn);
}else{$4.push($6.fcn);
}}}
if($3.length==0&&$4.length==0){return $1;
}var $8=function(){for(var $5=0;$5<$3.length;$5++){$3[$5].call(this,
$0,
$1,
$2,
arguments);
}var $9=$1.apply(this,
arguments);
for(var $5=0;$5<$4.length;$5++){$4[$5].call(this,
$0,
$1,
$2,
arguments,
$9);
}return $9;
};
if($2!=$[291]){$8.self=$1.self;
$8.base=$1.base;
}$1.wrapper=$8;
return $8;
},
addAdvice:function($0,
$1,
$2,
$3){if($0!=$[525]&&$0!=$[883]){throw new Error("Unknown position: '"+$0+"'");
}this.__registry.push({pos:$0,
type:$1,
re:$2,
fcn:$3});
}},
defer:function(){qx.core.Setting.define($[492],
false);
}});




/* ID: qx.Class */
qx.Class.define($[735],
{statics:{define:function($0,
$1){if(!$1){var $1={};
}if($1.include&&!($1.include instanceof Array)){$1.include=[$1.include];
}if($1.implement&&!($1.implement instanceof Array)){$1.implement=[$1.implement];
}if(!$1.hasOwnProperty($[773])&&!$1.type){$1.type=$[291];
}{};
var $2=this.__createClass($0,
$1.type,
$1.extend,
$1.statics,
$1.construct,
$1.destruct);
if($1.extend){var $3=$1.extend;
if($1.properties){this.__addProperties($2,
$1.properties,
true);
}if($1.members){this.__addMembers($2,
$1.members,
true,
true);
}if($1.events){this.__addEvents($2,
$1.events,
true);
}if($1.include){for(var $4=0,
$5=$1.include.length;$4<$5;$4++){this.__addMixin($2,
$1.include[$4],
false);
}}}if($1.settings){for(var $6 in $1.settings){qx.core.Setting.define($6,
$1.settings[$6]);
}}if($1.variants){for(var $6 in $1.variants){qx.core.Variant.define($6,
$1.variants[$6].allowedValues,
$1.variants[$6].defaultValue);
}}if($1.defer){$1.defer.self=$2;
$1.defer($2,
$2.prototype,
{add:function($0,
$1){var $7={};
$7[$0]=$1;
qx.Class.__addProperties($2,
$7,
true);
}});
}if($1.implement){for(var $4=0,
$5=$1.implement.length;$4<$5;$4++){this.__addInterface($2,
$1.implement[$4]);
}}},
createNamespace:function($0,
$1){var $2=$0.split($[47]);
var $3=window;
var $4=$2[0];
for(var $5=0,
$6=$2.length-1;$5<$6;$5++,
$4=$2[$5]){if(!$3[$4]){$3=$3[$4]={};
}else{$3=$3[$4];
}}{};
$3[$4]=$1;
return $4;
},
isDefined:function($0){return this.getByName($0)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.__registry);
},
getByName:function($0){return this.__registry[$0];
},
include:function($0,
$1){{};
qx.Class.__addMixin($0,
$1,
false);
},
patch:function($0,
$1){{};
qx.Class.__addMixin($0,
$1,
true);
},
isSubClassOf:function($0,
$1){if(!$0){return false;
}
if($0==$1){return true;
}
if($0.prototype instanceof $1){return true;
}return false;
},
getPropertyDefinition:function($0,
$1){while($0){if($0.$$properties&&$0.$$properties[$1]){return $0.$$properties[$1];
}$0=$0.superclass;
}return null;
},
getByProperty:function($0,
$1){while($0){if($0.$$properties&&$0.$$properties[$1]){return $0;
}$0=$0.superclass;
}return null;
},
hasProperty:function($0,
$1){return !!this.getPropertyDefinition($0,
$1);
},
getEventType:function($0,
$1){var $0=$0.constructor;
while($0.superclass){if($0.$$events&&$0.$$events[$1]!==undefined){return $0.$$events[$1];
}$0=$0.superclass;
}return null;
},
supportsEvent:function($0,
$1){return !!this.getEventType($0,
$1);
},
hasOwnMixin:function($0,
$1){return $0.$$includes&&$0.$$includes.indexOf($1)!==-1;
},
getByMixin:function($0,
$1){var $2,
$3,
$4;
while($0){if($0.$$includes){$2=$0.$$flatIncludes;
for($3=0,
$4=$2.length;$3<$4;$3++){if($2[$3]===$1){return $0;
}}}$0=$0.superclass;
}return null;
},
getMixins:function($0){var $1=[];
while($0){if($0.$$includes){$1.push.apply($1,
$0.$$flatIncludes);
}$0=$0.superclass;
}return $1;
},
hasMixin:function($0,
$1){return !!this.getByMixin($0,
$1);
},
hasOwnInterface:function($0,
$1){return $0.$$implements&&$0.$$implements.indexOf($1)!==-1;
},
getByInterface:function($0,
$1){var $2,
$3,
$4;
while($0){if($0.$$implements){$2=$0.$$flatImplements;
for($3=0,
$4=$2.length;$3<$4;$3++){if($2[$3]===$1){return $0;
}}}$0=$0.superclass;
}return null;
},
getInterfaces:function($0){var $1=[];
while($0){if($0.$$implements){$1.push.apply($1,
$0.$$flatImplements);
}$0=$0.superclass;
}return $1;
},
hasInterface:function($0,
$1){return !!this.getByInterface($0,
$1);
},
implementsInterface:function($0,
$1){if(this.hasInterface($0,
$1)){return true;
}
try{qx.Interface.assert($0,
$1,
false);
return true;
}catch(ex){}return false;
},
getInstance:function(){if(!this.$$instance){this.$$allowconstruct=true;
this.$$instance=new this;
delete this.$$allowconstruct;
}return this.$$instance;
},
genericToString:function(){return $[1693]+this.classname+$[106];
},
__registry:qx.core.Bootstrap.__registry,
__allowedKeys:null,
__staticAllowedKeys:null,
__validateConfig:function(){},
__createClass:function($0,
$1,
$2,
$3,
$4,
$5){var $6;
if(!$2&&true){$6=$3||{};
}else{$6={};
if($2){if(!$4){$4=this.__createDefaultConstructor();
}$6=this.__wrapConstructor($4,
$0,
$1);
}if($3){var $7;
for(var $8=0,
$9=qx.lang.Object.getKeys($3),
$a=$9.length;$8<$a;$8++){$7=$9[$8];
{$6[$7]=$3[$7];
};
var $b;
}}}var $c=this.createNamespace($0,
$6,
false);
$6.name=$6.classname=$0;
$6.basename=$c;
if(!$6.hasOwnProperty($[529])){$6.toString=this.genericToString;
}
if($2){var $d=$2.prototype;
var $e=this.__createEmptyFunction();
$e.prototype=$d;
var $f=new $e;
$6.prototype=$f;
$f.name=$f.classname=$0;
$f.basename=$c;
$4.base=$6.superclass=$2;
$4.self=$6.constructor=$f.constructor=$6;
if($5){{};
$6.$$destructor=$5;
}}{qx.Clazz=$6;
qx.Proto=$f||null;
qx.Super=$2||null;
};
this.__registry[$0]=$6;
return $6;
},
__addEvents:function($0,
$1,
$2){var $3,
$3;
if($0.$$events){for(var $3 in $1){$0.$$events[$3]=$1[$3];
}}else{$0.$$events=$1;
}},
__addProperties:function($0,
$1,
$2){var $3;
if($2===undefined){$2=false;
}var $4=!!$0.$$propertiesAttached;
for(var $5 in $1){$3=$1[$5];
{};
$3.name=$5;
if(!$3.refine){if($0.$$properties===undefined){$0.$$properties={};
}$0.$$properties[$5]=$3;
}if($3.init!==undefined){$0.prototype[$[375]+$5]=$3.init;
}if($3.event!==undefined){var $6={};
$6[$3.event]=$[247];
this.__addEvents($0,
$6,
$2);
}if($3.inheritable){qx.core.Property.$$inheritable[$5]=true;
}if($4){qx.core.Property.attachMethods($0,
$5,
$3);
}if($3._fast){qx.core.LegacyProperty.addFastProperty($3,
$0.prototype);
}else if($3._cached){qx.core.LegacyProperty.addCachedProperty($3,
$0.prototype);
}else if($3._legacy){qx.core.LegacyProperty.addProperty($3,
$0.prototype);
}}},
__validateProperty:null,
__addMembers:function($0,
$1,
$2,
$3){var $4=$0.superclass.prototype;
var $5=$0.prototype;
var $6,
$7;
for(var $8=0,
$9=qx.lang.Object.getKeys($1),
$a=$9.length;$8<$a;$8++){$6=$9[$8];
$7=$1[$6];
{};
if($3!==false&&$7 instanceof Function){if($4[$6]){$7.base=$4[$6];
}$7.self=$0;
{};
}$5[$6]=$7;
}},
__addInterface:function($0,
$1){{};
var $2=qx.Interface.flatten([$1]);
if($0.$$implements){$0.$$implements.push($1);
$0.$$flatImplements.push.apply($0.$$flatImplements,
$2);
}else{$0.$$implements=[$1];
$0.$$flatImplements=$2;
}},
__addMixin:function($0,
$1,
$2){{};
var $3=qx.Mixin.flatten([$1]);
var $4;
for(var $5=0,
$6=$3.length;$5<$6;$5++){$4=$3[$5];
if($4.$$events){this.__addEvents($0,
$4.$$events,
$2);
}if($4.$$properties){this.__addProperties($0,
$4.$$properties,
$2);
}if($4.$$members){this.__addMembers($0,
$4.$$members,
$2,
false);
}}if($0.$$includes){$0.$$includes.push($1);
$0.$$flatIncludes.push.apply($0.$$flatIncludes,
$3);
}else{$0.$$includes=[$1];
$0.$$flatIncludes=$3;
}},
__createDefaultConstructor:function(){function $0(){arguments.callee.base.apply(this,
arguments);
}return $0;
},
__createEmptyFunction:function(){return function(){};
},
__wrapConstructor:function($0,
$1,
$2){var $3=[];
$3.push($[1932]);
{};
$3.push($[820]);
$3.push($[1836]);
$3.push($[1191]);
$3.push($[1074]);
$3.push($[1048]);
$3.push($[1078],
$1,
$[1285]);
$3.push($[1314]);
var $4=new Function($3.join($[0]));
var $5;
if($2===$[24]){$4.getInstance=this.getInstance;
}$4.$$original=$0;
$0.wrapper=$4;
return $4;
}},
defer:function($0){var $1;
}});




/* ID: qx.Mixin */
qx.Class.define($[863],
{statics:{define:function($0,
$1){if($1){if($1.include&&!($1.include instanceof Array)){$1.include=[$1.include];
}{};
var $2=$1.statics?$1.statics:{};
for(var $3 in $2){$2[$3].mixin=$2;
}if($1.construct){$2.$$constructor=$1.construct;
}
if($1.include){$2.$$includes=$1.include;
}
if($1.properties){$2.$$properties=$1.properties;
}
if($1.members){$2.$$members=$1.members;
}
for(var $3 in $2.$$members){$2.$$members[$3].mixin=$2;
}
if($1.events){$2.$$events=$1.events;
}
if($1.destruct){$2.$$destructor=$1.destruct;
}}else{var $2={};
}$2.$$type=$[1958];
$2.name=$0;
$2.toString=this.genericToString;
$2.basename=qx.Class.createNamespace($0,
$2);
this.__registry[$0]=$2;
return $2;
},
checkCompatibility:function($0){var $1=this.flatten($0);
var $2=$1.length;
if($2<2){return true;
}var $3={};
var $4={};
var $5={};
var $6;
for(var $7=0;$7<$2;$7++){$6=$1[$7];
for(var $8 in $6.events){if($5[$8]){throw new Error('Conflict between mixin "'+$6.name+'" and "'+$5[$8]+'" in member "'+$8+'"!');
}$5[$8]=$6.name;
}
for(var $8 in $6.properties){if($3[$8]){throw new Error('Conflict between mixin "'+$6.name+'" and "'+$3[$8]+'" in property "'+$8+'"!');
}$3[$8]=$6.name;
}
for(var $8 in $6.members){if($4[$8]){throw new Error('Conflict between mixin "'+$6.name+'" and "'+$4[$8]+'" in member "'+$8+'"!');
}$4[$8]=$6.name;
}}return true;
},
isCompatible:function($0,
$1){var $2=qx.Class.getMixins($1);
$2.push($0);
return qx.Mixin.checkCompatibility($2);
},
getByName:function($0){return this.__registry[$0];
},
isDefined:function($0){return this.getByName($0)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.__registry);
},
flatten:function($0){if(!$0){return [];
}var $1=$0.concat();
for(var $2=0,
$3=$0.length;$2<$3;$2++){if($0[$2].$$includes){$1.push.apply($1,
this.flatten($0[$2].$$includes));
}}return $1;
},
genericToString:function(){return $[937]+this.name+$[106];
},
__registry:{},
__allowedKeys:null,
__validateConfig:function(){}}});




/* ID: qx.Interface */
qx.Class.define($[664],
{statics:{define:function($0,
$1){if($1){if($1.extend&&!($1.extend instanceof Array)){$1.extend=[$1.extend];
}{};
var $2=$1.statics?$1.statics:{};
if($1.extend){$2.$$extends=$1.extend;
}
if($1.properties){$2.$$properties=$1.properties;
}
if($1.members){$2.$$members=$1.members;
}
if($1.events){$2.$$events=$1.events;
}}else{var $2={};
}$2.$$type=$[1109];
$2.name=$0;
$2.toString=this.genericToString;
$2.basename=qx.Class.createNamespace($0,
$2);
qx.Interface.__registry[$0]=$2;
return $2;
},
getByName:function($0){return this.__registry[$0];
},
isDefined:function($0){return this.getByName($0)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.__registry);
},
flatten:function($0){if(!$0){return [];
}var $1=$0.concat();
for(var $2=0,
$3=$0.length;$2<$3;$2++){if($0[$2].$$extends){$1.push.apply($1,
this.flatten($0[$2].$$extends));
}}return $1;
},
assert:function($0,
$1,
$2){var $3=$1.$$members;
if($3){var $4=$0.prototype;
for(var $5 in $3){if(typeof $3[$5]===$[51]){if(typeof $4[$5]!==$[51]){throw new Error('Implementation of method "'+$5+'" is missing in class "'+$0.classname+'" required by interface "'+$1.name+'"');
}if($2===true&&!qx.Class.hasInterface($0,
$1)){$4[$5]=this.__wrapInterfaceMember($1,
$4[$5],
$5,
$3[$5]);
}}else{if(typeof $4[$5]===undefined){if(typeof $4[$5]!==$[51]){throw new Error('Implementation of member "'+$5+'" is missing in class "'+$0.classname+'" required by interface "'+$1.name+'"');
}}}}}if($1.$$properties){for(var $5 in $1.$$properties){if(!qx.Class.hasProperty($0,
$5)){throw new Error('The property "'+$5+'" is not supported by Class "'+$0.classname+'"!');
}}}if($1.$$events){for(var $5 in $1.$$events){if(!qx.Class.supportsEvent($0,
$5)){throw new Error('The event "'+$5+'" is not supported by Class "'+$0.classname+'"!');
}}}var $6=$1.$$extends;
if($6){for(var $7=0,
$8=$6.length;$7<$8;$7++){this.assert($0,
$6[$7],
$2);
}}},
genericToString:function(){return $[1096]+this.name+$[106];
},
__registry:{},
__wrapInterfaceMember:function(){},
__allowedKeys:null,
__validateConfig:function(){}}});




/* ID: qx.locale.MTranslation */
qx.Mixin.define($[1565],
{members:{tr:function($0,
$1){var $2=qx.locale.Manager;
if($2){return $2.tr.apply($2,
arguments);
}throw new Error("To enable localization please include qx.locale.Manager into your build!");
},
trn:function($0,
$1,
$2,
$3){var $4=qx.locale.Manager;
if($4){return $4.trn.apply($4,
arguments);
}throw new Error("To enable localization please include qx.locale.Manager into your build!");
},
marktr:function($0){var $1=qx.locale.Manager;
if($1){return $1.marktr.apply($1,
arguments);
}throw new Error("To enable localization please include qx.locale.Manager into your build!");
}}});




/* ID: qx.log.MLogging */
qx.Mixin.define($[1794],
{members:{getLogger:function(){if(qx.log.Logger){return qx.log.Logger.getClassLogger(this.constructor);
}throw new Error("To enable logging please include qx.log.Logger into your build!");
},
debug:function($0,
$1){this.getLogger().debug($0,
this.toHashCode(),
$1);
},
info:function($0,
$1){this.getLogger().info($0,
this.toHashCode(),
$1);
},
warn:function($0,
$1){this.getLogger().warn($0,
this.toHashCode(),
$1);
},
error:function($0,
$1){this.getLogger().error($0,
this.toHashCode(),
$1);
},
printStackTrace:function(){this.getLogger().printStackTrace();
}}});




/* ID: qx.core.MUserData */
qx.Mixin.define($[1486],
{members:{setUserData:function($0,
$1){if(!this.__userData){this.__userData={};
}this.__userData[$0]=$1;
},
getUserData:function($0){if(!this.__userData){return null;
}return this.__userData[$0];
}},
destruct:function(){this._disposeFields($[1926]);
}});




/* ID: qx.core.LegacyProperty */
qx.Class.define($[1072],
{statics:{getSetterName:function($0){return qx.core.Property.$$method.set[$0];
},
getGetterName:function($0){return qx.core.Property.$$method.get[$0];
},
getResetterName:function($0){return qx.core.Property.$$method.reset[$0];
},
addFastProperty:function($0,
$1){var $2=$0.name;
var $3=qx.lang.String.toFirstUp($2);
var $4=$[1583]+$3;
var $5=$[124]+$3;
var $6=$[27]+$3;
var $7=$[351]+$3;
$1[$4]=typeof $0.defaultValue!==$[7]?$0.defaultValue:null;
if($0.noCompute){$1[$5]=function(){return this[$4];
};
}else{$1[$5]=function(){return this[$4]==null?this[$4]=this[$7]():this[$4];
};
}$1[$5].self=$1.constructor;
if($0.setOnlyOnce){$1[$6]=function($8){this[$4]=$8;
this[$6]=null;
return $8;
};
}else{$1[$6]=function($8){return this[$4]=$8;
};
}$1[$6].self=$1.constructor;
if(!$0.noCompute){$1[$7]=function(){return null;
};
$1[$7].self=$1.constructor;
}},
addCachedProperty:function($0,
$1){var $2=$0.name;
var $3=qx.lang.String.toFirstUp($2);
var $4=$[1194]+$3;
var $5=$[351]+$3;
var $6=$[1556]+$3;
if(typeof $0.defaultValue!==$[7]){$1[$4]=$0.defaultValue;
}$1[$[124]+$3]=function(){if(this[$4]==null){this[$4]=this[$5]();
}return this[$4];
};
$1[$[432]+$3]=function(){if(this[$4]!=null){this[$4]=null;
if($0.addToQueueRuntime){this.addToQueueRuntime($0.name);
}}};
$1[$[498]+$3]=function(){var $7=this[$4];
var $8=this[$5]();
if($8!=$7){this[$4]=$8;
this[$6]($8,
$7);
return true;
}return false;
};
$1[$6]=function($8,
$7){};
$1[$5]=function(){return null;
};
$1[$[124]+$3].self=$1.constructor;
$1[$[432]+$3].self=$1.constructor;
$1[$[498]+$3].self=$1.constructor;
},
addProperty:function($0,
$1){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1263]);
if(typeof $0!==$[38]){throw new Error("AddProperty: Param should be an object!");
}
if(typeof $0.name!==$[8]){throw new Error("AddProperty: Malformed input parameters: name needed!");
}if($0.dispose===undefined&&($0.type==$[51]||$0.type==$[38])){$0.dispose=true;
}$0.method=qx.lang.String.toFirstUp($0.name);
$0.implMethod=$0.impl?qx.lang.String.toFirstUp($0.impl):$0.method;
if($0.defaultValue==undefined){$0.defaultValue=null;
}$0.allowNull=$0.allowNull!==false;
$0.allowMultipleArguments=$0.allowMultipleArguments===true;
if(typeof $0.type===$[8]){$0.hasType=true;
}else if(typeof $0.type!==$[7]){throw new Error("AddProperty: Invalid type definition for property "+$0.name+": "+$0.type);
}else{$0.hasType=false;
}
if(typeof $0.instance===$[8]){$0.hasInstance=true;
}else if(typeof $0.instance!==$[7]){throw new Error("AddProperty: Invalid instance definition for property "+$0.name+": "+$0.instance);
}else{$0.hasInstance=false;
}
if(typeof $0.classname===$[8]){$0.hasClassName=true;
}else if(typeof $0.classname!==$[7]){throw new Error("AddProperty: Invalid classname definition for property "+$0.name+": "+$0.classname);
}else{$0.hasClassName=false;
}$0.hasConvert=$0.convert!=null;
$0.hasPossibleValues=$0.possibleValues!=null;
$0.addToQueue=$0.addToQueue||false;
$0.addToQueueRuntime=$0.addToQueueRuntime||false;
$0.up=$0.name.toUpperCase();
var $2=qx.core.Property.$$store.user[$0.name]=$[585]+$0.name;
var $3=$[134]+$0.method;
var $4=$[1543]+$0.implMethod;
var $5=$[873]+$0.implMethod;
var $6=qx.core.Property.$$method;
if(!$6.set[$0.name]){$6.set[$0.name]=$[27]+$0.method;
$6.get[$0.name]=$[124]+$0.method;
$6.reset[$0.name]=$[114]+$0.method;
}$1[$2]=$0.defaultValue;
$1[$[124]+$0.method]=function(){return this[$2];
};
$1[$[882]+$0.method]=function($7){return this[$2]=$7;
};
$1[$[114]+$0.method]=function(){return this[$[27]+$0.method]($0.defaultValue);
};
if($0.type===$[62]){$1[$[471]+$0.method]=function($7){return this[$[27]+$0.method](!this[$2]);
};
}
if($0.allowMultipleArguments||$0.hasConvert||$0.hasInstance||$0.hasClassName||$0.hasPossibleValues||$0.hasUnitDetection||$0.addToQueue||$0.addToQueueRuntime||$0.addToStateQueue){$1[$[27]+$0.method]=function($7){if($0.allowMultipleArguments&&arguments.length>1){$7=qx.lang.Array.fromArguments(arguments);
}if($0.hasConvert){try{$7=$0.convert.call(this,
$7,
$0);
}catch(ex){throw new Error("Attention! Could not convert new value for "+$0.name+": "+$7+": "+ex);
}}var $8=this[$2];
if($7===$8){return $7;
}
if(!($0.allowNull&&$7==null)){if($0.hasType&&typeof $7!==$0.type){throw new Error("Attention! The value \""+$7+"\" is an invalid value for the property \""+$0.name+"\" which must be typeof \""+$0.type+"\" but is typeof \""+typeof $7+"\"!");
}
if(qx.Class.getByName($0.instance)){if($0.hasInstance&&!($7 instanceof qx.Class.getByName($0.instance))){throw new Error("Attention! The value \""+$7+"\" is an invalid value for the property \""+$0.name+"\" which must be an instance of \""+$0.instance+"\"!");
}}else{if($0.hasInstance&&!($7 instanceof qx.OO.classes[$0.instance])){throw new Error("Attention! The value \""+$7+"\" is an invalid value for the property \""+$0.name+"\" which must be an instance of \""+$0.instance+"\"!");
}}
if($0.hasClassName&&$7.classname!=$0.classname){throw new Error("Attention! The value \""+$7+"\" is an invalid value for the property \""+$0.name+"\" which must be an object with the classname \""+$0.classname+"\"!");
}
if($0.hasPossibleValues&&$7!=null&&!qx.lang.Array.contains($0.possibleValues,
$7)){throw new Error("Failed to save value for "+$0.name+". '"+$7+"' is not a possible value!");
}}if(this[$5]){try{$7=this[$5]($7,
$0);
if($7===$8){return $7;
}}catch(ex){return this.error("Failed to check property "+$0.name,
ex);
}}this[$2]=$7;
if(this[$4]){try{this[$4]($7,
$8,
$0);
}catch(ex){return this.error("Modification of property \""+$0.name+"\" failed with exception",
ex);
}}if($0.addToQueue){this.addToQueue($0.name);
}
if($0.addToQueueRuntime){this.addToQueueRuntime($0.name);
}if($0.addToStateQueue){this.addToStateQueue();
}if(this.hasEventListeners&&this.hasEventListeners($3)){try{this.createDispatchDataEvent($3,
$7);
}catch(ex){throw new Error("Property "+$0.name+" modified: Failed to dispatch change event: "+ex);
}}return $7;
};
}else{$1[$[27]+$0.method]=function($7){var $8=this[$2];
if($7===$8){return $7;
}
if(!($0.allowNull&&$7==null)){if($0.hasType&&typeof $7!==$0.type){throw new Error("Attention! The value \""+$7+"\" is an invalid value for the property \""+$0.name+"\" which must be typeof \""+$0.type+"\" but is typeof \""+typeof $7+"\"!");
}}if(this[$5]){try{$7=this[$5]($7,
$0);
if($7===$8){return $7;
}}catch(ex){return this.error("Failed to check property "+$0.name,
ex);
}}this[$2]=$7;
if(this[$4]){try{this[$4]($7,
$8,
$0);
}catch(ex){var $9=new String($7).substring(0,
50);
this.error("Setting property \""+$0.name+"\" to \""+$9+"\" failed with exception",
ex);
}}if(this.hasEventListeners&&this.hasEventListeners($3)){var $a=new qx.event.type.DataEvent($3,
$7,
$8,
false);
$a.setTarget(this);
try{this.dispatchEvent($a,
true);
}catch(ex){throw new Error("Property "+$0.name+" modified: Failed to dispatch change event: "+ex);
}}return $7;
};
}$1[$[27]+$0.method].self=$1.constructor;
if(typeof $0.getAlias===$[8]){$1[$0.getAlias]=$1[$[124]+$0.method];
}if(typeof $0.setAlias===$[8]){$1[$0.setAlias]=$1[$[27]+$0.method];
}}}});




/* ID: qx.core.Property */
qx.Class.define($[1872],
{statics:{__checks:{"Boolean":$[1956],
"String":$[1321],
"NonEmptyString":$[1333],
"Number":$[317],
"Integer":$[916],
"Float":$[317],
"Double":$[317],
"Error":$[1869],
"RegExp":$[1487],
"Object":$[1653],
"Array":$[1655],
"Map":$[1771],
"Function":$[1612],
"Date":$[977],
"Node":$[1302],
"Element":$[1769],
"Document":$[1778],
"Window":$[667],
"Event":$[1767],
"Class":$[1025],
"Mixin":$[834],
"Interface":$[862],
"Theme":$[1419],
"Color":$[1032],
"Border":$[1357],
"Font":$[922],
"Label":$[1240]},
__dispose:{"Object":true,
"Array":true,
"Map":true,
"Function":true,
"Date":true,
"Node":true,
"Element":true,
"Document":true,
"Window":true,
"Event":true,
"Class":true,
"Mixin":true,
"Interface":true,
"Theme":true,
"Border":true,
"Font":true},
$$inherit:$[127],
$$idcounter:0,
$$store:{user:{},
theme:{},
inherit:{},
init:{},
useinit:{}},
$$method:{get:{},
set:{},
reset:{},
init:{},
refresh:{},
style:{},
unstyle:{}},
$$allowedKeys:{name:$[8],
dispose:$[62],
inheritable:$[62],
nullable:$[62],
themeable:$[62],
refine:$[62],
init:null,
apply:$[8],
event:$[8],
check:null,
transform:$[8]},
$$allowedGroupKeys:{name:$[8],
group:$[38],
mode:$[8],
themeable:$[62]},
$$inheritable:{},
refresh:function($0){var $1=$0.getParent();
if($1){var $2=$0.constructor;
var $3=this.$$store.inherit;
var $4=this.$$method.refresh;
var $5;
{};
while($2){$5=$2.$$properties;
if($5){for(var $6 in this.$$inheritable){if($5[$6]){{};
$0[$4[$6]]($1[$3[$6]]);
}}}$2=$2.superclass;
}}},
attach:function($0){var $1=$0.$$properties;
if($1){for(var $2 in $1){this.attachMethods($0,
$2,
$1[$2]);
}}$0.$$propertiesAttached=true;
},
attachMethods:function($0,
$1,
$2){if($2._legacy||$2._fast||$2._cached){return;
}var $3,
$4;
if($1.charAt(0)===$[84]){if($1.charAt(1)===$[84]){$3=$[1033];
$4=qx.lang.String.toFirstUp($1.substring(2));
}else{$3=$[84];
$4=qx.lang.String.toFirstUp($1.substring(1));
}}else{$3=$[0];
$4=qx.lang.String.toFirstUp($1);
}$2.group?this.__attachGroupMethods($0,
$2,
$3,
$4):this.__attachPropertyMethods($0,
$2,
$3,
$4);
},
__attachGroupMethods:function($0,
$1,
$2,
$3){var $4=$0.prototype;
var $5=$1.name;
var $6=$1.themeable===true;
{};
var $7=[];
var $8=[];
if($6){var $9=[];
var $a=[];
}var $b=$[829];
$7.push($b);
if($6){$9.push($b);
}
if($1.mode==$[111]){var $c=$[1001];
$7.push($c);
if($6){$9.push($c);
}}
for(var $d=0,
$e=$1.group,
$f=$e.length;$d<$f;$d++){{};
$7.push($[233],
this.$$method.set[$e[$d]],
$[508],
$d,
$[442]);
$8.push($[233],
this.$$method.reset[$e[$d]],
$[620]);
if($6){$9.push($[233],
this.$$method.style[$e[$d]],
$[508],
$d,
$[442]);
$a.push($[233],
this.$$method.unstyle[$e[$d]],
$[620]);
}}this.$$method.set[$5]=$2+$[27]+$3;
$4[this.$$method.set[$5]]=new Function($7.join($[0]));
this.$$method.reset[$5]=$2+$[114]+$3;
$4[this.$$method.reset[$5]]=new Function($8.join($[0]));
if($6){this.$$method.style[$5]=$2+$[48]+$3;
$4[this.$$method.style[$5]]=new Function($9.join($[0]));
this.$$method.unstyle[$5]=$2+$[131]+$3;
$4[this.$$method.unstyle[$5]]=new Function($a.join($[0]));
}},
__attachPropertyMethods:function($0,
$1,
$2,
$3){var $4=$0.prototype;
var $5=$1.name;
{};
if($1.dispose===undefined&&typeof $1.check===$[8]){$1.dispose=this.__dispose[$1.check]||qx.Class.isDefined($1.check);
}var $6=this.$$method;
var $7=this.$$store;
$7.user[$5]=$[585]+$5;
$7.theme[$5]=$[1299]+$5;
$7.init[$5]=$[375]+$5;
$7.inherit[$5]=$[715]+$5;
$7.useinit[$5]=$[1105]+$5;
$6.get[$5]=$2+$[124]+$3;
$4[$6.get[$5]]=function(){return qx.core.Property.executeOptimizedGetter(this,
$0,
$5,
$[124]);
};
$6.set[$5]=$2+$[27]+$3;
$4[$6.set[$5]]=function($8){return qx.core.Property.executeOptimizedSetter(this,
$0,
$5,
$[27],
arguments);
};
$6.reset[$5]=$2+$[114]+$3;
$4[$6.reset[$5]]=function(){return qx.core.Property.executeOptimizedSetter(this,
$0,
$5,
$[114]);
};
if($1.inheritable||$1.apply||$1.event){$6.init[$5]=$2+$[92]+$3;
$4[$6.init[$5]]=function($8){return qx.core.Property.executeOptimizedSetter(this,
$0,
$5,
$[92],
arguments);
};
}
if($1.inheritable){$6.refresh[$5]=$2+$[159]+$3;
$4[$6.refresh[$5]]=function($8){return qx.core.Property.executeOptimizedSetter(this,
$0,
$5,
$[159],
arguments);
};
}
if($1.themeable){$6.style[$5]=$2+$[48]+$3;
$4[$6.style[$5]]=function($8){return qx.core.Property.executeOptimizedSetter(this,
$0,
$5,
$[48],
arguments);
};
$6.unstyle[$5]=$2+$[131]+$3;
$4[$6.unstyle[$5]]=function(){return qx.core.Property.executeOptimizedSetter(this,
$0,
$5,
$[131]);
};
}
if($1.check===$[2]){$4[$2+$[471]+$3]=new Function($[591]+$6.set[$5]+$[1088]+$6.get[$5]+$[1495]);
$4[$2+$[1776]+$3]=new Function($[591]+$6.get[$5]+$[1737]);
}},
__errors:{0:$[1603],
1:$[1403],
2:$[1107],
3:$[787],
4:$[1591],
5:$[1116]},
error:function($0,
$1,
$2,
$3,
$4){var $5=$0.constructor.classname;
var $6=$[1880]+$2+$[1629]+$5+$[1459]+this.$$method[$3][$2]+$[1600]+$4+$[1122];
$0.printStackTrace();
throw new Error($6+(this.__errors[$1]||"Unknown reason: "+$1));
},
__unwrapFunctionFromCode:function($0,
$1,
$2,
$3,
$4,
$5){var $6=this.$$method[$3][$2];
{$1[$6]=new Function($[379],
$4.join($[0]));
};
{};
if($5===undefined){return $0[$6]();
}else{return $0[$6]($5[0]);
}},
executeOptimizedGetter:function($0,
$1,
$2,
$3){var $4=$1.$$properties[$2];
var $5=$1.prototype;
var $6=[];
if($4.inheritable){$6.push($[105],
this.$$store.inherit[$2],
$[144]);
$6.push($[197],
this.$$store.inherit[$2],
$[15]);
$6.push($[446]);
}$6.push($[105],
this.$$store.user[$2],
$[144]);
$6.push($[197],
this.$$store.user[$2],
$[15]);
if($4.themeable){$6.push($[198],
this.$$store.theme[$2],
$[144]);
$6.push($[197],
this.$$store.theme[$2],
$[15]);
}
if($4.deferredInit&&$4.init===undefined){$6.push($[198],
this.$$store.init[$2],
$[144]);
$6.push($[197],
this.$$store.init[$2],
$[15]);
}$6.push($[446]);
if($4.init!==undefined){$6.push($[197],
this.$$store.init[$2],
$[15]);
}else if($4.inheritable||$4.nullable){$6.push($[1567]);
}else{$6.push($[1351],
$2,
$[1516],
$1.classname,
$[748]);
}return this.__unwrapFunctionFromCode($0,
$5,
$2,
$3,
$6);
},
executeOptimizedSetter:function($0,
$1,
$2,
$3,
$4){var $5=$1.$$properties[$2];
var $6=$1.prototype;
var $7=$4?$4[0]:undefined;
var $8=[];
var $9=$3===$[27]||$3===$[48]||($3===$[92]&&$5.init===undefined);
var $a=$3===$[114]||$3===$[131];
var $b=$5.apply||$5.event||$5.inheritable;
if($3===$[48]||$3===$[131]){var $c=this.$$store.theme[$2];
}else if($3===$[92]){var $c=this.$$store.init[$2];
}else{var $c=this.$$store.user[$2];
}{if(!$5.nullable||$5.check||$5.inheritable){$8.push($[1182]);
}if($3===$[27]){$8.push($[1466]+$2+$[297]+$3+$[335]);
}};
if($9){if($5.transform){$8.push($[1470],
$5.transform,
$[995]);
}}if($b){if($9){$8.push($[105],
$c,
$[1454]);
}else if($a){$8.push($[105],
$c,
$[1805]);
}}if($5.inheritable){$8.push($[685]);
}if($9&&(false||$3===$[27])){if(!$5.nullable){$8.push($[1406]+$2+$[297]+$3+$[335]);
}if($5.check!==undefined){if($5.nullable){$8.push($[1328]);
}if($5.inheritable){$8.push($[1083]);
}$8.push($[1867]);
if(this.__checks[$5.check]!==undefined){$8.push($[574],
this.__checks[$5.check],
$[254]);
}else if(qx.Class.isDefined($5.check)){$8.push($[921],
$5.check,
$[254]);
}else if(qx.Interface.isDefined($5.check)){$8.push($[1432],
$5.check,
$[1832]);
}else if(typeof $5.check===$[51]){$8.push($[812],
$1.classname,
$[536],
$2);
$8.push($[1974]);
}else if(typeof $5.check===$[8]){$8.push($[574],
$5.check,
$[254]);
}else if($5.check instanceof Array){$5.checkMap=qx.lang.Object.fromArray($5.check);
$8.push($1.classname,
$[536],
$2);
$8.push($[1973]);
}else{throw new Error("Could not add check to property "+$2+" of class "+$1.classname);
}$8.push($[1195]+$2+$[297]+$3+$[335]);
}}
if(!$b){if($3===$[27]){$8.push($[58],
this.$$store.user[$2],
$[53]);
}else if($3===$[114]){$8.push($[105],
this.$$store.user[$2],
$[144]);
$8.push($[130],
this.$$store.user[$2],
$[15]);
}else if($3===$[48]){$8.push($[58],
this.$$store.theme[$2],
$[53]);
}else if($3===$[131]){$8.push($[105],
this.$$store.theme[$2],
$[144]);
$8.push($[130],
this.$$store.theme[$2],
$[15]);
}else if($3===$[92]&&$9){$8.push($[58],
this.$$store.init[$2],
$[53]);
}}else{if($5.inheritable){$8.push($[1684],
this.$$store.inherit[$2],
$[15]);
}else{$8.push($[1938]);
}$8.push($[105],
this.$$store.user[$2],
$[221]);
if($3===$[27]){if(!$5.inheritable){$8.push($[250],
this.$$store.user[$2],
$[15]);
}$8.push($[37],
this.$$store.user[$2],
$[53]);
}else if($3===$[114]){if(!$5.inheritable){$8.push($[250],
this.$$store.user[$2],
$[15]);
}$8.push($[130],
this.$$store.user[$2],
$[15]);
$8.push($[105],
this.$$store.theme[$2],
$[144]);
$8.push($[37],
this.$$store.theme[$2],
$[15]);
$8.push($[198],
this.$$store.init[$2],
$[221]);
$8.push($[37],
this.$$store.init[$2],
$[15]);
$8.push($[58],
this.$$store.useinit[$2],
$[244]);
$8.push($[109]);
}else{if($5.inheritable){$8.push($[37],
this.$$store.user[$2],
$[15]);
}else{$8.push($[1796],
this.$$store.user[$2],
$[15]);
}if($3===$[48]){$8.push($[58],
this.$$store.theme[$2],
$[53]);
}else if($3===$[131]){$8.push($[130],
this.$$store.theme[$2],
$[15]);
}else if($3===$[92]&&$9){$8.push($[58],
this.$$store.init[$2],
$[53]);
}}$8.push($[109]);
if($5.themeable){$8.push($[198],
this.$$store.theme[$2],
$[221]);
if(!$5.inheritable){$8.push($[250],
this.$$store.theme[$2],
$[15]);
}
if($3===$[27]){$8.push($[37],
this.$$store.user[$2],
$[53]);
}else if($3===$[48]){$8.push($[37],
this.$$store.theme[$2],
$[53]);
}else if($3===$[131]){$8.push($[130],
this.$$store.theme[$2],
$[15]);
$8.push($[105],
this.$$store.init[$2],
$[221]);
$8.push($[37],
this.$$store.init[$2],
$[15]);
$8.push($[58],
this.$$store.useinit[$2],
$[244]);
$8.push($[109]);
}else if($3===$[92]){if($9){$8.push($[58],
this.$$store.init[$2],
$[53]);
}$8.push($[37],
this.$$store.theme[$2],
$[15]);
}else if($3===$[159]){$8.push($[37],
this.$$store.theme[$2],
$[15]);
}$8.push($[109]);
}$8.push($[198],
this.$$store.useinit[$2],
$[1143]);
if(!$5.inheritable){$8.push($[250],
this.$$store.init[$2],
$[15]);
}
if($3===$[92]){if($9){$8.push($[37],
this.$$store.init[$2],
$[53]);
}else{$8.push($[37],
this.$$store.init[$2],
$[15]);
}}else if($3===$[27]||$3===$[48]||$3===$[159]){$8.push($[130],
this.$$store.useinit[$2],
$[15]);
if($3===$[27]){$8.push($[37],
this.$$store.user[$2],
$[53]);
}else if($3===$[48]){$8.push($[37],
this.$$store.theme[$2],
$[53]);
}else if($3===$[159]){$8.push($[37],
this.$$store.init[$2],
$[15]);
}}$8.push($[109]);
if($3===$[27]||$3===$[48]||$3===$[92]){$8.push($[1288]);
if($3===$[27]){$8.push($[37],
this.$$store.user[$2],
$[53]);
}else if($3===$[48]){$8.push($[37],
this.$$store.theme[$2],
$[53]);
}else if($3===$[92]){if($9){$8.push($[37],
this.$$store.init[$2],
$[53]);
}else{$8.push($[37],
this.$$store.init[$2],
$[15]);
}$8.push($[58],
this.$$store.useinit[$2],
$[244]);
}$8.push($[109]);
}}
if($5.inheritable){$8.push($[1317]);
if($3===$[159]){$8.push($[783]);
}else{$8.push($[1741],
this.$$store.inherit[$2],
$[15]);
}$8.push($[987]);
$8.push($[58],
this.$$store.init[$2],
$[970]);
$8.push($[58],
this.$$store.init[$2],
$[1228]);
$8.push($[37],
this.$$store.init[$2],
$[15]);
$8.push($[58],
this.$$store.useinit[$2],
$[244]);
$8.push($[1940]);
$8.push($[130],
this.$$store.useinit[$2],
$[962]);
$8.push($[109]);
$8.push($[438]);
$8.push($[942]);
$8.push($[1307],
this.$$store.inherit[$2],
$[15]);
$8.push($[109]);
$8.push($[1898]);
$8.push($[130],
this.$$store.inherit[$2],
$[15]);
$8.push($[1906],
this.$$store.inherit[$2],
$[843]);
$8.push($[1070]);
$8.push($[540]);
$8.push($[624]);
}else if($b){if($3!==$[27]&&$3!==$[48]){$8.push($[540]);
}$8.push($[438]);
$8.push($[624]);
}if($b){if($5.apply){$8.push($[58],
$5.apply,
$[1849]);
}if($5.event){$8.push($[2017],
$5.event,
$[1648]);
}if($5.inheritable&&$6.getChildren){$8.push($[1034]);
$8.push($[1085],
this.$$method.refresh[$2],
$[673],
this.$$method.refresh[$2],
$[936]);
$8.push($[109]);
}}if($9){$8.push($[789]);
}return this.__unwrapFunctionFromCode($0,
$6,
$2,
$3,
$8,
$4);
}},
settings:{"qx.propertyDebugLevel":0}});




/* ID: qx.lang.String */
qx.Class.define($[1968],
{statics:{toCamelCase:function($0){return $0.replace(/\-([a-z])/g,
function($1,
$2){return $2.toUpperCase();
});
},
trimLeft:function($0){return $0.replace(/^\s+/,
$[0]);
},
trimRight:function($0){return $0.replace(/\s+$/,
$[0]);
},
trim:function($0){return $0.replace(/^\s+|\s+$/g,
$[0]);
},
startsWith:function($0,
$1){return !$0.indexOf($1);
},
startsWithAlternate:function($0,
$1){return $0.substring(0,
$1.length)===$1;
},
endsWith:function($0,
$1){return $0.lastIndexOf($1)===$0.length-$1.length;
},
endsWithAlternate:function($0,
$1){return $0.substring($0.length-$1.length,
$0.length)===$1;
},
pad:function($0,
$1,
$2,
$3){if(typeof $2===$[7]){$2=$[56];
}var $4=$[0];
for(var $5=$0.length;$5<$1;$5++){$4+=$2;
}
if($3==true){return $0+$4;
}else{return $4+$0;
}},
toFirstUp:function($0){return $0.charAt(0).toUpperCase()+$0.substr(1);
},
toFirstLower:function($0){return $0.charAt(0).toLowerCase()+$0.substr(1);
},
addListItem:function($0,
$1,
$2){if($0==$1||$0==$[0]){return $1;
}
if($2==null){$2=$[17];
}var $3=$0.split($2);
if($3.indexOf($1)==-1){$3.push($1);
return $3.join($2);
}else{return $0;
}},
removeListItem:function($0,
$1,
$2){if($0==$1||$0==$[0]){return $[0];
}else{if($2==null){$2=$[17];
}var $3=$0.split($2);
var $4=$3.indexOf($1);
if($4===-1){return $0;
}
do{$3.splice($4,
1);
}while(($4=$3.indexOf($1))!=-1);
return $3.join($2);
}},
contains:function($0,
$1){return $0.indexOf($1)!=-1;
},
format:function($0,
$1){var $2=$0;
for(var $3=0;$3<$1.length;$3++){$2=$2.replace(new RegExp($[230]+($3+1),
$[315]),
$1[$3]);
}return $2;
},
escapeRegexpChars:function($0){return $0.replace(/([\\\.\(\)\[\]\{\}\^\$\?\+\*])/g,
$[1058]);
},
toArray:function($0){return $0.split(/\B|\b/g);
}}});




/* ID: qx.core.Object */
qx.Class.define($[1674],
{extend:Object,
include:[qx.locale.MTranslation,
qx.log.MLogging,
qx.core.MUserData],
construct:function(){this._hashCode=qx.core.Object.__availableHashCode++;
if(this._autoDispose){this.__dbKey=qx.core.Object.__db.length;
qx.core.Object.__db.push(this);
}},
statics:{__availableHashCode:0,
__db:[],
__disposeAll:false,
$$type:$[97],
toHashCode:function($0){if($0._hashCode!=null){return $0._hashCode;
}return $0._hashCode=this.__availableHashCode++;
},
getDb:function(){return this.__db;
},
dispose:function(){if(this.__disposed){return;
}this.__disposed=true;
var $0;
var $1,
$2=this.__db;
for(var $3=$2.length-1;$3>=0;$3--){$1=$2[$3];
if($1&&$1.__disposed===false){try{$1.dispose();
}catch(ex){try{console.warn("Could not dispose: "+$1+": "+ex);
}catch(exc){throw new Error("Could not dispose: "+$1+": "+ex);
}}}}var $4,
$3,
$5,
$6,
$7,
$8;
},
inGlobalDispose:function(){return this.__disposed;
}},
members:{_autoDispose:true,
toHashCode:function(){return this._hashCode;
},
toString:function(){if(this.classname){return $[1172]+this.classname+$[106];
}return $[860];
},
base:function($0,
$1){if(arguments.length===1){return $0.callee.base.call(this);
}else{return $0.callee.base.apply(this,
Array.prototype.slice.call(arguments,
1));
}},
self:function($0){return $0.callee.self;
},
getDbKey:function(){return this.__dbKey;
},
set:function($0,
$1){var $2=qx.core.Property.$$method.set;
if(typeof $0===$[8]){{};
return this[$2[$0]]($1);
}else{for(var $3 in $0){{};
this[$2[$3]]($0[$3]);
}return this;
}},
get:function($0){var $1=qx.core.Property.$$method.get;
{};
return this[$1[$0]]();
},
reset:function($0){var $1=qx.core.Property.$$method.reset;
{};
this[$1[$0]]();
},
__disposed:false,
getDisposed:function(){return this.__disposed;
},
isDisposed:function(){return this.__disposed;
},
dispose:function(){if(this.__disposed){return;
}this.__disposed=true;
{};
var $0=this.constructor;
var $1;
while($0.superclass){if($0.$$destructor){$0.$$destructor.call(this);
}if($0.$$includes){$1=$0.$$flatIncludes;
for(var $2=0,
$3=$1.length;$2<$3;$2++){if($1[$2].$$destructor){$1[$2].$$destructor.call(this);
}}}$0=$0.superclass;
}var $4;
},
_disposeFields:function($0){var $1;
for(var $2=0,
$3=arguments.length;$2<$3;$2++){var $1=arguments[$2];
if(this[$1]==null){continue;
}
if(!this.hasOwnProperty($1)){{};
continue;
}this[$1]=null;
}},
_disposeObjects:function($0){var $1;
for(var $2=0,
$3=arguments.length;$2<$3;$2++){var $1=arguments[$2];
if(this[$1]==null){continue;
}
if(!this.hasOwnProperty($1)){{};
continue;
}
if(!this[$1].dispose){throw new Error(this.classname+" has no own object "+$1);
}this[$1].dispose();
this[$1]=null;
}},
_disposeObjectDeep:function($0,
$1){var $0;
if(this[$0]==null){return;
}
if(!this.hasOwnProperty($0)){{};
return;
}{};
this.__disposeObjectsDeepRecurser(this[$0],
$1||0);
this[$0]=null;
},
__disposeObjectsDeepRecurser:function($0,
$1){if($0 instanceof qx.core.Object){{};
$0.dispose();
}else if($0 instanceof Array){for(var $2=0,
$3=$0.length;$2<$3;$2++){var $4=$0[$2];
if($4==null){continue;
}
if(typeof $4==$[38]){if($1>0){{};
this.__disposeObjectsDeepRecurser($4,
$1-1);
}{};
$0[$2]=null;
}else if(typeof $4==$[51]){{};
$0[$2]=null;
}}}else if($0 instanceof Object){for(var $5 in $0){if($0[$5]==null||!$0.hasOwnProperty($5)){continue;
}var $4=$0[$5];
if(typeof $4==$[38]){if($1>0){{};
this.__disposeObjectsDeepRecurser($4,
$1-1);
}{};
$0[$5]=null;
}else if(typeof $4==$[51]){{};
$0[$5]=null;
}}}}},
settings:{"qx.disposerDebugLevel":0},
destruct:function(){var $0=this.constructor;
var $1;
var $2=qx.core.Property.$$store;
var $3=$2.user;
var $4=$2.theme;
var $5=$2.inherit;
var $6=$2.useinit;
var $7=$2.init;
while($0){$1=$0.$$properties;
if($1){for(var $8 in $1){if($1[$8].dispose){this[$3[$8]]=this[$4[$8]]=this[$5[$8]]=this[$6[$8]]=this[$7[$8]]=undefined;
}}}$0=$0.superclass;
}if(this.__dbKey!=null){if(qx.core.Object.__disposeAll){qx.core.Object.__db[this.__dbKey]=null;
}else{delete qx.core.Object.__db[this.__dbKey];
}}}});




/* ID: qx.core.Target */
qx.Class.define($[1499],
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
},
members:{addEventListener:function($0,
$1,
$2){if(this.getDisposed()){return;
}{};
if(this.__listeners===undefined){this.__listeners={};
}
if(this.__listeners[$0]===undefined){this.__listeners[$0]={};
}var $3=$[554]+qx.core.Object.toHashCode($1)+($2?$[162]+qx.core.Object.toHashCode($2):$[0]);
this.__listeners[$0][$3]={handler:$1,
object:$2};
},
removeEventListener:function($0,
$1,
$2){if(this.getDisposed()){return;
}var $3=this.__listeners;
if(!$3||$3[$0]===undefined){return;
}
if(typeof $1!==$[51]){throw new Error("qx.core.Target: removeEventListener("+$0+"): '"+$1+"' is not a function!");
}var $4=$[554]+qx.core.Object.toHashCode($1)+($2?$[162]+qx.core.Object.toHashCode($2):$[0]);
delete this.__listeners[$0][$4];
},
hasEventListeners:function($0){return this.__listeners&&this.__listeners[$0]!==undefined&&!qx.lang.Object.isEmpty(this.__listeners[$0]);
},
createDispatchEvent:function($0){if(this.hasEventListeners($0)){this.dispatchEvent(new qx.event.type.Event($0),
true);
}},
createDispatchDataEvent:function($0,
$1){if(this.hasEventListeners($0)){this.dispatchEvent(new qx.event.type.DataEvent($0,
$1),
true);
}},
createDispatchChangeEvent:function($0,
$1,
$2){if(this.hasEventListeners($0)){this.dispatchEvent(new qx.event.type.ChangeEvent($0,
$1,
$2),
true);
}},
dispatchEvent:function($0,
$1){if(this.getDisposed()){return;
}
if($0.getTarget()==null){$0.setTarget(this);
}
if($0.getCurrentTarget()==null){$0.setCurrentTarget(this);
}this._dispatchEvent($0,
$1);
var $2=$0._defaultPrevented;
$1&&$0.dispose();
return !$2;
},
_dispatchEvent:function($0){var $1=this.__listeners;
if($1){$0.setCurrentTarget(this);
var $2=$1[$0.getType()];
if($2){var $3,
$4;
for(var $5 in $2){$3=$2[$5].handler;
$4=$2[$5].object||this;
$3.call($4,
$0);
}}}if($0.getBubbles()&&!$0.getPropagationStopped()&&typeof (this.getParent)==$[51]){var $6=this.getParent();
if($6&&!$6.getDisposed()&&$6.getEnabled()){$6._dispatchEvent($0);
}}}},
destruct:function(){this._disposeObjectDeep($[1505],
2);
}});




/* ID: qx.event.type.Event */
qx.Class.define($[4],
{extend:qx.core.Object,
construct:function($0){arguments.callee.base.call(this);
this.setType($0);
},
properties:{type:{_fast:true,
setOnlyOnce:true},
originalTarget:{_fast:true,
setOnlyOnce:true},
target:{_fast:true,
setOnlyOnce:true},
relatedTarget:{_fast:true,
setOnlyOnce:true},
currentTarget:{_fast:true},
bubbles:{_fast:true,
defaultValue:false,
noCompute:true},
propagationStopped:{_fast:true,
defaultValue:true,
noCompute:true},
defaultPrevented:{_fast:true,
defaultValue:false,
noCompute:true}},
members:{_autoDispose:false,
preventDefault:function(){this.setDefaultPrevented(true);
},
stopPropagation:function(){this.setPropagationStopped(true);
}},
destruct:function(){this._disposeFields($[649],
$[1726],
$[856],
$[1622]);
}});




/* ID: qx.event.type.DataEvent */
qx.Class.define($[42],
{extend:qx.event.type.Event,
construct:function($0,
$1){arguments.callee.base.call(this,
$0);
this.setData($1);
},
properties:{propagationStopped:{_fast:true,
defaultValue:false},
data:{_fast:true}},
destruct:function(){this._disposeFields($[476]);
}});




/* ID: qx.event.type.ChangeEvent */
qx.Class.define($[247],
{extend:qx.event.type.Event,
construct:function($0,
$1,
$2){arguments.callee.base.call(this,
$0);
this.setValue($1);
this.setOldValue($2);
},
properties:{value:{_fast:true},
oldValue:{_fast:true}},
members:{getData:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[704]);
return this.getValue();
}},
destruct:function(){this._disposeFields($[1714],
$[1491]);
}});




/* ID: qx.log.Filter */
qx.Class.define($[943],
{extend:qx.core.Object,
type:$[82],
construct:function(){arguments.callee.base.call(this);
},
statics:{ACCEPT:1,
DENY:2,
NEUTRAL:3},
members:{decide:function($0){throw new Error("decide is abstract");
}}});




/* ID: qx.log.DefaultFilter */
qx.Class.define($[899],
{extend:qx.log.Filter,
construct:function(){arguments.callee.base.call(this);
},
properties:{enabled:{check:$[2],
init:true},
minLevel:{check:$[12],
nullable:true}},
members:{decide:function($0){var $1=qx.log.Filter;
if(!this.getEnabled()){return $1.DENY;
}else if(this.getMinLevel()==null){return $1.NEUTRAL;
}else{return ($0.level>=this.getMinLevel())?$1.ACCEPT:$1.DENY;
}}}});




/* ID: qx.log.LogEventProcessor */
qx.Class.define($[1512],
{extend:qx.core.Object,
type:$[82],
construct:function(){arguments.callee.base.call(this);
},
members:{addFilter:function($0){if(this._filterArr==null){this._filterArr=[];
}this._filterArr.push($0);
},
clearFilters:function(){this._filterArr=null;
},
getHeadFilter:function(){return (this._filterArr==null||this._filterArr.length==0)?null:this._filterArr[0];
},
_getDefaultFilter:function(){var $0=this.getHeadFilter();
if(!($0 instanceof qx.log.DefaultFilter)){this.clearFilters();
$0=new qx.log.DefaultFilter();
this.addFilter($0);
}return $0;
},
setEnabled:function($0){this._getDefaultFilter().setEnabled($0);
},
setMinLevel:function($0){this._getDefaultFilter().setMinLevel($0);
},
decideLogEvent:function($0){var $1=qx.log.Filter.NEUTRAL;
if(this._filterArr!=null){for(var $2=0;$2<this._filterArr.length;$2++){var $3=this._filterArr[$2].decide($0);
if($3!=$1){return $3;
}}}return $1;
},
handleLogEvent:function($0){throw new Error("handleLogEvent is abstract");
}},
destruct:function(){this._disposeFields($[1303]);
}});




/* ID: qx.log.appender.Abstract */
qx.Class.define($[2021],
{extend:qx.log.LogEventProcessor,
type:$[82],
construct:function(){arguments.callee.base.call(this);
},
properties:{useLongFormat:{check:$[2],
init:true}},
members:{handleLogEvent:function($0){if(this.decideLogEvent($0)!=qx.log.Filter.DENY){this.appendLogEvent($0);
}},
appendLogEvent:function($0){throw new Error("appendLogEvent is abstract");
},
formatLogEvent:function($0){var $1=qx.log.Logger;
var $2=$[0];
var $3=new String(new Date().getTime()-qx.core.Bootstrap.LOADSTART);
while($3.length<6){$3=$[56]+$3;
}$2+=$3;
if(this.getUseLongFormat()){switch($0.level){case $1.LEVEL_DEBUG:$2+=$[792];
break;
case $1.LEVEL_INFO:$2+=$[1732];
break;
case $1.LEVEL_WARN:$2+=$[786];
break;
case $1.LEVEL_ERROR:$2+=$[1841];
break;
case $1.LEVEL_FATAL:$2+=$[1915];
break;
}}else{$2+=$[108];
}var $4=$[0];
for(var $5=0;$5<$0.indent;$5++){$4+=$[301];
}$2+=$4;
if(this.getUseLongFormat()){$2+=$0.logger.getName();
if($0.instanceId!=null){$2+=$[606]+$0.instanceId+$[106];
}$2+=$[108];
}if(typeof $0.message==$[8]){$2+=$0.message;
}else{var $6=$0.message;
if($6==null){$2+=$[1456];
}else{$2+=$[1332]+$6+$[1829];
var $7=new Array();
try{for(var $8 in $6){$7.push($8);
}}catch(exc){$2+=$4+$[1215]+exc+$[482];
}$7.sort();
for(var $5=0;$5<$7.length;$5++){try{$2+=$4+$[301]+$7[$5]+$[33]+$6[$7[$5]]+$[195];
}catch(exc){$2+=$4+$[301]+$7[$5]+$[1458]+exc+$[482];
}}$2+=$4+$[1930];
}}if($0.throwable!=null){var $9=$0.throwable;
if($9.name==null){$2+=$[108]+$9;
}else{$2+=$[108]+$9.name;
}
if($9.message!=null){$2+=$[709]+$9.message;
}
if($9.number!=null){$2+=$[1148]+$9.number+$[44];
}var $a=qx.dev.StackTrace.getStackTraceFromError($9);
}
if($0.trace){var $a=$0.trace;
}
if($a&&$a.length>0){$2+=$[195];
for(var $5=0;$5<$a.length;$5++){$2+=$[1029]+$a[$5]+$[195];
}}return $2;
}}});




/* ID: qx.log.appender.Window */
qx.Class.define($[756],
{extend:qx.log.appender.Abstract,
construct:function($0){arguments.callee.base.call(this);
this._id=qx.log.appender.Window.register(this);
this._name=$0;
if(this._name==null){var $1=window.location.href;
var $2=0;
for(var $3=0;$3<$1.length;$3++){$2=($2+$1.charCodeAt($3))%10000000;
}this._name=$[1663]+$2;
}this._errorsPreventingAutoCloseCount=0;
this._divDataSets=[];
this._filterTextWords=[];
this._filterText=$[0];
},
statics:{_nextId:1,
_registeredAppenders:{},
register:function($0){var $1=qx.log.appender.Window;
var $2=$1._nextId++;
$1._registeredAppenders[$2]=$0;
return $2;
},
getAppender:function($0){return qx.log.appender.Window._registeredAppenders[$0];
}},
properties:{maxMessages:{check:$[6],
init:500},
popUnder:{check:$[2],
init:false},
autoCloseWithErrors:{check:$[2],
init:true,
apply:$[1441]},
windowWidth:{check:$[6],
init:600},
windowHeight:{check:$[6],
init:350},
windowLeft:{check:$[6],
nullable:true},
windowTop:{check:$[6],
nullable:true}},
members:{openWindow:function(){if(this._logWindow&&!this._logWindow.closed){return ;
}var $0=this.getWindowWidth();
var $1=this.getWindowHeight();
var $2=this.getWindowLeft();
if($2===null){$2=window.screen.width-$0;
}var $3=this.getWindowTop();
if($3===null){$3=window.screen.height-$1;
}var $4=$[1474]+$[1627]+$0+$[1046]+$1+$[1662]+$2+$[1650]+$3;
this._logWindow=window.open($[0],
this._name,
$4);
if(!this._logWindow||this._logWindow.closed){if(this._popupBlockerWarning){return;
}alert("Could not open log window. Please disable your popup blocker!");
this._popupBlockerWarning=true;
return;
}this._popupBlockerWarning=false;
if(this.getPopUnder()){this._logWindow.blur();
window.focus();
}var $5=this._logWindow.document;
var $6=qx.core.Variant.isSet($[1],
$[20])?$[1296]:$[263];
$5.open();
$5.write($[1457]+this._name+$[1544]+$[949]+this._id+$[827]+$[2049]+$[684]+$[1313]+$[647]+$[1531]+$[1839]+$[1421]+$[1013]+$6+$[952]+$[745]+$[670]+this._filterText+$[395]+$[433]+$[894]+$[2015]+$[433]+$[1954]);
$5.close();
this._logElem=$5.getElementById($[826]);
this._markerBtn=$5.getElementById($[1892]);
this._filterInput=$5.getElementById($[158]);
this._logLinesDiv=$5.getElementById($[941]);
var $7=this;
this._markerBtn.onclick=function(){$7._showMessageInLog($[851]);
};
this._filterInput.onkeyup=function(){$7.setFilterText($7._filterInput.value);
};
if(this._logEventQueue!=null){for(var $8=0;$8<this._logEventQueue.length;$8++){this.appendLogEvent(this._logEventQueue[$8]);
}this._logEventQueue.length=0;
}},
closeWindow:function(){if(this._logWindow!=null){this._logWindow.close();
this._logWindow=null;
this._logElem=null;
}},
_autoCloseWindow:function(){if(this.getAutoCloseWithErrors()||this._errorsPreventingAutoCloseCount==0){this.closeWindow();
}else{this._showMessageInLog($[1178]+this._errorsPreventingAutoCloseCount+$[1000]);
}},
_showMessageInLog:function($0){var $1={message:$0,
isDummyEventForMessage:true};
this.appendLogEvent($1);
},
appendLogEvent:function($0){if(!this._logWindow||this._logWindow.closed){if(!this._logWindow||!this._logEventQueue){this._logEventQueue=[];
}this._logEventQueue.push($0);
this.openWindow();
}else if(this._logElem==null){this._logEventQueue.push($0);
}else{var $1=this._logWindow.document.createElement($[101]);
if($0.level>=qx.log.Logger.LEVEL_ERROR){$1.style.backgroundColor=$[1781];
if(!this.getAutoCloseWithErrors()){this._errorsPreventingAutoCloseCount+=1;
}}else if($0.level==qx.log.Logger.LEVEL_DEBUG){$1.style.color=$[161];
}var $2;
if($0.isDummyEventForMessage){$2=$0.message;
}else{$2=qx.html.String.fromText(this.formatLogEvent($0));
}$1.innerHTML=$2;
this._logElem.appendChild($1);
var $3={txt:$2.toUpperCase(),
elem:$1};
this._divDataSets.push($3);
this._setDivVisibility($3);
while(this._logElem.childNodes.length>this.getMaxMessages()){this._logElem.removeChild(this._logElem.firstChild);
if(this._removedMessageCount==null){this._removedMessageCount=1;
}else{this._removedMessageCount++;
}}
if(this._removedMessageCount!=null){this._logElem.firstChild.innerHTML=$[100]+this._removedMessageCount+$[1482];
}this._logLinesDiv.scrollTop=this._logLinesDiv.scrollHeight;
}},
setFilterText:function($0){if($0==null){$0=$[0];
}this._filterText=$0;
$0=$0.toUpperCase();
this._filterTextWords=$0.split($[81]);
for(var $1=0;$1<this._divDataSets.length;$1++){this._setDivVisibility(this._divDataSets[$1]);
}},
_setDivVisibility:function($0){var $1=true;
for(var $2=0;$1&&($2<this._filterTextWords.length);$2++){$1=$0.txt.indexOf(this._filterTextWords[$2])>=0;
}$0.elem.style[$[173]]=($1?$[0]:$[11]);
},
_applyAutoCloseWithErrors:function($0,
$1){if(!$0&&$1){this._errorsPreventingAutoCloseCount=0;
this._showMessageInLog($[842]);
}else if($0&&!$1){this._showMessageInLog($[903]+this._errorsPreventingAutoCloseCount+$[1400]);
}}},
destruct:function(){try{if(this._markerBtn){this._markerBtn.onclick=null;
}
if(this._filterInput){this._filterInput.onkeyup=null;
}}catch(ex){}this._autoCloseWindow();
}});




/* ID: qx.log.appender.FireBug */
qx.Class.define($[1619],
{extend:qx.log.appender.Abstract,
construct:function(){arguments.callee.base.call(this);
},
members:{appendLogEvent:function($0){if(typeof console!=$[464]){var $1=qx.log.Logger;
var $2=this.formatLogEvent($0);
switch($0.level){case $1.LEVEL_DEBUG:if(console.debug){console.debug($2);
}break;
case $1.LEVEL_INFO:if(console.info){console.info($2);
}break;
case $1.LEVEL_WARN:if(console.warn){console.warn($2);
}break;
default:if(console.error){console.error($2);
}break;
}if($0.level>=$1.LEVEL_WARN&&(!$0.throwable||!$0.throwable.stack)&&console.trace){console.trace();
}}}}});




/* ID: qx.log.appender.Native */
qx.Class.define($[537],
{extend:qx.log.appender.Abstract,
construct:function(){arguments.callee.base.call(this);
if(typeof console!=$[464]&&console.debug&&!console.emu){this._appender=new qx.log.appender.FireBug;
}else{this._appender=new qx.log.appender.Window;
}},
members:{appendLogEvent:function($0){if(this._appender){return this._appender.appendLogEvent($0);
}}},
destruct:function(){this._disposeObjects($[1614]);
}});




/* ID: qx.log.Logger */
qx.Class.define($[1210],
{extend:qx.log.LogEventProcessor,
construct:function($0,
$1){arguments.callee.base.call(this);
this._name=$0;
this._parentLogger=$1;
},
statics:{deprecatedMethodWarning:function($0,
$1){var $2,
$3,
$4;
},
deprecatedClassWarning:function($0){var $1,
$2,
$3;
},
getClassLogger:function($0){var $1=$0._logger;
if($1==null){var $2=$0.classname;
var $3=$2.split($[47]);
var $4=window;
var $5=$[0];
var $6=qx.log.Logger.ROOT_LOGGER;
for(var $7=0;$7<$3.length-1;$7++){$4=$4[$3[$7]];
$5+=(($7!=0)?$[47]:$[0])+$3[$7];
if($4._logger==null){$4._logger=new qx.log.Logger($5,
$6);
}$6=$4._logger;
}$1=new qx.log.Logger($2,
$6);
$0._logger=$1;
}return $1;
},
_indent:0,
LEVEL_ALL:0,
LEVEL_DEBUG:200,
LEVEL_INFO:500,
LEVEL_WARN:600,
LEVEL_ERROR:700,
LEVEL_FATAL:800,
LEVEL_OFF:1000,
ROOT_LOGGER:null},
members:{getName:function(){return this._name;
},
getParentLogger:function(){return this._parentLogger;
},
indent:function(){qx.log.Logger._indent++;
},
unindent:function(){qx.log.Logger._indent--;
},
addAppender:function($0){if(this._appenderArr==null){this._appenderArr=[];
}this._appenderArr.push($0);
},
removeAppender:function($0){if(this._appenderArr!=null){this._appenderArr.remove($0);
}},
removeAllAppenders:function(){this._appenderArr=null;
},
handleLogEvent:function($0){var $1=qx.log.Filter;
var $2=$1.NEUTRAL;
var $3=this;
while($2==$1.NEUTRAL&&$3!=null){$2=$3.decideLogEvent($0);
$3=$3.getParentLogger();
}
if($2!=$1.DENY){this.appendLogEvent($0);
}},
appendLogEvent:function($0){if(this._appenderArr!=null&&this._appenderArr.length!=0){for(var $1=0;$1<this._appenderArr.length;$1++){this._appenderArr[$1].handleLogEvent($0);
}}else if(this._parentLogger!=null){this._parentLogger.appendLogEvent($0);
}},
log:function($0,
$1,
$2,
$3,
$4){var $5={logger:this,
level:$0,
message:$1,
throwable:$3,
trace:$4,
indent:qx.log.Logger._indent,
instanceId:$2};
this.handleLogEvent($5);
},
debug:function($0,
$1,
$2){this.log(qx.log.Logger.LEVEL_DEBUG,
$0,
$1,
$2);
},
info:function($0,
$1,
$2){this.log(qx.log.Logger.LEVEL_INFO,
$0,
$1,
$2);
},
warn:function($0,
$1,
$2){this.log(qx.log.Logger.LEVEL_WARN,
$0,
$1,
$2);
},
error:function($0,
$1,
$2){this.log(qx.log.Logger.LEVEL_ERROR,
$0,
$1,
$2);
},
fatal:function($0,
$1,
$2){this.log(qx.log.Logger.LEVEL_FATAL,
$0,
$1,
$2);
},
measureReset:function(){if(this._totalMeasureTime!=null){this.debug("Measure reset. Total measure time: "+this._totalMeasureTime+" ms");
}this._lastMeasureTime=null;
this._totalMeasureTime=null;
},
measure:function($0,
$1,
$2){if(this._lastMeasureTime==null){$0=$[751]+$0;
}else{var $3=new Date().getTime()-this._lastMeasureTime;
if(this._totalMeasureTime==null){this._totalMeasureTime=0;
}this._totalMeasureTime+=$3;
$0=$[1002]+$3+$[1225]+$0;
}this.debug($0,
$1,
$2);
this._lastMeasureTime=new Date().getTime();
},
printStackTrace:function(){var $0=qx.dev.StackTrace.getStackTrace();
qx.lang.Array.removeAt($0,
0);
this.log(qx.log.Logger.LEVEL_DEBUG,
$[1590],
$[0],
null,
$0);
}},
settings:{"qx.logAppender":$[537],
"qx.minLogLevel":200},
defer:function($0){$0.ROOT_LOGGER=new $0("root",
null);
$0.ROOT_LOGGER.setMinLevel(qx.core.Setting.get($[1145]));
$0.ROOT_LOGGER.addAppender(new (qx.Class.getByName(qx.core.Setting.get($[738]))));
},
destruct:function(){this._disposeFields($[1529],
$[1261]);
}});




/* ID: qx.dev.StackTrace */
qx.Class.define($[1852],
{statics:{getStackTrace:qx.core.Variant.select($[1],
{"gecko":function(){try{throw new Error();
}catch(e){var $0=this.getStackTraceFromError(e);
qx.lang.Array.removeAt($0,
0);
var $1=this.getStackTraceFromCaller(arguments);
var $2=$1.length>$0.length?$1:$0;
for(var $3=0;$3<Math.min($1.length,
$0.length);$3++){callerCall=$1[$3];
if(callerCall.indexOf($[1427])>=0){continue;
}callerArr=callerCall.split($[50]);
if(callerArr.length!=2){continue;
}var $4=callerArr[0];
var $5=callerArr[1];
var $6=$0[$3];
var $7=$6.split($[50]);
var $8=$7[0];
var $9=$7[1];
if(qx.Class.getByName($8)){var $a=$8;
}else{$a=$4;
}var $b=$a+$[50];
if($5){$b+=$5+$[50];
}$b+=$9;
$2[$3]=$b;
}return $2;
}},
"mshtml|webkit":function(){return this.getStackTraceFromCaller(arguments);
},
"opera":function(){var $0;
try{$0.bar();
}catch(e){var $1=this.getStackTraceFromError(e);
qx.lang.Array.removeAt($1,
0);
return $1;
}return [];
}}),
getStackTraceFromCaller:qx.core.Variant.select($[1],
{"opera":function($0){return [];
},
"default":function($0){var $1=[];
var $2=qx.lang.Function.getCaller($0);
var $3=0;
var $4={};
while($2){var $5=this.getFunctionName($2);
$1.push($5);
$2=$2.caller;
if(!$2){break;
}var $6=qx.core.Object.toHashCode($2);
if($4[$6]){$1.push($[1615]);
break;
}$4[$6]=$2;
}return $1;
}}),
getStackTraceFromError:qx.core.Variant.select($[1],
{"gecko":function($0){if(!$0.stack){return [];
}var $1=/@(.+):(\d+)$/gm;
var $2;
var $3=[];
while(($2=$1.exec($0.stack))!=null){var $4=$2[1];
var $5=$2[2];
var $6=this.__fileNameToClassName($4);
$3.push($6+$[50]+$5);
}return $3;
},
"webkit":function($0){if($0.sourceURL&&$0.line){return [this.__fileNameToClassName($0.sourceURL)+$[50]+$0.line];
}},
"opera":function($0){if($0.message.indexOf("Backtrace:")<0){return [];
}var $1=[];
var $2=qx.lang.String.trim($0.message.split("Backtrace:")[1]);
var $3=$2.split($[195]);
for(var $4=0;$4<$3.length;$4++){var $5=$3[$4].match(/\s*Line ([0-9]+) of.* (\S.*)/);
if($5&&$5.length>=2){var $6=$5[1];
var $7=this.__fileNameToClassName($5[2]);
$1.push($7+$[50]+$6);
}}return $1;
},
"default":function(){return [];
}}),
getFunctionName:function($0){if($0.$$original){return $0.classname+$[858];
}
if($0.wrapper){return $0.wrapper.classname+$[551];
}
if($0.classname){return $0.classname+$[551];
}
if($0.mixin){for(var $1 in $0.mixin.$$members){if($0.mixin.$$members[$1]==$0){return $0.mixin.name+$[50]+$1;
}}for(var $1 in $0.mixin){if($0.mixin[$1]==$0){return $0.mixin.name+$[50]+$1;
}}}
if($0.self){var $2=$0.self.constructor;
if($2){for(var $1 in $2.prototype){if($2.prototype[$1]==$0){return $2.classname+$[50]+$1;
}}for(var $1 in $2){if($2[$1]==$0){return $2.classname+$[50]+$1;
}}}}var $3=$0.toString().match(/(function\s*\w*\(.*?\))/);
if($3&&$3.length>=1&&$3[1]){return $3[1];
}var $3=$0.toString().match(/(function\s*\(.*?\))/);
if($3&&$3.length>=1&&$3[1]){return $[1146]+$3[1];
}return $[1870];
},
__fileNameToClassName:function($0){var $1=$[1503];
var $2=$0.indexOf($1);
var $3=($2==-1)?$0:$0.substring($2+$1.length).replace(/\//g,
$[47]).replace(/\.js$/,
$[0]);
return $3;
}}});




/* ID: qx.lang.Function */
qx.Class.define($[1850],
{statics:{globalEval:function($0){if(window.execScript){window.execScript($0);
}else{eval.call(window,
$0);
}},
returnTrue:function(){return true;
},
returnFalse:function(){return false;
},
returnNull:function(){return null;
},
returnThis:function(){return this;
},
returnInstance:function(){if(!this._instance){this._instance=new this;
}return this._instance;
},
returnZero:function(){return 0;
},
returnNegativeIndex:function(){return -1;
},
bind:function($0,
$1,
$2){{};
if(arguments.length>2){var $3=Array.prototype.slice.call(arguments,
2);
var $4=function(){$0.context=$1;
var $5=$0.apply($1,
$3.concat(qx.lang.Array.fromArguments(arguments)));
$0.context=null;
return $5;
};
}else{var $4=function(){$0.context=$1;
var $5=$0.apply($1,
arguments);
$0.context=null;
return $5;
};
}$4.self=$0.self?$0.self.constructor:$1;
return $4;
},
bindEvent:function($0,
$1){{};
var $2=function($3){$0.context=$1;
var $4=$0.call($1,
$3||window.event);
$0.context=null;
return $4;
};
$2.self=$0.self?$0.self.constructor:$1;
return $2;
},
getCaller:function($0){return $0.caller?$0.caller.callee:$0.callee.caller;
}}});




/* ID: qx.html.String */
qx.Class.define($[1831],
{statics:{escape:function($0){return qx.dom.String.escapeEntities($0,
qx.html.Entity.FROM_CHARCODE);
},
unescape:function($0){return qx.dom.String.unescapeEntities($0,
qx.html.Entity.TO_CHARCODE);
},
fromText:function($0){return qx.html.String.escape($0).replace(/(  |\n)/g,
function($1){var $2={"  ":$[733],
"\n":$[1576]};
return $2[$1]||$1;
});
},
toText:function($0){return qx.html.String.unescape($0.replace(/\s+|<([^>])+>/gi,
function($1){if(/\s+/.test($1)){return $[81];
}else if(/^<BR|^<br/gi.test($1)){return $[195];
}else{return $[0];
}}));
}}});




/* ID: qx.dom.String */
qx.Class.define($[1386],
{statics:{escapeEntities:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){var $2,
$3=[];
for(var $4=0,
$5=$0.length;$4<$5;$4++){var $6=$0.charAt($4);
var $7=$6.charCodeAt(0);
if($1[$7]){$2=$[60]+$1[$7]+$[75];
}else{if($7>0x7F){$2=$[505]+$7+$[75];
}else{$2=$6;
}}$3[$3.length]=$2;
}return $3.join($[0]);
},
"default":function($0,
$1){var $2,
$3=$[0];
for(var $4=0,
$5=$0.length;$4<$5;$4++){var $6=$0.charAt($4);
var $7=$6.charCodeAt(0);
if($1[$7]){$2=$[60]+$1[$7]+$[75];
}else{if($7>0x7F){$2=$[505]+$7+$[75];
}else{$2=$6;
}}$3+=$2;
}return $3;
}}),
unescapeEntities:function($0,
$1){return $0.replace(/&[#\w]+;/gi,
function($2){var $3=$2;
var $2=$2.substring(1,
$2.length-1);
var $4=$1[$2];
if($4){$3=String.fromCharCode($4);
}else{if($2.charAt(0)==$[1020]){if($2.charAt(1).toUpperCase()==$[1234]){$4=$2.substring(2);
if($4.match(/^[0-9A-Fa-f]+$/gi)){$3=String.fromCharCode(parseInt($[1222]+$4));
}}else{$4=$2.substring(1);
if($4.match(/^\d+$/gi)){$3=String.fromCharCode(parseInt($4));
}}}}return $3;
});
},
stripTags:function($0){return $0.replace(/<\/?[^>]+>/gi,
$[0]);
}}});




/* ID: qx.html.Entity */
qx.Class.define($[1425],
{statics:{TO_CHARCODE:{"quot":34,
"amp":38,
"lt":60,
"gt":62,
"nbsp":160,
"iexcl":161,
"cent":162,
"pound":163,
"curren":164,
"yen":165,
"brvbar":166,
"sect":167,
"uml":168,
"copy":169,
"ordf":170,
"laquo":171,
"not":172,
"shy":173,
"reg":174,
"macr":175,
"deg":176,
"plusmn":177,
"sup2":178,
"sup3":179,
"acute":180,
"micro":181,
"para":182,
"middot":183,
"cedil":184,
"sup1":185,
"ordm":186,
"raquo":187,
"frac14":188,
"frac12":189,
"frac34":190,
"iquest":191,
"Agrave":192,
"Aacute":193,
"Acirc":194,
"Atilde":195,
"Auml":196,
"Aring":197,
"AElig":198,
"Ccedil":199,
"Egrave":200,
"Eacute":201,
"Ecirc":202,
"Euml":203,
"Igrave":204,
"Iacute":205,
"Icirc":206,
"Iuml":207,
"ETH":208,
"Ntilde":209,
"Ograve":210,
"Oacute":211,
"Ocirc":212,
"Otilde":213,
"Ouml":214,
"times":215,
"Oslash":216,
"Ugrave":217,
"Uacute":218,
"Ucirc":219,
"Uuml":220,
"Yacute":221,
"THORN":222,
"szlig":223,
"agrave":224,
"aacute":225,
"acirc":226,
"atilde":227,
"auml":228,
"aring":229,
"aelig":230,
"ccedil":231,
"egrave":232,
"eacute":233,
"ecirc":234,
"euml":235,
"igrave":236,
"iacute":237,
"icirc":238,
"iuml":239,
"eth":240,
"ntilde":241,
"ograve":242,
"oacute":243,
"ocirc":244,
"otilde":245,
"ouml":246,
"divide":247,
"oslash":248,
"ugrave":249,
"uacute":250,
"ucirc":251,
"uuml":252,
"yacute":253,
"thorn":254,
"yuml":255,
"fnof":402,
"Alpha":913,
"Beta":914,
"Gamma":915,
"Delta":916,
"Epsilon":917,
"Zeta":918,
"Eta":919,
"Theta":920,
"Iota":921,
"Kappa":922,
"Lambda":923,
"Mu":924,
"Nu":925,
"Xi":926,
"Omicron":927,
"Pi":928,
"Rho":929,
"Sigma":931,
"Tau":932,
"Upsilon":933,
"Phi":934,
"Chi":935,
"Psi":936,
"Omega":937,
"alpha":945,
"beta":946,
"gamma":947,
"delta":948,
"epsilon":949,
"zeta":950,
"eta":951,
"theta":952,
"iota":953,
"kappa":954,
"lambda":955,
"mu":956,
"nu":957,
"xi":958,
"omicron":959,
"pi":960,
"rho":961,
"sigmaf":962,
"sigma":963,
"tau":964,
"upsilon":965,
"phi":966,
"chi":967,
"psi":968,
"omega":969,
"thetasym":977,
"upsih":978,
"piv":982,
"bull":8226,
"hellip":8230,
"prime":8242,
"Prime":8243,
"oline":8254,
"frasl":8260,
"weierp":8472,
"image":8465,
"real":8476,
"trade":8482,
"alefsym":8501,
"larr":8592,
"uarr":8593,
"rarr":8594,
"darr":8595,
"harr":8596,
"crarr":8629,
"lArr":8656,
"uArr":8657,
"rArr":8658,
"dArr":8659,
"hArr":8660,
"forall":8704,
"part":8706,
"exist":8707,
"empty":8709,
"nabla":8711,
"isin":8712,
"notin":8713,
"ni":8715,
"prod":8719,
"sum":8721,
"minus":8722,
"lowast":8727,
"radic":8730,
"prop":8733,
"infin":8734,
"ang":8736,
"and":8743,
"or":8744,
"cap":8745,
"cup":8746,
"int":8747,
"there4":8756,
"sim":8764,
"cong":8773,
"asymp":8776,
"ne":8800,
"equiv":8801,
"le":8804,
"ge":8805,
"sub":8834,
"sup":8835,
"sube":8838,
"supe":8839,
"oplus":8853,
"otimes":8855,
"perp":8869,
"sdot":8901,
"lceil":8968,
"rceil":8969,
"lfloor":8970,
"rfloor":8971,
"lang":9001,
"rang":9002,
"loz":9674,
"spades":9824,
"clubs":9827,
"hearts":9829,
"diams":9830,
"OElig":338,
"oelig":339,
"Scaron":352,
"scaron":353,
"Yuml":376,
"circ":710,
"tilde":732,
"ensp":8194,
"emsp":8195,
"thinsp":8201,
"zwnj":8204,
"zwj":8205,
"lrm":8206,
"rlm":8207,
"ndash":8211,
"mdash":8212,
"lsquo":8216,
"rsquo":8217,
"sbquo":8218,
"ldquo":8220,
"rdquo":8221,
"bdquo":8222,
"dagger":8224,
"Dagger":8225,
"permil":8240,
"lsaquo":8249,
"rsaquo":8250,
"euro":8364}},
defer:function($0,
$1,
$2){$0.FROM_CHARCODE=qx.lang.Object.invert($0.TO_CHARCODE);
}});




/* ID: qx.html.EventRegistration */
qx.Class.define($[1445],
{statics:{addEventListener:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1,
$2){$0.attachEvent($[91]+$1,
$2);
},
"default":function($0,
$1,
$2){$0.addEventListener($1,
$2,
false);
}}),
removeEventListener:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1,
$2){$0.detachEvent($[91]+$1,
$2);
},
"default":function($0,
$1,
$2){$0.removeEventListener($1,
$2,
false);
}})}});




/* ID: qx.core.Init */
qx.Class.define($[1291],
{type:$[24],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
qx.html.EventRegistration.addEventListener(window,
$[94],
qx.lang.Function.bind(this._onload,
this));
qx.html.EventRegistration.addEventListener(window,
$[360],
qx.lang.Function.bind(this._onbeforeunload,
this));
qx.html.EventRegistration.addEventListener(window,
$[485],
qx.lang.Function.bind(this._onunload,
this));
},
events:{"load":$[4],
"beforeunload":$[4],
"unload":$[4]},
properties:{application:{nullable:true,
check:function($0){if(typeof $0==$[51]){throw new Error("The application property takes an application instance as parameter "+"and no longer a class/constructor. You may have to fix your 'index.html'.");
}return $0&&qx.Class.hasInterface($0.constructor,
qx.application.IApplication);
}}},
members:{_autoDispose:false,
_onload:function($0){this.createDispatchEvent($[94]);
this.debug("qooxdoo "+qx.core.Version.toString());
{this.debug("loaded "+qx.lang.Object.getLength(qx.OO.classes)+" old classes");
};
this.debug("loaded "+qx.Class.getTotalNumber()+" classes");
this.debug("loaded "+qx.Interface.getTotalNumber()+" interfaces");
this.debug("loaded "+qx.Mixin.getTotalNumber()+" mixins");
if(qx.Theme){this.debug("loaded "+qx.Theme.getTotalNumber()+" themes");
}
if(qx.locale&&qx.locale.Manager){this.debug("loaded "+qx.locale.Manager.getInstance().getAvailableLocales().length+" locales");
}var $1=qx.core.Client.getInstance();
this.debug("client: "+$1.getEngine()+"-"+$1.getMajor()+"."+$1.getMinor()+"/"+$1.getPlatform()+"/"+$1.getLocale());
this.debug("browser: "+$1.getBrowser()+"/"+($1.supportsSvg()?"svg":$1.supportsVml()?"vml":"none"));
{};
if(!this.getApplication()){var $2=qx.Class.getByName(qx.core.Setting.get($[731]));
if($2){this.setApplication(new $2(this));
}}
if(!this.getApplication()){return;
}this.debug("application: "+this.getApplication().classname+"["+this.getApplication().toHashCode()+"]");
var $3=new Date;
{this.getApplication().main();
};
var $4,
$5,
$6;
this.info("main runtime: "+(new Date-$3)+"ms");
},
_onbeforeunload:function($0){this.createDispatchEvent($[360]);
if(this.getApplication()){var $1=this.getApplication().close();
if($1!=null){$0.returnValue=$1;
}}},
_onunload:function($0){this.createDispatchEvent($[485]);
if(this.getApplication()){this.getApplication().terminate();
}qx.core.Object.dispose();
}},
settings:{"qx.application":$[366],
"qx.isSource":true},
defer:function($0,
$1,
$2){$0.getInstance();
}});




/* ID: qx.application.IApplication */
qx.Interface.define($[726],
{members:{main:function(){return true;
},
close:function(){return true;
},
terminate:function(){return true;
}}});




/* ID: qx.core.Version */
qx.Class.define($[1199],
{statics:{major:0,
minor:0,
revision:0,
state:$[0],
svn:0,
folder:$[0],
toString:function(){return this.major+$[47]+this.minor+(this.revision==0?$[0]:$[47]+this.revision)+(this.state==$[0]?$[0]:$[96]+this.state)+(this.svn==0?$[0]:$[1895]+this.svn+$[44])+(this.folder==$[0]?$[0]:$[639]+this.folder+$[106]);
},
__init:function(){var $0=qx.core.Setting.get($[755]).split($[81]);
var $1=$0.shift();
var $2=$0.join($[81]);
if(/([0-9]+)\.([0-9]+)(\.([0-9]))?(-([a-z0-9]+))?/.test($1)){this.major=(RegExp.$1!=$[0]?parseInt(RegExp.$1):0);
this.minor=(RegExp.$2!=$[0]?parseInt(RegExp.$2):0);
this.revision=(RegExp.$4!=$[0]?parseInt(RegExp.$4):0);
this.state=typeof RegExp.$6==$[8]?RegExp.$6:$[0];
}
if(/(\(r([0-9]+)\))?(\s\[([a-zA-Z0-9_-]+)\])?/.test($2)){this.svn=(RegExp.$2!=$[0]?parseInt(RegExp.$2):0);
this.folder=typeof RegExp.$4==$[8]?RegExp.$4:$[0];
}}},
settings:{"qx.version":$[1156]},
defer:function($0){$0.__init();
}});




/* ID: qx.OO */
{qx.Class.define($[998],
{statics:{classes:{},
defineClass:function($0,
$1,
$2){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[870]);
var $3=$0.split($[47]);
var $4=$3.length-1;
var $5=window;
for(var $6=0;$6<$4;$6++){if(typeof $5[$3[$6]]===$[7]){$5[$3[$6]]={};
}$5=$5[$3[$6]];
}if(typeof $1===$[7]){if(typeof $2!==$[7]){throw new Error("SuperClass is undefined, but constructor was given for class: "+$0);
}qx.Clazz=$5[$3[$6]]={};
qx.Proto=null;
qx.Super=null;
}else if(typeof $2===$[7]){qx.Clazz=$5[$3[$6]]=$1;
qx.Proto=null;
qx.Super=$1;
}else{qx.Clazz=$5[$3[$6]]=$2;
var $7=function(){};
$7.prototype=$1.prototype;
qx.Proto=$2.prototype=new $7;
qx.Super=$2.superclass=$1;
qx.Proto.classname=$2.classname=$0;
qx.Proto.constructor=$2;
}qx.OO.classes[$0]=qx.Class;
},
isAvailable:function($0){qx.log.Logger.deprecatedMethodWarning(arguments.callee);
return qx.OO.classes[$0]!=null;
},
addFastProperty:function($0){{};
return qx.core.LegacyProperty.addFastProperty($0,
qx.Proto);
},
addCachedProperty:function($0){{};
return qx.core.LegacyProperty.addCachedProperty($0,
qx.Proto);
},
addPropertyGroup:function($0){{};
return qx.Class.addPropertyGroup($0,
qx.Proto);
},
removeProperty:function($0){{};
return qx.core.LegacyProperty.removeProperty($0,
qx.Proto);
},
changeProperty:function($0){qx.log.Logger.deprecatedMethodWarning(arguments.callee);
return qx.core.LegacyProperty.addProperty($0,
qx.Proto);
},
addProperty:function($0){qx.log.Logger.deprecatedMethodWarning(arguments.callee);
return qx.core.LegacyProperty.addProperty($0,
qx.Proto);
}}});
};




/* ID: qx.Theme */
qx.Class.define($[1710],
{statics:{define:function($0,
$1){if(!$1){var $1={};
}
if($1.include&&!($1.include instanceof Array)){$1.include=[$1.include];
}{};
var $2={$$type:$[132],
name:$0,
title:$1.title,
type:$1.type||$[171],
toString:this.genericToString};
if($1.extend){$2.supertheme=$1.extend;
}$2.basename=qx.Class.createNamespace($0,
$2);
this.__convert($2,
$1);
this.__registry[$0]=$2;
if($1.include){for(var $3=0,
$4=$1.include,
$5=$4.length;$3<$5;$3++){this.include($2,
$4[$3]);
}}},
getAll:function(){return this.__registry;
},
getByName:function($0){return this.__registry[$0];
},
isDefined:function($0){return this.getByName($0)!==undefined;
},
getTotalNumber:function(){return qx.lang.Object.getLength(this.__registry);
},
genericToString:function(){return $[1436]+this.name+$[106];
},
__extractInheritableKey:function($0){for(var $1=0,
$2=this.__inheritableKeys,
$3=$2.length;$1<$3;$1++){if($0[$2[$1]]){return $2[$1];
}}},
__convert:function($0,
$1){var $2=this.__extractInheritableKey($1);
if($1.extend){var $3=this.__extractInheritableKey($1.extend);
if(!$2){$2=$3;
}}if(!$2){return;
}var $4=function(){};
if($1.extend){$4.prototype=new $1.extend.$$clazz;
}var $5=$4.prototype;
var $6=$1[$2];
for(var $7 in $6){$5[$7]=$6[$7];
}$0.$$clazz=$4;
$0[$2]=new $4;
},
__registry:{},
__inheritableKeys:[$[448],
$[614],
$[539],
$[557],
$[616],
$[357],
$[402]],
__allowedKeys:null,
__metaKeys:null,
__validateConfig:function(){},
patch:function($0,
$1){var $2=this.__extractInheritableKey($1);
if($2!==this.__extractInheritableKey($0)){throw new Error("The mixins '"+$0.name+"' are not compatible '"+$1.name+"'!");
}var $3=$1[$2];
var $4=$0[$2];
for(var $5 in $3){$4[$5]=$3[$5];
}},
include:function($0,
$1){var $2=this.__extractInheritableKey($1);
if($2!==this.__extractInheritableKey($0)){throw new Error("The mixins '"+$0.name+"' are not compatible '"+$1.name+"'!");
}var $3=$1[$2];
var $4=$0[$2];
for(var $5 in $3){if($4[$5]!==undefined){throw new Error("It is not allowed to overwrite the key '"+$5+"' of theme '"+$0.name+"' by mixin theme '"+$1.name+"'.");
}$4[$5]=$3[$5];
}}}});




/* ID: qx.theme.classic.color.Royale */
qx.Theme.define($[830],
{title:$[1198],
colors:{"background":[235,
233,
237],
"border-light":$[73],
"border-light-shadow":[220,
223,
228],
"border-dark":[133,
135,
140],
"border-dark-shadow":[167,
166,
170],
"effect":[254,
200,
60],
"selected":[51,
94,
168],
"text":$[207],
"text-disabled":[167,
166,
170],
"text-selected":$[73],
"tooltip":[255,
255,
225],
"tooltip-text":$[207],
"menu":$[73],
"list":$[73],
"field":$[73],
"button":[235,
233,
237],
"button-hover":[246,
245,
247],
"button-abandoned":[235,
233,
237],
"window-active-caption-text":[255,
255,
255],
"window-inactive-caption-text":[255,
255,
255],
"window-active-caption":[51,
94,
168],
"window-inactive-caption":[111,
161,
217],
"button-view-pane":[250,
251,
254],
"button-view-bar":[225,
238,
255],
"tab-view-pane":[250,
251,
254],
"tab-view-border":[145,
165,
189],
"tab-view-button":[225,
238,
255],
"tab-view-button-hover":[250,
251,
254],
"tab-view-button-checked":[250,
251,
254],
"radio-view-pane":[250,
251,
254],
"radio-view-bar":[225,
238,
255],
"radio-view-button-checked":[250,
251,
254],
"list-view":$[73],
"list-view-border":[167,
166,
170],
"list-view-header":[242,
242,
242],
"list-view-header-border":[214,
213,
217],
"list-view-header-cell-hover":$[73],
"date-chooser":$[73],
"date-chooser-title":[98,
133,
186],
"table-pane":$[73],
"table-header":[242,
242,
242],
"table-header-border":[214,
213,
217],
"table-header-cell":[235,
234,
219],
"table-header-cell-hover":[255,
255,
255],
"table-focus-indicator":[197,
200,
202],
"table-focus-indicator-active":[179,
217,
255],
"table-row-background-focused-selected":[90,
138,
211],
"table-row-background-focused-selected-blur":[179,
186,
198],
"table-row-background-focused":[221,
238,
255],
"table-row-background-focused-blur":[218,
224,
231],
"table-row-background-selected":[51,
94,
168],
"table-row-background-selected-blur":[152,
158,
168],
"table-row-background-even":[250,
248,
243],
"table-row-background-odd":[255,
255,
255],
"table-row-selected":[255,
255,
255],
"table-row":[0,
0,
0]}});




/* ID: qx.theme.classic.Border */
qx.Theme.define($[1517],
{title:$[339],
borders:{"black":{width:1,
color:$[207]},
"white":{width:1,
color:$[73]},
"dark-shadow":{width:1,
color:$[10]},
"light-shadow":{width:1,
color:$[136]},
"light":{width:1,
color:$[35]},
"dark":{width:1,
color:$[138]},
"tooltip":{width:1,
color:$[570]},
"inset":{width:2,
color:[$[10],
$[35],
$[35],
$[10]],
innerColor:[$[138],
$[136],
$[136],
$[138]]},
"outset":{width:2,
color:[$[136],
$[138],
$[138],
$[136]],
innerColor:[$[35],
$[10],
$[10],
$[35]]},
"groove":{width:2,
color:[$[10],
$[35],
$[35],
$[10]],
innerColor:[$[35],
$[10],
$[10],
$[35]]},
"ridge":{width:2,
color:[$[35],
$[10],
$[10],
$[35]],
innerColor:[$[10],
$[35],
$[35],
$[10]]},
"inset-thin":{width:1,
color:[$[10],
$[35],
$[35],
$[10]]},
"outset-thin":{width:1,
color:[$[35],
$[10],
$[10],
$[35]]},
"resizer":{width:[1,
3,
3,
1],
color:[$[35],
$[10],
$[10],
$[35]],
innerColor:[$[136],
$[138],
$[138],
$[136]]},
"line-left":{widthLeft:1,
colorLeft:$[10]},
"line-right":{widthRight:1,
colorRight:$[10]},
"line-top":{widthTop:1,
colorTop:$[10]},
"line-bottom":{widthBottom:1,
colorBottom:$[10]},
"divider-vertical":{widthTop:1,
colorTop:$[10]},
"divider-horizontal":{widthLeft:1,
colorLeft:$[10]}}});




/* ID: qx.theme.classic.font.Default */
qx.Theme.define($[1327],
{title:$[339],
fonts:{"default":{size:11,
family:[$[251],
$[237],
$[269],
$[218],
$[241]]},
"bold":{size:11,
family:[$[251],
$[237],
$[269],
$[218],
$[241]],
bold:true},
"large":{size:13,
family:[$[251],
$[237],
$[269],
$[218],
$[241]]},
"bold-large":{size:13,
family:[$[251],
$[237],
$[269],
$[218],
$[241]],
bold:true},
"monospace":{size:11,
family:[$[1564],
$[1301],
$[1259],
$[2050]]}}});




/* ID: qx.util.manager.Value */
qx.Class.define($[1945],
{type:$[82],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this._registry={};
this._dynamic={};
},
members:{connect:function($0,
$1,
$2){{};
var $3=$[548]+$1.toHashCode()+$[162]+qx.core.Object.toHashCode($0);
var $4=this._registry;
if($2!==null&&this._preprocess){$2=this._preprocess($2);
}if(this.isDynamic($2)){$4[$3]={callback:$0,
object:$1,
value:$2};
}else if($4[$3]){delete $4[$3];
}$0.call($1,
this.resolveDynamic($2)||$2);
},
resolveDynamic:function($0){return this._dynamic[$0];
},
isDynamic:function($0){return this._dynamic[$0]!==undefined;
},
_updateObjects:function(){var $0=this._registry;
var $1;
for(var $2 in $0){$1=$0[$2];
$1.callback.call($1.object,
this.resolveDynamic($1.value));
}}},
destruct:function(){this._disposeFields($[1787],
$[1745]);
}});




/* ID: qx.io.Alias */
qx.Class.define($[849],
{type:$[24],
extend:qx.util.manager.Value,
construct:function(){arguments.callee.base.call(this);
this._aliases={};
this.add($[291],
qx.core.Setting.get($[246])+$[978]);
},
members:{_preprocess:function($0){var $1=this._dynamic;
if($1[$0]===false){return $0;
}else if($1[$0]===undefined){if($0.charAt(0)===$[145]||$0.charAt(0)===$[47]||$0.indexOf($[1284])===0||$0.indexOf($[1022])===$[56]||$0.indexOf($[1595])===0){$1[$0]=false;
return $0;
}var $2=$0.substring(0,
$0.indexOf($[145]));
var $3=this._aliases[$2];
if($3!==undefined){$1[$0]=$3+$0.substring($2.length);
}}return $0;
},
add:function($0,
$1){this._aliases[$0]=$1;
var $2=this._dynamic;
var $3=this._registry;
var $4;
var $5={};
for(var $6 in $2){if($6.substring(0,
$6.indexOf($[145]))===$0){$2[$6]=$1+$6.substring($0.length);
$5[$6]=true;
}}for(var $7 in $3){$4=$3[$7];
if($5[$4.value]){$4.callback.call($4.object,
$2[$4.value]);
}}},
remove:function($0){delete this._aliases[$0];
},
resolve:function($0){if($0!==null){$0=this._preprocess($0);
}return this._dynamic[$0]||$0;
}},
settings:{"qx.resourceUri":$[691]},
destruct:function(){this._disposeFields($[1065]);
}});




/* ID: qx.theme.classic.Widget */
qx.Theme.define($[1121],
{title:$[420],
widgets:{uri:qx.core.Setting.get($[246])+$[1181]}});




/* ID: qx.theme.classic.Appearance */
qx.Theme.define($[1961],
{title:$[339],
appearances:{"empty":{},
"widget":{},
"image":{},
"atom":{},
"popup":{},
"cursor-dnd-move":{style:function($0){return {source:$[1475]};
}},
"cursor-dnd-copy":{style:function($0){return {source:$[1127]};
}},
"cursor-dnd-alias":{style:function($0){return {source:$[1527]};
}},
"cursor-dnd-nodrop":{style:function($0){return {source:$[1651]};
}},
"label":{style:function($0){return {textColor:$0.disabled?$[323]:$[7]};
}},
"client-document":{style:function($0){return {backgroundColor:$[85],
textColor:$[186],
font:$[43]};
}},
"client-document-blocker":{style:function($0){return {cursor:$[43],
backgroundImage:$[204]};
}},
"tool-tip":{include:$[491],
style:function($0){return {backgroundColor:$[573],
textColor:$[570],
border:$[573],
padding:[1,
3,
2,
3]};
}},
"iframe":{style:function($0){return {border:$[72]};
}},
"check-box":{style:function($0){return {padding:[2,
3]};
}},
"radio-button":{include:$[1066]},
"button":{style:function($0){if($0.pressed||$0.checked||$0.abandoned){var $1=$[72];
}else{var $1=$[69];
}
if($0.pressed||$0.abandoned){var $2=[4,
3,
2,
5];
}else{var $2=[3,
4];
}return {backgroundColor:$0.abandoned?$[255]:$0.over?$[1833]:$[156],
border:$1,
padding:$2};
}},
"toolbar":{style:function($0){return {border:$[206],
backgroundColor:$[85]};
}},
"toolbar-part":{},
"toolbar-part-handle":{style:function($0){return {width:10};
}},
"toolbar-part-handle-line":{style:function($0){return {top:2,
left:3,
bottom:2,
width:4,
border:$[206]};
}},
"toolbar-separator":{style:function($0){return {width:8};
}},
"toolbar-separator-line":{style:function($0){return {top:2,
left:3,
width:$[3],
bottom:2,
border:$[1843]};
}},
"toolbar-button":{style:function($0){if($0.pressed||$0.checked||$0.abandoned){var $1=$[208];
var $2=[3,
2,
1,
4];
}else if($0.over){var $1=$[206];
var $2=[2,
3];
}else{var $1=$[7];
var $2=[3,
4];
}return {cursor:$[43],
spacing:4,
width:$[3],
border:$1,
padding:$2,
verticalChildrenAlign:$[30],
backgroundColor:$0.abandoned?$[255]:$[156],
backgroundImage:$0.checked&&!$0.over?$[495]:null};
}},
"button-view":{style:function($0){return {border:$[260]};
}},
"button-view-pane":{style:function($0){return {backgroundColor:$[549],
padding:10};
}},
"button-view-page":{},
"button-view-bar":{style:function($0){var $1=$[7];
var $2=$[7];
var $3=qx.ui.core.Border;
if($0.barTop){$1=[1,
0];
$2=$3.fromConfig({bottom:[1,
$[5],
$[10]]});
}else if($0.barBottom){$1=[1,
0];
$2=$3.fromConfig({top:[1,
$[5],
$[10]]});
}else if($0.barLeft){$1=[0,
1];
$2=$3.fromConfig({right:[1,
$[5],
$[10]]});
}else if($0.barRight){$1=[0,
1];
$2=$3.fromConfig({left:[1,
$[5],
$[10]]});
}return {backgroundColor:$[1144],
padding:$1||$[7],
border:$2||$[7]};
}},
"button-view-button":{style:function($0){var $1,
$2,
$3,
$4,
$5;
var $6=qx.ui.core.Border;
if($0.checked||$0.over){$5=new qx.ui.core.Border(1,
$[5],
$[10]);
if($0.barTop){$5.setBottom(3,
$[5],
$[74]);
$4=[3,
6,
1,
6];
}else if($0.barBottom){$5.setTop(3,
$[5],
$[74]);
$4=[1,
6,
3,
6];
}else if($0.barLeft){$5.setRight(3,
$[5],
$[74]);
$4=[3,
4,
3,
6];
}else{$5.setLeft(3,
$[5],
$[74]);
$4=[3,
6,
3,
4];
}}else{$5=$[7];
$4=[4,
7];
}
if($0.barTop||$0.barBottom){$1=[0,
1];
$2=$[3];
$3=null;
}else{$1=[1,
0];
$3=$[3];
$2=null;
}return {backgroundColor:$0.checked?$[549]:$[7],
iconPosition:$[23],
margin:$1,
width:$2,
height:$3,
border:$5,
padding:$4||$[7]};
}},
"tab-view":{style:function($0){return {spacing:-1};
}},
"tab-view-bar":{},
"tab-view-pane":{style:function($0){return {backgroundColor:$[708],
border:new qx.ui.core.Border(1,
$[5],
$[398]),
padding:10};
}},
"tab-view-page":{},
"tab-view-button":{style:function($0){var $1,
$2,
$3,
$4;
var $5,
$6,
$7,
$8;
var $9,
$a,
$b;
$5=0;
$6=0;
$b=new qx.ui.core.Border(1,
$[5],
$[398]);
if($0.checked){$1=2;
$2=4;
$3=7;
$4=8;
$7=-1;
$8=-2;
$9=$[770];
if($0.barTop){$b.setWidthBottom(0);
$b.setTop(3,
$[5],
$[74]);
}else{$b.setWidthTop(0);
$b.setBottom(3,
$[5],
$[74]);
}
if($0.alignLeft){if($0.firstChild){$3=6;
$4=7;
$8=0;
}}else{if($0.lastChild){$3=8;
$4=5;
$7=0;
}}}else{$1=2;
$2=2;
$3=5;
$4=6;
$7=1;
$8=0;
$9=$0.over?$[1063]:$[800];
if($0.barTop){$b.setWidthBottom(0);
$5=3;
$6=1;
}else{$b.setWidthTop(0);
$5=1;
$6=3;
}
if($0.alignLeft){if($0.firstChild){$3=6;
$4=5;
}}else{if($0.lastChild){$3=6;
$4=5;
$7=0;
}}}return {padding:[$1,
$4,
$2,
$3],
margin:[$5,
$7,
$6,
$8],
border:$b,
backgroundColor:$9};
}},
"radio-view":{include:$[1493]},
"radio-view-pane":{style:function($0){return {backgroundColor:$[975]};
}},
"radio-view-page":{},
"radio-view-bar":{style:function($0){return {backgroundColor:$[915],
padding:[1,
0],
border:$0.barTop?qx.ui.core.Border.fromConfig({bottom:[1,
$[5],
$[10]]}):qx.ui.core.Border.fromConfig({top:[1,
$[5],
$[10]]})};
}},
"radio-view-button":{style:function($0){var $1,
$2;
if($0.checked||$0.over){$1=new qx.ui.core.Border(1,
$[5],
$[10]);
$1.setLeft(3,
$[5],
$[74]);
$2=[2,
6,
2,
4];
}else{$1=$[7];
$2=[3,
7];
}return {backgroundColor:$0.checked?$[767]:$[7],
iconPosition:$[13],
margin:[0,
1],
width:$[3],
opacity:$0.checked?1.0:0.3,
border:$1,
padding:$2};
}},
"window":{style:function($0){return {backgroundColor:$[85],
padding:1,
border:$0.maximized?$[7]:$[69]};
}},
"window-captionbar":{style:function($0){return {padding:[1,
2,
2],
verticalChildrenAlign:$[30],
backgroundColor:$0.active?$[1399]:$[1944],
textColor:$0.active?$[1935]:$[874]};
}},
"window-resize-frame":{style:function($0){return {border:$[260]};
}},
"window-captionbar-icon":{style:function($0){return {marginRight:2};
}},
"window-captionbar-title":{style:function($0){return {cursor:$[43],
font:$[304],
marginRight:2};
}},
"window-captionbar-button":{include:$[156],
style:function($0){return {padding:$0.pressed||$0.abandoned?[2,
1,
0,
3]:[1,
2]};
}},
"window-captionbar-minimize-button":{include:$[268],
style:function($0){return {icon:$[1207]};
}},
"window-captionbar-restore-button":{include:$[268],
style:function($0){return {icon:$[1044]};
}},
"window-captionbar-maximize-button":{include:$[268],
style:function($0){return {icon:$[1404]};
}},
"window-captionbar-close-button":{include:$[268],
style:function($0){return {marginLeft:2,
icon:$[1304]};
}},
"window-statusbar":{style:function($0){return {border:$[208]};
}},
"window-statusbar-text":{style:function($0){return {padding:[1,
4]};
}},
"color-popup":{style:function($0){return {padding:4,
border:$[69],
backgroundColor:$[85]};
}},
"resizer":{style:function($0){return {border:$[69]};
}},
"resizer-frame":{style:function($0){return {border:$[260]};
}},
"menu":{style:function($0){return {backgroundColor:$[582],
border:$[69],
padding:1};
}},
"menu-layout":{},
"menu-button":{style:function($0){return {spacing:2,
padding:[2,
4],
verticalChildrenAlign:$[30],
backgroundColor:$0.over?$[183]:$[7],
textColor:$0.over?$[209]:$[7]};
}},
"menu-button-arrow":{style:function($0){return {source:$[1287]};
}},
"menu-check-box":{include:$[314],
style:function($0){return {icon:$0.checked?$[1129]:$[204]};
}},
"menu-radio-button":{include:$[314],
style:function($0){return {icon:$0.checked?$[1239]:$[204]};
}},
"menu-separator":{style:function($0){return {marginTop:3,
marginBottom:2,
paddingLeft:3,
paddingRight:3};
}},
"menu-separator-line":{style:function($0){return {right:0,
left:0,
height:$[3],
border:$[1323]};
}},
"list":{style:function($0){return {border:$[208],
backgroundColor:$[189]};
}},
"list-item":{style:function($0){return {horizontalChildrenAlign:$[13],
verticalChildrenAlign:$[30],
spacing:4,
padding:[3,
5],
backgroundColor:$0.selected?$[183]:$[7],
textColor:$0.selected?$[209]:$[7]};
}},
"text-field":{style:function($0){return {border:$[72],
padding:[1,
3],
textColor:$0.disabled?$[323]:$[7],
backgroundColor:$[220]};
}},
"text-area":{include:$[157]},
"combo-box":{style:function($0){return {border:$[72],
backgroundColor:$[220]};
}},
"combo-box-list":{include:$[189],
style:function($0){return {border:$[7],
overflow:$[104]};
}},
"combo-box-popup":{include:$[189],
style:function($0){return {maxHeight:150,
border:$[260]};
}},
"combo-box-text-field":{include:$[157],
style:function($0){return {border:$[7],
backgroundColor:$[235]};
}},
"combo-box-button":{include:$[156],
style:function($0){return {padding:[0,
3,
0,
2],
icon:$[626]};
}},
"combo-box-ex":{style:function($0){return {border:$[72],
backgroundColor:$[220]};
}},
"combo-box-ex-list":{include:$[189],
style:function($0){return {border:$[7],
edge:0};
}},
"combo-box-ex-text-field":{include:$[157],
style:function($0){return {border:$[7],
minWidth:30,
width:100,
backgroundColor:$[235]};
}},
"combo-box-ex-popup":{include:$[189],
style:function($0){return {border:$[576]};
}},
"combo-box-ex-button":{include:$[1281]},
"treevirtual-focus-indicator":{include:$[1761]},
"tree-element":{style:function($0){return {height:16,
verticalChildrenAlign:$[30]};
}},
"tree-element-icon":{style:function($0){return {width:16,
height:16};
}},
"tree-element-label":{include:$[180],
style:function($0){return {marginLeft:3,
height:15,
padding:2,
backgroundColor:$0.selected?$[183]:$[7],
textColor:$0.selected?$[209]:$[7]};
}},
"tree-folder":{include:$[2048]},
"tree-folder-icon":{include:$[1777]},
"tree-folder-label":{include:$[1155]},
"tree":{include:$[1727]},
"tree-icon":{include:$[1200]},
"tree-label":{include:$[1762]},
"list-view":{style:function($0){return {border:new qx.ui.core.Border(1,
$[5],
$[901]),
backgroundColor:$[846]};
}},
"list-view-pane":{style:function($0){return {horizontalSpacing:1};
}},
"list-view-header":{style:function($0){return {border:qx.ui.core.Border.fromConfig({bottom:[1,
$[5],
$[634]]}),
backgroundColor:$[712]};
}},
"list-view-header-cell":{style:function($0){return {padding:[2,
6],
spacing:4,
backgroundColor:$0.over?$[908]:$[7],
paddingBottom:$0.over?0:2,
border:$0.over?new qx.ui.core.Border.fromConfig({bottom:[2,
$[5],
$[74]]}):$[7]};
}},
"list-view-header-cell-arrow-up":{style:function($0){return {source:$[887]};
}},
"list-view-header-cell-arrow-down":{style:function($0){return {source:$[626]};
}},
"list-view-header-separator":{style:function($0){return {backgroundColor:$[634],
width:1,
marginTop:1,
marginBottom:1};
}},
"list-view-content-cell":{style:function($0){return {cursor:$[43],
backgroundColor:$0.selected?$[183]:$[7],
textColor:$0.selected?$[209]:$[7],
border:$0.lead&&
!$0.selected?
new qx.ui.core.Border.fromConfig({top:[1,
$[5],
$[74]],
bottom:[1,
$[5],
$[74]]}):$[7],
marginTop:$0.lead&&!$0.selected?0:1,
marginBottom:$0.lead&&!$0.selected?0:1};
}},
"list-view-content-cell-image":{include:$[393],
style:function($0){return {paddingLeft:6,
paddingRight:6};
}},
"list-view-content-cell-text":{include:$[393],
style:function($0){return {overflow:$[21],
paddingLeft:6,
paddingRight:6};
}},
"list-view-content-cell-html":{include:$[280]},
"list-view-content-cell-icon-html":{include:$[280]},
"list-view-content-cell-link":{include:$[280]},
"group-box":{style:function($0){return {backgroundColor:$[85]};
}},
"group-box-legend":{style:function($0){return {location:[10,
1],
backgroundColor:$[85],
paddingRight:3,
paddingLeft:4,
marginRight:10};
}},
"group-box-frame":{style:function($0){return {edge:[8,
0,
0],
padding:[12,
9],
border:$[163]};
}},
"check-box-group-box-legend":{style:function($0){return {location:[10,
1],
backgroundColor:$[85],
paddingRight:3};
}},
"radio-button-group-box-legend":{include:$[1051]},
"spinner":{style:function($0){return {border:$[72],
backgroundColor:$[220]};
}},
"spinner-text-field":{include:$[157],
style:function($0){return {backgroundColor:$[235]};
}},
"spinner-button":{style:function($0){return {width:16,
backgroundColor:$[85],
paddingLeft:3,
border:$0.pressed||$0.checked||$0.abandoned?$[72]:$[69]};
}},
"spinner-button-up":{include:$[455],
style:function($0){return {source:$[1108]};
}},
"spinner-button-down":{include:$[455],
style:function($0){return {paddingTop:1,
source:$[1842]};
}},
"colorselector":{style:function($0){return {backgroundColor:$[85],
border:$[69]};
}},
"datechooser-toolbar-button":{style:function($0){var $1={backgroundColor:$0.abandoned?$[255]:$[156],
backgroundImage:($0.checked&&!$0.over)?$[495]:null,
spacing:4,
width:$[3],
verticalChildrenAlign:$[30]};
if($0.pressed||$0.checked||$0.abandoned){$1.border=$[208];
}else if($0.over){$1.border=$[206];
}else{$1.border=$[7];
}
if($0.pressed||$0.checked||$0.abandoned){$1.padding=[2,
0,
0,
2];
}else if($0.over){$1.padding=1;
}else{$1.padding=2;
}return $1;
}},
"datechooser-monthyear":{style:function($0){return {font:$[1913],
textAlign:$[52],
verticalAlign:$[30]};
}},
"datechooser-datepane":{style:function($0){return {border:new qx.ui.core.Border(1,
$[5],
$[161]),
backgroundColor:$[282]};
}},
"datechooser-weekday":{style:function($0){var $1=qx.ui.core.Border.fromConfig({bottom:[1,
$[5],
$[161]]});
return {border:$1,
font:$[1186],
textAlign:$[52],
textColor:$0.weekend?$[272]:$[282],
backgroundColor:$0.weekend?$[282]:$[272]};
}},
"datechooser-day":{style:function($0){return {textAlign:$[52],
verticalAlign:$[30],
border:$0.today?$[207]:$[7],
textColor:$0.selected?$[209]:$0.otherMonth?$[323]:$[7],
backgroundColor:$0.selected?$[183]:$[7],
padding:[2,
4]};
}},
"datechooser-week":{style:function($0){if($0.header){var $1=qx.ui.core.Border.fromConfig({right:[1,
$[5],
$[161]],
bottom:[1,
$[5],
$[161]]});
}else{var $1=qx.ui.core.Border.fromConfig({right:[1,
$[5],
$[161]]});
}return {textAlign:$[52],
textColor:$[272],
padding:[2,
4],
border:$1};
}},
"table-focus-statusbar":{style:function($0){return {border:qx.ui.core.Border.fromConfig({top:[1,
$[5],
$[10]]}),
paddingLeft:2,
paddingRight:2};
}},
"table-focus-indicator":{style:function($0){var $1;
if($0.editing){$1=new qx.ui.core.Border(2,
$[5],
$[424]);
}else if($0.tableHasFocus){$1=new qx.ui.core.Border(3,
$[5],
$[424]);
}else{$1=new qx.ui.core.Border(3,
$[5],
$[636]);
}return {border:$1};
}},
"table-editor-textfield":{include:$[157],
style:function($0){return {border:$[7],
padding:[0,
2]};
}},
"table-pane":{style:function($0){return {backgroundColor:$[502]};
}},
"table-header":{style:function($0){return {border:qx.ui.core.Border.fromConfig({bottom:[1,
$[5],
$[305]]}),
backgroundColor:$[367]};
}},
"table-menubar-button":{style:function($0){if($0.pressed||$0.checked||$0.abandoned){var $1=$[208];
var $2=[3,
2,
1,
4];
}else if($0.over){var $1=$[206];
var $2=[2,
3];
}else{var $1=$[7];
var $2=[3,
4];
}return {cursor:$[43],
spacing:4,
width:$[3],
border:$1,
padding:$2,
verticalChildrenAlign:$[30],
backgroundColor:$0.abandoned?$[255]:$[156],
icon:$[1185]};
}},
"table-header-cell":{style:function($0){var $1,
$2,
$3;
if($0.mouseover){$1=qx.ui.core.Border.fromConfig({right:[1,
$[5],
$[305]],
bottom:[2,
$[5],
$[74]]});
$3=0;
$2=$[1994];
}else{$1=qx.ui.core.Border.fromConfig({right:[1,
$[5],
$[305]]});
$3=2;
$2=$[603];
}return {paddingLeft:2,
paddingRight:2,
paddingBottom:$3,
spacing:2,
overflow:$[21],
iconPosition:$[14],
verticalChildrenAlign:$[30],
border:$1,
backgroundColor:$2,
icon:$0.sorted?($0.sortedAscending?$[1526]:$[1859]):null,
horizontalChildrenAlign:$[13]};
}},
"table-row":{style:function($0){return {font:$[43],
bgcolFocusedSelected:$[385],
bgcolFocusedSelectedBlur:$[588],
bgcolFocused:$[600],
bgcolFocusedBlur:$[355],
bgcolSelected:$[380],
bgcolSelectedBlur:$[558],
bgcolEven:$[443],
bgcolOdd:$[490],
colSelected:$[596],
colNormal:$[321]};
}},
"splitpane":{style:function($0){return {overflow:$[21],
splitterSize:8,
backgroundColor:$[85]};
}},
"splitpane-splitter":{style:function($0){return {cursor:$0.horizontal?$[368]:$[564]};
}},
"splitpane-slider":{style:function($0){return {opacity:0.5,
backgroundColor:$[85]};
}},
"splitpane-knob":{style:function($0){if($0.horizontal){return {opacity:$0.dragging?0.5:1.0,
top:$[223],
left:$[223],
cursor:$[368],
source:$[886],
marginLeft:-2,
marginTop:-7};
}else{return {opacity:$0.dragging?0.5:1.0,
top:$[223],
left:$[223],
source:$[1469],
marginTop:-2,
marginLeft:-7,
cursor:$[564]};
}}},
"scrollbar-blocker":{style:function($0){return {backgroundColor:$[207],
opacity:0.2};
}}}});




/* ID: qx.theme.icon.Nuvola */
qx.Theme.define($[1689],
{title:$[1560],
icons:{uri:qx.core.Setting.get($[246])+$[1640]}});




/* ID: qx.theme.ClassicRoyale */
qx.Theme.define($[489],
{title:$[1233],
meta:{color:qx.theme.classic.color.Royale,
border:qx.theme.classic.Border,
font:qx.theme.classic.font.Default,
widget:qx.theme.classic.Widget,
appearance:qx.theme.classic.Appearance,
icon:qx.theme.icon.Nuvola}});




/* ID: qx.theme.icon.CrystalClear */
qx.Theme.define($[2008],
{title:$[686],
icons:{uri:qx.core.Setting.get($[246])+$[1806]}});




/* ID: qx.application.Gui */
qx.Class.define($[366],
{extend:qx.core.Target,
implement:qx.application.IApplication,
properties:{uiReady:{check:$[2],
init:false}},
members:{main:function(){this._initializedMain=true;
qx.ui.core.Widget.initScrollbarWidth();
qx.theme.manager.Meta.getInstance().initialize();
qx.event.handler.EventHandler.getInstance();
qx.ui.core.ClientDocument.getInstance();
qx.client.Timer.once(this._preload,
this,
0);
},
close:function(){},
terminate:function(){},
_preload:function(){this.debug("preloading visible images...");
this.__preloader=new qx.io.image.PreloaderSystem(qx.io.image.Manager.getInstance().getVisibleImages(),
this._preloaderDone,
this);
this.__preloader.start();
},
_preloaderDone:function(){this.setUiReady(true);
this.__preloader.dispose();
this.__preloader=null;
var $0=(new Date).valueOf();
qx.ui.core.Widget.flushGlobalQueues();
this.info("render runtime: "+(new Date-$0)+"ms");
qx.event.handler.EventHandler.getInstance().attachEvents();
qx.client.Timer.once(this._postload,
this,
100);
},
_postload:function(){this.debug("preloading hidden images...");
this.__postloader=new qx.io.image.PreloaderSystem(qx.io.image.Manager.getInstance().getHiddenImages(),
this._postloaderDone,
this);
this.__postloader.start();
},
_postloaderDone:function(){this.__postloader.dispose();
this.__postloader=null;
}}});




/* ID: qx.ui.core.Widget */
qx.Class.define($[112],
{extend:qx.core.Target,
type:$[82],
construct:function(){arguments.callee.base.call(this);
this._layoutChanges={};
},
events:{"beforeAppear":$[4],
"appear":$[4],
"beforeDisappear":$[4],
"disappear":$[4],
"beforeInsertDom":$[4],
"insertDom":$[4],
"beforeRemoveDom":$[4],
"removeDom":$[4],
"create":$[4],
"execute":$[4],
"mouseover":$[95],
"mousemove":$[95],
"mouseout":$[95],
"mousedown":$[95],
"mouseup":$[95],
"mousewheel":$[95],
"click":$[95],
"dblclick":$[95],
"contextmenu":$[95],
"keydown":$[201],
"keypress":$[201],
"keyinput":$[201],
"keyup":$[201],
"focusout":$[187],
"focusin":$[187],
"blur":$[187],
"focus":$[187],
"dragdrop":$[182],
"dragout":$[182],
"dragover":$[182],
"dragmove":$[182],
"dragstart":$[182],
"dragend":$[182]},
statics:{create:function($0,
$1){$0._appearance=$1;
return new $0;
},
SCROLLBAR_SIZE:null,
_autoFlushTimeout:null,
_initAutoFlush:function(){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._autoFlushTimeout=window.setTimeout(qx.ui.core.Widget._autoFlushHelper,
0);
}},
_removeAutoFlush:function(){if(qx.ui.core.Widget._autoFlushTimeout!=null){window.clearTimeout(qx.ui.core.Widget._autoFlushTimeout);
qx.ui.core.Widget._autoFlushTimeout=null;
}},
_autoFlushHelper:function(){qx.ui.core.Widget._autoFlushTimeout=null;
if(!qx.core.Object.inGlobalDispose()){qx.ui.core.Widget.flushGlobalQueues();
}},
flushGlobalQueues:function(){if(qx.ui.core.Widget._autoFlushTimeout!=null){qx.ui.core.Widget._removeAutoFlush();
}
if(qx.ui.core.Widget._inFlushGlobalQueues||!qx.core.Init.getInstance().getApplication().getUiReady()){return;
}qx.ui.core.Widget._inFlushGlobalQueues=true;
qx.ui.core.Widget.flushGlobalWidgetQueue();
qx.ui.core.Widget.flushGlobalStateQueue();
qx.ui.core.Widget.flushGlobalElementQueue();
qx.ui.core.Widget.flushGlobalJobQueue();
qx.ui.core.Widget.flushGlobalLayoutQueue();
qx.ui.core.Widget.flushGlobalDisplayQueue();
delete qx.ui.core.Widget._inFlushGlobalQueues;
},
_globalWidgetQueue:[],
addToGlobalWidgetQueue:function($0){if(!$0._isInGlobalWidgetQueue&&$0._isDisplayable){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._initAutoFlush();
}qx.ui.core.Widget._globalWidgetQueue.push($0);
$0._isInGlobalWidgetQueue=true;
}},
removeFromGlobalWidgetQueue:function($0){if($0._isInGlobalWidgetQueue){qx.lang.Array.remove(qx.ui.core.Widget._globalWidgetQueue,
$0);
delete $0._isInGlobalWidgetQueue;
}},
flushGlobalWidgetQueue:function(){var $0=qx.ui.core.Widget._globalWidgetQueue,
$1,
$2;
while(($1=$0.length)>0){for(var $3=0;$3<$1;$3++){$2=$0[$3];
$2.flushWidgetQueue();
delete $2._isInGlobalWidgetQueue;
}$0.splice(0,
$1);
}},
_globalElementQueue:[],
addToGlobalElementQueue:function($0){if(!$0._isInGlobalElementQueue&&$0._isDisplayable){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._initAutoFlush();
}qx.ui.core.Widget._globalElementQueue.push($0);
$0._isInGlobalElementQueue=true;
}},
removeFromGlobalElementQueue:function($0){if($0._isInGlobalElementQueue){qx.lang.Array.remove(qx.ui.core.Widget._globalElementQueue,
$0);
delete $0._isInGlobalElementQueue;
}},
flushGlobalElementQueue:function(){var $0=qx.ui.core.Widget._globalElementQueue,
$1,
$2;
while(($1=$0.length)>0){for(var $3=0;$3<$1;$3++){$2=$0[$3];
$2._createElementImpl();
delete $2._isInGlobalElementQueue;
}$0.splice(0,
$1);
}},
_globalStateQueue:[],
addToGlobalStateQueue:function($0){if(!$0._isInGlobalStateQueue&&$0._isDisplayable){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._initAutoFlush();
}qx.ui.core.Widget._globalStateQueue.push($0);
$0._isInGlobalStateQueue=true;
}},
removeFromGlobalStateQueue:function($0){if($0._isInGlobalStateQueue){qx.lang.Array.remove(qx.ui.core.Widget._globalStateQueue,
$0);
delete $0._isInGlobalStateQueue;
}},
flushGlobalStateQueue:function(){var $0=qx.ui.core.Widget._globalStateQueue,
$1,
$2;
while(($1=$0.length)>0){for(var $3=0;$3<$1;$3++){$2=$0[$3];
$2._renderAppearance();
delete $2._isInGlobalStateQueue;
}$0.splice(0,
$1);
}},
_globalJobQueue:[],
addToGlobalJobQueue:function($0){if(!$0._isInGlobalJobQueue&&$0._isDisplayable){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._initAutoFlush();
}qx.ui.core.Widget._globalJobQueue.push($0);
$0._isInGlobalJobQueue=true;
}},
removeFromGlobalJobQueue:function($0){if($0._isInGlobalJobQueue){qx.lang.Array.remove(qx.ui.core.Widget._globalJobQueue,
$0);
delete $0._isInGlobalJobQueue;
}},
flushGlobalJobQueue:function(){var $0=qx.ui.core.Widget._globalJobQueue,
$1,
$2;
while(($1=$0.length)>0){for(var $3=0;$3<$1;$3++){$2=$0[$3];
$2._flushJobQueue($2._jobQueue);
delete $2._isInGlobalJobQueue;
}$0.splice(0,
$1);
}},
_globalLayoutQueue:[],
addToGlobalLayoutQueue:function($0){if(!$0._isInGlobalLayoutQueue&&$0._isDisplayable){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._initAutoFlush();
}qx.ui.core.Widget._globalLayoutQueue.push($0);
$0._isInGlobalLayoutQueue=true;
}},
removeFromGlobalLayoutQueue:function($0){if($0._isInGlobalLayoutQueue){qx.lang.Array.remove(qx.ui.core.Widget._globalLayoutQueue,
$0);
delete $0._isInGlobalLayoutQueue;
}},
flushGlobalLayoutQueue:function(){var $0=qx.ui.core.Widget._globalLayoutQueue,
$1,
$2;
while(($1=$0.length)>0){for(var $3=0;$3<$1;$3++){$2=$0[$3];
$2._flushChildrenQueue();
delete $2._isInGlobalLayoutQueue;
}$0.splice(0,
$1);
}},
_fastGlobalDisplayQueue:[],
_lazyGlobalDisplayQueues:{},
addToGlobalDisplayQueue:function($0){if(!$0._isInGlobalDisplayQueue&&$0._isDisplayable){if(qx.ui.core.Widget._autoFlushTimeout==null){qx.ui.core.Widget._initAutoFlush();
}var $1=$0.getParent();
if($1.isSeeable()){var $2=$1.toHashCode();
if(qx.ui.core.Widget._lazyGlobalDisplayQueues[$2]){qx.ui.core.Widget._lazyGlobalDisplayQueues[$2].push($0);
}else{qx.ui.core.Widget._lazyGlobalDisplayQueues[$2]=[$0];
}}else{qx.ui.core.Widget._fastGlobalDisplayQueue.push($0);
}$0._isInGlobalDisplayQueue=true;
}},
removeFromGlobalDisplayQueue:function($0){},
flushGlobalDisplayQueue:function(){var $0,
$1,
$2,
$3;
var $4=qx.ui.core.Widget._fastGlobalDisplayQueue;
var $5=qx.ui.core.Widget._lazyGlobalDisplayQueues;
for(var $6=0,
$7=$4.length;$6<$7;$6++){$2=$4[$6];
$2.getParent()._getTargetNode().appendChild($2.getElement());
}if(qx.Class.isDefined($[675])){for($0 in $5){$1=$5[$0];
for(var $6=0;$6<$1.length;$6++){$2=$1[$6];
if($2 instanceof qx.ui.basic.Inline){$2._beforeInsertDom();
try{document.getElementById($2.getInlineNodeId()).appendChild($2.getElement());
}catch(ex){$2.debug("Could not append to inline id: "+$2.getInlineNodeId(),
ex);
}$2._afterInsertDom();
$2._afterAppear();
qx.lang.Array.remove($1,
$2);
$6--;
delete $2._isInGlobalDisplayQueue;
}}}}for($0 in $5){$1=$5[$0];
if(document.createDocumentFragment&&$1.length>=3){$3=document.createDocumentFragment();
for(var $6=0,
$7=$1.length;$6<$7;$6++){$2=$1[$6];
$2._beforeInsertDom();
$3.appendChild($2.getElement());
}$1[0].getParent()._getTargetNode().appendChild($3);
for(var $6=0,
$7=$1.length;$6<$7;$6++){$2=$1[$6];
$2._afterInsertDom();
}}else{for(var $6=0,
$7=$1.length;$6<$7;$6++){$2=$1[$6];
$2._beforeInsertDom();
$2.getParent()._getTargetNode().appendChild($2.getElement());
$2._afterInsertDom();
}}}for($0 in $5){$1=$5[$0];
for(var $6=0,
$7=$1.length;$6<$7;$6++){$2=$1[$6];
if($2.getVisibility()){$2._afterAppear();
}delete $2._isInGlobalDisplayQueue;
}delete $5[$0];
}for(var $6=0,
$7=$4.length;$6<$7;$6++){delete $4[$6]._isInGlobalDisplayQueue;
}qx.lang.Array.removeAll($4);
},
getActiveSiblingHelperIgnore:function($0,
$1){for(var $2=0;$2<$0.length;$2++){if($1 instanceof $0[$2]){return true;
}}return false;
},
getActiveSiblingHelper:function($0,
$1,
$2,
$3,
$4){if(!$3){$3=[];
}var $5=$1.getChildren();
var $6=$4==null?$5.indexOf($0)+$2:$4===$[469]?0:$5.length-1;
var $7=$5[$6];
while($7&&(!$7.getEnabled()||qx.ui.core.Widget.getActiveSiblingHelperIgnore($3,
$7))){$6+=$2;
$7=$5[$6];
if(!$7){return null;
}}return $7;
},
__initApplyMethods:function($0){var $1=$[1970];
var $2=$[1005];
var $3=$[1888];
var $4=$[1161];
var $5=$[548];
var $6=[$[13],
$[14],
$[23],
$[22],
$[26],
$[32],
$[65],
$[66],
$[89],
$[88]];
var $7=[$[147],
$[148],
$[1362],
$[1909],
$[1115],
$[754],
$[1886],
$[1246],
$[2040],
$[1810]];
var $8=$1+$[546];
var $9=$2+$[546];
var $a=$3+$[497];
for(var $b=0;$b<4;$b++){$0[$8+$7[$b]]=new Function($5,
$a+$7[$b]+$4);
$0[$9+$7[$b]]=new Function($a+$7[$b]+$[333]);
}var $c=$1+$[556];
var $d=$2+$[556];
var $e=$3+$[911];
if(qx.core.Variant.isSet($[1],
$[25])){for(var $b=0;$b<4;$b++){$0[$c+$7[$b]]=new Function($5,
$e+$7[$b]+$4);
$0[$d+$7[$b]]=new Function($e+$7[$b]+$[333]);
}}else{for(var $b=0;$b<4;$b++){$0[$c+$7[$b]]=new Function($5,
$[1703]+$7[$b]+$[1581]);
$0[$d+$7[$b]]=new Function($[723]+$7[$b]+$[1061]);
}}for(var $b=0;$b<$6.length;$b++){$0[$1+$7[$b]]=new Function($5,
$3+$6[$b]+$4);
$0[$2+$7[$b]]=new Function($3+$6[$b]+$[333]);
}},
TYPE_NULL:0,
TYPE_PIXEL:1,
TYPE_PERCENT:2,
TYPE_AUTO:3,
TYPE_FLEX:4,
layoutPropertyTypes:{},
__initLayoutProperties:function($0){var $1=[$[26],
$[32],
$[65],
$[66],
$[89],
$[88],
$[13],
$[14],
$[23],
$[22]];
for(var $2=0,
$3=$1.length,
$4,
$5,
$6;$2<$3;$2++){$4=$1[$2];
$5=$[1219]+qx.lang.String.toFirstUp($4);
$6=$5+$[845];
$0.layoutPropertyTypes[$4]={dataType:$6,
dataParsed:$5+$[1410],
dataValue:$5+$[996],
typePixel:$6+$[774],
typePercent:$6+$[1278],
typeAuto:$6+$[1993],
typeFlex:$6+$[1678],
typeNull:$6+$[972]};
}},
initScrollbarWidth:function(){var $0=document.createElement($[101]);
var $1=$0.style;
$1.height=$1.width=$[274];
$1.overflow=$[40];
document.body.appendChild($0);
var $2=qx.html.Dimension.getScrollBarSizeRight($0);
qx.ui.core.Widget.SCROLLBAR_SIZE=$2?$2:16;
document.body.removeChild($0);
}},
properties:{enabled:{init:$[127],
check:$[2],
inheritable:true,
apply:$[325],
event:$[1492]},
parent:{check:$[330],
nullable:true,
event:$[762],
apply:$[1497]},
element:{check:$[1825],
nullable:true,
apply:$[1515],
event:$[750]},
visibility:{check:$[2],
init:true,
apply:$[1316],
event:$[1818]},
display:{check:$[2],
init:true,
apply:$[1371],
event:$[1559]},
anonymous:{check:$[2],
init:false,
event:$[796]},
horizontalAlign:{check:[$[13],
$[52],
$[14]],
themeable:true,
nullable:true},
verticalAlign:{check:[$[23],
$[30],
$[22]],
themeable:true,
nullable:true},
allowStretchX:{check:$[2],
init:true},
allowStretchY:{check:$[2],
init:true},
zIndex:{check:$[12],
apply:$[1060],
event:$[1326],
themeable:true,
nullable:true,
init:null},
backgroundColor:{nullable:true,
init:null,
check:$[34],
apply:$[1280],
event:$[1094],
themeable:true},
textColor:{nullable:true,
init:$[127],
check:$[34],
apply:$[1664],
event:$[781],
themeable:true,
inheritable:true},
border:{nullable:true,
init:null,
apply:$[864],
event:$[1923],
check:$[646],
themeable:true},
font:{nullable:true,
init:$[127],
apply:$[703],
check:$[659],
event:$[973],
themeable:true,
inheritable:true},
opacity:{check:$[12],
apply:$[1041],
themeable:true,
nullable:true,
init:null},
cursor:{check:$[9],
apply:$[1816],
themeable:true,
nullable:true,
init:null},
backgroundImage:{check:$[9],
nullable:true,
apply:$[775],
themeable:true},
overflow:{check:[$[21],
$[3],
$[40],
$[122],
$[104]],
nullable:true,
apply:$[974],
event:$[1608],
themeable:true,
init:null},
clipLeft:{check:$[6],
apply:$[265],
themeable:true,
nullable:true},
clipTop:{check:$[6],
apply:$[265],
themeable:true,
nullable:true},
clipWidth:{check:$[6],
apply:$[265],
themeable:true,
nullable:true},
clipHeight:{check:$[6],
apply:$[265],
themeable:true,
nullable:true},
tabIndex:{check:$[6],
nullable:true,
init:null,
apply:$[1077],
event:$[1967]},
hideFocus:{check:$[2],
init:false,
apply:$[1480],
themeable:true},
enableElementFocus:{check:$[2],
init:true},
focused:{check:$[2],
init:false,
apply:$[940],
event:$[463]},
selectable:{check:$[2],
init:null,
nullable:true,
apply:$[765]},
toolTip:{check:$[261],
nullable:true},
contextMenu:{check:$[175],
nullable:true},
capture:{check:$[2],
init:false,
apply:$[1971],
event:$[479]},
dropDataTypes:{nullable:true},
command:{check:$[1633],
nullable:true,
apply:$[1639]},
appearance:{check:$[9],
init:$[288],
apply:$[1039],
event:$[1079]},
supportsDropMethod:{check:$[68],
nullable:true,
init:null},
marginTop:{check:$[12],
apply:$[1311],
nullable:true,
themeable:true},
marginRight:{check:$[12],
apply:$[1675],
nullable:true,
themeable:true},
marginBottom:{check:$[12],
apply:$[764],
nullable:true,
themeable:true},
marginLeft:{check:$[12],
apply:$[1508],
nullable:true,
themeable:true},
paddingTop:{check:$[12],
apply:$[955],
nullable:true,
themeable:true},
paddingRight:{check:$[12],
apply:$[1922],
nullable:true,
themeable:true},
paddingBottom:{check:$[12],
apply:$[1784],
nullable:true,
themeable:true},
paddingLeft:{check:$[12],
apply:$[1071],
nullable:true,
themeable:true},
left:{apply:$[1166],
event:$[1696],
nullable:true,
themeable:true,
init:null},
right:{apply:$[869],
event:$[1095],
nullable:true,
themeable:true,
init:null},
width:{apply:$[1561],
event:$[1522],
nullable:true,
themeable:true,
init:null},
minWidth:{apply:$[1632],
event:$[1936],
nullable:true,
themeable:true,
init:null},
maxWidth:{apply:$[1320],
event:$[2039],
nullable:true,
themeable:true,
init:null},
top:{apply:$[1734],
event:$[1699],
nullable:true,
themeable:true,
init:null},
bottom:{apply:$[852],
event:$[1183],
nullable:true,
themeable:true,
init:null},
height:{apply:$[1685],
event:$[1750],
nullable:true,
themeable:true,
init:null},
minHeight:{apply:$[807],
event:$[1566],
nullable:true,
themeable:true,
init:null},
maxHeight:{apply:$[879],
event:$[1563],
nullable:true,
themeable:true,
init:null},
location:{group:[$[13],
$[23]],
themeable:true},
dimension:{group:[$[26],
$[32]],
themeable:true},
space:{group:[$[13],
$[26],
$[23],
$[32]],
themeable:true},
edge:{group:[$[23],
$[14],
$[22],
$[13]],
themeable:true,
mode:$[111]},
padding:{group:[$[228],
$[267],
$[252],
$[264]],
mode:$[111],
themeable:true},
margin:{group:[$[168],
$[242],
$[257],
$[174]],
mode:$[111],
themeable:true},
heights:{group:[$[89],
$[32],
$[88]],
themeable:true},
widths:{group:[$[65],
$[26],
$[66]],
themeable:true},
align:{group:[$[1950],
$[951]],
themeable:true},
clipLocation:{group:[$[612],
$[531]]},
clipDimension:{group:[$[623],
$[429]]},
clip:{group:[$[612],
$[531],
$[623],
$[429]]},
innerWidth:{_cached:true,
defaultValue:null},
innerHeight:{_cached:true,
defaultValue:null},
boxWidth:{_cached:true,
defaultValue:null},
boxHeight:{_cached:true,
defaultValue:null},
outerWidth:{_cached:true,
defaultValue:null},
outerHeight:{_cached:true,
defaultValue:null},
frameWidth:{_cached:true,
defaultValue:null,
addToQueueRuntime:true},
frameHeight:{_cached:true,
defaultValue:null,
addToQueueRuntime:true},
preferredInnerWidth:{_cached:true,
defaultValue:null,
addToQueueRuntime:true},
preferredInnerHeight:{_cached:true,
defaultValue:null,
addToQueueRuntime:true},
preferredBoxWidth:{_cached:true,
defaultValue:null},
preferredBoxHeight:{_cached:true,
defaultValue:null},
hasPercentX:{_cached:true,
defaultValue:false},
hasPercentY:{_cached:true,
defaultValue:false},
hasAutoX:{_cached:true,
defaultValue:false},
hasAutoY:{_cached:true,
defaultValue:false},
hasFlexX:{_cached:true,
defaultValue:false},
hasFlexY:{_cached:true,
defaultValue:false}},
members:{_computedLeftValue:null,
_computedLeftParsed:null,
_computedLeftType:null,
_computedLeftTypeNull:true,
_computedLeftTypePixel:false,
_computedLeftTypePercent:false,
_computedLeftTypeAuto:false,
_computedLeftTypeFlex:false,
_computedRightValue:null,
_computedRightParsed:null,
_computedRightType:null,
_computedRightTypeNull:true,
_computedRightTypePixel:false,
_computedRightTypePercent:false,
_computedRightTypeAuto:false,
_computedRightTypeFlex:false,
_computedTopValue:null,
_computedTopParsed:null,
_computedTopType:null,
_computedTopTypeNull:true,
_computedTopTypePixel:false,
_computedTopTypePercent:false,
_computedTopTypeAuto:false,
_computedTopTypeFlex:false,
_computedBottomValue:null,
_computedBottomParsed:null,
_computedBottomType:null,
_computedBottomTypeNull:true,
_computedBottomTypePixel:false,
_computedBottomTypePercent:false,
_computedBottomTypeAuto:false,
_computedBottomTypeFlex:false,
_computedWidthValue:null,
_computedWidthParsed:null,
_computedWidthType:null,
_computedWidthTypeNull:true,
_computedWidthTypePixel:false,
_computedWidthTypePercent:false,
_computedWidthTypeAuto:false,
_computedWidthTypeFlex:false,
_computedMinWidthValue:null,
_computedMinWidthParsed:null,
_computedMinWidthType:null,
_computedMinWidthTypeNull:true,
_computedMinWidthTypePixel:false,
_computedMinWidthTypePercent:false,
_computedMinWidthTypeAuto:false,
_computedMinWidthTypeFlex:false,
_computedMaxWidthValue:null,
_computedMaxWidthParsed:null,
_computedMaxWidthType:null,
_computedMaxWidthTypeNull:true,
_computedMaxWidthTypePixel:false,
_computedMaxWidthTypePercent:false,
_computedMaxWidthTypeAuto:false,
_computedMaxWidthTypeFlex:false,
_computedHeightValue:null,
_computedHeightParsed:null,
_computedHeightType:null,
_computedHeightTypeNull:true,
_computedHeightTypePixel:false,
_computedHeightTypePercent:false,
_computedHeightTypeAuto:false,
_computedHeightTypeFlex:false,
_computedMinHeightValue:null,
_computedMinHeightParsed:null,
_computedMinHeightType:null,
_computedMinHeightTypeNull:true,
_computedMinHeightTypePixel:false,
_computedMinHeightTypePercent:false,
_computedMinHeightTypeAuto:false,
_computedMinHeightTypeFlex:false,
_computedMaxHeightValue:null,
_computedMaxHeightParsed:null,
_computedMaxHeightType:null,
_computedMaxHeightTypeNull:true,
_computedMaxHeightTypePixel:false,
_computedMaxHeightTypePercent:false,
_computedMaxHeightTypeAuto:false,
_computedMaxHeightTypeFlex:false,
_applyLeft:function($0,
$1){this._unitDetectionPixelPercent($[13],
$0);
this.addToQueue($[13]);
},
_applyRight:function($0,
$1){this._unitDetectionPixelPercent($[14],
$0);
this.addToQueue($[14]);
},
_applyTop:function($0,
$1){this._unitDetectionPixelPercent($[23],
$0);
this.addToQueue($[23]);
},
_applyBottom:function($0,
$1){this._unitDetectionPixelPercent($[22],
$0);
this.addToQueue($[22]);
},
_applyWidth:function($0,
$1){this._unitDetectionPixelPercentAutoFlex($[26],
$0);
this.addToQueue($[26]);
},
_applyMinWidth:function($0,
$1){this._unitDetectionPixelPercentAuto($[65],
$0);
this.addToQueue($[65]);
},
_applyMaxWidth:function($0,
$1){this._unitDetectionPixelPercentAuto($[66],
$0);
this.addToQueue($[66]);
},
_applyHeight:function($0,
$1){this._unitDetectionPixelPercentAutoFlex($[32],
$0);
this.addToQueue($[32]);
},
_applyMinHeight:function($0,
$1){this._unitDetectionPixelPercentAuto($[89],
$0);
this.addToQueue($[89]);
},
_applyMaxHeight:function($0,
$1){this._unitDetectionPixelPercentAuto($[88],
$0);
this.addToQueue($[88]);
},
isMaterialized:function(){var $0=this._element;
return (this._initialLayoutDone&&this._isDisplayable&&qx.html.Style.getStyleProperty($0,
$[173])!=$[11]&&qx.html.Style.getStyleProperty($0,
$[309])!=$[21]&&$0.offsetWidth>0&&$0.offsetHeight>0);
},
pack:function(){this.setWidth(this.getPreferredBoxWidth());
this.setHeight(this.getPreferredBoxHeight());
},
auto:function(){this.setWidth($[3]);
this.setHeight($[3]);
},
getChildren:qx.lang.Function.returnNull,
getChildrenLength:qx.lang.Function.returnZero,
hasChildren:qx.lang.Function.returnFalse,
isEmpty:qx.lang.Function.returnTrue,
indexOf:qx.lang.Function.returnNegativeIndex,
contains:qx.lang.Function.returnFalse,
getVisibleChildren:qx.lang.Function.returnNull,
getVisibleChildrenLength:qx.lang.Function.returnZero,
hasVisibleChildren:qx.lang.Function.returnFalse,
isVisibleEmpty:qx.lang.Function.returnTrue,
_hasParent:false,
_isDisplayable:false,
isDisplayable:function(){return this._isDisplayable;
},
_checkParent:function($0,
$1){if(this.contains($0)){throw new Error("Could not insert myself into a child "+$0+"!");
}return $0;
},
_applyParent:function($0,
$1){if($1){var $2=$1.getChildren().indexOf(this);
this._computedWidthValue=this._computedMinWidthValue=this._computedMaxWidthValue=this._computedLeftValue=this._computedRightValue=null;
this._computedHeightValue=this._computedMinHeightValue=this._computedMaxHeightValue=this._computedTopValue=this._computedBottomValue=null;
this._cachedBoxWidth=this._cachedInnerWidth=this._cachedOuterWidth=null;
this._cachedBoxHeight=this._cachedInnerHeight=this._cachedOuterHeight=null;
qx.lang.Array.removeAt($1.getChildren(),
$2);
$1._invalidateVisibleChildren();
$1._removeChildFromChildrenQueue(this);
$1.getLayoutImpl().updateChildrenOnRemoveChild(this,
$2);
$1.addToJobQueue($[447]);
$1._invalidatePreferredInnerDimensions();
this._oldParent=$1;
}
if($0){this._hasParent=true;
if(typeof this._insertIndex==$[54]){qx.lang.Array.insertAt($0.getChildren(),
this,
this._insertIndex);
delete this._insertIndex;
}else{$0.getChildren().push(this);
}}else{this._hasParent=false;
}qx.core.Property.refresh(this);
return this._handleDisplayable($[390]);
},
_applyDisplay:function($0,
$1){return this._handleDisplayable($[173]);
},
_handleDisplayable:function($0){var $1=this._computeDisplayable();
if(this._isDisplayable==$1&&!($1&&$0==$[390])){return true;
}this._isDisplayable=$1;
var $2=this.getParent();
if($2){$2._invalidateVisibleChildren();
$2._invalidatePreferredInnerDimensions();
}if($0&&this._oldParent&&this._oldParent._initialLayoutDone){var $3=this.getElement();
if($3){if(this.getVisibility()){this._beforeDisappear();
}this._beforeRemoveDom();
this._oldParent._getTargetNode().removeChild($3);
this._afterRemoveDom();
if(this.getVisibility()){this._afterDisappear();
}}delete this._oldParent;
}if($1){if($2._initialLayoutDone){$2.getLayoutImpl().updateChildrenOnAddChild(this,
$2.getChildren().indexOf(this));
$2.addToJobQueue($[1547]);
}this.addToLayoutChanges($[1911]);
this.addToCustomQueues($0);
if(this.getVisibility()){this._beforeAppear();
}if(!this._isCreated){qx.ui.core.Widget.addToGlobalElementQueue(this);
}qx.ui.core.Widget.addToGlobalStateQueue(this);
if(!qx.lang.Object.isEmpty(this._jobQueue)){qx.ui.core.Widget.addToGlobalJobQueue(this);
}
if(!qx.lang.Object.isEmpty(this._childrenQueue)){qx.ui.core.Widget.addToGlobalLayoutQueue(this);
}}else{qx.ui.core.Widget.removeFromGlobalElementQueue(this);
qx.ui.core.Widget.removeFromGlobalStateQueue(this);
qx.ui.core.Widget.removeFromGlobalJobQueue(this);
qx.ui.core.Widget.removeFromGlobalLayoutQueue(this);
this.removeFromCustomQueues($0);
if($2&&$0){if(this.getVisibility()){this._beforeDisappear();
}if($2._initialLayoutDone&&this._initialLayoutDone){$2.getLayoutImpl().updateChildrenOnRemoveChild(this,
$2.getChildren().indexOf(this));
$2.addToJobQueue($[447]);
this._beforeRemoveDom();
$2._getTargetNode().removeChild(this.getElement());
this._afterRemoveDom();
}$2._removeChildFromChildrenQueue(this);
if(this.getVisibility()){this._afterDisappear();
}}}this._handleDisplayableCustom($1,
$2,
$0);
return true;
},
addToCustomQueues:qx.lang.Function.returnTrue,
removeFromCustomQueues:qx.lang.Function.returnTrue,
_handleDisplayableCustom:qx.lang.Function.returnTrue,
_computeDisplayable:function(){return this.getDisplay()&&this._hasParent&&this.getParent()._isDisplayable?true:false;
},
_beforeAppear:function(){this.createDispatchEvent($[865]);
},
_afterAppear:function(){this._isSeeable=true;
this.createDispatchEvent($[210]);
},
_beforeDisappear:function(){this.removeState($[64]);
if(qx.Class.isDefined($[326])){this.removeState($[31]);
this.removeState($[55]);
}this.createDispatchEvent($[1189]);
},
_afterDisappear:function(){this._isSeeable=false;
this.createDispatchEvent($[176]);
},
_isSeeable:false,
isSeeable:function(){return this._isSeeable;
},
isAppearRelevant:function(){return this.getVisibility()&&this._isDisplayable;
},
_beforeInsertDom:function(){this.createDispatchEvent($[1440]);
},
_afterInsertDom:function(){this.createDispatchEvent($[1755]);
},
_beforeRemoveDom:function(){this.createDispatchEvent($[1506]);
},
_afterRemoveDom:function(){this.createDispatchEvent($[1255]);
},
_applyVisibility:function($0,
$1){if($0){if(this._isDisplayable){this._beforeAppear();
}this.removeStyleProperty($[173]);
if(this._isDisplayable){this._afterAppear();
}}else{if(this._isDisplayable){this._beforeDisappear();
}this.setStyleProperty($[173],
$[11]);
if(this._isDisplayable){this._afterDisappear();
}}},
show:function(){this.setVisibility(true);
this.setDisplay(true);
},
hide:function(){this.setVisibility(false);
},
connect:function(){this.setDisplay(true);
},
disconnect:function(){this.setDisplay(false);
},
_isCreated:false,
_getTargetNode:qx.core.Variant.select($[1],
{"gecko":function(){return this._element;
},
"default":function(){return this._borderElement||this._element;
}}),
addToDocument:function(){qx.ui.core.ClientDocument.getInstance().add(this);
},
isCreated:function(){return this._isCreated;
},
_createElementImpl:function(){this.setElement(this.getTopLevelWidget().getDocumentElement().createElement($[101]));
},
_applyElement:function($0,
$1){this._isCreated=$0!=null;
if($1){$1.qx_Widget=null;
}
if($0){$0.qx_Widget=this;
$0.style.position=$[63];
this._element=$0;
this._style=$0.style;
this._applyStyleProperties($0);
this._applyHtmlProperties($0);
this._applyHtmlAttributes($0);
this._applyElementData($0);
this.createDispatchEvent($[1341]);
this.addToStateQueue();
}else{this._element=this._style=null;
}},
addToJobQueue:function($0){if(this._hasParent){qx.ui.core.Widget.addToGlobalJobQueue(this);
}
if(!this._jobQueue){this._jobQueue={};
}this._jobQueue[$0]=true;
return true;
},
_flushJobQueue:function($0){try{var $1=this._jobQueue;
var $2=this.getParent();
if(!$2||qx.lang.Object.isEmpty($1)){return;
}var $3=this instanceof qx.ui.core.Parent?this.getLayoutImpl():null;
if($3){$3.updateSelfOnJobQueueFlush($1);
}}catch(ex){this.error("Flushing job queue (prechecks#1) failed",
ex);
}try{var $4=false;
var $5=$1.marginLeft||$1.marginRight;
var $6=$1.marginTop||$1.marginBottom;
var $7=$1.frameWidth;
var $8=$1.frameHeight;
var $9=($1.frameWidth||$1.preferredInnerWidth)&&this._recomputePreferredBoxWidth();
var $a=($1.frameHeight||$1.preferredInnerHeight)&&this._recomputePreferredBoxHeight();
if($9){var $b=this.getPreferredBoxWidth();
if(this._computedWidthTypeAuto){this._computedWidthValue=$b;
$1.width=true;
}
if(this._computedMinWidthTypeAuto){this._computedMinWidthValue=$b;
$1.minWidth=true;
}
if(this._computedMaxWidthTypeAuto){this._computedMaxWidthValue=$b;
$1.maxWidth=true;
}}
if($a){var $b=this.getPreferredBoxHeight();
if(this._computedHeightTypeAuto){this._computedHeightValue=$b;
$1.height=true;
}
if(this._computedMinHeightTypeAuto){this._computedMinHeightValue=$b;
$1.minHeight=true;
}
if(this._computedMaxHeightTypeAuto){this._computedMaxHeightValue=$b;
$1.maxHeight=true;
}}
if(($1.width||$1.minWidth||$1.maxWidth||$1.left||$1.right)&&this._recomputeBoxWidth()){$5=$7=true;
}
if(($1.height||$1.minHeight||$1.maxHeight||$1.top||$1.bottom)&&this._recomputeBoxHeight()){$6=$8=true;
}}catch(ex){this.error("Flushing job queue (recompute#2) failed",
ex);
}try{if(($5&&this._recomputeOuterWidth())||$9){$2._invalidatePreferredInnerWidth();
$2.getLayoutImpl().updateSelfOnChildOuterWidthChange(this);
$4=true;
}
if(($6&&this._recomputeOuterHeight())||$a){$2._invalidatePreferredInnerHeight();
$2.getLayoutImpl().updateSelfOnChildOuterHeightChange(this);
$4=true;
}
if($4){$2._flushJobQueue();
}}catch(ex){this.error("Flushing job queue (parentsignals#3) failed",
ex);
}try{$2._addChildToChildrenQueue(this);
for(var $c in $1){this._layoutChanges[$c]=true;
}}catch(ex){this.error("Flushing job queue (addjobs#4) failed",
ex);
}try{if(this instanceof qx.ui.core.Parent&&($1.paddingLeft||$1.paddingRight||$1.paddingTop||$1.paddingBottom)){var $d=this.getChildren(),
$e=$d.length;
if($1.paddingLeft){for(var $c=0;$c<$e;$c++){$d[$c].addToLayoutChanges($[1588]);
}}
if($1.paddingRight){for(var $c=0;$c<$e;$c++){$d[$c].addToLayoutChanges($[1059]);
}}
if($1.paddingTop){for(var $c=0;$c<$e;$c++){$d[$c].addToLayoutChanges($[1949]);
}}
if($1.paddingBottom){for(var $c=0;$c<$e;$c++){$d[$c].addToLayoutChanges($[888]);
}}}
if($7){this._recomputeInnerWidth();
}
if($8){this._recomputeInnerHeight();
}
if(this._initialLayoutDone){if($3){$3.updateChildrenOnJobQueueFlush($1);
}}}catch(ex){this.error("Flushing job queue (childrensignals#5) failed",
ex);
}delete this._jobQueue;
},
_isWidthEssential:qx.lang.Function.returnTrue,
_isHeightEssential:qx.lang.Function.returnTrue,
_computeBoxWidthFallback:function(){return 0;
},
_computeBoxHeightFallback:function(){return 0;
},
_computeBoxWidth:function(){var $0=this.getParent().getLayoutImpl();
return Math.max(0,
qx.lang.Number.limit($0.computeChildBoxWidth(this),
this.getMinWidthValue(),
this.getMaxWidthValue()));
},
_computeBoxHeight:function(){var $0=this.getParent().getLayoutImpl();
return Math.max(0,
qx.lang.Number.limit($0.computeChildBoxHeight(this),
this.getMinHeightValue(),
this.getMaxHeightValue()));
},
_computeOuterWidth:function(){return Math.max(0,
(this.getMarginLeft()+this.getBoxWidth()+this.getMarginRight()));
},
_computeOuterHeight:function(){return Math.max(0,
(this.getMarginTop()+this.getBoxHeight()+this.getMarginBottom()));
},
_computeInnerWidth:function(){return Math.max(0,
this.getBoxWidth()-this.getFrameWidth());
},
_computeInnerHeight:function(){return Math.max(0,
this.getBoxHeight()-this.getFrameHeight());
},
getNeededWidth:function(){var $0=this.getParent().getLayoutImpl();
return Math.max(0,
$0.computeChildNeededWidth(this));
},
getNeededHeight:function(){var $0=this.getParent().getLayoutImpl();
return Math.max(0,
$0.computeChildNeededHeight(this));
},
_recomputeFlexX:function(){if(!this.getHasFlexX()){return false;
}
if(this._computedWidthTypeFlex){this._computedWidthValue=null;
this.addToLayoutChanges($[26]);
}return true;
},
_recomputeFlexY:function(){if(!this.getHasFlexY()){return false;
}
if(this._computedHeightTypeFlex){this._computedHeightValue=null;
this.addToLayoutChanges($[32]);
}return true;
},
_recomputePercentX:function(){if(!this.getHasPercentX()){return false;
}
if(this._computedWidthTypePercent){this._computedWidthValue=null;
this.addToLayoutChanges($[26]);
}
if(this._computedMinWidthTypePercent){this._computedMinWidthValue=null;
this.addToLayoutChanges($[65]);
}
if(this._computedMaxWidthTypePercent){this._computedMaxWidthValue=null;
this.addToLayoutChanges($[66]);
}
if(this._computedLeftTypePercent){this._computedLeftValue=null;
this.addToLayoutChanges($[13]);
}
if(this._computedRightTypePercent){this._computedRightValue=null;
this.addToLayoutChanges($[14]);
}return true;
},
_recomputePercentY:function(){if(!this.getHasPercentY()){return false;
}
if(this._computedHeightTypePercent){this._computedHeightValue=null;
this.addToLayoutChanges($[32]);
}
if(this._computedMinHeightTypePercent){this._computedMinHeightValue=null;
this.addToLayoutChanges($[89]);
}
if(this._computedMaxHeightTypePercent){this._computedMaxHeightValue=null;
this.addToLayoutChanges($[88]);
}
if(this._computedTopTypePercent){this._computedTopValue=null;
this.addToLayoutChanges($[23]);
}
if(this._computedBottomTypePercent){this._computedBottomValue=null;
this.addToLayoutChanges($[22]);
}return true;
},
_recomputeRangeX:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function(){if(this._computedLeftTypeNull||this._computedRightTypeNull){return false;
}this.addToLayoutChanges($[26]);
return true;
},
"default":function(){return !(this._computedLeftTypeNull||this._computedRightTypeNull);
}}),
_recomputeRangeY:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function(){if(this._computedTopTypeNull||this._computedBottomTypeNull){return false;
}this.addToLayoutChanges($[32]);
return true;
},
"default":function(){return !(this._computedTopTypeNull||this._computedBottomTypeNull);
}}),
_recomputeStretchingX:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function(){if(this.getAllowStretchX()&&this._computedWidthTypeNull){this._computedWidthValue=null;
this.addToLayoutChanges($[26]);
return true;
}return false;
},
"default":function(){if(this.getAllowStretchX()&&this._computedWidthTypeNull){return true;
}return false;
}}),
_recomputeStretchingY:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function(){if(this.getAllowStretchY()&&this._computedHeightTypeNull){this._computedHeightValue=null;
this.addToLayoutChanges($[32]);
return true;
}return false;
},
"default":function(){if(this.getAllowStretchY()&&this._computedHeightTypeNull){return true;
}return false;
}}),
_computeValuePixel:function($0){return Math.round($0);
},
_computeValuePixelLimit:function($0){return Math.max(0,
this._computeValuePixel($0));
},
_computeValuePercentX:function($0){return Math.round(this.getParent().getInnerWidthForChild(this)*$0*0.01);
},
_computeValuePercentXLimit:function($0){return Math.max(0,
this._computeValuePercentX($0));
},
_computeValuePercentY:function($0){return Math.round(this.getParent().getInnerHeightForChild(this)*$0*0.01);
},
_computeValuePercentYLimit:function($0){return Math.max(0,
this._computeValuePercentY($0));
},
getWidthValue:function(){if(this._computedWidthValue!=null){return this._computedWidthValue;
}
switch(this._computedWidthType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedWidthValue=this._computeValuePixelLimit(this._computedWidthParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedWidthValue=this._computeValuePercentXLimit(this._computedWidthParsed);
case qx.ui.core.Widget.TYPE_AUTO:return this._computedWidthValue=this.getPreferredBoxWidth();
case qx.ui.core.Widget.TYPE_FLEX:if(this.getParent().getLayoutImpl().computeChildrenFlexWidth===undefined){throw new Error("Widget "+this+": having horizontal flex size (width="+this.getWidth()+") but parent layout "+this.getParent()+" does not support it");
}this.getParent().getLayoutImpl().computeChildrenFlexWidth();
return this._computedWidthValue=this._computedWidthFlexValue;
}return null;
},
getMinWidthValue:function(){if(this._computedMinWidthValue!=null){return this._computedMinWidthValue;
}
switch(this._computedMinWidthType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedWidthValue=this._computeValuePixelLimit(this._computedMinWidthParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedWidthValue=this._computeValuePercentXLimit(this._computedMinWidthParsed);
case qx.ui.core.Widget.TYPE_AUTO:return this._computedMinWidthValue=this.getPreferredBoxWidth();
}return null;
},
getMaxWidthValue:function(){if(this._computedMaxWidthValue!=null){return this._computedMaxWidthValue;
}
switch(this._computedMaxWidthType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedWidthValue=this._computeValuePixelLimit(this._computedMaxWidthParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedWidthValue=this._computeValuePercentXLimit(this._computedMaxWidthParsed);
case qx.ui.core.Widget.TYPE_AUTO:return this._computedMaxWidthValue=this.getPreferredBoxWidth();
}return null;
},
getLeftValue:function(){if(this._computedLeftValue!=null){return this._computedLeftValue;
}
switch(this._computedLeftType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedLeftValue=this._computeValuePixel(this._computedLeftParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedLeftValue=this._computeValuePercentX(this._computedLeftParsed);
}return null;
},
getRightValue:function(){if(this._computedRightValue!=null){return this._computedRightValue;
}
switch(this._computedRightType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedRightValue=this._computeValuePixel(this._computedRightParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedRightValue=this._computeValuePercentX(this._computedRightParsed);
}return null;
},
getHeightValue:function(){if(this._computedHeightValue!=null){return this._computedHeightValue;
}
switch(this._computedHeightType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedHeightValue=this._computeValuePixelLimit(this._computedHeightParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedHeightValue=this._computeValuePercentYLimit(this._computedHeightParsed);
case qx.ui.core.Widget.TYPE_AUTO:return this._computedHeightValue=this.getPreferredBoxHeight();
case qx.ui.core.Widget.TYPE_FLEX:if(this.getParent().getLayoutImpl().computeChildrenFlexHeight===undefined){throw new Error("Widget "+this+": having vertical flex size (height="+this.getHeight()+") but parent layout "+this.getParent()+" does not support it");
}this.getParent().getLayoutImpl().computeChildrenFlexHeight();
return this._computedHeightValue=this._computedHeightFlexValue;
}return null;
},
getMinHeightValue:function(){if(this._computedMinHeightValue!=null){return this._computedMinHeightValue;
}
switch(this._computedMinHeightType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedMinHeightValue=this._computeValuePixelLimit(this._computedMinHeightParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedMinHeightValue=this._computeValuePercentYLimit(this._computedMinHeightParsed);
case qx.ui.core.Widget.TYPE_AUTO:return this._computedMinHeightValue=this.getPreferredBoxHeight();
}return null;
},
getMaxHeightValue:function(){if(this._computedMaxHeightValue!=null){return this._computedMaxHeightValue;
}
switch(this._computedMaxHeightType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedMaxHeightValue=this._computeValuePixelLimit(this._computedMaxHeightParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedMaxHeightValue=this._computeValuePercentYLimit(this._computedMaxHeightParsed);
case qx.ui.core.Widget.TYPE_AUTO:return this._computedMaxHeightValue=this.getPreferredBoxHeight();
}return null;
},
getTopValue:function(){if(this._computedTopValue!=null){return this._computedTopValue;
}
switch(this._computedTopType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedTopValue=this._computeValuePixel(this._computedTopParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedTopValue=this._computeValuePercentY(this._computedTopParsed);
}return null;
},
getBottomValue:function(){if(this._computedBottomValue!=null){return this._computedBottomValue;
}
switch(this._computedBottomType){case qx.ui.core.Widget.TYPE_PIXEL:return this._computedBottomValue=this._computeValuePixel(this._computedBottomParsed);
case qx.ui.core.Widget.TYPE_PERCENT:return this._computedBottomValue=this._computeValuePercentY(this._computedBottomParsed);
}return null;
},
_computeFrameWidth:function(){var $0=this._cachedBorderLeft+this.getPaddingLeft()+this.getPaddingRight()+this._cachedBorderRight;
switch(this.getOverflow()){case $[40]:case $[104]:$0+=qx.ui.core.Widget.SCROLLBAR_SIZE;
break;
case $[3]:break;
}return $0;
},
_computeFrameHeight:function(){var $0=this._cachedBorderTop+this.getPaddingTop()+this.getPaddingBottom()+this._cachedBorderBottom;
switch(this.getOverflow()){case $[40]:case $[122]:$0+=qx.ui.core.Widget.SCROLLBAR_SIZE;
break;
case $[3]:break;
}return $0;
},
_invalidateFrameDimensions:function(){this._invalidateFrameWidth();
this._invalidateFrameHeight();
},
_invalidatePreferredInnerDimensions:function(){this._invalidatePreferredInnerWidth();
this._invalidatePreferredInnerHeight();
},
_computePreferredBoxWidth:function(){try{return Math.max(0,
this.getPreferredInnerWidth()+this.getFrameWidth());
}catch(ex){this.error("_computePreferredBoxWidth failed",
ex);
}},
_computePreferredBoxHeight:function(){try{return Math.max(0,
this.getPreferredInnerHeight()+this.getFrameHeight());
}catch(ex){this.error("_computePreferredBoxHeight failed",
ex);
}},
_initialLayoutDone:false,
addToLayoutChanges:function($0){if(this._isDisplayable){this.getParent()._addChildToChildrenQueue(this);
}return this._layoutChanges[$0]=true;
},
addToQueue:function($0){this._initialLayoutDone?this.addToJobQueue($0):this.addToLayoutChanges($0);
},
addToQueueRuntime:function($0){return !this._initialLayoutDone||this.addToJobQueue($0);
},
_computeHasPercentX:function(){return (this._computedLeftTypePercent||this._computedWidthTypePercent||this._computedMinWidthTypePercent||this._computedMaxWidthTypePercent||this._computedRightTypePercent);
},
_computeHasPercentY:function(){return (this._computedTopTypePercent||this._computedHeightTypePercent||this._computedMinHeightTypePercent||this._computedMaxHeightTypePercent||this._computedBottomTypePercent);
},
_computeHasAutoX:function(){return (this._computedWidthTypeAuto||this._computedMinWidthTypeAuto||this._computedMaxWidthTypeAuto);
},
_computeHasAutoY:function(){return (this._computedHeightTypeAuto||this._computedMinHeightTypeAuto||this._computedMaxHeightTypeAuto);
},
_computeHasFlexX:function(){return this._computedWidthTypeFlex;
},
_computeHasFlexY:function(){return this._computedHeightTypeFlex;
},
_evalUnitsPixelPercentAutoFlex:function($0){switch($0){case $[3]:return qx.ui.core.Widget.TYPE_AUTO;
case Infinity:case -Infinity:return qx.ui.core.Widget.TYPE_NULL;
}
switch(typeof $0){case $[54]:return isNaN($0)?qx.ui.core.Widget.TYPE_NULL:qx.ui.core.Widget.TYPE_PIXEL;
case $[8]:return $0.indexOf($[230])!=-1?qx.ui.core.Widget.TYPE_PERCENT:$0.indexOf($[153])!=-1?qx.ui.core.Widget.TYPE_FLEX:qx.ui.core.Widget.TYPE_NULL;
}return qx.ui.core.Widget.TYPE_NULL;
},
_evalUnitsPixelPercentAuto:function($0){switch($0){case $[3]:return qx.ui.core.Widget.TYPE_AUTO;
case Infinity:case -Infinity:return qx.ui.core.Widget.TYPE_NULL;
}
switch(typeof $0){case $[54]:return isNaN($0)?qx.ui.core.Widget.TYPE_NULL:qx.ui.core.Widget.TYPE_PIXEL;
case $[8]:return $0.indexOf($[230])!=-1?qx.ui.core.Widget.TYPE_PERCENT:qx.ui.core.Widget.TYPE_NULL;
}return qx.ui.core.Widget.TYPE_NULL;
},
_evalUnitsPixelPercent:function($0){switch($0){case Infinity:case -Infinity:return qx.ui.core.Widget.TYPE_NULL;
}
switch(typeof $0){case $[54]:return isNaN($0)?qx.ui.core.Widget.TYPE_NULL:qx.ui.core.Widget.TYPE_PIXEL;
case $[8]:return $0.indexOf($[230])!=-1?qx.ui.core.Widget.TYPE_PERCENT:qx.ui.core.Widget.TYPE_NULL;
}return qx.ui.core.Widget.TYPE_NULL;
},
_unitDetectionPixelPercentAutoFlex:function($0,
$1){var $2=qx.ui.core.Widget.layoutPropertyTypes[$0];
var $3=$2.dataType;
var $4=$2.dataParsed;
var $5=$2.dataValue;
var $6=$2.typePixel;
var $7=$2.typePercent;
var $8=$2.typeAuto;
var $9=$2.typeFlex;
var $a=$2.typeNull;
var $b=this[$7];
var $c=this[$8];
var $d=this[$9];
switch(this[$3]=this._evalUnitsPixelPercentAutoFlex($1)){case qx.ui.core.Widget.TYPE_PIXEL:this[$6]=true;
this[$7]=this[$8]=this[$9]=this[$a]=false;
this[$4]=this[$5]=Math.round($1);
break;
case qx.ui.core.Widget.TYPE_PERCENT:this[$7]=true;
this[$6]=this[$8]=this[$9]=this[$a]=false;
this[$4]=parseFloat($1);
this[$5]=null;
break;
case qx.ui.core.Widget.TYPE_AUTO:this[$8]=true;
this[$6]=this[$7]=this[$9]=this[$a]=false;
this[$4]=this[$5]=null;
break;
case qx.ui.core.Widget.TYPE_FLEX:this[$9]=true;
this[$6]=this[$7]=this[$8]=this[$a]=false;
this[$4]=parseFloat($1);
this[$5]=null;
break;
default:this[$a]=true;
this[$6]=this[$7]=this[$8]=this[$9]=false;
this[$4]=this[$5]=null;
break;
}
if($b!=this[$7]){switch($0){case $[65]:case $[66]:case $[26]:case $[13]:case $[14]:this._invalidateHasPercentX();
break;
case $[88]:case $[89]:case $[32]:case $[23]:case $[22]:this._invalidateHasPercentY();
break;
}}if($c!=this[$8]){switch($0){case $[65]:case $[66]:case $[26]:this._invalidateHasAutoX();
break;
case $[89]:case $[88]:case $[32]:this._invalidateHasAutoY();
break;
}}if($d!=this[$9]){switch($0){case $[26]:this._invalidateHasFlexX();
break;
case $[32]:this._invalidateHasFlexY();
break;
}}},
_unitDetectionPixelPercentAuto:function($0,
$1){var $2=qx.ui.core.Widget.layoutPropertyTypes[$0];
var $3=$2.dataType;
var $4=$2.dataParsed;
var $5=$2.dataValue;
var $6=$2.typePixel;
var $7=$2.typePercent;
var $8=$2.typeAuto;
var $9=$2.typeNull;
var $a=this[$7];
var $b=this[$8];
switch(this[$3]=this._evalUnitsPixelPercentAuto($1)){case qx.ui.core.Widget.TYPE_PIXEL:this[$6]=true;
this[$7]=this[$8]=this[$9]=false;
this[$4]=this[$5]=Math.round($1);
break;
case qx.ui.core.Widget.TYPE_PERCENT:this[$7]=true;
this[$6]=this[$8]=this[$9]=false;
this[$4]=parseFloat($1);
this[$5]=null;
break;
case qx.ui.core.Widget.TYPE_AUTO:this[$8]=true;
this[$6]=this[$7]=this[$9]=false;
this[$4]=this[$5]=null;
break;
default:this[$9]=true;
this[$6]=this[$7]=this[$8]=false;
this[$4]=this[$5]=null;
break;
}
if($a!=this[$7]){switch($0){case $[65]:case $[66]:case $[26]:case $[13]:case $[14]:this._invalidateHasPercentX();
break;
case $[89]:case $[88]:case $[32]:case $[23]:case $[22]:this._invalidateHasPercentY();
break;
}}if($b!=this[$8]){switch($0){case $[65]:case $[66]:case $[26]:this._invalidateHasAutoX();
break;
case $[89]:case $[88]:case $[32]:this._invalidateHasAutoY();
break;
}}},
_unitDetectionPixelPercent:function($0,
$1){var $2=qx.ui.core.Widget.layoutPropertyTypes[$0];
var $3=$2.dataType;
var $4=$2.dataParsed;
var $5=$2.dataValue;
var $6=$2.typePixel;
var $7=$2.typePercent;
var $8=$2.typeNull;
var $9=this[$7];
switch(this[$3]=this._evalUnitsPixelPercent($1)){case qx.ui.core.Widget.TYPE_PIXEL:this[$6]=true;
this[$7]=this[$8]=false;
this[$4]=this[$5]=Math.round($1);
break;
case qx.ui.core.Widget.TYPE_PERCENT:this[$7]=true;
this[$6]=this[$8]=false;
this[$4]=parseFloat($1);
this[$5]=null;
break;
default:this[$8]=true;
this[$6]=this[$7]=false;
this[$4]=this[$5]=null;
break;
}
if($9!=this[$7]){switch($0){case $[65]:case $[66]:case $[26]:case $[13]:case $[14]:this._invalidateHasPercentX();
break;
case $[89]:case $[88]:case $[32]:case $[23]:case $[22]:this._invalidateHasPercentY();
break;
}}},
getTopLevelWidget:function(){return this._hasParent?this.getParent().getTopLevelWidget():null;
},
moveSelfBefore:function($0){this.getParent().addBefore(this,
$0);
},
moveSelfAfter:function($0){this.getParent().addAfter(this,
$0);
},
moveSelfToBegin:function(){this.getParent().addAtBegin(this);
},
moveSelfToEnd:function(){this.getParent().addAtEnd(this);
},
getPreviousSibling:function(){var $0=this.getParent();
if($0==null){return null;
}var $1=$0.getChildren();
return $1[$1.indexOf(this)-1];
},
getNextSibling:function(){var $0=this.getParent();
if($0==null){return null;
}var $1=$0.getChildren();
return $1[$1.indexOf(this)+1];
},
getPreviousVisibleSibling:function(){if(!this._hasParent){return null;
}var $0=this.getParent().getVisibleChildren();
return $0[$0.indexOf(this)-1];
},
getNextVisibleSibling:function(){if(!this._hasParent){return null;
}var $0=this.getParent().getVisibleChildren();
return $0[$0.indexOf(this)+1];
},
getPreviousActiveSibling:function($0){var $1=qx.ui.core.Widget.getActiveSiblingHelper(this,
this.getParent(),
-1,
$0,
null);
return $1?$1:this.getParent().getLastActiveChild();
},
getNextActiveSibling:function($0){var $1=qx.ui.core.Widget.getActiveSiblingHelper(this,
this.getParent(),
1,
$0,
null);
return $1?$1:this.getParent().getFirstActiveChild();
},
isFirstChild:function(){return this._hasParent&&this.getParent().getFirstChild()==this;
},
isLastChild:function(){return this._hasParent&&this.getParent().getLastChild()==this;
},
isFirstVisibleChild:function(){return this._hasParent&&this.getParent().getFirstVisibleChild()==this;
},
isLastVisibleChild:function(){return this._hasParent&&this.getParent().getLastVisibleChild()==this;
},
hasState:function($0){return this.__states&&this.__states[$0]?true:false;
},
addState:function($0){if(!this.__states){this.__states={};
}
if(!this.__states[$0]){this.__states[$0]=true;
if(this._hasParent){qx.ui.core.Widget.addToGlobalStateQueue(this);
}}},
removeState:function($0){if(this.__states&&this.__states[$0]){delete this.__states[$0];
if(this._hasParent){qx.ui.core.Widget.addToGlobalStateQueue(this);
}}},
_styleFromMap:function($0){var $1=qx.core.Property.$$method.style;
var $2=qx.core.Property.$$method.unstyle;
var $3;
var $4;
for(var $4 in $0){$3=$0[$4];
$3===$[7]?this[$2[$4]]():this[$1[$4]]($3);
}},
_unstyleFromArray:function($0){var $1=qx.core.Property.$$method.unstyle;
var $2,
$3;
for(var $2=0,
$3=$0.length;$2<$3;$2++){this[$1[$0[$2]]]();
}},
_renderAppearance:function(){if(!this.__states){this.__states={};
}this._applyStateStyleFocus(this.__states);
var $0=this.getAppearance();
if($0){try{var $1=qx.theme.manager.Appearance.getInstance().styleFrom($0,
this.__states);
if($1){this._styleFromMap($1);
}}catch(ex){this.error("Could not apply state appearance",
ex);
}}},
_resetAppearanceThemeWrapper:function($0,
$1){var $2=this.getAppearance();
if($2){var $3=qx.theme.manager.Appearance.getInstance();
var $4=$3.styleFromTheme($1,
$2,
this.__states);
var $5=$3.styleFromTheme($0,
$2,
this.__states);
var $6=[];
for(var $7 in $4){if($5[$7]===undefined){$6.push($7);
}}this._unstyleFromArray($6);
this._styleFromMap($5);
}},
_applyStateStyleFocus:qx.core.Variant.select($[1],
{"mshtml":function($0){},
"gecko":function($0){if($0.focused){if(!qx.event.handler.FocusHandler.mouseFocus&&!this.getHideFocus()){this.setStyleProperty($[349],
$[370]);
}}else{this.removeStyleProperty($[349]);
}},
"default":function($0){if($0.focused){if(!qx.event.handler.FocusHandler.mouseFocus&&!this.getHideFocus()){this.setStyleProperty($[416],
$[370]);
}}else{this.removeStyleProperty($[416]);
}}}),
addToStateQueue:function(){qx.ui.core.Widget.addToGlobalStateQueue(this);
},
recursiveAddToStateQueue:function(){this.addToStateQueue();
},
_applyAppearance:function($0,
$1){if(!this.__states){this.__states={};
}var $2=qx.theme.manager.Appearance.getInstance();
if($0){var $3=$2.styleFrom($0,
this.__states)||{};
}
if($1){var $4=$2.styleFrom($1,
this.__states)||{};
var $5=[];
for(var $6 in $4){if(!$3||!($6 in $3)){$5.push($6);
}}}
if($5){this._unstyleFromArray($5);
}
if($3){this._styleFromMap($3);
}},
_recursiveAppearanceThemeUpdate:function($0,
$1){try{this._resetAppearanceThemeWrapper($0,
$1);
}catch(ex){this.error("Failed to update appearance theme",
ex);
}},
_applyElementData:function($0){},
setHtmlProperty:function($0,
$1){if(!this._htmlProperties){this._htmlProperties={};
}this._htmlProperties[$0]=$1;
if(this._isCreated&&this.getElement()[$0]!=$1){this.getElement()[$0]=$1;
}return true;
},
removeHtmlProperty:qx.core.Variant.select($[1],
{"mshtml":function($0){if(!this._htmlProperties){return;
}delete this._htmlProperties[$0];
if(this._isCreated){this.getElement().removeAttribute($0);
}return true;
},
"default":function($0){if(!this._htmlProperties){return;
}delete this._htmlProperties[$0];
if(this._isCreated){this.getElement().removeAttribute($0);
delete this.getElement()[$0];
}return true;
}}),
getHtmlProperty:function($0){if(!this._htmlProperties){return $[0];
}return this._htmlProperties[$0]||$[0];
},
_applyHtmlProperties:function($0){var $1=this._htmlProperties;
if($1){var $2;
for($2 in $1){$0[$2]=$1[$2];
}}},
setHtmlAttribute:function($0,
$1){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1264]);
if(!this._htmlAttributes){this._htmlAttributes={};
}this._htmlAttributes[$0]=$1;
if(this._isCreated){this.getElement().setAttribute($0,
$1);
}return true;
},
removeHtmlAttribute:function($0){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[717]);
if(!this._htmlAttributes){return;
}delete this._htmlAttributes[$0];
if(this._isCreated){this.getElement().removeAttribute($0);
}return true;
},
getHtmlAttribute:function($0){if(!this._htmlAttributes){return $[0];
}return this._htmlAttributes[$0]||$[0];
},
_applyHtmlAttributes:function($0){var $1=this._htmlAttributes;
if($1){var $2;
for($2 in $1){$0.setAttribute($2,
$1[$2]);
}}},
getStyleProperty:function($0){if(!this._styleProperties){return $[0];
}return this._styleProperties[$0]||$[0];
},
__outerElementStyleProperties:{cursor:true,
zIndex:true,
filter:true,
display:true,
visibility:true},
setStyleProperty:function($0,
$1){if(!this._styleProperties){this._styleProperties={};
}this._styleProperties[$0]=$1;
if(this._isCreated){var $2=this.__outerElementStyleProperties[$0]?this.getElement():this._getTargetNode();
if($2){$2.style[$0]=($1==null)?$[0]:$1;
}}},
removeStyleProperty:function($0){if(!this._styleProperties){return;
}delete this._styleProperties[$0];
if(this._isCreated){var $1=this.__outerElementStyleProperties[$0]?this.getElement():this._getTargetNode();
if($1){$1.style[$0]=$[0];
}}},
_applyStyleProperties:function($0){var $1=this._styleProperties;
if(!$1){return;
}var $2;
var $3=$0;
var $4=this._getTargetNode();
var $0;
var $5;
for($2 in $1){$0=this.__outerElementStyleProperties[$2]?$3:$4;
$5=$1[$2];
$0.style[$2]=($5==null)?$[0]:$5;
}},
_applyEnabled:function($0,
$1){if($0===false){this.addState($[475]);
this.removeState($[64]);
if(qx.Class.isDefined($[326])){this.removeState($[55]);
this.removeState($[31]);
}}else{this.removeState($[475]);
}},
isFocusable:function(){return this.getEnabled()&&this.isSeeable()&&this.getTabIndex()>=0&&this.getTabIndex()!=null;
},
isFocusRoot:function(){return false;
},
getFocusRoot:function(){if(this._hasParent){return this.getParent().getFocusRoot();
}return null;
},
getActiveChild:function(){var $0=this.getFocusRoot();
if($0){return $0.getActiveChild();
}return null;
},
_ontabfocus:qx.lang.Function.returnTrue,
_applyFocused:function($0,
$1){if(!this.isCreated()){return;
}var $2=this.getFocusRoot();
if($2){if($0){$2.setFocusedChild(this);
this._visualizeFocus();
}else{if($2.getFocusedChild()==this){$2.setFocusedChild(null);
}this._visualizeBlur();
}}},
_applyHideFocus:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){this.setHtmlProperty($[1917],
$0);
},
"default":qx.lang.Function.returnTrue}),
_visualizeBlur:function(){if(this.getEnableElementFocus()&&(!this.getFocusRoot().getFocusedChild()||(this.getFocusRoot().getFocusedChild()&&this.getFocusRoot().getFocusedChild().getEnableElementFocus()))){try{this.getElement().blur();
}catch(ex){}}this.removeState($[500]);
},
_visualizeFocus:function(){if(!qx.event.handler.FocusHandler.mouseFocus&&this.getEnableElementFocus()){try{this.getElement().focus();
}catch(ex){}}this.addState($[500]);
},
focus:function(){delete qx.event.handler.FocusHandler.mouseFocus;
this.setFocused(true);
},
blur:function(){delete qx.event.handler.FocusHandler.mouseFocus;
this.setFocused(false);
},
_applyCapture:function($0,
$1){var $2=qx.event.handler.EventHandler.getInstance();
if($1){$2.setCaptureWidget(null);
}else if($0){$2.setCaptureWidget(this);
}},
_applyZIndex:function($0,
$1){if($0==null){this.removeStyleProperty($[343]);
}else{this.setStyleProperty($[343],
$0);
}},
_applyTabIndex:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){this.setHtmlProperty($[405],
$0<0?-1:1);
},
"gecko":function($0,
$1){this.setStyleProperty($[1672],
($0<0?$[583]:$[171]));
},
"default":function($0,
$1){this.setStyleProperty($[885],
($0<0?$[583]:$[171]));
this.setHtmlProperty($[405],
$0<0?-1:1);
}}),
_applySelectable:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){},
"gecko":function($0,
$1){if($0){this.removeStyleProperty($[426]);
}else{this.setStyleProperty($[426],
$[11]);
}},
"webkit":function($0,
$1){if($0){this.removeStyleProperty($[608]);
}else{this.setStyleProperty($[608],
$[11]);
}},
"khtml":function($0,
$1){if($0){this.removeStyleProperty($[439]);
}else{this.setStyleProperty($[439],
$[11]);
}},
"default":function($0,
$1){if($0){return this.removeStyleProperty($[617]);
}else{this.setStyleProperty($[617],
$[11]);
}}}),
_applyOpacity:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){if($0==null||$0>=1||$0<0){this.removeStyleProperty($[158]);
}else{this.setStyleProperty($[158],
($[1049]+Math.round($0*100)+$[44]));
}},
"default":function($0,
$1){if($0==null||$0>1){if(qx.core.Variant.isSet($[1],
$[25])){this.removeStyleProperty($[484]);
}else if(qx.core.Variant.isSet($[1],
$[172])){this.removeStyleProperty($[413]);
}this.removeStyleProperty($[407]);
}else{$0=qx.lang.Number.limit($0,
0,
1);
if(qx.core.Variant.isSet($[1],
$[25])){this.setStyleProperty($[484],
$0);
}else if(qx.core.Variant.isSet($[1],
$[172])){this.setStyleProperty($[413],
$0);
}this.setStyleProperty($[407],
$0);
}}}),
__cursorMap:qx.core.Variant.select($[1],
{"mshtml":{"cursor":$[217],
"ew-resize":$[342],
"ns-resize":$[310],
"nesw-resize":$[494],
"nwse-resize":$[372]},
"opera":{"col-resize":$[342],
"row-resize":$[310],
"ew-resize":$[342],
"ns-resize":$[310],
"nesw-resize":$[494],
"nwse-resize":$[372]},
"default":{}}),
_applyCursor:function($0,
$1){if($0){this.setStyleProperty($[359],
this.__cursorMap[$0]||$0);
}else{this.removeStyleProperty($[359]);
}},
_applyCommand:function($0,
$1){},
_applyBackgroundImage:function($0,
$1){var $2=qx.io.image.Manager.getInstance();
var $3=qx.io.Alias.getInstance();
if($1){$2.hide($1);
}
if($0){$2.show($0);
}$3.connect(this._styleBackgroundImage,
this,
$0);
},
_styleBackgroundImage:function($0){$0?this.setStyleProperty($[509],
$[2007]+$0+$[44]):this.removeStyleProperty($[509]);
},
_applyClip:function($0,
$1){return this._compileClipString();
},
_compileClipString:function(){var $0=this.getClipLeft();
var $1=this.getClipTop();
var $2=this.getClipWidth();
var $3=this.getClipHeight();
var $4,
$5;
if($0==null){$4=($2==null?$[3]:$2+$[46]);
$0=$[3];
}else{$4=($2==null?$[3]:$0+$2+$[46]);
$0=$0+$[46];
}
if($1==null){$5=($3==null?$[3]:$3+$[46]);
$1=$[3];
}else{$5=($3==null?$[3]:$1+$3+$[46]);
$1=$1+$[46];
}return this.setStyleProperty($[1176],
($[1983]+$1+$[17]+$4+$[17]+$5+$[17]+$0+$[44]));
},
_applyOverflow:qx.core.Variant.select($[1],
{"default":function($0,
$1){var $2=$0;
var $3=$[71];
switch($0){case $[122]:$3=$[193];
$2=$[40];
break;
case $[104]:$3=$[194];
$2=$[40];
break;
}var $4=[$[71],
$[193],
$[194]];
for(var $5=0;$5<$4.length;$5++){if($4[$5]!=$3){this.removeStyleProperty($4[$5]);
}}
switch($0){case $[122]:this.setStyleProperty($[194],
$[21]);
break;
case $[104]:this.setStyleProperty($[193],
$[21]);
break;
}this._renderOverflow($3,
$2,
$0,
$1);
this.addToQueue($[71]);
},
"gecko":function($0,
$1){var $2=$0;
var $3=$[71];
switch($2){case $[21]:$2=$[1905];
break;
case $[122]:$2=$[307];
break;
case $[104]:$2=$[300];
break;
}this._renderOverflow($3,
$2,
$0,
$1);
this.addToQueue($[71]);
},
"opera":function($0,
$1){var $2=$0;
var $3=$[71];
switch($2){case $[122]:case $[104]:$2=$[40];
break;
}this._renderOverflow($3,
$2,
$0,
$1);
this.addToQueue($[71]);
}}),
_renderOverflow:function($0,
$1,
$2,
$3){this.setStyleProperty($0,
$1||$[0]);
this._invalidateFrameWidth();
this._invalidateFrameHeight();
},
getOverflowX:function(){var $0=this.getOverflow();
return $0==$[104]?$[21]:$0;
},
getOverflowY:function(){var $0=this.getOverflow();
return $0==$[122]?$[21]:$0;
},
_applyBackgroundColor:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBackgroundColor,
this,
$0);
},
_styleBackgroundColor:function($0){$0?this.setStyleProperty($[562],
$0):this.removeStyleProperty($[562]);
},
_applyTextColor:function($0,
$1){},
_applyFont:function($0,
$1){},
_cachedBorderTop:0,
_cachedBorderRight:0,
_cachedBorderBottom:0,
_cachedBorderLeft:0,
_applyBorder:function($0,
$1){qx.theme.manager.Border.getInstance().connect(this._queueBorder,
this,
$0);
},
__borderJobs:{top:$[947],
right:$[1649],
bottom:$[782],
left:$[1729]},
_queueBorder:function($0,
$1){if(!$1){var $2=this.__borderJobs;
for(var $3 in $2){this.addToQueue($2[$3]);
}this.__reflowBorderX($0);
this.__reflowBorderY($0);
}else{if($1===$[13]||$1===$[14]){this.__reflowBorderX($0);
}else{this.__reflowBorderY($0);
}this.addToQueue(this.__borderJobs[$1]);
}this.__borderObject=$0;
},
__reflowBorderX:function($0){var $1=this._cachedBorderLeft;
var $2=this._cachedBorderRight;
this._cachedBorderLeft=$0?$0.getWidthLeft():0;
this._cachedBorderRight=$0?$0.getWidthRight():0;
if(($1+$2)!=(this._cachedBorderLeft+this._cachedBorderRight)){this._invalidateFrameWidth();
}},
__reflowBorderY:function($0){var $1=this._cachedBorderTop;
var $2=this._cachedBorderBottom;
this._cachedBorderTop=$0?$0.getWidthTop():0;
this._cachedBorderBottom=$0?$0.getWidthBottom():0;
if(($1+$2)!=(this._cachedBorderTop+this._cachedBorderBottom)){this._invalidateFrameHeight();
}},
renderBorder:function($0){var $1=this.__borderObject;
var $2=qx.theme.manager.Border.getInstance();
if($1){if($0.borderTop){$1.renderTop(this);
}
if($0.borderRight){$1.renderRight(this);
}
if($0.borderBottom){$1.renderBottom(this);
}
if($0.borderLeft){$1.renderLeft(this);
}}else{var $3=qx.ui.core.Border;
if($0.borderTop){$3.resetTop(this);
}
if($0.borderRight){$3.resetRight(this);
}
if($0.borderBottom){$3.resetBottom(this);
}
if($0.borderLeft){$3.resetLeft(this);
}}},
prepareEnhancedBorder:qx.core.Variant.select($[1],
{"gecko":qx.lang.Function.returnTrue,
"default":function(){var $0=this.getElement();
var $1=this._borderElement=document.createElement($[101]);
var $2=$0.style;
var $3=this._innerStyle=$1.style;
if(qx.core.Variant.isSet($[1],
$[20])){}else{$3.width=$3.height=$[80];
}$3.position=$[63];
for(var $4 in this._styleProperties){switch($4){case $[343]:case $[158]:case $[173]:break;
default:$3[$4]=$2[$4];
$2[$4]=$[0];
}}
for(var $4 in this._htmlProperties){switch($4){case $[1568]:$1.unselectable=this._htmlProperties[$4];
}}while($0.firstChild){$1.appendChild($0.firstChild);
}$0.appendChild($1);
}}),
_applyPaddingTop:function($0,
$1){this.addToQueue($[228]);
this._invalidateFrameHeight();
},
_applyPaddingRight:function($0,
$1){this.addToQueue($[267]);
this._invalidateFrameWidth();
},
_applyPaddingBottom:function($0,
$1){this.addToQueue($[252]);
this._invalidateFrameHeight();
},
_applyPaddingLeft:function($0,
$1){this.addToQueue($[264]);
this._invalidateFrameWidth();
},
renderPadding:function($0){},
_applyMarginLeft:function($0,
$1){this.addToQueue($[174]);
},
_applyMarginRight:function($0,
$1){this.addToQueue($[242]);
},
_applyMarginTop:function($0,
$1){this.addToQueue($[168]);
},
_applyMarginBottom:function($0,
$1){this.addToQueue($[257]);
},
execute:function(){var $0=this.getCommand();
if($0){$0.execute(this);
}this.createDispatchEvent($[117]);
},
_visualPropertyCheck:function(){if(!this.isCreated()){throw new Error(this.classname+": Element must be created previously!");
}},
setScrollLeft:function($0){this._visualPropertyCheck();
this._getTargetNode().scrollLeft=$0;
},
setScrollTop:function($0){this._visualPropertyCheck();
this._getTargetNode().scrollTop=$0;
},
getOffsetLeft:function(){this._visualPropertyCheck();
return qx.html.Offset.getLeft(this.getElement());
},
getOffsetTop:function(){this._visualPropertyCheck();
return qx.html.Offset.getTop(this.getElement());
},
getScrollLeft:function(){this._visualPropertyCheck();
return this._getTargetNode().scrollLeft;
},
getScrollTop:function(){this._visualPropertyCheck();
return this._getTargetNode().scrollTop;
},
getClientWidth:function(){this._visualPropertyCheck();
return this._getTargetNode().clientWidth;
},
getClientHeight:function(){this._visualPropertyCheck();
return this._getTargetNode().clientHeight;
},
getOffsetWidth:function(){this._visualPropertyCheck();
return this.getElement().offsetWidth;
},
getOffsetHeight:function(){this._visualPropertyCheck();
return this.getElement().offsetHeight;
},
getScrollWidth:function(){this._visualPropertyCheck();
return this._getTargetNode().scrollWidth;
},
getScrollHeight:function(){this._visualPropertyCheck();
return this._getTargetNode().scrollHeight;
},
scrollIntoView:function($0){this.scrollIntoViewX($0);
this.scrollIntoViewY($0);
},
scrollIntoViewX:function($0){if(!this._isCreated||!this._isDisplayable){this.warn("The function scrollIntoViewX can only be called after the widget is created!");
return false;
}return qx.html.ScrollIntoView.scrollX(this.getElement(),
$0);
},
scrollIntoViewY:function($0){if(!this._isCreated||!this._isDisplayable){this.warn("The function scrollIntoViewY can only be called after the widget is created!");
return false;
}return qx.html.ScrollIntoView.scrollY(this.getElement(),
$0);
},
supportsDrop:function($0){var $1=this.getSupportsDropMethod();
if($1!==null){return $1.call(this,
$0);
}return (this!=$0.sourceWidget);
}},
settings:{"qx.widgetQueueDebugging":false},
defer:function($0,
$1){$0.__initApplyMethods($1);
if(qx.core.Variant.isSet($[1],
$[20])){$1._renderRuntimeWidth=function($2){this._style.pixelWidth=($2==null)?0:$2;
if(this._innerStyle){this._innerStyle.pixelWidth=($2==null)?0:$2-2;
}};
$1._renderRuntimeHeight=function($2){this._style.pixelHeight=($2==null)?0:$2;
if(this._innerStyle){this._innerStyle.pixelHeight=($2==null)?0:$2-2;
}};
$1._resetRuntimeWidth=function(){this._style.width=$[0];
if(this._innerStyle){this._innerStyle.width=$[0];
}};
$1._resetRuntimeHeight=function(){this._style.height=$[0];
if(this._innerStyle){this._innerStyle.height=$[0];
}};
}$0.__initLayoutProperties($0);
{};
},
destruct:function(){var $0=this.getElement();
if($0){$0.qx_Widget=null;
}this._disposeFields($[1942],
$[1343],
$[273],
$[1695],
$[1170],
$[1446],
$[1467],
$[1040],
$[1613],
$[1141],
$[788],
$[1952],
$[1274],
$[1877]);
}});




/* ID: qx.html.Dimension */
qx.Class.define($[702],
{statics:{getOuterWidth:function($0){return qx.html.Dimension.getBoxWidth($0)+qx.html.Style.getMarginLeft($0)+qx.html.Style.getMarginRight($0);
},
getOuterHeight:function($0){return qx.html.Dimension.getBoxHeight($0)+qx.html.Style.getMarginTop($0)+qx.html.Style.getMarginBottom($0);
},
getBoxWidthForZeroHeight:function($0){var $1=$0.offsetHeight;
if($1==0){var $2=$0.style.height;
$0.style.height=$[179];
}var $3=$0.offsetWidth;
if($1==0){$0.style.height=$2;
}return $3;
},
getBoxHeightForZeroWidth:function($0){var $1=$0.offsetWidth;
if($1==0){var $2=$0.style.width;
$0.style.width=$[179];
}var $3=$0.offsetHeight;
if($1==0){$0.style.width=$2;
}return $3;
},
getBoxWidth:function($0){return $0.offsetWidth;
},
getBoxHeight:function($0){return $0.offsetHeight;
},
getAreaWidth:qx.core.Variant.select($[1],
{"gecko":function($0){if($0.clientWidth!=0&&$0.clientWidth!=(qx.html.Style.getBorderLeft($0)+qx.html.Style.getBorderRight($0))){return $0.clientWidth;
}else{return qx.html.Dimension.getBoxWidth($0)-qx.html.Dimension.getInsetLeft($0)-qx.html.Dimension.getInsetRight($0);
}},
"default":function($0){return $0.clientWidth!=0?$0.clientWidth:(qx.html.Dimension.getBoxWidth($0)-qx.html.Dimension.getInsetLeft($0)-qx.html.Dimension.getInsetRight($0));
}}),
getAreaHeight:qx.core.Variant.select($[1],
{"gecko":function($0){if($0.clientHeight!=0&&$0.clientHeight!=(qx.html.Style.getBorderTop($0)+qx.html.Style.getBorderBottom($0))){return $0.clientHeight;
}else{return qx.html.Dimension.getBoxHeight($0)-qx.html.Dimension.getInsetTop($0)-qx.html.Dimension.getInsetBottom($0);
}},
"default":function($0){return $0.clientHeight!=0?$0.clientHeight:(qx.html.Dimension.getBoxHeight($0)-qx.html.Dimension.getInsetTop($0)-qx.html.Dimension.getInsetBottom($0));
}}),
getInnerWidth:function($0){return qx.html.Dimension.getAreaWidth($0)-qx.html.Style.getPaddingLeft($0)-qx.html.Style.getPaddingRight($0);
},
getInnerHeight:function($0){return qx.html.Dimension.getAreaHeight($0)-qx.html.Style.getPaddingTop($0)-qx.html.Style.getPaddingBottom($0);
},
getInsetLeft:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.clientLeft;
},
"default":function($0){return qx.html.Style.getBorderLeft($0);
}}),
getInsetTop:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.clientTop;
},
"default":function($0){return qx.html.Style.getBorderTop($0);
}}),
getInsetRight:qx.core.Variant.select($[1],
{"mshtml":function($0){if(qx.html.Style.getStyleProperty($0,
$[194])==$[21]||$0.clientWidth==0){return qx.html.Style.getBorderRight($0);
}return Math.max(0,
$0.offsetWidth-$0.clientLeft-$0.clientWidth);
},
"default":function($0){if($0.clientWidth==0){var $1=qx.html.Style.getStyleProperty($0,
$[71]);
var $2=$1==$[40]||$1==$[300]?16:0;
return Math.max(0,
qx.html.Style.getBorderRight($0)+$2);
}return Math.max(0,
$0.offsetWidth-$0.clientWidth-qx.html.Style.getBorderLeft($0));
}}),
getInsetBottom:qx.core.Variant.select($[1],
{"mshtml":function($0){if(qx.html.Style.getStyleProperty($0,
$[193])==$[21]||$0.clientHeight==0){return qx.html.Style.getBorderBottom($0);
}return Math.max(0,
$0.offsetHeight-$0.clientTop-$0.clientHeight);
},
"default":function($0){if($0.clientHeight==0){var $1=qx.html.Style.getStyleProperty($0,
$[71]);
var $2=$1==$[40]||$1==$[307]?16:0;
return Math.max(0,
qx.html.Style.getBorderBottom($0)+$2);
}return Math.max(0,
$0.offsetHeight-$0.clientHeight-qx.html.Style.getBorderTop($0));
}}),
getScrollBarSizeLeft:function($0){return 0;
},
getScrollBarSizeTop:function($0){return 0;
},
getScrollBarSizeRight:function($0){return qx.html.Dimension.getInsetRight($0)-qx.html.Style.getBorderRight($0);
},
getScrollBarSizeBottom:function($0){return qx.html.Dimension.getInsetBottom($0)-qx.html.Style.getBorderBottom($0);
},
getScrollBarVisibleX:function($0){return qx.html.Dimension.getScrollBarSizeRight($0)>0;
},
getScrollBarVisibleY:function($0){return qx.html.Dimension.getScrollBarSizeBottom($0)>0;
}}});




/* ID: qx.html.Style */
qx.Class.define($[2023],
{statics:{getStylePropertySure:qx.lang.Object.select((document.defaultView&&document.defaultView.getComputedStyle)?$[518]:$[440],
{"hasComputed":function($0,
$1){return !$0?null:$0.ownerDocument?$0.ownerDocument.defaultView.getComputedStyle($0,
$[0])[$1]:$0.style[$1];
},
"noComputed":qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){try{if(!$0){return null;
}
if($0.parentNode&&$0.currentStyle){return $0.currentStyle[$1];
}else{var $2=$0.runtimeStyle[$1];
if($2!=null&&typeof $2!=$[7]&&$2!=$[0]){return $2;
}return $0.style[$1];
}}catch(ex){throw new Error("Could not evaluate computed style: "+$0+"["+$1+"]: "+ex);
}},
"default":function($0,
$1){return !$0?null:$0.style[$1];
}})}),
getStyleProperty:qx.lang.Object.select((document.defaultView&&document.defaultView.getComputedStyle)?$[518]:$[440],
{"hasComputed":function($0,
$1){try{return $0.ownerDocument.defaultView.getComputedStyle($0,
$[0])[$1];
}catch(ex){throw new Error("Could not evaluate computed style: "+$0+"["+$1+"]: "+ex);
}},
"noComputed":qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){try{return $0.currentStyle[$1];
}catch(ex){throw new Error("Could not evaluate computed style: "+$0+"["+$1+"]: "+ex);
}},
"default":function($0,
$1){try{return $0.style[$1];
}catch(ex){throw new Error("Could not evaluate computed style: "+$0+"["+$1+"]");
}}})}),
getStyleSize:function($0,
$1){return parseInt(qx.html.Style.getStyleProperty($0,
$1))||0;
},
getMarginLeft:function($0){return qx.html.Style.getStyleSize($0,
$[174]);
},
getMarginTop:function($0){return qx.html.Style.getStyleSize($0,
$[168]);
},
getMarginRight:function($0){return qx.html.Style.getStyleSize($0,
$[242]);
},
getMarginBottom:function($0){return qx.html.Style.getStyleSize($0,
$[257]);
},
getPaddingLeft:function($0){return qx.html.Style.getStyleSize($0,
$[264]);
},
getPaddingTop:function($0){return qx.html.Style.getStyleSize($0,
$[228]);
},
getPaddingRight:function($0){return qx.html.Style.getStyleSize($0,
$[267]);
},
getPaddingBottom:function($0){return qx.html.Style.getStyleSize($0,
$[252]);
},
getBorderLeft:function($0){return qx.html.Style.getStyleProperty($0,
$[980])==$[11]?0:qx.html.Style.getStyleSize($0,
$[83]);
},
getBorderTop:function($0){return qx.html.Style.getStyleProperty($0,
$[1103])==$[11]?0:qx.html.Style.getStyleSize($0,
$[76]);
},
getBorderRight:function($0){return qx.html.Style.getStyleProperty($0,
$[1124])==$[11]?0:qx.html.Style.getStyleSize($0,
$[483]);
},
getBorderBottom:function($0){return qx.html.Style.getStyleProperty($0,
$[658])==$[11]?0:qx.html.Style.getStyleSize($0,
$[386]);
}}});




/* ID: qx.html.StyleSheet */
qx.Class.define($[1260],
{statics:{includeFile:function($0){var $1=document.createElement($[1602]);
$1.type=$[511];
$1.rel=$[1104];
$1.href=$0;
var $2=document.getElementsByTagName($[594])[0];
$2.appendChild($1);
},
createElement:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0){var $1=document.createStyleSheet();
if($0){$1.cssText=$0;
}return $1;
},
"other":function($0){var $1=document.createElement($[48]);
$1.type=$[511];
$1.appendChild(document.createTextNode($0||$[1395]));
document.getElementsByTagName($[594])[0].appendChild($1);
if($1.sheet){return $1.sheet;
}else{var $2=document.styleSheets;
for(var $3=$2.length-1;$3>=0;$3--){if($2[$3].ownerNode==$1){return $2[$3];
}}}throw $[1768];
}}),
addRule:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0,
$1,
$2){$0.addRule($1,
$2);
},
"other":qx.lang.Object.select(qx.core.Client.getInstance().isSafari2()?$[262]:$[61],
{"safari2+":function($0,
$1,
$2){if(!$0._qxRules){$0._qxRules={};
}
if(!$0._qxRules[$1]){var $3=document.createTextNode($1+$[313]+$2+$[199]);
$0.ownerNode.appendChild($3);
$0._qxRules[$1]=$3;
}},
"other":function($0,
$1,
$2){$0.insertRule($1+$[313]+$2+$[199],
$0.cssRules.length);
}})}),
removeRule:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0,
$1){var $2=$0.rules;
var $3=$2.length;
for(var $4=$3-1;$4>=0;$4--){if($2[$4].selectorText==$1){$0.removeRule($4);
}}},
"other":qx.lang.Object.select(qx.core.Client.getInstance().isSafari2()?$[262]:$[61],
{"safari2+":function($0,
$1){var $2=function(){qx.log.Logger.ROOT_LOGGER.warn("In Safari/Webkit you can only remove rules that are created using qx.html.StyleSheet.addRule");
};
if(!$0._qxRules){$2();
}var $3=$0._qxRules[$1];
if($3){$0.ownerNode.removeChild($3);
$0._qxRules[$1]=null;
}else{$2();
}},
"other":function($0,
$1){var $2=$0.cssRules;
var $3=$2.length;
for(var $4=$3-1;$4>=0;$4--){if($2[$4].selectorText==$1){$0.deleteRule($4);
}}}})}),
removeAllRules:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0){var $1=$0.rules;
var $2=$1.length;
for(var $3=$2-1;$3>=0;$3--){$0.removeRule($3);
}},
"other":qx.lang.Object.select(qx.core.Client.getInstance().isSafari2()?$[262]:$[61],
{"safari2+":function($0){var $1=$0.ownerNode;
var $2=$1.childNodes;
while($2.length>0){$1.removeChild($2[0]);
}},
"other":function($0){var $1=$0.cssRules;
var $2=$1.length;
for(var $3=$2-1;$3>=0;$3--){$0.deleteRule($3);
}}})}),
addImport:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0,
$1){$0.addImport($1);
},
"other":qx.lang.Object.select(qx.core.Client.getInstance().isSafari2()?$[262]:$[61],
{"safari2+":function($0,
$1){$0.ownerNode.appendChild(document.createTextNode($[613]+$1+$[451]));
},
"other":function($0,
$1){$0.insertRule($[613]+$1+$[451],
$0.cssRules.length);
}})}),
removeImport:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0,
$1){var $2=$0.imports;
var $3=$2.length;
for(var $4=$3-1;$4>=0;$4--){if($2[$4].href==$1){$0.removeImport($4);
}}},
"other":function($0,
$1){var $2=$0.cssRules;
var $3=$2.length;
for(var $4=$3-1;$4>=0;$4--){if($2[$4].href==$1){$0.deleteRule($4);
}}}}),
removeAllImports:qx.lang.Object.select(document.createStyleSheet?$[154]:$[61],
{"ie4+":function($0){var $1=$0.imports;
var $2=$1.length;
for(var $3=$2-1;$3>=0;$3--){$0.removeImport($3);
}},
"other":function($0){var $1=$0.cssRules;
var $2=$1.length;
for(var $3=$2-1;$3>=0;$3--){if($1[$3].type==$1[$3].IMPORT_RULE){$0.deleteRule($3);
}}}})}});




/* ID: qx.ui.core.Parent */
qx.Class.define($[330],
{extend:qx.ui.core.Widget,
type:$[82],
construct:function(){arguments.callee.base.call(this);
this._children=[];
this._layoutImpl=this._createLayoutImpl();
},
properties:{focusHandler:{check:$[605],
apply:$[1361],
nullable:true},
activeChild:{check:$[112],
apply:$[1808],
event:$[821],
nullable:true},
focusedChild:{check:$[112],
apply:$[1521],
event:$[1538],
nullable:true},
visibleChildren:{_cached:true,
defaultValue:null}},
members:{isFocusRoot:function(){return this.getFocusHandler()!=null;
},
getFocusRoot:function(){if(this.isFocusRoot()){return this;
}
if(this._hasParent){return this.getParent().getFocusRoot();
}return null;
},
activateFocusRoot:function(){this.setFocusHandler(new qx.event.handler.FocusHandler(this));
},
_onfocuskeyevent:function($0){this.getFocusHandler()._onkeyevent(this,
$0);
},
_applyFocusHandler:function($0,
$1){if($0){this.addEventListener($[57],
this._onfocuskeyevent);
if(this.getTabIndex()<1){this.setTabIndex(1);
}this.setHideFocus(true);
this.setActiveChild(this);
}else{this.removeEventListener($[45],
this._onfocuskeyevent);
this.removeEventListener($[57],
this._onfocuskeyevent);
this.setTabIndex(-1);
this.setHideFocus(false);
}},
_applyActiveChild:function($0,
$1){},
_applyFocusedChild:function($0,
$1){var $2=$0!=null;
var $3=$1!=null;
if(qx.Class.isDefined($[184])&&$2){var $4=qx.ui.popup.PopupManager.getInstance();
if($4){$4.update($0);
}}
if($3){if($1.hasEventListeners($[295])){var $5=new qx.event.type.FocusEvent($[295],
$1);
if($2){$5.setRelatedTarget($0);
}$1.dispatchEvent($5);
$5.dispose();
}}
if($2){if($0.hasEventListeners($[276])){var $5=new qx.event.type.FocusEvent($[276],
$0);
if($3){$5.setRelatedTarget($1);
}$0.dispatchEvent($5);
$5.dispose();
}}
if($3){if(this.getActiveChild()==$1&&!$2){this.setActiveChild(null);
}$1.setFocused(false);
var $5=new qx.event.type.FocusEvent($[214],
$1);
if($2){$5.setRelatedTarget($0);
}$1.dispatchEvent($5);
if(qx.Class.isDefined($[165])){var $4=qx.ui.popup.ToolTipManager.getInstance();
if($4){$4.handleBlur($5);
}}$5.dispose();
}
if($2){this.setActiveChild($0);
$0.setFocused(true);
qx.event.handler.EventHandler.getInstance().setFocusRoot(this);
var $5=new qx.event.type.FocusEvent($[256],
$0);
if($3){$5.setRelatedTarget($1);
}$0.dispatchEvent($5);
if(qx.Class.isDefined($[165])){var $4=qx.ui.popup.ToolTipManager.getInstance();
if($4){$4.handleFocus($5);
}}$5.dispose();
}},
_layoutImpl:null,
_createLayoutImpl:function(){return null;
},
getLayoutImpl:function(){return this._layoutImpl;
},
getChildren:function(){return this._children;
},
getChildrenLength:function(){return this.getChildren().length;
},
hasChildren:function(){return this.getChildrenLength()>0;
},
isEmpty:function(){return this.getChildrenLength()==0;
},
indexOf:function($0){return this.getChildren().indexOf($0);
},
contains:function($0){switch($0){case null:return false;
case this:return true;
default:return this.contains($0.getParent());
}},
_computeVisibleChildren:function(){var $0=[];
var $1=this.getChildren();
if(!$1){return 0;
}var $2=$1.length;
for(var $3=0;$3<$2;$3++){var $4=$1[$3];
if($4._isDisplayable){$0.push($4);
}}return $0;
},
getVisibleChildrenLength:function(){return this.getVisibleChildren().length;
},
hasVisibleChildren:function(){return this.getVisibleChildrenLength()>0;
},
isVisibleEmpty:function(){return this.getVisibleChildrenLength()==0;
},
add:function($0){var $1;
for(var $2=0,
$3=arguments.length;$2<$3;$2++){$1=arguments[$2];
if(!($1 instanceof qx.ui.core.Parent)&&!($1 instanceof qx.ui.basic.Terminator)){throw new Error("Invalid Widget: "+$1);
}else{$1.setParent(this);
}}return this;
},
addAt:function($0,
$1){if($1==null||$1<0){throw new Error("Not a valid index for addAt(): "+$1);
}
if($0.getParent()==this){var $2=this.getChildren();
var $3=$2.indexOf($0);
if($3!=$1){if($3!=-1){qx.lang.Array.removeAt($2,
$3);
}qx.lang.Array.insertAt($2,
$0,
$1);
if(this._initialLayoutDone){this._invalidateVisibleChildren();
this.getLayoutImpl().updateChildrenOnMoveChild($0,
$1,
$3);
}}}else{$0._insertIndex=$1;
$0.setParent(this);
}},
addAtBegin:function($0){return this.addAt($0,
0);
},
addAtEnd:function($0){var $1=this.getChildrenLength();
return this.addAt($0,
$0.getParent()==this?$1-1:$1);
},
addBefore:function($0,
$1){var $2=this.getChildren();
var $3=$2.indexOf($1);
if($3==-1){throw new Error("Child to add before: "+$1+" is not inside this parent.");
}var $4=$2.indexOf($0);
if($4==-1||$4>$3){$3++;
}return this.addAt($0,
Math.max(0,
$3-1));
},
addAfter:function($0,
$1){var $2=this.getChildren();
var $3=$2.indexOf($1);
if($3==-1){throw new Error("Child to add after: "+$1+" is not inside this parent.");
}var $4=$2.indexOf($0);
if($4!=-1&&$4<$3){$3--;
}return this.addAt($0,
Math.min($2.length,
$3+1));
},
remove:function($0){var $1;
for(var $2=0,
$3=arguments.length;$2<$3;$2++){$1=arguments[$2];
if(!($1 instanceof qx.ui.core.Parent)&&!($1 instanceof qx.ui.basic.Terminator)){throw new Error("Invalid Widget: "+$1);
}else if($1.getParent()==this){$1.setParent(null);
}}},
removeAt:function($0){var $1=this.getChildren()[$0];
if($1){delete $1._insertIndex;
$1.setParent(null);
}},
removeAll:function(){var $0=this.getChildren();
var $1=$0[0];
while($1){this.remove($1);
$1=$0[0];
}},
getFirstChild:function(){return qx.lang.Array.getFirst(this.getChildren())||null;
},
getFirstVisibleChild:function(){return qx.lang.Array.getFirst(this.getVisibleChildren())||null;
},
getFirstActiveChild:function($0){return qx.ui.core.Widget.getActiveSiblingHelper(null,
this,
1,
$0,
$[469])||null;
},
getLastChild:function(){return qx.lang.Array.getLast(this.getChildren())||null;
},
getLastVisibleChild:function(){return qx.lang.Array.getLast(this.getVisibleChildren())||null;
},
getLastActiveChild:function($0){return qx.ui.core.Widget.getActiveSiblingHelper(null,
this,
-1,
$0,
$[1004])||null;
},
forEachChild:function($0){var $1=this.getChildren(),
$2,
$3=-1;
if(!$1){return;
}
while($2=$1[++$3]){$0.call($2,
$3);
}},
forEachVisibleChild:function($0){var $1=this.getVisibleChildren(),
$2,
$3=-1;
if(!$1){return;
}
while($2=$1[++$3]){$0.call($2,
$3);
}},
_beforeAppear:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._beforeAppear();
}});
},
_afterAppear:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._afterAppear();
}});
},
_beforeDisappear:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._beforeDisappear();
}});
},
_afterDisappear:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._afterDisappear();
}});
},
_beforeInsertDom:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._beforeInsertDom();
}});
},
_afterInsertDom:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._afterInsertDom();
}});
},
_beforeRemoveDom:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._beforeRemoveDom();
}});
},
_afterRemoveDom:function(){arguments.callee.base.call(this);
this.forEachVisibleChild(function(){if(this.isAppearRelevant()){this._afterRemoveDom();
}});
},
_handleDisplayableCustom:function($0,
$1,
$2){this.forEachChild(function(){this._handleDisplayable();
});
},
_addChildrenToStateQueue:function(){this.forEachVisibleChild(function(){this.addToStateQueue();
});
},
recursiveAddToStateQueue:function(){this.addToStateQueue();
this.forEachVisibleChild(function(){this.recursiveAddToStateQueue();
});
},
_recursiveAppearanceThemeUpdate:function($0,
$1){arguments.callee.base.call(this,
$0,
$1);
this.forEachVisibleChild(function(){this._recursiveAppearanceThemeUpdate($0,
$1);
});
},
_addChildToChildrenQueue:function($0){if(!$0._isInParentChildrenQueue&&!$0._isDisplayable){this.warn("Ignoring invisible child: "+$0);
}
if(!$0._isInParentChildrenQueue&&$0._isDisplayable){qx.ui.core.Widget.addToGlobalLayoutQueue(this);
if(!this._childrenQueue){this._childrenQueue={};
}this._childrenQueue[$0.toHashCode()]=$0;
}},
_removeChildFromChildrenQueue:function($0){if(this._childrenQueue&&$0._isInParentChildrenQueue){delete this._childrenQueue[$0.toHashCode()];
if(qx.lang.Object.isEmpty(this._childrenQueue)){qx.ui.core.Widget.removeFromGlobalLayoutQueue(this);
}}},
_flushChildrenQueue:function(){if(!qx.lang.Object.isEmpty(this._childrenQueue)){this.getLayoutImpl().flushChildrenQueue(this._childrenQueue);
delete this._childrenQueue;
}},
_addChildrenToLayoutQueue:function($0){this.forEachChild(function(){this.addToLayoutChanges($0);
});
},
_layoutChild:function($0){if(!$0._isDisplayable){return ;
}var $1=$0._layoutChanges;
try{if($0.renderBorder){if($1.borderTop||$1.borderRight||$1.borderBottom||$1.borderLeft){$0.renderBorder($1);
}}}catch(ex){this.error("Could not apply border to child "+$0,
ex);
}
try{if($0.renderPadding){if($1.paddingLeft||$1.paddingRight||$1.paddingTop||$1.paddingBottom){$0.renderPadding($1);
}}}catch(ex){this.error("Could not apply padding to child "+$0,
ex);
}try{this.getLayoutImpl().layoutChild($0,
$1);
}catch(ex){this.error("Could not layout child "+$0+" through layout handler",
ex);
}try{$0._layoutPost($1);
}catch(ex){this.error("Could not post layout child "+$0,
ex);
}try{if($1.initial){$0._initialLayoutDone=true;
qx.ui.core.Widget.addToGlobalDisplayQueue($0);
}}catch(ex){this.error("Could not handle display updates from layout flush for child "+$0,
ex);
}$0._layoutChanges={};
delete $0._isInParentLayoutQueue;
delete this._childrenQueue[$0.toHashCode()];
},
_layoutPost:qx.lang.Function.returnTrue,
_computePreferredInnerWidth:function(){return this.getLayoutImpl().computeChildrenNeededWidth();
},
_computePreferredInnerHeight:function(){return this.getLayoutImpl().computeChildrenNeededHeight();
},
_changeInnerWidth:function($0,
$1){var $2=this.getLayoutImpl();
if($2.invalidateChildrenFlexWidth){$2.invalidateChildrenFlexWidth();
}this.forEachVisibleChild(function(){if($2.updateChildOnInnerWidthChange(this)&&this._recomputeBoxWidth()){this._recomputeOuterWidth();
this._recomputeInnerWidth();
}});
},
_changeInnerHeight:function($0,
$1){var $2=this.getLayoutImpl();
if($2.invalidateChildrenFlexHeight){$2.invalidateChildrenFlexHeight();
}this.forEachVisibleChild(function(){if($2.updateChildOnInnerHeightChange(this)&&this._recomputeBoxHeight()){this._recomputeOuterHeight();
this._recomputeInnerHeight();
}});
},
getInnerWidthForChild:function($0){return this.getInnerWidth();
},
getInnerHeightForChild:function($0){return this.getInnerHeight();
},
_remappingChildTable:[$[422],
$[444],
$[461],
$[559],
$[354],
$[611],
$[538],
$[369],
$[358]],
_remapStart:$[2030],
_remapStop:$[1786],
remapChildrenHandlingTo:function($0){var $1=this._remappingChildTable;
this._remappingChildTarget=$0;
for(var $2=0,
$3=$1.length,
$4;$2<$3;$2++){$4=$1[$2];
this[$4]=new Function(qx.ui.core.Parent.prototype._remapStart+$4+qx.ui.core.Parent.prototype._remapStop);
}}},
defer:function($0,
$1,
$2){if(qx.core.Variant.isSet($[1],
$[142])){$1._layoutChildOrig=$1._layoutChild;
$1._layoutChild=function($3){if(!$3._initialLayoutDone||!$3._layoutChanges.border){return this._layoutChildOrig($3);
}var $4=$3.getElement().style;
var $5=$4.display;
$4.display=$[11];
var $6=this._layoutChildOrig($3);
$4.display=$5;
return $6;
};
}},
destruct:function(){this._disposeObjectDeep($[1540],
1);
this._disposeObjects($[1192]);
this._disposeFields($[347],
$[347],
$[1265],
$[1571],
$[697]);
}});




/* ID: qx.event.type.FocusEvent */
qx.Class.define($[187],
{extend:qx.event.type.Event,
construct:function($0,
$1){arguments.callee.base.call(this,
$0);
this.setTarget($1);
switch($0){case $[276]:case $[295]:this.setBubbles(true);
this.setPropagationStopped(false);
}}});




/* ID: qx.event.handler.EventHandler */
qx.Class.define($[739],
{type:$[24],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this.__onmouseevent=qx.lang.Function.bind(this._onmouseevent,
this);
this.__ondragevent=qx.lang.Function.bind(this._ondragevent,
this);
this.__onselectevent=qx.lang.Function.bind(this._onselectevent,
this);
this.__onwindowblur=qx.lang.Function.bind(this._onwindowblur,
this);
this.__onwindowfocus=qx.lang.Function.bind(this._onwindowfocus,
this);
this.__onwindowresize=qx.lang.Function.bind(this._onwindowresize,
this);
this._commands={};
},
events:{"error":$[42]},
statics:{mouseEventTypes:[$[86],
$[135],
$[113],
$[18],
$[39],
$[99],
$[152],
$[196],
qx.core.Variant.isSet($[1],
$[25])?$[457]:$[238]],
keyEventTypes:[$[45],
$[57],
$[146]],
dragEventTypes:qx.core.Variant.select($[1],
{"gecko":[$[503],
$[281],
$[283],
$[528],
$[542]],
"mshtml":[$[1623],
$[281],
$[445],
$[466],
$[283],
$[384]],
"default":[$[445],
$[503],
$[281],
$[466],
$[384],
$[283],
$[528],
$[542]]}),
getDomTarget:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.target||$0.srcElement;
},
"webkit":function($0){var $1=$0.target||$0.srcElement;
if($1&&($1.nodeType==qx.dom.Node.TEXT)){$1=$1.parentNode;
}return $1;
},
"default":function($0){return $0.target;
}}),
stopDomEvent:function($0){if($0.preventDefault){$0.preventDefault();
}$0.returnValue=false;
},
getOriginalTargetObject:function($0){if($0==document.documentElement){$0=document.body;
}while($0!=null&&$0.qx_Widget==null){try{$0=$0.parentNode;
}catch(vDomEvent){$0=null;
}}return $0?$0.qx_Widget:null;
},
getOriginalTargetObjectFromEvent:function($0,
$1){var $2=qx.event.handler.EventHandler.getDomTarget($0);
if($1){var $3=$1.document;
if($2==$1||$2==$3||$2==$3.documentElement||$2==$3.body){return $3.body.qx_Widget;
}}return qx.event.handler.EventHandler.getOriginalTargetObject($2);
},
getRelatedOriginalTargetObjectFromEvent:function($0){return qx.event.handler.EventHandler.getOriginalTargetObject($0.relatedTarget||($0.type==$[86]?$0.fromElement:$0.toElement));
},
getTargetObject:function($0,
$1,
$2){if(!$1){var $1=qx.event.handler.EventHandler.getOriginalTargetObject($0);
if(!$1){return null;
}}while($1){if(!$2&&!$1.getEnabled()){return null;
}if(!$1.getAnonymous()){break;
}$1=$1.getParent();
}return $1;
},
getTargetObjectFromEvent:function($0){return qx.event.handler.EventHandler.getTargetObject(qx.event.handler.EventHandler.getDomTarget($0));
},
getRelatedTargetObjectFromEvent:function($0){var $1=$0.relatedTarget;
if(!$1){if($0.type==$[86]){$1=$0.fromElement;
}else{$1=$0.toElement;
}}return qx.event.handler.EventHandler.getTargetObject($1);
}},
properties:{allowClientContextMenu:{check:$[2],
init:false},
allowClientSelectAll:{check:$[2],
init:false},
captureWidget:{check:$[112],
nullable:true,
apply:$[1426]},
focusRoot:{check:$[330],
nullable:true,
apply:$[674]}},
members:{_lastMouseEventType:null,
_lastMouseDown:false,
_lastMouseEventDate:0,
_applyCaptureWidget:function($0,
$1){if($1){$1.setCapture(false);
}
if($0){$0.setCapture(true);
}},
_applyFocusRoot:function($0,
$1){if($1){$1.setFocusedChild(null);
}
if($0&&$0.getFocusedChild()==null){$0.setFocusedChild($0);
}},
addCommand:function($0){this._commands[$0.toHashCode()]=$0;
},
removeCommand:function($0){delete this._commands[$0.toHashCode()];
},
_checkKeyEventMatch:function($0){var $1;
for(var $2 in this._commands){$1=this._commands[$2];
if($1.getEnabled()&&$1.matchesKeyEvent($0)){if(!$1.execute($0.getTarget())){$0.preventDefault();
}break;
}}},
attachEvents:function(){this.attachEventTypes(qx.event.handler.EventHandler.mouseEventTypes,
this.__onmouseevent);
this.attachEventTypes(qx.event.handler.EventHandler.dragEventTypes,
this.__ondragevent);
qx.event.handler.KeyEventHandler.getInstance()._attachEvents();
qx.html.EventRegistration.addEventListener(window,
$[214],
this.__onwindowblur);
qx.html.EventRegistration.addEventListener(window,
$[256],
this.__onwindowfocus);
qx.html.EventRegistration.addEventListener(window,
$[353],
this.__onwindowresize);
document.body.onselect=document.onselectstart=document.onselectionchange=this.__onselectevent;
},
detachEvents:function(){this.detachEventTypes(qx.event.handler.EventHandler.mouseEventTypes,
this.__onmouseevent);
this.detachEventTypes(qx.event.handler.EventHandler.dragEventTypes,
this.__ondragevent);
qx.event.handler.KeyEventHandler.getInstance()._detachEvents();
qx.html.EventRegistration.removeEventListener(window,
$[214],
this.__onwindowblur);
qx.html.EventRegistration.removeEventListener(window,
$[256],
this.__onwindowfocus);
qx.html.EventRegistration.removeEventListener(window,
$[353],
this.__onwindowresize);
document.body.onselect=document.onselectstart=document.onselectionchange=null;
},
attachEventTypes:function($0,
$1){try{var $2=qx.core.Variant.isSet($[1],
$[25])?window:document.body;
for(var $3=0,
$4=$0.length;$3<$4;$3++){qx.html.EventRegistration.addEventListener($2,
$0[$3],
$1);
}}catch(ex){throw new Error("qx.event.handler.EventHandler: Failed to attach window event types: "+$0+": "+ex);
}},
detachEventTypes:function($0,
$1){try{var $2=qx.core.Variant.isSet($[1],
$[25])?window:document.body;
for(var $3=0,
$4=$0.length;$3<$4;$3++){qx.html.EventRegistration.removeEventListener($2,
$0[$3],
$1);
}}catch(ex){throw new Error("qx.event.handler.EventHandler: Failed to detach window event types: "+$0+": "+ex);
}},
_onkeyevent_post:function($0,
$1,
$2,
$3,
$4){var $5=qx.event.handler.EventHandler.getDomTarget($0);
var $6=this.getFocusRoot();
var $7=this.getCaptureWidget()||($6==null?null:$6.getActiveChild());
var $8=new qx.event.type.KeyEvent($1,
$0,
$5,
$7,
null,
$2,
$3,
$4);
if($1==$[45]){this._checkKeyEventMatch($8);
}
if($7!=null&&$7.getEnabled()){switch($4){case $[245]:case $[253]:if(qx.Class.isDefined($[166])){qx.ui.menu.Manager.getInstance().update($7,
$1);
}break;
}if(!this.getAllowClientSelectAll()){if($0.ctrlKey&&$4==$[205]){switch($5.tagName.toLowerCase()){case $[128]:case $[311]:case $[334]:break;
default:qx.event.handler.EventHandler.stopDomEvent($0);
}}}
try{$7.dispatchEvent($8);
if(qx.Class.isDefined($[328])){qx.event.handler.DragAndDropHandler.getInstance().handleKeyEvent($8);
}}catch(ex){this.error("Failed to dispatch key event",
ex);
this.createDispatchDataEvent($[78],
ex);
}}$8.dispose();
},
_onmouseevent:qx.core.Variant.select($[1],
{"mshtml":function($0){if(!$0){$0=window.event;
}var $1=qx.event.handler.EventHandler.getDomTarget($0);
var $2=$0.type;
if($2==$[135]){if(this._mouseIsDown&&$0.button==0){this._onmouseevent_post($0,
$[39]);
this._mouseIsDown=false;
}}else{if($2==$[18]){this._mouseIsDown=true;
}else if($2==$[39]){this._mouseIsDown=false;
}if($2==$[39]&&!this._lastMouseDown&&((new Date).valueOf()-this._lastMouseEventDate)<250){this._onmouseevent_post($0,
$[18]);
}else if($2==$[152]&&this._lastMouseEventType==$[39]&&((new Date).valueOf()-this._lastMouseEventDate)<250){this._onmouseevent_post($0,
$[99]);
}
switch($2){case $[18]:case $[39]:case $[99]:case $[152]:case $[196]:this._lastMouseEventType=$2;
this._lastMouseEventDate=(new Date).valueOf();
this._lastMouseDown=$2==$[18];
}}this._onmouseevent_post($0,
$2,
$1);
},
"default":function($0){var $1=qx.event.handler.EventHandler.getDomTarget($0);
var $2=$0.type;
switch($2){case $[457]:$2=$[238];
break;
case $[99]:case $[152]:if($0.which!==1){return;
}}this._onmouseevent_post($0,
$2,
$1);
}}),
_onmouseevent_click_fix:qx.core.Variant.select($[1],
{"gecko":function($0,
$1,
$2){var $3=false;
switch($1){case $[18]:this._lastMouseDownDomTarget=$0;
this._lastMouseDownDispatchTarget=$2;
break;
case $[39]:if(this._lastMouseDownDispatchTarget===$2&&$0!==this._lastMouseDownDomTarget){$3=true;
}else{this._lastMouseDownDomTarget=null;
this._lastMouseDownDispatchTarget=null;
}}return $3;
},
"default":null}),
_onmouseevent_post:function($0,
$1,
$2){var $3,
$4,
$5,
$6,
$7,
$8,
$9,
$a;
$4=this.getCaptureWidget();
$7=qx.event.handler.EventHandler.getOriginalTargetObject($2);
if(!$4){$5=$6=qx.event.handler.EventHandler.getTargetObject(null,
$7,
true);
}else{$5=$4;
$6=qx.event.handler.EventHandler.getTargetObject(null,
$7,
true);
}if(!$6){return;
}$a=$6.getEnabled();
if(qx.core.Variant.isSet($[1],
$[25])){$9=this._onmouseevent_click_fix($2,
$1,
$5);
}if($1==$[196]&&!this.getAllowClientContextMenu()){qx.event.handler.EventHandler.stopDomEvent($0);
}if($a&&$1==$[18]){qx.event.handler.FocusHandler.mouseFocus=true;
var $b=$6.getFocusRoot();
if($b){this.setFocusRoot($b);
var $c=$6;
while(!$c.isFocusable()&&$c!=$b){$c=$c.getParent();
}$b.setFocusedChild($c);
$b.setActiveChild($6);
}}switch($1){case $[86]:case $[113]:$8=qx.event.handler.EventHandler.getRelatedTargetObjectFromEvent($0);
if($8==$6){return;
}}$3=new qx.event.type.MouseEvent($1,
$0,
$2,
$6,
$7,
$8);
qx.event.type.MouseEvent.storeEventState($3);
if($a){var $d=false;
$d=$5?$5.dispatchEvent($3):true;
this._onmouseevent_special_post($1,
$6,
$7,
$5,
$d,
$3,
$0);
}else{if($1==$[86]){if(qx.Class.isDefined($[165])){qx.ui.popup.ToolTipManager.getInstance().handleMouseOver($3);
}}}$3.dispose();
$3=null;
qx.ui.core.Widget.flushGlobalQueues();
if($9){this._onmouseevent_post($0,
$[99],
this._lastMouseDownDomTarget);
this._lastMouseDownDomTarget=null;
this._lastMouseDownDispatchTarget=null;
}},
_onmouseevent_special_post:function($0,
$1,
$2,
$3,
$4,
$5,
$6){switch($0){case $[18]:if(qx.Class.isDefined($[184])){qx.ui.popup.PopupManager.getInstance().update($1);
}
if(qx.Class.isDefined($[166])){qx.ui.menu.Manager.getInstance().update($1,
$0);
}
if(qx.Class.isDefined($[285])){qx.ui.embed.IframeManager.getInstance().handleMouseDown($5);
}break;
case $[39]:if(qx.Class.isDefined($[166])){qx.ui.menu.Manager.getInstance().update($1,
$0);
}
if(qx.Class.isDefined($[285])){qx.ui.embed.IframeManager.getInstance().handleMouseUp($5);
}break;
case $[86]:if(qx.Class.isDefined($[165])){qx.ui.popup.ToolTipManager.getInstance().handleMouseOver($5);
}break;
case $[113]:if(qx.Class.isDefined($[165])){qx.ui.popup.ToolTipManager.getInstance().handleMouseOut($5);
}break;
}this._ignoreWindowBlur=$0===$[18];
if(qx.Class.isDefined($[328])&&$1){qx.event.handler.DragAndDropHandler.getInstance().handleMouseEvent($5);
}},
_ondragevent:function($0){if(!$0){$0=window.event;
}qx.event.handler.EventHandler.stopDomEvent($0);
},
_onselectevent:function($0){if(!$0){$0=window.event;
}var $1=qx.event.handler.EventHandler.getOriginalTargetObjectFromEvent($0);
while($1){if($1.getSelectable()!=null){if(!$1.getSelectable()){qx.event.handler.EventHandler.stopDomEvent($0);
}break;
}$1=$1.getParent();
}},
_focused:false,
_onwindowblur:function($0){if(!this._focused||this._ignoreWindowBlur){return;
}this._focused=false;
this.setCaptureWidget(null);
if(qx.Class.isDefined($[184])){qx.ui.popup.PopupManager.getInstance().update();
}if(qx.Class.isDefined($[166])){qx.ui.menu.Manager.getInstance().update();
}if(qx.Class.isDefined($[328])){qx.event.handler.DragAndDropHandler.getInstance().globalCancelDrag();
}qx.ui.core.ClientDocument.getInstance().createDispatchEvent($[1375]);
},
_onwindowfocus:function($0){if(this._focused){return;
}this._focused=true;
qx.ui.core.ClientDocument.getInstance().createDispatchEvent($[1704]);
},
_onwindowresize:function($0){qx.ui.core.ClientDocument.getInstance().createDispatchEvent($[481]);
}},
destruct:function(){this.detachEvents();
this._disposeObjectDeep($[2010],
1);
this._disposeFields($[1159],
$[1490],
$[1700],
$[1175],
$[1989],
$[1934]);
this._disposeFields($[1688],
$[1428],
$[1242],
$[1823],
$[935]);
}});




/* ID: qx.dom.Node */
qx.Class.define($[1815],
{statics:{ELEMENT:1,
ATTRIBUTE:2,
TEXT:3,
CDATA_SECTION:4,
ENTITY_REFERENCE:5,
ENTITY:6,
PROCESSING_INSTRUCTION:7,
COMMENT:8,
DOCUMENT:9,
DOCUMENT_TYPE:10,
DOCUMENT_FRAGMENT:11,
NOTATION:12,
getDocument:function($0){if(this.isDocument($0)){return $0;
}return $0.ownerDocument||$0.document||null;
},
getWindow:qx.core.Variant.select($[1],
{"mshtml":function($0){return this.getDocument($0).parentWindow;
},
"default":function($0){return this.getDocument($0).defaultView;
}}),
getDocumentElement:function($0){return this.getDocument($0).documentElement;
},
getBodyElement:function($0){return this.getDocument($0).body;
},
isElement:function($0){return !!($0&&$0.nodeType===qx.dom.Node.ELEMENT);
},
isDocument:function($0){return !!($0&&$0.nodeType===qx.dom.Node.DOCUMENT);
},
isText:function($0){return !!($0&&$0.nodeType===qx.dom.Node.TEXT);
},
isWindow:function($0){return $0.document&&this.getWindow($0.document)==$0;
},
getText:function($0){if(!$0||!$0.nodeType){return null;
}
switch($0.nodeType){case 1:var $1,
$2=[],
$3=$0.childNodes,
$4=$3.length;
for($1=0;$1<$4;$1++){$2[$1]=this.getText($3[$1]);
}return $2.join($[0]);
case 2:return $0.nodeValue;
break;
case 3:return $0.nodeValue;
break;
}return null;
}}});




/* ID: qx.event.handler.KeyEventHandler */
qx.Class.define($[1596],
{type:$[24],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this.__onkeypress=qx.lang.Function.bind(this._onkeypress,
this);
this.__onkeyupdown=qx.lang.Function.bind(this._onkeyupdown,
this);
},
members:{_attachEvents:function(){var $0=qx.core.Variant.isSet($[1],
$[25])?window:document.body;
qx.html.EventRegistration.addEventListener($0,
$[57],
this.__onkeypress);
qx.html.EventRegistration.addEventListener($0,
$[146],
this.__onkeyupdown);
qx.html.EventRegistration.addEventListener($0,
$[45],
this.__onkeyupdown);
},
_detachEvents:function(){var $0=qx.core.Variant.isSet($[1],
$[25])?window:document.body;
qx.html.EventRegistration.removeEventListener($0,
$[57],
this.__onkeypress);
qx.html.EventRegistration.removeEventListener($0,
$[146],
this.__onkeyupdown);
qx.html.EventRegistration.removeEventListener($0,
$[45],
this.__onkeyupdown);
},
_onkeyupdown:qx.core.Variant.select($[1],
{"mshtml":function($0){$0=window.event||$0;
var $1=$0.keyCode;
var $2=0;
var $3=$0.type;
if(!(this._lastUpDownType[$1]==$[45]&&$3==$[45])){this._idealKeyHandler($1,
$2,
$3,
$0);
}if($3==$[45]){if(this._isNonPrintableKeyCode($1)||
$1==
8||$1==9){this._idealKeyHandler($1,
$2,
$[57],
$0);
}}this._lastUpDownType[$1]=$3;
},
"gecko":function($0){var $1=this._keyCodeFix[$0.keyCode]||$0.keyCode;
var $2=$0.charCode;
var $3=$0.type;
if(qx.core.Client.getInstance().runsOnWindows()){var $4=$1?this._keyCodeToIdentifier($1):this._charCodeToIdentifier($2);
if(!(this._lastUpDownType[$4]==$[57]&&$3==$[45])){this._idealKeyHandler($1,
$2,
$3,
$0);
}this._lastUpDownType[$4]=$3;
}else{this._idealKeyHandler($1,
$2,
$3,
$0);
}},
"webkit":function($0){var $1=0;
var $2=0;
var $3=$0.type;
if(qx.core.Client.getInstance().getVersion()<420){if(!this._lastCharCodeForType){this._lastCharCodeForType={};
}var $4=this._lastCharCodeForType[$3]>63000;
if($4){this._lastCharCodeForType[$3]=null;
return;
}this._lastCharCodeForType[$3]=$0.charCode;
}
if($3==$[146]||$3==$[45]){$1=this._charCode2KeyCode[$0.charCode]||$0.keyCode;
}else{if(this._charCode2KeyCode[$0.charCode]){$1=this._charCode2KeyCode[$0.charCode];
}else{$2=$0.charCode;
}}this._idealKeyHandler($1,
$2,
$3,
$0);
},
"opera":function($0){this._idealKeyHandler($0.keyCode,
0,
$0.type,
$0);
},
"default":function(){throw new Error("Unsupported browser for key event handler!");
}}),
_onkeypress:qx.core.Variant.select($[1],
{"mshtml":function($0){var $0=window.event||$0;
if(this._charCode2KeyCode[$0.keyCode]){this._idealKeyHandler(this._charCode2KeyCode[$0.keyCode],
0,
$0.type,
$0);
}else{this._idealKeyHandler(0,
$0.keyCode,
$0.type,
$0);
}},
"gecko":function($0){var $1=this._keyCodeFix[$0.keyCode]||$0.keyCode;
var $2=$0.charCode;
var $3=$0.type;
if(qx.core.Client.getInstance().runsOnWindows()){var $4=$1?this._keyCodeToIdentifier($1):this._charCodeToIdentifier($2);
if(!(this._lastUpDownType[$4]==$[57]&&$3==$[45])){this._idealKeyHandler($1,
$2,
$3,
$0);
}this._lastUpDownType[$4]=$3;
}else{this._idealKeyHandler($1,
$2,
$3,
$0);
}},
"webkit":function($0){var $1=0;
var $2=0;
var $3=$0.type;
if(qx.core.Client.getInstance().getVersion()<420){if(!this._lastCharCodeForType){this._lastCharCodeForType={};
}var $4=this._lastCharCodeForType[$3]>63000;
if($4){this._lastCharCodeForType[$3]=null;
return;
}this._lastCharCodeForType[$3]=$0.charCode;
}
if($3==$[146]||$3==$[45]){$1=this._charCode2KeyCode[$0.charCode]||$0.keyCode;
}else{if(this._charCode2KeyCode[$0.charCode]){$1=this._charCode2KeyCode[$0.charCode];
}else{$2=$0.charCode;
}}this._idealKeyHandler($1,
$2,
$3,
$0);
},
"opera":function($0){if(this._keyCodeToIdentifierMap[$0.keyCode]){this._idealKeyHandler($0.keyCode,
0,
$0.type,
$0);
}else{this._idealKeyHandler(0,
$0.keyCode,
$0.type,
$0);
}},
"default":function(){throw new Error("Unsupported browser for key event handler!");
}}),
_specialCharCodeMap:{8:$[561],
9:$[253],
13:$[110],
27:$[245],
32:$[248]},
_keyCodeToIdentifierMap:{16:$[633],
17:$[399],
18:$[560],
20:$[1236],
224:$[1373],
37:$[147],
38:$[116],
39:$[148],
40:$[155],
33:$[126],
34:$[177],
35:$[266],
36:$[227],
45:$[271],
46:$[284],
112:$[352],
113:$[275],
114:$[397],
115:$[421],
116:$[441],
117:$[454],
118:$[478],
119:$[504],
120:$[516],
121:$[427],
122:$[406],
123:$[383],
144:$[192],
44:$[580],
145:$[1030],
19:$[650],
91:$[1405],
93:$[1309]},
_numpadToCharCode:{96:$[56].charCodeAt(0),
97:$[1572].charCodeAt(0),
98:$[1294].charCodeAt(0),
99:$[1393].charCodeAt(0),
100:$[1093].charCodeAt(0),
101:$[1193].charCodeAt(0),
102:$[895].charCodeAt(0),
103:$[982].charCodeAt(0),
104:$[892].charCodeAt(0),
105:$[229].charCodeAt(0),
106:$[153].charCodeAt(0),
107:$[212].charCodeAt(0),
109:$[96].charCodeAt(0),
110:$[17].charCodeAt(0),
111:$[145].charCodeAt(0)},
_charCodeA:$[205].charCodeAt(0),
_charCodeZ:$[581].charCodeAt(0),
_charCode0:$[56].charCodeAt(0),
_charCode9:$[229].charCodeAt(0),
_isNonPrintableKeyCode:function($0){return this._keyCodeToIdentifierMap[$0]?true:false;
},
_isIdentifiableKeyCode:function($0){if($0>=this._charCodeA&&$0<=this._charCodeZ){return true;
}if($0>=this._charCode0&&$0<=this._charCode9){return true;
}if(this._specialCharCodeMap[$0]){return true;
}if(this._numpadToCharCode[$0]){return true;
}if(this._isNonPrintableKeyCode($0)){return true;
}return false;
},
isValidKeyIdentifier:function($0){if(this._identifierToKeyCodeMap[$0]){return true;
}
if($0.length!=1){return false;
}
if($0>=$[56]&&$0<=$[229]){return true;
}
if($0>=$[205]&&$0<=$[581]){return true;
}
switch($0){case $[212]:case $[96]:case $[153]:case $[145]:return true;
default:return false;
}},
_keyCodeToIdentifier:function($0){if(this._isIdentifiableKeyCode($0)){var $1=this._numpadToCharCode[$0];
if($1){return String.fromCharCode($1);
}return (this._keyCodeToIdentifierMap[$0]||this._specialCharCodeMap[$0]||String.fromCharCode($0));
}else{return $[907];
}},
_charCodeToIdentifier:function($0){return this._specialCharCodeMap[$0]||String.fromCharCode($0).toUpperCase();
},
_identifierToKeyCode:function($0){return this._identifierToKeyCodeMap[$0]||$0.charCodeAt(0);
},
_idealKeyHandler:function($0,
$1,
$2,
$3){if(!$0&&!$1){return;
}var $4;
if($0){$4=this._keyCodeToIdentifier($0);
qx.event.handler.EventHandler.getInstance()._onkeyevent_post($3,
$2,
$0,
$1,
$4);
}else{$4=this._charCodeToIdentifier($1);
qx.event.handler.EventHandler.getInstance()._onkeyevent_post($3,
$[57],
$0,
$1,
$4);
qx.event.handler.EventHandler.getInstance()._onkeyevent_post($3,
$[1611],
$0,
$1,
$4);
}}},
defer:function($0,
$1,
$2){if(!$1._identifierToKeyCodeMap){$1._identifierToKeyCodeMap={};
for(var $3 in $1._keyCodeToIdentifierMap){$1._identifierToKeyCodeMap[$1._keyCodeToIdentifierMap[$3]]=parseInt($3);
}
for(var $3 in $1._specialCharCodeMap){$1._identifierToKeyCodeMap[$1._specialCharCodeMap[$3]]=parseInt($3);
}}
if(qx.core.Variant.isSet($[1],
$[20])){$1._lastUpDownType={};
$1._charCode2KeyCode={13:13,
27:27};
}else if(qx.core.Variant.isSet($[1],
$[25])){$1._lastUpDownType={};
$1._keyCodeFix={12:$1._identifierToKeyCode($[192])};
}else if(qx.core.Variant.isSet($[1],
$[160])){$1._charCode2KeyCode={63289:$1._identifierToKeyCode($[192]),
63276:$1._identifierToKeyCode($[126]),
63277:$1._identifierToKeyCode($[177]),
63275:$1._identifierToKeyCode($[266]),
63273:$1._identifierToKeyCode($[227]),
63234:$1._identifierToKeyCode($[147]),
63232:$1._identifierToKeyCode($[116]),
63235:$1._identifierToKeyCode($[148]),
63233:$1._identifierToKeyCode($[155]),
63272:$1._identifierToKeyCode($[284]),
63302:$1._identifierToKeyCode($[271]),
63236:$1._identifierToKeyCode($[352]),
63237:$1._identifierToKeyCode($[275]),
63238:$1._identifierToKeyCode($[397]),
63239:$1._identifierToKeyCode($[421]),
63240:$1._identifierToKeyCode($[441]),
63241:$1._identifierToKeyCode($[454]),
63242:$1._identifierToKeyCode($[478]),
63243:$1._identifierToKeyCode($[504]),
63244:$1._identifierToKeyCode($[516]),
63245:$1._identifierToKeyCode($[427]),
63246:$1._identifierToKeyCode($[406]),
63247:$1._identifierToKeyCode($[383]),
63248:$1._identifierToKeyCode($[580]),
3:$1._identifierToKeyCode($[110]),
12:$1._identifierToKeyCode($[192]),
13:$1._identifierToKeyCode($[110])};
}},
destruct:function(){this._detachEvents();
this._disposeFields($[1073]);
}});




/* ID: qx.event.type.DomEvent */
qx.Class.define($[1488],
{extend:qx.event.type.Event,
construct:function($0,
$1,
$2,
$3,
$4){arguments.callee.base.call(this,
$0);
this.setDomEvent($1);
this.setDomTarget($2);
this.setTarget($3);
this.setOriginalTarget($4);
},
statics:{SHIFT_MASK:1,
CTRL_MASK:2,
ALT_MASK:4,
META_MASK:8},
properties:{bubbles:{_fast:true,
defaultValue:true,
noCompute:true},
propagationStopped:{_fast:true,
defaultValue:false,
noCompute:true},
domEvent:{_fast:true,
setOnlyOnce:true,
noCompute:true},
domTarget:{_fast:true,
setOnlyOnce:true,
noCompute:true},
modifiers:{_cached:true,
defaultValue:null}},
members:{_computeModifiers:function(){var $0=0;
var $1=this.getDomEvent();
if($1.shiftKey)$0|=qx.event.type.DomEvent.SHIFT_MASK;
if($1.ctrlKey)$0|=qx.event.type.DomEvent.CTRL_MASK;
if($1.altKey)$0|=qx.event.type.DomEvent.ALT_MASK;
if($1.metaKey)$0|=qx.event.type.DomEvent.META_MASK;
return $0;
},
isCtrlPressed:function(){return this.getDomEvent().ctrlKey;
},
isShiftPressed:function(){return this.getDomEvent().shiftKey;
},
isAltPressed:function(){return this.getDomEvent().altKey;
},
isMetaPressed:function(){return this.getDomEvent().metaKey;
},
isCtrlOrCommandPressed:function(){if(qx.core.Client.getInstance().runsOnMacintosh()){return this.getDomEvent().metaKey;
}else{return this.getDomEvent().ctrlKey;
}},
setDefaultPrevented:qx.core.Variant.select($[1],
{"mshtml":function($0){if(!$0){return this.error("It is not possible to set preventDefault to false if it was true before!",
"setDefaultPrevented");
}this.getDomEvent().returnValue=false;
arguments.callee.base.call(this,
$0);
},
"default":function($0){if(!$0){return this.error("It is not possible to set preventDefault to false if it was true before!",
"setDefaultPrevented");
}this.getDomEvent().preventDefault();
this.getDomEvent().returnValue=false;
arguments.callee.base.call(this,
$0);
}})},
destruct:function(){this._disposeFields($[1162],
$[1697]);
}});




/* ID: qx.event.type.KeyEvent */
qx.Class.define($[201],
{extend:qx.event.type.DomEvent,
construct:function($0,
$1,
$2,
$3,
$4,
$5,
$6,
$7){arguments.callee.base.call(this,
$0,
$1,
$2,
$3,
$4);
this._keyCode=$5;
this.setCharCode($6);
this.setKeyIdentifier($7);
},
statics:{keys:{esc:27,
enter:13,
tab:9,
space:32,
up:38,
down:40,
left:37,
right:39,
shift:16,
ctrl:17,
alt:18,
f1:112,
f2:113,
f3:114,
f4:115,
f5:116,
f6:117,
f7:118,
f8:119,
f9:120,
f10:121,
f11:122,
f12:123,
print:124,
del:46,
backspace:8,
insert:45,
home:36,
end:35,
pageup:33,
pagedown:34,
numlock:144,
numpad_0:96,
numpad_1:97,
numpad_2:98,
numpad_3:99,
numpad_4:100,
numpad_5:101,
numpad_6:102,
numpad_7:103,
numpad_8:104,
numpad_9:105,
numpad_divide:111,
numpad_multiply:106,
numpad_minus:109,
numpad_plus:107},
codes:{}},
properties:{charCode:{_fast:true,
setOnlyOnce:true,
noCompute:true},
keyIdentifier:{_fast:true,
setOnlyOnce:true,
noCompute:true}},
members:{getKeyCode:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1076]);
return this._keyCode;
}},
defer:function($0){for(var $1 in $0.keys){$0.codes[$0.keys[$1]]=$1;
}}});




/* ID: qx.event.type.MouseEvent */
qx.Class.define($[95],
{extend:qx.event.type.DomEvent,
construct:function($0,
$1,
$2,
$3,
$4,
$5){arguments.callee.base.call(this,
$0,
$1,
$2,
$3,
$4);
if($5){this.setRelatedTarget($5);
}},
statics:{C_BUTTON_LEFT:"left",
C_BUTTON_MIDDLE:"middle",
C_BUTTON_RIGHT:"right",
C_BUTTON_NONE:"none",
_screenX:0,
_screenY:0,
_clientX:0,
_clientY:0,
_pageX:0,
_pageY:0,
_button:null,
buttons:qx.core.Variant.select($[1],
{"mshtml":{left:1,
right:2,
middle:4},
"default":{left:0,
right:2,
middle:1}}),
storeEventState:function($0){this._screenX=$0.getScreenX();
this._screenY=$0.getScreenY();
this._clientX=$0.getClientX();
this._clientY=$0.getClientY();
this._pageX=$0.getPageX();
this._pageY=$0.getPageY();
this._button=$0.getButton();
},
getScreenX:function(){return this._screenX;
},
getScreenY:function(){return this._screenY;
},
getClientX:function(){return this._clientX;
},
getClientY:function(){return this._clientY;
},
getPageX:function(){return this._pageX;
},
getPageY:function(){return this._pageY;
},
getButton:function(){return this._button;
}},
properties:{button:{_fast:true,
readOnly:true},
wheelDelta:{_fast:true,
readOnly:true}},
members:{getPageX:qx.core.Variant.select($[1],
{"mshtml":function(){return this.getDomEvent().clientX+qx.bom.Viewport.getScrollLeft(window);
},
"default":function(){return this.getDomEvent().pageX;
}}),
getPageY:qx.core.Variant.select($[1],
{"mshtml":function(){return this.getDomEvent().clientY+qx.bom.Viewport.getScrollTop(window);
},
"default":function(){return this.getDomEvent().pageY;
}}),
getClientX:function(){return this.getDomEvent().clientX;
},
getClientY:function(){return this.getDomEvent().clientY;
},
getScreenX:function(){return this.getDomEvent().screenX;
},
getScreenY:function(){return this.getDomEvent().screenY;
},
isLeftButtonPressed:qx.core.Variant.select($[1],
{"mshtml":function(){if(this.getType()==$[99]){return true;
}else{return this.getButton()===qx.event.type.MouseEvent.C_BUTTON_LEFT;
}},
"default":function(){return this.getButton()===qx.event.type.MouseEvent.C_BUTTON_LEFT;
}}),
isMiddleButtonPressed:function(){return this.getButton()===qx.event.type.MouseEvent.C_BUTTON_MIDDLE;
},
isRightButtonPressed:function(){return this.getButton()===qx.event.type.MouseEvent.C_BUTTON_RIGHT;
},
__buttons:qx.core.Variant.select($[1],
{"mshtml":{1:$[13],
2:$[14],
4:$[30]},
"default":{0:$[13],
2:$[14],
1:$[30]}}),
_computeButton:function(){switch(this.getDomEvent().type){case $[99]:case $[152]:return $[13];
case $[196]:return $[14];
default:return this.__buttons[this.getDomEvent().button]||$[11];
}},
_computeWheelDelta:qx.core.Variant.select($[1],
{"default":function(){return this.getDomEvent().wheelDelta/120;
},
"gecko":function(){return -(this.getDomEvent().detail/3);
}})}});




/* ID: qx.bom.Viewport */
qx.Class.define($[2005],
{statics:{getWidth:qx.core.Variant.select($[1],
{"opera":function($0){return ($0||window).document.body.clientWidth;
},
"webkit":function($0){return ($0||window).innerWidth;
},
"default":function($0){var $1=($0||window).document;
return $1.compatMode===$[98]?$1.documentElement.clientWidth:$1.body.clientWidth;
}}),
getHeight:qx.core.Variant.select($[1],
{"opera":function($0){return ($0||window).document.body.clientHeight;
},
"webkit":function($0){return ($0||window).innerHeight;
},
"default":function($0){var $1=($0||window).document;
return $1.compatMode===$[98]?$1.documentElement.clientHeight:$1.body.clientHeight;
}}),
getScrollLeft:qx.core.Variant.select($[1],
{"mshtml":function($0){var $1=($0||window).document;
return $1.documentElement.scrollLeft||$1.body.scrollLeft;
},
"default":function($0){return ($0||window).pageXOffset;
}}),
getScrollTop:qx.core.Variant.select($[1],
{"mshtml":function($0){var $1=($0||window).document;
return $1.documentElement.scrollTop||$1.body.scrollTop;
},
"default":function($0){return ($0||window).pageYOffset;
}})}});




/* ID: qx.util.manager.Object */
qx.Class.define($[1269],
{extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this._objects={};
},
members:{add:function($0){if(this.getDisposed()){return;
}this._objects[$0.toHashCode()]=$0;
},
remove:function($0){if(this.getDisposed()){return false;
}delete this._objects[$0.toHashCode()];
},
has:function($0){return this._objects[$0.toHashCode()]!=null;
},
get:function($0){return this._objects[$0.toHashCode()];
},
getAll:function(){return this._objects;
},
enableAll:function(){for(var $0 in this._objects){this._objects[$0].setEnabled(true);
}},
disableAll:function(){for(var $0 in this._objects){this._objects[$0].setEnabled(false);
}}},
destruct:function(){this._disposeObjectDeep($[579]);
}});




/* ID: qx.ui.embed.IframeManager */
qx.Class.define($[285],
{type:$[24],
extend:qx.util.manager.Object,
construct:function(){arguments.callee.base.call(this);
},
members:{handleMouseDown:function($0){var $1=this.getAll();
for(var $2 in $1){var $3=$1[$2];
$3.block();
}},
handleMouseUp:function($0){var $1=this.getAll();
for(var $2 in $1){var $3=$1[$2];
$3.release();
}}}});




/* ID: qx.ui.layout.CanvasLayout */
qx.Class.define($[1569],
{extend:qx.ui.core.Parent,
construct:function(){arguments.callee.base.call(this);
},
members:{_createLayoutImpl:function(){return new qx.ui.layout.impl.CanvasLayoutImpl(this);
}}});




/* ID: qx.ui.layout.impl.LayoutImpl */
qx.Class.define($[960],
{extend:qx.core.Object,
construct:function($0){arguments.callee.base.call(this);
this._widget=$0;
},
members:{getWidget:function(){return this._widget;
},
computeChildBoxWidth:function($0){return $0.getWidthValue()||$0._computeBoxWidthFallback();
},
computeChildBoxHeight:function($0){return $0.getHeightValue()||$0._computeBoxHeightFallback();
},
computeChildNeededWidth:function($0){var $1=$0._computedMinWidthTypePercent?null:$0.getMinWidthValue();
var $2=$0._computedMaxWidthTypePercent?null:$0.getMaxWidthValue();
var $3=($0._computedWidthTypePercent||$0._computedWidthTypeFlex?null:$0.getWidthValue())||$0.getPreferredBoxWidth()||0;
return qx.lang.Number.limit($3,
$1,
$2)+$0.getMarginLeft()+$0.getMarginRight();
},
computeChildNeededHeight:function($0){var $1=$0._computedMinHeightTypePercent?null:$0.getMinHeightValue();
var $2=$0._computedMaxHeightTypePercent?null:$0.getMaxHeightValue();
var $3=($0._computedHeightTypePercent||$0._computedHeightTypeFlex?null:$0.getHeightValue())||$0.getPreferredBoxHeight()||0;
return qx.lang.Number.limit($3,
$1,
$2)+$0.getMarginTop()+$0.getMarginBottom();
},
computeChildrenNeededWidth_max:function(){for(var $0=0,
$1=this.getWidget().getVisibleChildren(),
$2=$1.length,
$3=0;$0<$2;$0++){$3=Math.max($3,
$1[$0].getNeededWidth());
}return $3;
},
computeChildrenNeededHeight_max:function(){for(var $0=0,
$1=this.getWidget().getVisibleChildren(),
$2=$1.length,
$3=0;$0<$2;$0++){$3=Math.max($3,
$1[$0].getNeededHeight());
}return $3;
},
computeChildrenNeededWidth_sum:function(){for(var $0=0,
$1=this.getWidget().getVisibleChildren(),
$2=$1.length,
$3=0;$0<$2;$0++){$3+=$1[$0].getNeededWidth();
}return $3;
},
computeChildrenNeededHeight_sum:function(){for(var $0=0,
$1=this.getWidget().getVisibleChildren(),
$2=$1.length,
$3=0;$0<$2;$0++){$3+=$1[$0].getNeededHeight();
}return $3;
},
computeChildrenNeededWidth:null,
computeChildrenNeededHeight:null,
updateSelfOnChildOuterWidthChange:function($0){},
updateSelfOnChildOuterHeightChange:function($0){},
updateChildOnInnerWidthChange:function($0){},
updateChildOnInnerHeightChange:function($0){},
updateSelfOnJobQueueFlush:function($0){},
updateChildrenOnJobQueueFlush:function($0){},
updateChildrenOnAddChild:function($0,
$1){},
updateChildrenOnRemoveChild:function($0,
$1){},
updateChildrenOnMoveChild:function($0,
$1,
$2){},
flushChildrenQueue:function($0){var $1=this.getWidget();
for(var $2 in $0){$1._layoutChild($0[$2]);
}},
layoutChild:function($0,
$1){},
layoutChild_sizeLimitX:qx.core.Variant.select($[1],
{"mshtml":qx.lang.Function.returnTrue,
"default":function($0,
$1){if($1.minWidth){$0._computedMinWidthTypeNull?$0._resetRuntimeMinWidth():$0._renderRuntimeMinWidth($0.getMinWidthValue());
}else if($1.initial&&!$0._computedMinWidthTypeNull){$0._renderRuntimeMinWidth($0.getMinWidthValue());
}
if($1.maxWidth){$0._computedMaxWidthTypeNull?$0._resetRuntimeMaxWidth():$0._renderRuntimeMaxWidth($0.getMaxWidthValue());
}else if($1.initial&&!$0._computedMaxWidthTypeNull){$0._renderRuntimeMaxWidth($0.getMaxWidthValue());
}}}),
layoutChild_sizeLimitY:qx.core.Variant.select($[1],
{"mshtml":qx.lang.Function.returnTrue,
"default":function($0,
$1){if($1.minHeight){$0._computedMinHeightTypeNull?$0._resetRuntimeMinHeight():$0._renderRuntimeMinHeight($0.getMinHeightValue());
}else if($1.initial&&!$0._computedMinHeightTypeNull){$0._renderRuntimeMinHeight($0.getMinHeightValue());
}
if($1.maxHeight){$0._computedMaxHeightTypeNull?$0._resetRuntimeMaxHeight():$0._renderRuntimeMaxHeight($0.getMaxHeightValue());
}else if($1.initial&&!$0._computedMaxHeightTypeNull){$0._renderRuntimeMaxHeight($0.getMaxHeightValue());
}}}),
layoutChild_marginX:function($0,
$1){if($1.marginLeft||$1.initial){var $2=$0.getMarginLeft();
$2!=null?$0._renderRuntimeMarginLeft($2):$0._resetRuntimeMarginLeft();
}
if($1.marginRight||$1.initial){var $3=$0.getMarginRight();
$3!=null?$0._renderRuntimeMarginRight($3):$0._resetRuntimeMarginRight();
}},
layoutChild_marginY:function($0,
$1){if($1.marginTop||$1.initial){var $2=$0.getMarginTop();
$2!=null?$0._renderRuntimeMarginTop($2):$0._resetRuntimeMarginTop();
}
if($1.marginBottom||$1.initial){var $3=$0.getMarginBottom();
$3!=null?$0._renderRuntimeMarginBottom($3):$0._resetRuntimeMarginBottom();
}},
layoutChild_sizeX_essentialWrapper:function($0,
$1){return $0._isWidthEssential()?this.layoutChild_sizeX($0,
$1):$0._resetRuntimeWidth();
},
layoutChild_sizeY_essentialWrapper:function($0,
$1){return $0._isHeightEssential()?this.layoutChild_sizeY($0,
$1):$0._resetRuntimeHeight();
}},
defer:function($0,
$1){$1.computeChildrenNeededWidth=$1.computeChildrenNeededWidth_max;
$1.computeChildrenNeededHeight=$1.computeChildrenNeededHeight_max;
},
destruct:function(){this._disposeFields($[1407]);
}});




/* ID: qx.lang.Number */
qx.Class.define($[1963],
{statics:{isInRange:function($0,
$1,
$2){return $0>=$1&&$0<=$2;
},
isBetweenRange:function($0,
$1,
$2){return $0>$1&&$0<$2;
},
limit:function($0,
$1,
$2){if(typeof $2===$[54]&&$0>$2){return $2;
}else if(typeof $1===$[54]&&$0<$1){return $1;
}else{return $0;
}}}});




/* ID: qx.ui.layout.impl.CanvasLayoutImpl */
qx.Class.define($[2045],
{extend:qx.ui.layout.impl.LayoutImpl,
construct:function($0){arguments.callee.base.call(this,
$0);
},
members:{computeChildBoxWidth:function($0){var $1=null;
if($0._computedLeftTypeNull||$0._computedRightTypeNull){$1=$0.getWidthValue();
}else if($0._hasParent){$1=this.getWidget().getInnerWidth()-$0.getLeftValue()-$0.getRightValue();
}return $1||$0._computeBoxWidthFallback();
},
computeChildBoxHeight:function($0){var $1=null;
if($0._computedTopTypeNull||$0._computedBottomTypeNull){$1=$0.getHeightValue();
}else if($0._hasParent){$1=this.getWidget().getInnerHeight()-$0.getTopValue()-$0.getBottomValue();
}return $1||$0._computeBoxHeightFallback();
},
computeChildNeededWidth:function($0){var $1=$0._computedLeftTypePercent?null:$0.getLeftValue();
var $2=$0._computedRightTypePercent?null:$0.getRightValue();
var $3=$0._computedMinWidthTypePercent?null:$0.getMinWidthValue();
var $4=$0._computedMaxWidthTypePercent?null:$0.getMaxWidthValue();
if($1!=null&&$2!=null){var $5=$0.getPreferredBoxWidth()||0;
}else{var $5=($0._computedWidthTypePercent?null:$0.getWidthValue())||$0.getPreferredBoxWidth()||0;
}return qx.lang.Number.limit($5,
$3,
$4)+$1+$2+$0.getMarginLeft()+$0.getMarginRight();
},
computeChildNeededHeight:function($0){var $1=$0._computedTopTypePercent?null:$0.getTopValue();
var $2=$0._computedBottomTypePercent?null:$0.getBottomValue();
var $3=$0._computedMinHeightTypePercent?null:$0.getMinHeightValue();
var $4=$0._computedMaxHeightTypePercent?null:$0.getMaxHeightValue();
if($1!=null&&$2!=null){var $5=$0.getPreferredBoxHeight()||0;
}else{var $5=($0._computedHeightTypePercent?null:$0.getHeightValue())||$0.getPreferredBoxHeight()||0;
}return qx.lang.Number.limit($5,
$3,
$4)+$1+$2+$0.getMarginTop()+$0.getMarginBottom();
},
updateChildOnInnerWidthChange:function($0){var $1=$0._recomputePercentX();
var $2=$0._recomputeRangeX();
return $1||$2;
},
updateChildOnInnerHeightChange:function($0){var $1=$0._recomputePercentY();
var $2=$0._recomputeRangeY();
return $1||$2;
},
layoutChild:function($0,
$1){this.layoutChild_sizeX_essentialWrapper($0,
$1);
this.layoutChild_sizeY_essentialWrapper($0,
$1);
this.layoutChild_sizeLimitX($0,
$1);
this.layoutChild_sizeLimitY($0,
$1);
this.layoutChild_locationX($0,
$1);
this.layoutChild_locationY($0,
$1);
this.layoutChild_marginX($0,
$1);
this.layoutChild_marginY($0,
$1);
},
layoutChild_sizeX:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function($0,
$1){if($1.initial||$1.width||$1.minWidth||$1.maxWidth||$1.left||$1.right){if($0._computedMinWidthTypeNull&&$0._computedWidthTypeNull&&$0._computedMaxWidthTypeNull&&!(!$0._computedLeftTypeNull&&!$0._computedRightTypeNull)){$0._resetRuntimeWidth();
}else{$0._renderRuntimeWidth($0.getBoxWidth());
}}},
"default":function($0,
$1){if($1.initial||$1.width){$0._computedWidthTypeNull?$0._resetRuntimeWidth():$0._renderRuntimeWidth($0.getWidthValue());
}}}),
layoutChild_sizeY:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function($0,
$1){if($1.initial||$1.height||$1.minHeight||$1.maxHeight||$1.top||$1.bottom){if($0._computedMinHeightTypeNull&&$0._computedHeightTypeNull&&$0._computedMaxHeightTypeNull&&!(!$0._computedTopTypeNull&&!$0._computedBottomTypeNull)){$0._resetRuntimeHeight();
}else{$0._renderRuntimeHeight($0.getBoxHeight());
}}},
"default":function($0,
$1){if($1.initial||$1.height){$0._computedHeightTypeNull?$0._resetRuntimeHeight():$0._renderRuntimeHeight($0.getHeightValue());
}}}),
layoutChild_locationX:function($0,
$1){var $2=this.getWidget();
if($1.initial||$1.left||$1.parentPaddingLeft){$0._computedLeftTypeNull?$0._computedRightTypeNull&&$2.getPaddingLeft()>0?$0._renderRuntimeLeft($2.getPaddingLeft()):$0._resetRuntimeLeft():$0._renderRuntimeLeft($0.getLeftValue()+$2.getPaddingLeft());
}
if($1.initial||$1.right||$1.parentPaddingRight){$0._computedRightTypeNull?$0._computedLeftTypeNull&&$2.getPaddingRight()>0?$0._renderRuntimeRight($2.getPaddingRight()):$0._resetRuntimeRight():$0._renderRuntimeRight($0.getRightValue()+$2.getPaddingRight());
}},
layoutChild_locationY:function($0,
$1){var $2=this.getWidget();
if($1.initial||$1.top||$1.parentPaddingTop){$0._computedTopTypeNull?$0._computedBottomTypeNull&&$2.getPaddingTop()>0?$0._renderRuntimeTop($2.getPaddingTop()):$0._resetRuntimeTop():$0._renderRuntimeTop($0.getTopValue()+$2.getPaddingTop());
}
if($1.initial||$1.bottom||$1.parentPaddingBottom){$0._computedBottomTypeNull?$0._computedTopTypeNull&&$2.getPaddingBottom()>0?$0._renderRuntimeBottom($2.getPaddingBottom()):$0._resetRuntimeBottom():$0._renderRuntimeBottom($0.getBottomValue()+$2.getPaddingBottom());
}}}});




/* ID: qx.ui.core.ClientDocument */
qx.Class.define($[1268],
{type:$[24],
extend:qx.ui.layout.CanvasLayout,
construct:function(){arguments.callee.base.call(this);
this._window=window;
this._document=window.document;
this.setElement(this._document.body);
this._document.body.style.position=$[0];
try{document.execCommand($[1996],
false,
true);
}catch(err){}this._cachedInnerWidth=this._document.body.offsetWidth;
this._cachedInnerHeight=this._document.body.offsetHeight;
this.addEventListener($[481],
this._onwindowresize);
this._modalWidgets=[];
this._modalNativeWindow=null;
this.activateFocusRoot();
this.initHideFocus();
this.initSelectable();
qx.event.handler.EventHandler.getInstance().setFocusRoot(this);
},
events:{"focus":$[4],
"windowblur":$[4],
"windowfocus":$[4],
"windowresize":$[4]},
properties:{appearance:{refine:true,
init:$[1123]},
enableElementFocus:{refine:true,
init:false},
enabled:{refine:true,
init:true},
selectable:{refine:true,
init:false},
hideFocus:{refine:true,
init:true},
globalCursor:{check:$[9],
nullable:true,
themeable:true,
apply:$[1244],
event:$[1736]}},
members:{_applyParent:qx.lang.Function.returnTrue,
getTopLevelWidget:qx.lang.Function.returnThis,
getWindowElement:function(){return this._window;
},
getDocumentElement:function(){return this._document;
},
getParent:qx.lang.Function.returnNull,
getToolTip:qx.lang.Function.returnNull,
isMaterialized:qx.lang.Function.returnTrue,
isSeeable:qx.lang.Function.returnTrue,
_isDisplayable:true,
_hasParent:false,
_initialLayoutDone:true,
_getBlocker:function(){if(!this._blocker){this._blocker=new qx.ui.core.ClientDocumentBlocker;
this._blocker.addEventListener($[18],
this.blockHelper,
this);
this._blocker.addEventListener($[39],
this.blockHelper,
this);
this.add(this._blocker);
}return this._blocker;
},
blockHelper:function($0){if(this._modalNativeWindow){if(!this._modalNativeWindow.isClosed()){this._modalNativeWindow.focus();
}else{this.debug("Window seems to be closed already! => Releasing Blocker");
this.release(this._modalNativeWindow);
}}},
block:function($0){this._getBlocker().show();
if(qx.Class.isDefined($[593])&&$0 instanceof qx.ui.window.Window){this._modalWidgets.push($0);
var $1=$0.getZIndex();
this._getBlocker().setZIndex($1);
$0.setZIndex($1+1);
}else if(qx.Class.isDefined($[337])&&$0 instanceof qx.client.NativeWindow){this._modalNativeWindow=$0;
this._getBlocker().setZIndex(1e7);
}},
release:function($0){if($0){if(qx.Class.isDefined($[337])&&$0 instanceof qx.client.NativeWindow){this._modalNativeWindow=null;
}else{qx.lang.Array.remove(this._modalWidgets,
$0);
}}var $1=this._modalWidgets.length;
if($1==0){this._getBlocker().hide();
}else{var $2=this._modalWidgets[$1-1];
var $3=$2.getZIndex();
this._getBlocker().setZIndex($3);
$2.setZIndex($3+1);
}},
createStyleElement:function($0){return qx.html.StyleSheet.createElement($0);
},
addCssRule:function($0,
$1,
$2){return qx.html.StyleSheet.addRule($0,
$1,
$2);
},
removeCssRule:function($0,
$1){return qx.html.StyleSheet.removeRule($0,
$1);
},
removeAllCssRules:function($0){return qx.html.StyleSheet.removeAllRules($0);
},
_applyGlobalCursor:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){if($0==$[318]){$0=$[217];
}
if($1==$[318]){$1=$[217];
}var $2,
$3;
var $4=this._cursorElements;
if($4){for(var $5=0,
$6=$4.length;$5<$6;$5++){$2=$4[$5];
if($2.style.cursor==$1){$2.style.cursor=$2._oldCursor;
$2._oldCursor=null;
}}}var $7=document.all;
var $4=this._cursorElements=[];
if($0!=null&&$0!=$[0]&&$0!=$[3]){for(var $5=0,
$6=$7.length;$5<$6;$5++){$2=$7[$5];
$3=$2.style.cursor;
if($3!=null&&$3!=$[0]&&$3!=$[3]){$2._oldCursor=$3;
$2.style.cursor=$0;
$4.push($2);
}}document.body.style.cursor=$0;
}else{document.body.style.cursor=$[0];
}},
"default":function($0,
$1){if(!this._globalCursorStyleSheet){this._globalCursorStyleSheet=this.createStyleElement();
}this.removeCssRule(this._globalCursorStyleSheet,
$[153]);
if($0){this.addCssRule(this._globalCursorStyleSheet,
$[153],
$[772]+$0+$[933]);
}}}),
_onwindowresize:function($0){if(qx.Class.isDefined($[184])){qx.ui.popup.PopupManager.getInstance().update();
}this._recomputeInnerWidth();
this._recomputeInnerHeight();
qx.ui.core.Widget.flushGlobalQueues();
},
_computeInnerWidth:function(){return this._document.body.offsetWidth;
},
_computeInnerHeight:function(){return this._document.body.offsetHeight;
}},
settings:{"qx.enableApplicationLayout":true,
"qx.boxModelCorrection":true},
defer:function(){if(qx.core.Setting.get($[784])){var $0=qx.core.Client.getInstance().getEngineBoxSizingAttributes();
var $1=$0.join($[423])+$[423];
var $2=$0.join($[400])+$[400];
qx.html.StyleSheet.createElement($[926]+$[1577]+$[1790]+$1+$[1671]+$[2009]+$2+$[199]);
}
if(qx.core.Setting.get($[1951])){qx.html.StyleSheet.createElement($[2019]);
}},
destruct:function(){this._disposeObjects($[568]);
this._disposeFields($[1348],
$[1372],
$[1812],
$[1691],
$[1856]);
}});




/* ID: qx.ui.basic.Terminator */
qx.Class.define($[1462],
{extend:qx.ui.core.Widget,
members:{renderPadding:function($0){if($0.paddingLeft){this._renderRuntimePaddingLeft(this.getPaddingLeft());
}
if($0.paddingRight){this._renderRuntimePaddingRight(this.getPaddingRight());
}
if($0.paddingTop){this._renderRuntimePaddingTop(this.getPaddingTop());
}
if($0.paddingBottom){this._renderRuntimePaddingBottom(this.getPaddingBottom());
}},
_renderContent:function(){if(this._computedWidthTypePixel){this._cachedPreferredInnerWidth=null;
}else{this._invalidatePreferredInnerWidth();
}if(this._computedHeightTypePixel){this._cachedPreferredInnerHeight=null;
}else{this._invalidatePreferredInnerHeight();
}if(this._initialLayoutDone){this.addToJobQueue($[94]);
}},
_layoutPost:function($0){if($0.initial||$0.load||$0.width||$0.height){this._postApply();
}},
_postApply:qx.lang.Function.returnTrue,
_computeBoxWidthFallback:function(){return this.getPreferredBoxWidth();
},
_computeBoxHeightFallback:function(){return this.getPreferredBoxHeight();
},
_computePreferredInnerWidth:qx.lang.Function.returnZero,
_computePreferredInnerHeight:qx.lang.Function.returnZero,
_isWidthEssential:function(){if(!this._computedLeftTypeNull&&!this._computedRightTypeNull){return true;
}
if(!this._computedWidthTypeNull&&!this._computedWidthTypeAuto){return true;
}
if(!this._computedMinWidthTypeNull&&!this._computedMinWidthTypeAuto){return true;
}
if(!this._computedMaxWidthTypeNull&&!this._computedMaxWidthTypeAuto){return true;
}
if(this._borderElement){return true;
}return false;
},
_isHeightEssential:function(){if(!this._computedTopTypeNull&&!this._computedBottomTypeNull){return true;
}
if(!this._computedHeightTypeNull&&!this._computedHeightTypeAuto){return true;
}
if(!this._computedMinHeightTypeNull&&!this._computedMinHeightTypeAuto){return true;
}
if(!this._computedMaxHeightTypeNull&&!this._computedMaxHeightTypeAuto){return true;
}
if(this._borderElement){return true;
}return false;
}}});




/* ID: qx.ui.core.ClientDocumentBlocker */
qx.Class.define($[1840],
{extend:qx.ui.basic.Terminator,
construct:function(){arguments.callee.base.call(this);
this.initTop();
this.initRight();
this.initBottom();
this.initLeft();
this.initZIndex();
},
properties:{appearance:{refine:true,
init:$[896]},
zIndex:{refine:true,
init:1e8},
top:{refine:true,
init:0},
right:{refine:true,
init:0},
bottom:{refine:true,
init:0},
left:{refine:true,
init:0},
display:{refine:true,
init:false}},
members:{getFocusRoot:function(){return null;
}}});




/* ID: qx.theme.manager.Appearance */
qx.Class.define($[1586],
{type:$[24],
extend:qx.util.manager.Object,
construct:function(){arguments.callee.base.call(this);
this.__cache={};
this.__stateMap={};
this.__stateMapLength=1;
},
properties:{appearanceTheme:{check:$[132],
nullable:true,
apply:$[1864],
event:$[2051]}},
members:{_applyAppearanceTheme:function($0,
$1){this._currentTheme=$0;
this._oldTheme=$1;
if(qx.theme.manager.Meta.getInstance().getAutoSync()){this.syncAppearanceTheme();
}},
syncAppearanceTheme:function(){if(!this._currentTheme&&!this._oldTheme){return;
}
if(this._currentTheme){this.__cache[this._currentTheme.name]={};
}var $0=qx.core.Init.getInstance().getApplication();
if($0&&$0.getUiReady()){qx.ui.core.ClientDocument.getInstance()._recursiveAppearanceThemeUpdate(this._currentTheme,
this._oldTheme);
}
if(this._oldTheme){delete this.__cache[this._oldTheme.name];
}delete this._currentTheme;
delete this._oldTheme;
},
styleFrom:function($0,
$1){var $2=this.getAppearanceTheme();
if(!$2){return;
}return this.styleFromTheme($2,
$0,
$1);
},
styleFromTheme:function($0,
$1,
$2){var $3=$0.appearances[$1];
if(!$3){{};
return null;
}if(!$3.style){if($3.include){return this.styleFromTheme($0,
$3.include,
$2);
}else{return null;
}}var $4=this.__stateMap;
var $5=[$1];
for(var $6 in $2){if(!$4[$6]){$4[$6]=this.__stateMapLength++;
}$5[$4[$6]]=true;
}var $7=$5.join();
var $8=this.__cache[$0.name];
if($8&&$8[$7]!==undefined){return $8[$7];
}var $9;
if($3.include||$3.base){var $a=$3.style($2);
var $b;
if($3.include){$b=this.styleFromTheme($0,
$3.include,
$2);
}$9={};
if($3.base&&$0.supertheme){var $c=this.styleFromTheme($0.supertheme,
$1,
$2);
if($3.include){for(var $d in $c){if($b[$d]===undefined&&$a[$d]===undefined){$9[$d]=$c[$d];
}}}else{for(var $d in $c){if($a[$d]===undefined){$9[$d]=$c[$d];
}}}}if($3.include){for(var $d in $b){if($a[$d]===undefined){$9[$d]=$b[$d];
}}}for(var $d in $a){$9[$d]=$a[$d];
}}else{$9=$3.style($2);
}if($8){$8[$7]=$9||null;
}return $9||null;
}},
destruct:function(){this._disposeFields($[871],
$[1610]);
}});




/* ID: qx.theme.manager.Meta */
qx.Class.define($[1801],
{type:$[24],
extend:qx.core.Target,
properties:{theme:{check:$[132],
nullable:true,
apply:$[1221],
event:$[1230]},
autoSync:{check:$[2],
init:true,
apply:$[1027]}},
members:{_applyTheme:function($0,
$1){var $2=null;
var $3=null;
var $4=null;
var $5=null;
var $6=null;
var $7=null;
if($0){$2=$0.meta.color||null;
$3=$0.meta.border||null;
$4=$0.meta.font||null;
$5=$0.meta.widget||null;
$6=$0.meta.icon||null;
$7=$0.meta.appearance||null;
}
if($1){this.setAutoSync(false);
}var $8=qx.theme.manager.Color.getInstance();
var $9=qx.theme.manager.Border.getInstance();
var $a=qx.theme.manager.Font.getInstance();
var $b=qx.theme.manager.Icon.getInstance();
var $c=qx.theme.manager.Widget.getInstance();
var $d=qx.theme.manager.Appearance.getInstance();
$8.setColorTheme($2);
$9.setBorderTheme($3);
$a.setFontTheme($4);
$c.setWidgetTheme($5);
$b.setIconTheme($6);
$d.setAppearanceTheme($7);
if($1){this.setAutoSync(true);
}},
_applyAutoSync:function($0,
$1){if($0){qx.theme.manager.Appearance.getInstance().syncAppearanceTheme();
qx.theme.manager.Icon.getInstance().syncIconTheme();
qx.theme.manager.Widget.getInstance().syncWidgetTheme();
qx.theme.manager.Font.getInstance().syncFontTheme();
qx.theme.manager.Border.getInstance().syncBorderTheme();
qx.theme.manager.Color.getInstance().syncColorTheme();
}},
initialize:function(){var $0=qx.core.Setting;
var $1,
$2;
$1=$0.get($[1753]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The meta theme to use is not available: "+$1);
}this.setTheme($2);
}$1=$0.get($[1283]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The color theme to use is not available: "+$1);
}qx.theme.manager.Color.getInstance().setColorTheme($2);
}$1=$0.get($[1765]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The border theme to use is not available: "+$1);
}qx.theme.manager.Border.getInstance().setBorderTheme($2);
}$1=$0.get($[964]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The font theme to use is not available: "+$1);
}qx.theme.manager.Font.getInstance().setFontTheme($2);
}$1=$0.get($[1901]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The widget theme to use is not available: "+$1);
}qx.theme.manager.Widget.getInstance().setWidgetTheme($2);
}$1=$0.get($[741]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The icon theme to use is not available: "+$1);
}qx.theme.manager.Icon.getInstance().setIconTheme($2);
}$1=$0.get($[1174]);
if($1){$2=qx.Theme.getByName($1);
if(!$2){throw new Error("The appearance theme to use is not available: "+$1);
}qx.theme.manager.Appearance.getInstance().setAppearanceTheme($2);
}},
__queryThemes:function($0){var $1=qx.Theme.getAll();
var $2;
var $3=[];
for(var $4 in $1){$2=$1[$4];
if($2[$0]){$3.push($2);
}}return $3;
},
getMetaThemes:function(){return this.__queryThemes($[402]);
},
getColorThemes:function(){return this.__queryThemes($[448]);
},
getBorderThemes:function(){return this.__queryThemes($[614]);
},
getFontThemes:function(){return this.__queryThemes($[539]);
},
getWidgetThemes:function(){return this.__queryThemes($[616]);
},
getIconThemes:function(){return this.__queryThemes($[557]);
},
getAppearanceThemes:function(){return this.__queryThemes($[357]);
}},
settings:{"qx.theme":$[489],
"qx.colorTheme":null,
"qx.borderTheme":null,
"qx.fontTheme":null,
"qx.widgetTheme":null,
"qx.appearanceTheme":null,
"qx.iconTheme":null}});




/* ID: qx.theme.manager.Color */
qx.Class.define($[1099],
{type:$[24],
extend:qx.util.manager.Value,
properties:{colorTheme:{check:$[132],
nullable:true,
apply:$[1798],
event:$[999]}},
members:{_applyColorTheme:function($0){var $1=this._dynamic={};
if($0){var $2=$0.colors;
var $3=qx.util.ColorUtil;
var $4;
for(var $5 in $2){$4=$2[$5];
if(typeof $4===$[8]){if(!$3.isCssString($4)){throw new Error("Could not parse color: "+$4);
}}else if($4 instanceof Array){$4=$3.rgbToRgbString($4);
}else{throw new Error("Could not parse color: "+$4);
}$1[$5]=$4;
}}
if(qx.theme.manager.Meta.getInstance().getAutoSync()){this.syncColorTheme();
}},
syncColorTheme:function(){this._updateObjects();
}}});




/* ID: qx.util.ColorUtil */
qx.Class.define($[1725],
{statics:{REGEXP:{hex3:/^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
hex6:/^#([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
rgb:/^rgb\(\s*([0-9]{1,3}\.{0,1}[0-9]*)\s*,\s*([0-9]{1,3}\.{0,1}[0-9]*)\s*,\s*([0-9]{1,3}\.{0,1}[0-9]*)\s*\)$/},
SYSTEM:{activeborder:true,
activecaption:true,
appworkspace:true,
background:true,
buttonface:true,
buttonhighlight:true,
buttonshadow:true,
buttontext:true,
captiontext:true,
graytext:true,
highlight:true,
highlighttext:true,
inactiveborder:true,
inactivecaption:true,
inactivecaptiontext:true,
infobackground:true,
infotext:true,
menu:true,
menutext:true,
scrollbar:true,
threeddarkshadow:true,
threedface:true,
threedhighlight:true,
threedlightshadow:true,
threedshadow:true,
window:true,
windowframe:true,
windowtext:true},
NAMED:{black:[0,
0,
0],
silver:[192,
192,
192],
gray:[128,
128,
128],
white:[255,
255,
255],
maroon:[128,
0,
0],
red:[255,
0,
0],
purple:[128,
0,
128],
fuchsia:[255,
0,
255],
green:[0,
128,
0],
lime:[0,
255,
0],
olive:[128,
128,
0],
yellow:[255,
255,
0],
navy:[0,
0,
128],
blue:[0,
0,
255],
teal:[0,
128,
128],
aqua:[0,
255,
255],
transparent:[-1,
-1,
-1],
grey:[128,
128,
128],
magenta:[255,
0,
255],
orange:[255,
165,
0],
brown:[165,
42,
42]},
isNamedColor:function($0){return this.NAMED[$0]!==undefined;
},
isSystemColor:function($0){return this.SYSTEM[$0]!==undefined;
},
isThemedColor:function($0){return qx.theme.manager.Color.getInstance().isDynamic($0);
},
stringToRgb:function($0){if(this.isThemedColor($0)){var $0=qx.theme.manager.Color.getInstance().resolveDynamic($0);
}
if(this.isNamedColor($0)){return this.NAMED[$0];
}else if(this.isSystemColor($0)){throw new Error("Could not convert system colors to RGB: "+$0);
}else if(this.isRgbString($0)){return this.__rgbStringToRgb();
}else if(this.isHex3String($0)){return this.__hex3StringToRgb();
}else if(this.isHex6String($0)){return this.__hex6StringToRgb();
}throw new Error("Could not parse color: "+$0);
},
cssStringToRgb:function($0){if(this.isNamedColor($0)){return this.NAMED[$0];
}else if(this.isSystemColor($0)){throw new Error("Could not convert system colors to RGB: "+$0);
}else if(this.isRgbString($0)){return this.__rgbStringToRgb();
}else if(this.isHex3String($0)){return this.__hex3StringToRgb();
}else if(this.isHex6String($0)){return this.__hex6StringToRgb();
}throw new Error("Could not parse color: "+$0);
},
stringToRgbString:function($0){return this.rgbToRgbString(this.stringToRgb($0));
},
rgbToRgbString:function($0){return $[1305]+$0[0]+$[17]+$0[1]+$[17]+$0[2]+$[44];
},
rgbToHexString:function($0){return (qx.lang.String.pad($0[0].toString(16).toUpperCase(),
2)+qx.lang.String.pad($0[1].toString(16).toUpperCase(),
2)+qx.lang.String.pad($0[2].toString(16).toUpperCase(),
2));
},
isValid:function($0){return this.isThemedColor($0)||this.isCssString($0);
},
isCssString:function($0){return this.isSystemColor($0)||this.isNamedColor($0)||this.isHex3String($0)||this.isHex6String($0)||this.isRgbString($0);
},
isHex3String:function($0){return this.REGEXP.hex3.test($0);
},
isHex6String:function($0){return this.REGEXP.hex6.test($0);
},
isRgbString:function($0){return this.REGEXP.rgb.test($0);
},
__rgbStringToRgb:function(){var $0=parseInt(RegExp.$1);
var $1=parseInt(RegExp.$2);
var $2=parseInt(RegExp.$3);
return [$0,
$1,
$2];
},
__hex3StringToRgb:function(){var $0=parseInt(RegExp.$1,
16)*17;
var $1=parseInt(RegExp.$2,
16)*17;
var $2=parseInt(RegExp.$3,
16)*17;
return [$0,
$1,
$2];
},
__hex6StringToRgb:function(){var $0=(parseInt(RegExp.$1,
16)*16)+parseInt(RegExp.$2,
16);
var $1=(parseInt(RegExp.$3,
16)*16)+parseInt(RegExp.$4,
16);
var $2=(parseInt(RegExp.$5,
16)*16)+parseInt(RegExp.$6,
16);
return [$0,
$1,
$2];
},
hex3StringToRgb:function($0){if(this.isHex3String($0)){return this.__hex3StringToRgb($0);
}throw new Error("Invalid hex3 value: "+$0);
},
hex6StringToRgb:function($0){if(this.isHex6String($0)){return this.__hex6StringToRgb($0);
}throw new Error("Invalid hex6 value: "+$0);
},
hexStringToRgb:function($0){if(this.isHex3String($0)){return this.__hex3StringToRgb($0);
}
if(this.isHex6String($0)){return this.__hex6StringToRgb($0);
}throw new Error("Invalid hex value: "+$0);
},
rgbToHsb:function($0){var $1,
$2,
$3;
var $4=$0[0];
var $5=$0[1];
var $6=$0[2];
var $7=($4>$5)?$4:$5;
if($6>$7){$7=$6;
}var $8=($4<$5)?$4:$5;
if($6<$8){$8=$6;
}$3=$7/255.0;
if($7!=0){$2=($7-$8)/$7;
}else{$2=0;
}
if($2==0){$1=0;
}else{var $9=($7-$4)/($7-$8);
var $a=($7-$5)/($7-$8);
var $b=($7-$6)/($7-$8);
if($4==$7){$1=$b-$a;
}else if($5==$7){$1=2.0+$9-$b;
}else{$1=4.0+$a-$9;
}$1=$1/6.0;
if($1<0){$1=$1+1.0;
}}return [Math.round($1*360),
Math.round($2*100),
Math.round($3*100)];
},
hsbToRgb:function($0){var $1,
$2,
$3,
$4,
$5;
var $6=$0[0]/360;
var $7=$0[1]/100;
var $8=$0[2]/100;
if($6>=1.0){$6%=1.0;
}
if($7>1.0){$7=1.0;
}
if($8>1.0){$8=1.0;
}var $9=Math.floor(255*$8);
var $a={};
if($7==0.0){$a.red=$a.green=$a.blue=$9;
}else{$6*=6.0;
$1=Math.floor($6);
$2=$6-$1;
$3=Math.floor($9*(1.0-$7));
$4=Math.floor($9*(1.0-($7*$2)));
$5=Math.floor($9*(1.0-($7*(1.0-$2))));
switch($1){case 0:$a.red=$9;
$a.green=$5;
$a.blue=$3;
break;
case 1:$a.red=$4;
$a.green=$9;
$a.blue=$3;
break;
case 2:$a.red=$3;
$a.green=$9;
$a.blue=$5;
break;
case 3:$a.red=$3;
$a.green=$4;
$a.blue=$9;
break;
case 4:$a.red=$5;
$a.green=$3;
$a.blue=$9;
break;
case 5:$a.red=$9;
$a.green=$3;
$a.blue=$4;
break;
}}return $a;
},
randomColor:function(){var $0=Math.round(Math.random()*255);
var $1=Math.round(Math.random()*255);
var $2=Math.round(Math.random()*255);
return this.rgbToRgbString([$0,
$1,
$2]);
}}});




/* ID: qx.theme.manager.Border */
qx.Class.define($[1205],
{type:$[24],
extend:qx.util.manager.Value,
properties:{borderTheme:{check:$[132],
nullable:true,
apply:$[1056],
event:$[716]}},
members:{resolveDynamic:function($0){return $0 instanceof qx.ui.core.Border?$0:this._dynamic[$0];
},
isDynamic:function($0){return $0&&($0 instanceof qx.ui.core.Border||this._dynamic[$0]!==undefined);
},
syncBorderTheme:function(){this._updateObjects();
},
updateObjectsEdge:function($0,
$1){var $2=this._registry;
var $3=this._dynamic;
var $4;
for(var $5 in $2){$4=$2[$5];
if($4.value===$0||$3[$4.value]===$0){$4.callback.call($4.object,
$0,
$1);
}}},
_applyBorderTheme:function($0){var $1=this._dynamic;
for(var $2 in $1){if($1[$2].themed){$1[$2].dispose();
delete $1[$2];
}}
if($0){var $3=$0.borders;
var $4=qx.ui.core.Border;
for(var $2 in $3){$1[$2]=(new $4).set($3[$2]);
$1[$2].themed=true;
}}
if(qx.theme.manager.Meta.getInstance().getAutoSync()){this.syncBorderTheme();
}}}});




/* ID: qx.ui.core.Border */
qx.Class.define($[1402],
{extend:qx.core.Object,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
if($0!==undefined){this.setWidth($0);
}
if($1!==undefined){this.setStyle($1);
}
if($2!==undefined){this.setColor($2);
}},
statics:{fromString:function($0){var $1=new qx.ui.core.Border;
var $2=$0.split(/\s+/);
var $3,
$4;
for(var $5=0,
$6=$2.length;$5<$6;$5++){$3=$2[$5];
switch($3){case $[163]:case $[211]:case $[72]:case $[69]:case $[5]:case $[185]:case $[203]:case $[191]:case $[11]:$1.setStyle($3);
break;
default:$4=parseInt($3);
if($4===$3||qx.lang.String.contains($3,
$[46])){$1.setWidth($4);
}else{$1.setColor($3);
}break;
}}return $1;
},
fromConfig:function($0){var $1=new qx.ui.core.Border;
$1.set($0);
return $1;
},
resetTop:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
if($1){$1.borderTopWidth=$1.borderTopStyle=$1.borderTopColor=$1.MozBorderTopColors=$[0];
}},
"default":function($0){var $1=$0._style;
if($1){$1.borderTopWidth=$1.borderTopStyle=$1.borderTopColor=$[0];
}$1=$0._innerStyle;
if($1){$1.borderTopWidth=$1.borderTopStyle=$1.borderTopColor=$[0];
}}}),
resetRight:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
if($1){$1.borderRightWidth=$1.borderRightStyle=$1.borderRightColor=$1.MozBorderRightColors=$[0];
}},
"default":function($0){var $1=$0._style;
if($1){$1.borderRightWidth=$1.borderRightStyle=$1.borderRightColor=$[0];
}$1=$0._innerStyle;
if($1){$1.borderRightWidth=$1.borderRightStyle=$1.borderRightColor=$[0];
}}}),
resetBottom:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
if($1){$1.borderBottomWidth=$1.borderBottomStyle=$1.borderBottomColor=$1.MozBorderBottomColors=$[0];
}},
"default":function($0){var $1=$0._style;
if($1){$1.borderBottomWidth=$1.borderBottomStyle=$1.borderBottomColor=$[0];
}$1=$0._innerStyle;
if($1){$1.borderBottomWidth=$1.borderBottomStyle=$1.borderBottomColor=$[0];
}}}),
resetLeft:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
if($1){$1.borderLeftWidth=$1.borderLeftStyle=$1.borderLeftColor=$1.MozBorderLeftColors=$[0];
}},
"default":function($0){var $1=$0._style;
if($1){$1.borderLeftWidth=$1.borderLeftStyle=$1.borderLeftColor=$[0];
}$1=$0._innerStyle;
if($1){$1.borderLeftWidth=$1.borderLeftStyle=$1.borderLeftColor=$[0];
}}})},
properties:{widthTop:{check:$[12],
init:0,
apply:$[1694]},
widthRight:{check:$[12],
init:0,
apply:$[1346]},
widthBottom:{check:$[12],
init:0,
apply:$[1464]},
widthLeft:{check:$[12],
init:0,
apply:$[1929]},
styleTop:{nullable:true,
check:[$[5],
$[185],
$[203],
$[191],
$[69],
$[72],
$[211],
$[163]],
init:$[5],
apply:$[1890]},
styleRight:{nullable:true,
check:[$[5],
$[185],
$[203],
$[191],
$[69],
$[72],
$[211],
$[163]],
init:$[5],
apply:$[1453]},
styleBottom:{nullable:true,
check:[$[5],
$[185],
$[203],
$[191],
$[69],
$[72],
$[211],
$[163]],
init:$[5],
apply:$[1245]},
styleLeft:{nullable:true,
check:[$[5],
$[185],
$[203],
$[191],
$[69],
$[72],
$[211],
$[163]],
init:$[5],
apply:$[1676]},
colorTop:{nullable:true,
check:$[34],
apply:$[2018]},
colorRight:{nullable:true,
check:$[34],
apply:$[1463]},
colorBottom:{nullable:true,
check:$[34],
apply:$[732]},
colorLeft:{nullable:true,
check:$[34],
apply:$[1535]},
colorInnerTop:{nullable:true,
check:$[34],
apply:$[1667]},
colorInnerRight:{nullable:true,
check:$[34],
apply:$[1562]},
colorInnerBottom:{nullable:true,
check:$[34],
apply:$[1164]},
colorInnerLeft:{nullable:true,
check:$[34],
apply:$[2001]},
left:{group:[$[621],
$[417],
$[628]]},
right:{group:[$[524],
$[412],
$[435]]},
top:{group:[$[545],
$[381],
$[472]]},
bottom:{group:[$[459],
$[523],
$[452]]},
width:{group:[$[545],
$[524],
$[459],
$[621]],
mode:$[111]},
style:{group:[$[381],
$[412],
$[523],
$[417]],
mode:$[111]},
color:{group:[$[472],
$[435],
$[452],
$[628]],
mode:$[111]},
innerColor:{group:[$[1819],
$[1985],
$[1117],
$[1912]],
mode:$[111]}},
members:{_applyWidthTop:function($0,
$1){this.__widthTop=$0==null?$[59]:$0+$[46];
this.__computeComplexTop();
this.__informManager($[23]);
},
_applyWidthRight:function($0,
$1){this.__widthRight=$0==null?$[59]:$0+$[46];
this.__computeComplexRight();
this.__informManager($[14]);
},
_applyWidthBottom:function($0,
$1){this.__widthBottom=$0==null?$[59]:$0+$[46];
this.__computeComplexBottom();
this.__informManager($[22]);
},
_applyWidthLeft:function($0,
$1){this.__widthLeft=$0==null?$[59]:$0+$[46];
this.__computeComplexLeft();
this.__informManager($[13]);
},
_applyColorTop:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorTop,
this,
$0);
},
_applyColorRight:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorRight,
this,
$0);
},
_applyColorBottom:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorBottom,
this,
$0);
},
_applyColorLeft:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorLeft,
this,
$0);
},
_applyColorInnerTop:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorInnerTop,
this,
$0);
},
_applyColorInnerRight:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorInnerRight,
this,
$0);
},
_applyColorInnerBottom:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorInnerBottom,
this,
$0);
},
_applyColorInnerLeft:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._changeColorInnerLeft,
this,
$0);
},
_applyStyleTop:function(){this.__informManager($[23]);
},
_applyStyleRight:function(){this.__informManager($[14]);
},
_applyStyleBottom:function(){this.__informManager($[22]);
},
_applyStyleLeft:function(){this.__informManager($[13]);
},
_changeColorTop:function($0){this.__colorTop=$0;
this.__computeComplexTop();
this.__informManager($[23]);
},
_changeColorInnerTop:function($0){this.__colorInnerTop=$0;
this.__computeComplexTop();
this.__informManager($[23]);
},
_changeColorRight:function($0){this.__colorRight=$0;
this.__computeComplexRight();
this.__informManager($[14]);
},
_changeColorInnerRight:function($0){this.__colorInnerRight=$0;
this.__computeComplexRight();
this.__informManager($[14]);
},
_changeColorBottom:function($0){this.__colorBottom=$0;
this.__computeComplexBottom();
this.__informManager($[22]);
},
_changeColorInnerBottom:function($0){this.__colorInnerBottom=$0;
this.__computeComplexBottom();
this.__informManager($[22]);
},
_changeColorLeft:function($0){this.__colorLeft=$0;
this.__computeComplexLeft();
this.__informManager($[13]);
},
_changeColorInnerLeft:function($0){this.__colorInnerLeft=$0;
this.__computeComplexLeft();
this.__informManager($[13]);
},
__computeComplexTop:function(){this.__complexTop=this.getWidthTop()===2&&this.__colorInnerTop!=null&&this.__colorTop!=this.__colorInnerTop;
},
__computeComplexRight:function(){this.__complexRight=this.getWidthRight()===2&&this.__colorInnerRight!=null&&this.__colorRight!=this.__colorInnerRight;
},
__computeComplexBottom:function(){this.__complexBottom=this.getWidthBottom()===2&&this.__colorInnerBottom!=null&&this.__colorBottom!=this.__colorInnerBottom;
},
__computeComplexLeft:function(){this.__complexLeft=this.getWidthLeft()===2&&this.__colorInnerLeft!=null&&this.__colorLeft!=this.__colorInnerLeft;
},
__informManager:function($0){qx.theme.manager.Border.getInstance().updateObjectsEdge(this,
$0);
},
renderTop:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
$1.borderTopWidth=this.__widthTop||$[59];
$1.borderTopColor=this.__colorTop||$[0];
if(this.__complexTop){$1.borderTopStyle=$[5];
$1.MozBorderTopColors=this.__colorTop+$[81]+this.__colorInnerTop;
}else{$1.borderTopStyle=this.getStyleTop()||$[11];
$1.MozBorderTopColors=$[0];
}},
"default":function($0){var $1=$0._style;
var $2=$0._innerStyle;
if(this.__complexTop){if(!$2){$0.prepareEnhancedBorder();
$2=$0._innerStyle;
}$1.borderTopWidth=$2.borderTopWidth=$[179];
$1.borderTopStyle=$2.borderTopStyle=$[5];
$1.borderTopColor=this.__colorTop;
$2.borderTopColor=this.__colorInnerTop;
}else{$1.borderTopWidth=this.__widthTop||$[59];
$1.borderTopStyle=this.getStyleTop()||$[11];
$1.borderTopColor=this.__colorTop||$[0];
if($2){$2.borderTopWidth=$2.borderTopStyle=$2.borderTopColor=$[0];
}}}}),
renderRight:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
$1.borderRightWidth=this.__widthRight||$[59];
$1.borderRightColor=this.__colorRight||$[0];
if(this.__complexRight){$1.borderRightStyle=$[5];
$1.MozBorderRightColors=this.__colorRight+$[81]+this.__colorInnerRight;
}else{$1.borderRightStyle=this.getStyleRight()||$[11];
$1.MozBorderRightColors=$[0];
}},
"default":function($0){var $1=$0._style;
var $2=$0._innerStyle;
if(this.__complexRight){if(!$2){$0.prepareEnhancedBorder();
$2=$0._innerStyle;
}$1.borderRightWidth=$2.borderRightWidth=$[179];
$1.borderRightStyle=$2.borderRightStyle=$[5];
$1.borderRightColor=this.__colorRight;
$2.borderRightColor=this.__colorInnerRight;
}else{$1.borderRightWidth=this.__widthRight||$[59];
$1.borderRightStyle=this.getStyleRight()||$[11];
$1.borderRightColor=this.__colorRight||$[0];
if($2){$2.borderRightWidth=$2.borderRightStyle=$2.borderRightColor=$[0];
}}}}),
renderBottom:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
$1.borderBottomWidth=this.__widthBottom||$[59];
$1.borderBottomColor=this.__colorBottom||$[0];
if(this.__complexBottom){$1.borderBottomStyle=$[5];
$1.MozBorderBottomColors=this.__colorBottom+$[81]+this.__colorInnerBottom;
}else{$1.borderBottomStyle=this.getStyleBottom()||$[11];
$1.MozBorderBottomColors=$[0];
}},
"default":function($0){var $1=$0._style;
var $2=$0._innerStyle;
if(this.__complexBottom){if(!$2){$0.prepareEnhancedBorder();
$2=$0._innerStyle;
}$1.borderBottomWidth=$2.borderBottomWidth=$[179];
$1.borderBottomStyle=$2.borderBottomStyle=$[5];
$1.borderBottomColor=this.__colorBottom;
$2.borderBottomColor=this.__colorInnerBottom;
}else{$1.borderBottomWidth=this.__widthBottom||$[59];
$1.borderBottomStyle=this.getStyleBottom()||$[11];
$1.borderBottomColor=this.__colorBottom||$[0];
if($2){$2.borderBottomWidth=$2.borderBottomStyle=$2.borderBottomColor=$[0];
}}}}),
renderLeft:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0._style;
$1.borderLeftWidth=this.__widthLeft||$[59];
$1.borderLeftColor=this.__colorLeft||$[0];
if(this.__complexLeft){$1.borderLeftStyle=$[5];
$1.MozBorderLeftColors=this.__colorLeft+$[81]+this.__colorInnerLeft;
}else{$1.borderLeftStyle=this.getStyleLeft()||$[11];
$1.MozBorderLeftColors=$[0];
}},
"default":function($0){var $1=$0._style;
var $2=$0._innerStyle;
if(this.__complexLeft){if(!$2){$0.prepareEnhancedBorder();
$2=$0._innerStyle;
}$1.borderLeftWidth=$2.borderLeftWidth=$[179];
$1.borderLeftStyle=$2.borderLeftStyle=$[5];
$1.borderLeftColor=this.__colorLeft;
$2.borderLeftColor=this.__colorInnerLeft;
}else{$1.borderLeftWidth=this.__widthLeft||$[59];
$1.borderLeftStyle=this.getStyleLeft()||$[11];
$1.borderLeftColor=this.__colorLeft||$[0];
if($2){$2.borderLeftWidth=$2.borderLeftStyle=$2.borderLeftColor=$[0];
}}}})}});




/* ID: qx.theme.manager.Font */
qx.Class.define($[2038],
{type:$[24],
extend:qx.util.manager.Value,
properties:{fontTheme:{check:$[132],
nullable:true,
apply:$[1075],
event:$[1394]}},
members:{resolveDynamic:function($0){return $0 instanceof qx.ui.core.Font?$0:this._dynamic[$0];
},
isDynamic:function($0){return $0&&($0 instanceof qx.ui.core.Font||this._dynamic[$0]!==undefined);
},
syncFontTheme:function(){this._updateObjects();
},
_applyFontTheme:function($0){var $1=this._dynamic;
for(var $2 in $1){if($1[$2].themed){$1[$2].dispose();
delete $1[$2];
}}
if($0){var $3=$0.fonts;
var $4=qx.ui.core.Font;
for(var $2 in $3){$1[$2]=(new $4).set($3[$2]);
$1[$2].themed=true;
}}
if(qx.theme.manager.Meta.getInstance().getAutoSync()){this.syncFontTheme();
}}}});




/* ID: qx.ui.core.Font */
qx.Class.define($[959],
{extend:qx.core.Object,
construct:function($0,
$1){arguments.callee.base.call(this);
if($0!==undefined){this.setSize($0);
}
if($1!==undefined){this.setFamily($1);
}},
statics:{fromString:function($0){var $1=new qx.ui.core.Font;
var $2=$0.split(/\s+/);
var $3=[];
var $4;
for(var $5=0;$5<$2.length;$5++){switch($4=$2[$5]){case $[304]:$1.setBold(true);
break;
case $[431]:$1.setItalic(true);
break;
case $[327]:$1.setDecoration($[327]);
break;
default:var $6=parseInt($4);
if($6==$4||qx.lang.String.contains($4,
$[46])){$1.setSize($6);
}else{$3.push($4);
}break;
}}
if($3.length>0){$1.setFamily($3);
}return $1;
},
fromConfig:function($0){var $1=new qx.ui.core.Font;
$1.set($0);
return $1;
},
reset:function($0){$0.removeStyleProperty($[543]);
$0.removeStyleProperty($[222]);
$0.removeStyleProperty($[437]);
$0.removeStyleProperty($[378]);
$0.removeStyleProperty($[541]);
},
resetElement:function($0){var $1=$0.style;
$1.fontFamily=$[0];
$1.fontSize=$[0];
$1.fontWeight=$[0];
$1.fontStyle=$[0];
$1.textDecoration=$[0];
},
resetStyle:function($0){$0.fontFamily=$[0];
$0.fontSize=$[0];
$0.fontWeight=$[0];
$0.fontStyle=$[0];
$0.textDecoration=$[0];
}},
properties:{size:{check:$[6],
nullable:true,
apply:$[719]},
family:{check:$[467],
nullable:true,
apply:$[1757]},
bold:{check:$[2],
nullable:true,
apply:$[2011]},
italic:{check:$[2],
nullable:true,
apply:$[1468]},
decoration:{check:[$[327],
$[816],
$[1975]],
nullable:true,
apply:$[1981]}},
members:{__size:null,
__family:null,
__bold:null,
__italic:null,
__decoration:null,
_applySize:function($0,
$1){this.__size=$0===null?null:$0+$[46];
},
_applyFamily:function($0,
$1){var $2=$[0];
for(var $3=0,
$4=$0.length;$3<$4;$3++){if($0[$3].indexOf($[81])>0){$2+=$[119]+$0[$3]+$[119];
}else{$2+=$0[$3];
}
if($3!=$4-1){$2+=$[17];
}}this.__family=$2;
},
_applyBold:function($0,
$1){this.__bold=$0===null?null:$0?$[304]:$[171];
},
_applyItalic:function($0,
$1){this.__italic=$0===null?null:$0?$[431]:$[171];
},
_applyDecoration:function($0,
$1){this.__decoration=$0===null?null:$0;
},
render:function($0){$0.setStyleProperty($[543],
this.__family);
$0.setStyleProperty($[222],
this.__size);
$0.setStyleProperty($[437],
this.__bold);
$0.setStyleProperty($[378],
this.__italic);
$0.setStyleProperty($[541],
this.__decoration);
},
renderStyle:function($0){$0.fontFamily=this.__family||$[0];
$0.fontSize=this.__size||$[0];
$0.fontWeight=this.__bold||$[0];
$0.fontStyle=this.__italic||$[0];
$0.textDecoration=this.__decoration||$[0];
},
renderElement:function($0){var $1=$0.style;
$1.fontFamily=this.__family||$[0];
$1.fontSize=this.__size||$[0];
$1.fontWeight=this.__bold||$[0];
$1.fontStyle=this.__italic||$[0];
$1.textDecoration=this.__decoration||$[0];
},
generateStyle:function(){return (this.__family?$[1683]+this.__family.replace(/\"/g,
$[188])+$[75]:$[0])+(this.__size?$[1090]+this.__size+$[75]:$[0])+(this.__weight?$[1701]+this.__weight+$[75]:$[0])+(this.__style?$[1310]+this.__style+$[75]:$[0])+(this.__decoration?$[1518]+this.__decoration+$[75]:$[0]);
}}});




/* ID: qx.theme.manager.Icon */
qx.Class.define($[1196],
{type:$[24],
extend:qx.core.Target,
properties:{iconTheme:{check:$[132],
nullable:true,
apply:$[1345],
event:$[1638]}},
members:{_applyIconTheme:function($0,
$1){if(qx.theme.manager.Meta.getInstance().getAutoSync()){this.syncIconTheme();
}},
syncIconTheme:function(){var $0=this.getIconTheme();
var $1=qx.io.Alias.getInstance();
$0?$1.add($[169],
$0.icons.uri):$1.remove($[169]);
}}});




/* ID: qx.theme.manager.Widget */
qx.Class.define($[1673],
{type:$[24],
extend:qx.core.Target,
properties:{widgetTheme:{check:$[132],
nullable:true,
apply:$[1573],
event:$[2013]}},
members:{_applyWidgetTheme:function($0,
$1){if(qx.theme.manager.Meta.getInstance().getAutoSync()){this.syncWidgetTheme();
}},
syncWidgetTheme:function(){var $0=this.getWidgetTheme();
var $1=qx.io.Alias.getInstance();
$0?$1.add($[288],
$0.widgets.uri):$1.remove($[288]);
}}});




/* ID: qx.event.handler.FocusHandler */
qx.Class.define($[605],
{extend:qx.core.Target,
construct:function($0){arguments.callee.base.call(this);
if($0!=null){this._attachedWidget=$0;
}},
statics:{mouseFocus:false},
members:{getAttachedWidget:function(){return this._attachedWidget;
},
_onkeyevent:function($0,
$1){if($1.getKeyIdentifier()!=$[253]){return;
}$1.stopPropagation();
$1.preventDefault();
qx.event.handler.FocusHandler.mouseFocus=false;
var $2=this.getAttachedWidget().getFocusedChild();
if(!$1.isShiftPressed()){var $3=$2?this.getWidgetAfter($0,
$2):this.getFirstWidget($0);
}else{var $3=$2?this.getWidgetBefore($0,
$2):this.getLastWidget($0);
}if($3){$3.setFocused(true);
$3._ontabfocus();
}},
compareTabOrder:function($0,
$1){if($0==$1){return 0;
}var $2=$0.getTabIndex();
var $3=$1.getTabIndex();
if($2!=$3){return $2-$3;
}var $4=qx.html.Location.getPageBoxTop($0.getElement());
var $5=qx.html.Location.getPageBoxTop($1.getElement());
if($4!=$5){return $4-$5;
}var $6=qx.html.Location.getPageBoxLeft($0.getElement());
var $7=qx.html.Location.getPageBoxLeft($1.getElement());
if($6!=$7){return $6-$7;
}var $8=$0.getZIndex();
var $9=$1.getZIndex();
if($8!=$9){return $8-$9;
}return 0;
},
getFirstWidget:function($0){return this._getFirst($0,
null);
},
getLastWidget:function($0){return this._getLast($0,
null);
},
getWidgetAfter:function($0,
$1){if($0==$1){return this.getFirstWidget($0);
}
if($1.getAnonymous()){$1=$1.getParent();
}
if($1==null){return [];
}var $2=[];
this._getAllAfter($0,
$1,
$2);
$2.sort(this.compareTabOrder);
return $2.length>0?$2[0]:this.getFirstWidget($0);
},
getWidgetBefore:function($0,
$1){if($0==$1){return this.getLastWidget($0);
}
if($1.getAnonymous()){$1=$1.getParent();
}
if($1==null){return [];
}var $2=[];
this._getAllBefore($0,
$1,
$2);
$2.sort(this.compareTabOrder);
var $3=$2.length;
return $3>0?$2[$3-1]:this.getLastWidget($0);
},
_getAllAfter:function($0,
$1,
$2){var $3=$0.getChildren();
var $4;
var $5=$3.length;
for(var $6=0;$6<$5;$6++){$4=$3[$6];
if(!($4 instanceof qx.ui.core.Parent)&&!($4 instanceof qx.ui.basic.Terminator)){continue;
}
if($4.isFocusable()&&$4.getTabIndex()>0&&this.compareTabOrder($1,
$4)<0){$2.push($3[$6]);
}
if(!$4.isFocusRoot()&&$4 instanceof qx.ui.core.Parent){this._getAllAfter($4,
$1,
$2);
}}},
_getAllBefore:function($0,
$1,
$2){var $3=$0.getChildren();
var $4;
var $5=$3.length;
for(var $6=0;$6<$5;$6++){$4=$3[$6];
if(!($4 instanceof qx.ui.core.Parent)&&!($4 instanceof qx.ui.basic.Terminator)){continue;
}
if($4.isFocusable()&&$4.getTabIndex()>0&&this.compareTabOrder($1,
$4)>0){$2.push($4);
}
if(!$4.isFocusRoot()&&$4 instanceof qx.ui.core.Parent){this._getAllBefore($4,
$1,
$2);
}}},
_getFirst:function($0,
$1){var $2=$0.getChildren();
var $3;
var $4=$2.length;
for(var $5=0;$5<$4;$5++){$3=$2[$5];
if(!($3 instanceof qx.ui.core.Parent)&&!($3 instanceof qx.ui.basic.Terminator)){continue;
}
if($3.isFocusable()&&$3.getTabIndex()>0){if($1==null||this.compareTabOrder($3,
$1)<0){$1=$3;
}}
if(!$3.isFocusRoot()&&$3 instanceof qx.ui.core.Parent){$1=this._getFirst($3,
$1);
}}return $1;
},
_getLast:function($0,
$1){var $2=$0.getChildren();
var $3;
var $4=$2.length;
for(var $5=0;$5<$4;$5++){$3=$2[$5];
if(!($3 instanceof qx.ui.core.Parent)&&!($3 instanceof qx.ui.basic.Terminator)){continue;
}
if($3.isFocusable()&&$3.getTabIndex()>0){if($1==null||this.compareTabOrder($3,
$1)>0){$1=$3;
}}
if(!$3.isFocusRoot()&&$3 instanceof qx.ui.core.Parent){$1=this._getLast($3,
$1);
}}return $1;
}},
destruct:function(){this._disposeFields($[1376]);
}});




/* ID: qx.html.Location */
qx.Class.define($[1510],
{statics:{getPageOuterLeft:function($0){return qx.html.Location.getPageBoxLeft($0)-qx.html.Style.getMarginLeft($0);
},
getPageOuterTop:function($0){return qx.html.Location.getPageBoxTop($0)-qx.html.Style.getMarginTop($0);
},
getPageOuterRight:function($0){return qx.html.Location.getPageBoxRight($0)+qx.html.Style.getMarginRight($0);
},
getPageOuterBottom:function($0){return qx.html.Location.getPageBoxBottom($0)+qx.html.Style.getMarginBottom($0);
},
getClientOuterLeft:function($0){return qx.html.Location.getClientBoxLeft($0)-qx.html.Style.getMarginLeft($0);
},
getClientOuterTop:function($0){return qx.html.Location.getClientBoxTop($0)-qx.html.Style.getMarginTop($0);
},
getClientOuterRight:function($0){return qx.html.Location.getClientBoxRight($0)+qx.html.Style.getMarginRight($0);
},
getClientOuterBottom:function($0){return qx.html.Location.getClientBoxBottom($0)+qx.html.Style.getMarginBottom($0);
},
getClientBoxLeft:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.getBoundingClientRect().left;
},
"gecko":function($0){return qx.html.Location.getClientAreaLeft($0)-qx.html.Style.getBorderLeft($0);
},
"default":function($0){var $1=$0.offsetLeft;
while($0.tagName.toLowerCase()!=$[137]){$0=$0.offsetParent;
$1+=$0.offsetLeft-$0.scrollLeft;
}return $1;
}}),
getClientBoxTop:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.getBoundingClientRect().top;
},
"gecko":function($0){return qx.html.Location.getClientAreaTop($0)-qx.html.Style.getBorderTop($0);
},
"default":function($0){var $1=$0.offsetTop;
while($0.tagName.toLowerCase()!=$[137]){$0=$0.offsetParent;
$1+=$0.offsetTop-$0.scrollTop;
}return $1;
}}),
getClientBoxRight:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.getBoundingClientRect().right;
},
"default":function($0){return qx.html.Location.getClientBoxLeft($0)+qx.html.Dimension.getBoxWidth($0);
}}),
getClientBoxBottom:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.getBoundingClientRect().bottom;
},
"default":function($0){return qx.html.Location.getClientBoxTop($0)+qx.html.Dimension.getBoxHeight($0);
}}),
getPageBoxLeft:qx.core.Variant.select($[1],
{"mshtml":function($0){return qx.html.Location.getClientBoxLeft($0)+qx.html.Scroll.getLeftSum($0);
},
"gecko":function($0){return qx.html.Location.getPageAreaLeft($0)-qx.html.Style.getBorderLeft($0);
},
"default":function($0){var $1=$0.offsetLeft;
while($0.tagName.toLowerCase()!=$[137]){$0=$0.offsetParent;
$1+=$0.offsetLeft;
}return $1;
}}),
getPageBoxTop:qx.core.Variant.select($[1],
{"mshtml":function($0){return qx.html.Location.getClientBoxTop($0)+qx.html.Scroll.getTopSum($0);
},
"gecko":function($0){return qx.html.Location.getPageAreaTop($0)-qx.html.Style.getBorderTop($0);
},
"default":function($0){var $1=$0.offsetTop;
while($0.tagName.toLowerCase()!=$[137]){$0=$0.offsetParent;
$1+=$0.offsetTop;
}return $1;
}}),
getPageBoxRight:qx.core.Variant.select($[1],
{"mshtml":function($0){return qx.html.Location.getClientBoxRight($0)+qx.html.Scroll.getLeftSum($0);
},
"default":function($0){return qx.html.Location.getPageBoxLeft($0)+qx.html.Dimension.getBoxWidth($0);
}}),
getPageBoxBottom:qx.core.Variant.select($[1],
{"mshtml":function($0){return qx.html.Location.getClientBoxBottom($0)+qx.html.Scroll.getTopSum($0);
},
"default":function($0){return qx.html.Location.getPageBoxTop($0)+qx.html.Dimension.getBoxHeight($0);
}}),
getClientAreaLeft:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.html.Location.getPageAreaLeft($0)-qx.html.Scroll.getLeftSum($0);
},
"default":function($0){return qx.html.Location.getClientBoxLeft($0)+qx.html.Style.getBorderLeft($0);
}}),
getClientAreaTop:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.html.Location.getPageAreaTop($0)-qx.html.Scroll.getTopSum($0);
},
"default":function($0){return qx.html.Location.getClientBoxTop($0)+qx.html.Style.getBorderTop($0);
}}),
getClientAreaRight:function($0){return qx.html.Location.getClientAreaLeft($0)+qx.html.Dimension.getAreaWidth($0);
},
getClientAreaBottom:function($0){return qx.html.Location.getClientAreaTop($0)+qx.html.Dimension.getAreaHeight($0);
},
getPageAreaLeft:qx.core.Variant.select($[1],
{"gecko":function($0){return $0.ownerDocument.getBoxObjectFor($0).x;
},
"default":function($0){return qx.html.Location.getPageBoxLeft($0)+qx.html.Style.getBorderLeft($0);
}}),
getPageAreaTop:qx.core.Variant.select($[1],
{"gecko":function($0){return $0.ownerDocument.getBoxObjectFor($0).y;
},
"default":function($0){return qx.html.Location.getPageBoxTop($0)+qx.html.Style.getBorderTop($0);
}}),
getPageAreaRight:function($0){return qx.html.Location.getPageAreaLeft($0)+qx.html.Dimension.getAreaWidth($0);
},
getPageAreaBottom:function($0){return qx.html.Location.getPageAreaTop($0)+qx.html.Dimension.getAreaHeight($0);
},
getClientInnerLeft:function($0){return qx.html.Location.getClientAreaLeft($0)+qx.html.Style.getPaddingLeft($0);
},
getClientInnerTop:function($0){return qx.html.Location.getClientAreaTop($0)+qx.html.Style.getPaddingTop($0);
},
getClientInnerRight:function($0){return qx.html.Location.getClientInnerLeft($0)+qx.html.Dimension.getInnerWidth($0);
},
getClientInnerBottom:function($0){return qx.html.Location.getClientInnerTop($0)+qx.html.Dimension.getInnerHeight($0);
},
getPageInnerLeft:function($0){return qx.html.Location.getPageAreaLeft($0)+qx.html.Style.getPaddingLeft($0);
},
getPageInnerTop:function($0){return qx.html.Location.getPageAreaTop($0)+qx.html.Style.getPaddingTop($0);
},
getPageInnerRight:function($0){return qx.html.Location.getPageInnerLeft($0)+qx.html.Dimension.getInnerWidth($0);
},
getPageInnerBottom:function($0){return qx.html.Location.getPageInnerTop($0)+qx.html.Dimension.getInnerHeight($0);
},
getScreenBoxLeft:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=0;
var $2=$0.parentNode;
while($2.nodeType==1){$1+=$2.scrollLeft;
$2=$2.parentNode;
}return $0.ownerDocument.getBoxObjectFor($0).screenX-$1;
},
"default":function($0){return qx.html.Location.getScreenDocumentLeft($0)+qx.html.Location.getPageBoxLeft($0);
}}),
getScreenBoxTop:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=0;
var $2=$0.parentNode;
while($2.nodeType==1){$1+=$2.scrollTop;
$2=$2.parentNode;
}return $0.ownerDocument.getBoxObjectFor($0).screenY-$1;
},
"default":function($0){return qx.html.Location.getScreenDocumentTop($0)+qx.html.Location.getPageBoxTop($0);
}}),
getScreenBoxRight:function($0){return qx.html.Location.getScreenBoxLeft($0)+qx.html.Dimension.getBoxWidth($0);
},
getScreenBoxBottom:function($0){return qx.html.Location.getScreenBoxTop($0)+qx.html.Dimension.getBoxHeight($0);
},
getScreenOuterLeft:function($0){return qx.html.Location.getScreenBoxLeft($0)-qx.html.Style.getMarginLeft($0);
},
getScreenOuterTop:function($0){return qx.html.Location.getScreenBoxTop($0)-qx.html.Style.getMarginTop($0);
},
getScreenOuterRight:function($0){return qx.html.Location.getScreenBoxRight($0)+qx.html.Style.getMarginRight($0);
},
getScreenOuterBottom:function($0){return qx.html.Location.getScreenBoxBottom($0)+qx.html.Style.getMarginBottom($0);
},
getScreenAreaLeft:function($0){return qx.html.Location.getScreenBoxLeft($0)+qx.html.Dimension.getInsetLeft($0);
},
getScreenAreaTop:function($0){return qx.html.Location.getScreenBoxTop($0)+qx.html.Dimension.getInsetTop($0);
},
getScreenAreaRight:function($0){return qx.html.Location.getScreenBoxRight($0)-qx.html.Dimension.getInsetRight($0);
},
getScreenAreaBottom:function($0){return qx.html.Location.getScreenBoxBottom($0)-qx.html.Dimension.getInsetBottom($0);
},
getScreenInnerLeft:function($0){return qx.html.Location.getScreenAreaLeft($0)+qx.html.Style.getPaddingLeft($0);
},
getScreenInnerTop:function($0){return qx.html.Location.getScreenAreaTop($0)+qx.html.Style.getPaddingTop($0);
},
getScreenInnerRight:function($0){return qx.html.Location.getScreenAreaRight($0)-qx.html.Style.getPaddingRight($0);
},
getScreenInnerBottom:function($0){return qx.html.Location.getScreenAreaBottom($0)-qx.html.Style.getPaddingBottom($0);
},
getScreenDocumentLeft:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.html.Location.getScreenOuterLeft($0.ownerDocument.body);
},
"default":function($0){return $0.document.parentWindow.screenLeft;
}}),
getScreenDocumentTop:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.html.Location.getScreenOuterTop($0.ownerDocument.body);
},
"default":function($0){return $0.document.parentWindow.screenTop;
}}),
getScreenDocumentRight:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.html.Location.getScreenOuterRight($0.ownerDocument.body);
},
"default":function($0){}}),
getScreenDocumentBottom:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.html.Location.getScreenOuterBottom($0.ownerDocument.body);
},
"default":function($0){}})}});




/* ID: qx.html.Scroll */
qx.Class.define($[923],
{statics:{getLeftSum:function($0){var $1=0;
var $2=$0.parentNode;
while($2.nodeType==1){$1+=$2.scrollLeft;
$2=$2.parentNode;
}return $1;
},
getTopSum:function($0){var $1=0;
var $2=$0.parentNode;
while($2.nodeType==1){$1+=$2.scrollTop;
$2=$2.parentNode;
}return $1;
}}});




/* ID: qx.io.image.Manager */
qx.Class.define($[804],
{type:$[24],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this.__visible={};
this.__all={};
},
members:{add:function($0){var $1=this.__all;
if($1[$0]===undefined){$1[$0]=1;
}else{$1[$0]++;
}},
remove:function($0){var $1=this.__all;
if($1[$0]!==undefined){$1[$0]--;
}
if($1[$0]<=0){delete $1[$0];
}},
show:function($0){var $1=this.__visible;
if($1[$0]===undefined){$1[$0]=1;
}else{$1[$0]++;
}},
hide:function($0){var $1=this.__visible;
if($1[$0]!==undefined){$1[$0]--;
}
if($1[$0]<=0){delete $1[$0];
}},
getVisibleImages:function(){var $0=this.__visible;
var $1={};
for(var $2 in $0){if($0[$2]>0){$1[$2]=true;
}}return $1;
},
getHiddenImages:function(){var $0=this.__visible;
var $1=this.__all;
var $2={};
for(var $3 in $1){if($0[$3]===undefined){$2[$3]=true;
}}return $2;
}},
destruct:function(){this._disposeFields($[938],
$[1658]);
}});




/* ID: qx.html.Offset */
qx.Class.define($[1043],
{statics:{getLeft:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0.offsetLeft;
var $2=$0.parentNode;
var $3=qx.html.Style.getStyleProperty($0,
$[90]);
var $4=qx.html.Style.getStyleProperty($2,
$[90]);
if($3!=$[63]&&$3!=$[133]){$1-=qx.html.Style.getBorderLeft($2);
}if($4!=$[63]&&$4!=$[133]){while($2){$2=$2.parentNode;
if(!$2||typeof $2.tagName!==$[8]){break;
}var $5=qx.html.Style.getStyleProperty($2,
$[90]);
if($5==$[63]||$5==$[133]){$1-=qx.html.Style.getBorderLeft($2)+qx.html.Style.getPaddingLeft($2);
break;
}}}return $1;
},
"default":function($0){return $0.offsetLeft;
}}),
getTop:qx.core.Variant.select($[1],
{"gecko":function($0){var $1=$0.offsetTop;
var $2=$0.parentNode;
var $3=qx.html.Style.getStyleProperty($0,
$[90]);
var $4=qx.html.Style.getStyleProperty($2,
$[90]);
if($3!=$[63]&&$3!=$[133]){$1-=qx.html.Style.getBorderTop($2);
}if($4!=$[63]&&$4!=$[133]){while($2){$2=$2.parentNode;
if(!$2||typeof $2.tagName!==$[8]){break;
}var $5=qx.html.Style.getStyleProperty($2,
$[90]);
if($5==$[63]||$5==$[133]){$1-=qx.html.Style.getBorderTop($2)+qx.html.Style.getPaddingTop($2);
break;
}}}return $1;
},
"default":function($0){return $0.offsetTop;
}})}});




/* ID: qx.html.ScrollIntoView */
qx.Class.define($[1977],
{statics:{scrollX:function($0,
$1){var $2,
$3,
$4,
$5;
var $6=$0.parentNode;
var $7=$0.offsetLeft;
var $4=$0.offsetWidth;
while($6){switch(qx.html.Style.getStyleProperty($6,
$[71])){case $[40]:case $[3]:case $[307]:$5=true;
break;
default:switch(qx.html.Style.getStyleProperty($6,
$[193])){case $[40]:case $[3]:$5=true;
break;
default:$5=false;
}}
if($5){$2=$6.clientWidth;
$3=$6.scrollLeft;
if($1){$6.scrollLeft=$7;
}else if($1==false){$6.scrollLeft=$7+$4-$2;
}else if($4>$2||$7<$3){$6.scrollLeft=$7;
}else if(($7+$4)>($3+$2)){$6.scrollLeft=$7+$4-$2;
}$7=$6.offsetLeft;
$4=$6.offsetWidth;
}else{$7+=$6.offsetLeft;
}
if($6.tagName.toLowerCase()==$[137]){break;
}$6=$6.offsetParent;
}return true;
},
scrollY:function($0,
$1){var $2,
$3,
$4,
$5;
var $6=$0.parentNode;
var $7=$0.offsetTop;
var $4=$0.offsetHeight;
while($6){switch(qx.html.Style.getStyleProperty($6,
$[71])){case $[40]:case $[3]:case $[300]:$5=true;
break;
default:switch(qx.html.Style.getStyleProperty($6,
$[194])){case $[40]:case $[3]:$5=true;
break;
default:$5=false;
}}
if($5){$2=$6.clientHeight;
$3=$6.scrollTop;
if($1){$6.scrollTop=$7;
}else if($1==false){$6.scrollTop=$7+$4-$2;
}else if($4>$2||$7<$3){$6.scrollTop=$7;
}else if(($7+$4)>($3+$2)){$6.scrollTop=$7+$4-$2;
}$7=$6.offsetTop;
$4=$6.offsetHeight;
}else{$7+=$6.offsetTop;
}
if($6.tagName.toLowerCase()==$[137]){break;
}$6=$6.offsetParent;
}return true;
}}});




/* ID: qx.client.Timer */
qx.Class.define($[1848],
{extend:qx.core.Target,
construct:function($0){arguments.callee.base.call(this);
this.setEnabled(false);
if($0!=null){this.setInterval($0);
}this.__oninterval=qx.lang.Function.bind(this._oninterval,
this);
},
events:{"interval":$[4]},
statics:{once:function($0,
$1,
$2){var $3=new qx.client.Timer($2);
$3.addEventListener($[67],
function($4){$3.dispose();
$0.call($1,
$4);
$1=null;
},
$1);
$3.start();
}},
properties:{enabled:{init:true,
check:$[2],
apply:$[325]},
interval:{check:$[6],
init:1000,
apply:$[1249]}},
members:{__intervalHandler:null,
_applyInterval:function($0,
$1){if(this.getEnabled()){this.restart();
}},
_applyEnabled:function($0,
$1){if($1){window.clearInterval(this.__intervalHandler);
this.__intervalHandler=null;
}else if($0){this.__intervalHandler=window.setInterval(this.__oninterval,
this.getInterval());
}},
start:function(){this.setEnabled(true);
},
startWith:function($0){this.setInterval($0);
this.start();
},
stop:function(){this.setEnabled(false);
},
restart:function(){this.stop();
this.start();
},
restartWith:function($0){this.stop();
this.startWith($0);
},
_oninterval:function(){if(this.getEnabled()){this.createDispatchEvent($[67]);
}}},
destruct:function(){if(this.__intervalHandler){window.clearInterval(this.__intervalHandler);
}this._disposeFields($[1616],
$[2034]);
}});




/* ID: qx.io.image.PreloaderSystem */
qx.Class.define($[1443],
{extend:qx.core.Target,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
if($0 instanceof Array){this._list=qx.lang.Object.fromArray($0);
}else{this._list=$0;
}this._timer=new qx.client.Timer(qx.core.Setting.get($[1584]));
this._timer.addEventListener($[67],
this.__oninterval,
this);
if($1){this.addEventListener($[16],
$1,
$2||null);
}},
events:{"completed":$[4]},
members:{_stopped:false,
start:function(){if(qx.lang.Object.isEmpty(this._list)){this.createDispatchEvent($[16]);
return;
}
for(var $0 in this._list){var $1=qx.io.image.PreloaderManager.getInstance().create(qx.io.Alias.getInstance().resolve($0));
if($1.isErroneous()||$1.isLoaded()){delete this._list[$0];
}else{$1._origSource=$0;
$1.addEventListener($[94],
this.__onload,
this);
$1.addEventListener($[78],
this.__onerror,
this);
}}this._check();
},
__onload:function($0){if(this.getDisposed()){return;
}delete this._list[$0.getTarget()._origSource];
this._check();
},
__onerror:function($0){if(this.getDisposed()){return;
}delete this._list[$0.getTarget()._origSource];
this._check();
},
__oninterval:function($0){this.debug("Cannot preload: "+qx.lang.Object.getKeysAsString(this._list));
this._stopped=true;
this._timer.stop();
this.createDispatchEvent($[16]);
},
_check:function(){if(this._stopped){return;
}if(qx.lang.Object.isEmpty(this._list)){this._timer.stop();
this.createDispatchEvent($[16]);
}else{this._timer.restart();
}}},
settings:{"qx.preloaderTimeout":3000},
destruct:function(){if(this._timer){this._timer.removeEventListener($[67],
this.__oninterval,
this);
this._disposeObjects($[202]);
}this._disposeFields($[818]);
}});




/* ID: qx.io.image.PreloaderManager */
qx.Class.define($[2042],
{type:$[24],
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._objects={};
},
members:{add:function($0){this._objects[$0.getUri()]=$0;
},
remove:function($0){delete this._objects[$0.getUri()];
},
has:function($0){return this._objects[$0]!=null;
},
get:function($0){return this._objects[$0];
},
create:function($0){if(this._objects[$0]){return this._objects[$0];
}return new qx.io.image.Preloader($0);
}},
destruct:function(){this._disposeFields($[579]);
}});




/* ID: qx.io.image.Preloader */
qx.Class.define($[470],
{extend:qx.core.Target,
events:{"load":$[4],
"error":$[4]},
construct:function($0){if(qx.io.image.PreloaderManager.getInstance().has($0)){this.debug("Reuse qx.io.image.Preloader in old-style!");
this.debug("Please use qx.io.image.PreloaderManager.getInstance().create(source) instead!");
return qx.io.image.PreloaderManager.getInstance().get($0);
}arguments.callee.base.call(this);
this._element=new Image;
this._element.onload=qx.lang.Function.bind(this.__onload,
this);
this._element.onerror=qx.lang.Function.bind(this.__onerror,
this);
this._source=$0;
this._element.src=$0;
if(qx.core.Variant.isSet($[1],
$[20])){this._isPng=/\.png$/i.test(this._element.nameProp);
}qx.io.image.PreloaderManager.getInstance().add(this);
},
members:{_source:null,
_isLoaded:false,
_isErroneous:false,
getUri:function(){return this._source;
},
getSource:function(){return this._source;
},
isLoaded:function(){return this._isLoaded;
},
isErroneous:function(){return this._isErroneous;
},
_isPng:false,
getIsPng:function(){return this._isPng;
},
getWidth:qx.core.Variant.select($[1],
{"gecko":function(){return this._element.naturalWidth;
},
"default":function(){return this._element.width;
}}),
getHeight:qx.core.Variant.select($[1],
{"gecko":function(){return this._element.naturalHeight;
},
"default":function(){return this._element.height;
}}),
__onload:function(){if(this._isLoaded||this._isErroneous){return;
}this._isLoaded=true;
this._isErroneous=false;
if(this.hasEventListeners($[94])){this.dispatchEvent(new qx.event.type.Event($[94]),
true);
}},
__onerror:function(){if(this._isLoaded||this._isErroneous){return;
}this.debug("Could not load: "+this._source);
this._isLoaded=false;
this._isErroneous=true;
if(this.hasEventListeners($[78])){this.dispatchEvent(new qx.event.type.Event($[78]),
true);
}}},
destruct:function(){if(this._element){this._element.onload=this._element.onerror=null;
}this._disposeFields($[273],
$[1986],
$[1692],
$[1824]);
}});




/* ID: Tr.Application */
qx.Class.define($[986],
{extend:qx.application.Gui,
members:{main:function(){var $0=this;
arguments.callee.base.call(this);
qx.io.Alias.getInstance().add($[1391],
qx.core.Setting.get($[1472]));
Tr.Server.getInstance().setLocalUrl($[1381]);
var $1=new qx.ui.layout.VerticalBoxLayout();
with($1){setPadding(8);
setLocation(0,
0);
setWidth($[302]);
setHeight($[302]);
setSpacing(2);
setBackgroundColor($[1939]);
}$1.addToDocument();
var $2=new qx.ui.layout.HorizontalBoxLayout();
$2.set({height:$[129]});
var $3=new qx.ui.basic.Atom($[825]);
with($3){setTextColor($[450]);
setFont(qx.ui.core.Font.fromString($[1775]));
}$2.add($3);
$2.add(new qx.ui.basic.HorizontalSpacer());
$2.add(new Tr.ui.ActionButton());
$1.add($2);
var $4=new Tr.ui.TraceTable();
$1.add($4);
$1.add(new Tr.ui.Footer(this.tr($[710]),
$[948]));
},
close:function($0){arguments.callee.base.call(this);
},
terminate:function($0){arguments.callee.base.call(this);
}},
settings:{'Tr.resourceUri':$[1206]}});




/* ID: qx.io.remote.Rpc */
qx.Class.define($[1031],
{extend:qx.core.Target,
construct:function($0,
$1){arguments.callee.base.call(this);
if($0!==undefined){this.setUrl($0);
}
if($1!=null){this.setServiceName($1);
}this._previousServerSuffix=null;
this._currentServerSuffix=null;
if(qx.core.ServerSettings){this._currentServerSuffix=qx.core.ServerSettings.serverPathSuffix;
}},
events:{"completed":$[4],
"aborted":$[4],
"failed":$[4],
"timeout":$[4]},
statics:{origin:{server:1,
application:2,
transport:3,
local:4},
localError:{timeout:1,
abort:2},
makeServerURL:function($0){var $1=null;
if(qx.core.ServerSettings){$1=qx.core.ServerSettings.serverPathPrefix+$[1132]+qx.core.ServerSettings.serverPathSuffix;
if($0!=null){$1+=$[676]+$0;
}}return $1;
}},
properties:{timeout:{check:$[6],
nullable:true},
crossDomain:{check:$[2],
init:false},
url:{check:$[9],
nullable:true},
serviceName:{check:$[9],
nullable:true},
serverData:{check:$[97],
nullable:true},
username:{check:$[9],
nullable:true},
password:{check:$[9],
nullable:true},
useBasicHttpAuth:{check:$[2],
nullable:true}},
members:{_callInternal:function($0,
$1,
$2){var $3=this;
var $4=($1==0?0:1);
var $5=($2?$[1766]:$0[$4]);
var $6=$0[0];
var $7=[];
var $8=this;
for(var $9=$4+1;$9<$0.length;++$9){$7.push($0[$9]);
}var $a=new qx.io.remote.Request(this.getUrl(),
qx.net.Http.METHOD_POST,
qx.util.Mime.JSON);
var $b={"service":($2?null:this.getServiceName()),
"method":$5,
"id":$a.getSequenceNumber(),
"params":$7};
var $c=this.getServerData();
if($c!==undefined){$b.server_data=$c;
}$a.setCrossDomain(this.getCrossDomain());
if(this.getUsername()){$a.setUseBasicHttpAuth(this.getUseBasicHttpAuth());
$a.setUsername(this.getUsername());
$a.setPassword(this.getPassword());
}$a.setTimeout(this.getTimeout());
var $d=null;
var $e=null;
var $f=null;
var $g=null;
var $h=function($i,
$8){switch($1){case 0:break;
case 1:$6($f,
$d,
$e);
break;
case 2:if(!$d){$8.createDispatchDataEvent($i,
$g);
}else{$d.id=$e;
if($0[0]){$8.createDispatchDataEvent($[19],
$d);
}else{$8.createDispatchDataEvent($i,
$d);
}}}};
var $j=function($k){$k.toString=function(){switch($k.origin){case qx.io.remote.Rpc.origin.server:return $[1389]+$k.code+$[108]+$k.message;
case qx.io.remote.Rpc.origin.application:return $[993]+$k.code+$[108]+$k.message;
case qx.io.remote.Rpc.origin.transport:return $[1887]+$k.code+$[108]+$k.message;
case qx.io.remote.Rpc.origin.local:return $[1377]+$k.code+$[108]+$k.message;
default:return ($[1021]+$k.origin+$[1081]+$k.code+$[108]+$k.message);
}};
};
var $l=function($m,
$n,
$o){var $d=new Object();
$d.origin=$m;
$d.code=$n;
$d.message=$o;
$j($d);
return $d;
};
$a.addEventListener($[19],
function($p){var $n=$p.getStatusCode();
$d=$l(qx.io.remote.Rpc.origin.transport,
$n,
qx.io.remote.Exchange.statusCodeToString($n));
$e=this.getSequenceNumber();
$h($[19],
$8);
});
$a.addEventListener($[29],
function($p){this.debug("TIMEOUT OCCURRED");
$d=$l(qx.io.remote.Rpc.origin.local,
qx.io.remote.Rpc.localError.timeout,
$[1744]);
$e=this.getSequenceNumber();
$h($[29],
$8);
});
$a.addEventListener($[28],
function($p){$d=$l(qx.io.remote.Rpc.origin.local,
qx.io.remote.Rpc.localError.abort,
$[1682]);
$e=this.getSequenceNumber();
$h($[28],
$8);
});
$a.addEventListener($[16],
function($p){$g=$p.getContent();
$e=$g[$[1118]];
if($e!=this.getSequenceNumber()){this.warn("Received id ("+$e+") does not match requested id "+"("+this.getSequenceNumber()+")!");
}var $q=$g[$[78]];
if($q!=null){$f=null;
$j($q);
$d=$q;
}else{$f=$g[$[1250]];
if($2){$f=eval($[100]+$f+$[44]);
var $r=qx.core.ServerSettings.serverPathSuffix;
if($3._currentServerSuffix!=$r){$3._previousServerSuffix=$3._currentServerSuffix;
$3._currentServerSuffix=$r;
}$3.setUrl($3.fixUrl($3.getUrl()));
}}$h($[16],
$8);
});
$a.setData(qx.io.Json.stringify($b));
$a.setAsynchronous($1>0);
if($a.getCrossDomain()){$a.setRequestHeader($[216],
$[371]);
}else{$a.setRequestHeader($[216],
qx.util.Mime.JSON);
}$a.send();
if($1==0){if($d!=null){var $s=new Error($d.toString());
$s.rpcdetails=$d;
throw $s;
}return $f;
}else{return $a;
}},
fixUrl:function($0){if(this._previousServerSuffix==null||this._currentServerSuffix==null||this._previousServerSuffix==$[0]||this._previousServerSuffix==this._currentServerSuffix){return $0;
}var $1=$0.indexOf(this._previousServerSuffix);
if($1==-1){return $0;
}return ($0.substring(0,
$1)+this._currentServerSuffix+$0.substring($1+this._previousServerSuffix.length));
},
callSync:function($0){return this._callInternal(arguments,
0);
},
callAsync:function($0,
$1){return this._callInternal(arguments,
1);
},
callAsyncListeners:function($0,
$1){return this._callInternal(arguments,
2);
},
refreshSession:function($0){if(this.getCrossDomain()){if(qx.core.ServerSettings&&qx.core.ServerSettings.serverPathSuffix){var $1=(new Date()).getTime()-qx.core.ServerSettings.lastSessionRefresh;
if($1/1000>(qx.core.ServerSettings.sessionTimeoutInSeconds-30)){this._callInternal([$0],
1,
true);
}else{$0(true);
}}else{$0(false);
}}else{$0(true);
}},
abort:function($0){$0.abort();
}}});




/* ID: qx.net.Http */
qx.Class.define($[1084],
{statics:{METHOD_GET:"GET",
METHOD_POST:"POST",
METHOD_PUT:"PUT",
METHOD_HEAD:"HEAD",
METHOD_DELETE:"DELETE"}});




/* ID: qx.util.Mime */
qx.Class.define($[1553],
{statics:{JAVASCRIPT:"text/javascript",
JSON:"application/json",
XML:"application/xml",
TEXT:"text/plain",
HTML:"text/html"}});




/* ID: qx.io.remote.Request */
qx.Class.define($[610],
{extend:qx.core.Target,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
this._requestHeaders={};
this._parameters={};
this._formFields={};
if($0!==undefined){this.setUrl($0);
}
if($1!==undefined){this.setMethod($1);
}
if($2!==undefined){this.setResponseType($2);
}this.setProhibitCaching(true);
this.setRequestHeader($[1752],
$[1008]);
this.setRequestHeader($[1904],
qx.core.Version.toString());
this._seqNum=++qx.io.remote.Request._seqNum;
},
events:{"created":$[4],
"configured":$[4],
"sending":$[4],
"receiving":$[4],
"completed":$[103],
"aborted":$[103],
"failed":$[103],
"timeout":$[103]},
statics:{_seqNum:0},
properties:{url:{check:$[9],
init:$[0]},
method:{check:[qx.net.Http.METHOD_GET,
qx.net.Http.METHOD_POST,
qx.net.Http.METHOD_PUT,
qx.net.Http.METHOD_HEAD,
qx.net.Http.METHOD_DELETE],
apply:$[1542],
init:qx.net.Http.METHOD_GET},
asynchronous:{check:$[2],
init:true},
data:{check:$[9],
nullable:true},
username:{check:$[9],
nullable:true},
password:{check:$[9],
nullable:true},
state:{check:[$[79],
$[213],
$[36],
$[41],
$[16],
$[28],
$[29],
$[19]],
init:$[79],
apply:$[340],
event:$[316]},
responseType:{check:[qx.util.Mime.TEXT,
qx.util.Mime.JAVASCRIPT,
qx.util.Mime.JSON,
qx.util.Mime.XML,
qx.util.Mime.HTML],
init:qx.util.Mime.TEXT,
apply:$[1286]},
timeout:{check:$[6],
nullable:true},
prohibitCaching:{check:$[2],
init:true,
apply:$[1885]},
crossDomain:{check:$[2],
init:false},
fileUpload:{check:$[2],
init:false},
transport:{check:$[601],
nullable:true},
useBasicHttpAuth:{check:$[2],
init:false}},
members:{send:function(){qx.io.remote.RequestQueue.getInstance().add(this);
},
abort:function(){qx.io.remote.RequestQueue.getInstance().abort(this);
},
reset:function(){switch(this.getState()){case $[36]:case $[41]:this.error("Aborting already sent request!");
case $[213]:this.abort();
break;
}},
isConfigured:function(){return this.getState()===$[79];
},
isQueued:function(){return this.getState()===$[213];
},
isSending:function(){return this.getState()===$[36];
},
isReceiving:function(){return this.getState()===$[41];
},
isCompleted:function(){return this.getState()===$[16];
},
isAborted:function(){return this.getState()===$[28];
},
isTimeout:function(){return this.getState()===$[29];
},
isFailed:function(){return this.getState()===$[19];
},
_onqueued:function($0){this.setState($[213]);
this.dispatchEvent($0);
},
_onsending:function($0){this.setState($[36]);
this.dispatchEvent($0);
},
_onreceiving:function($0){this.setState($[41]);
this.dispatchEvent($0);
},
_oncompleted:function($0){this.setState($[16]);
this.dispatchEvent($0);
this.dispose();
},
_onaborted:function($0){this.setState($[28]);
this.dispatchEvent($0);
this.dispose();
},
_ontimeout:function($0){this.setState($[29]);
this.dispatchEvent($0);
this.dispose();
},
_onfailed:function($0){this.setState($[19]);
this.dispatchEvent($0);
this.dispose();
},
_applyState:function($0,
$1){{};
},
_applyProhibitCaching:function($0,
$1){if($0){this.setParameter($[404],
new Date().valueOf());
this.setRequestHeader($[436],
$[425]);
this.setRequestHeader($[493],
$[425]);
}else{this.removeParameter($[404]);
this.removeRequestHeader($[436]);
this.removeRequestHeader($[493]);
}},
_applyMethod:function($0,
$1){if($0===qx.net.Http.METHOD_POST){this.setRequestHeader($[216],
$[371]);
}else{this.removeRequestHeader($[216]);
}},
_applyResponseType:function($0,
$1){this.setRequestHeader($[968],
$0);
},
setRequestHeader:function($0,
$1){this._requestHeaders[$0]=$1;
},
removeRequestHeader:function($0){delete this._requestHeaders[$0];
},
getRequestHeader:function($0){return this._requestHeaders[$0]||null;
},
getRequestHeaders:function(){return this._requestHeaders;
},
setParameter:function($0,
$1){this._parameters[$0]=$1;
},
removeParameter:function($0){delete this._parameters[$0];
},
getParameter:function($0){return this._parameters[$0]||null;
},
getParameters:function(){return this._parameters;
},
setFormField:function($0,
$1){this._formFields[$0]=$1;
},
removeFormField:function($0){delete this._formFields[$0];
},
getFormField:function($0){return this._formFields[$0]||null;
},
getFormFields:function(){return this._formFields;
},
getSequenceNumber:function(){return this._seqNum;
}},
destruct:function(){this.setTransport(null);
this._disposeFields($[1224],
$[1722],
$[1473]);
}});




/* ID: qx.io.remote.RequestQueue */
qx.Class.define($[1163],
{type:$[24],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this._queue=[];
this._active=[];
this._totalRequests=0;
this._timer=new qx.client.Timer(500);
this._timer.addEventListener($[67],
this._oninterval,
this);
},
properties:{enabled:{init:true,
check:$[2],
apply:$[325]},
maxTotalRequests:{check:$[6],
nullable:true},
maxConcurrentRequests:{check:$[6],
init:3},
defaultTimeout:{check:$[6],
init:5000}},
members:{_debug:function(){var $0=this._active.length+$[145]+(this._queue.length+this._active.length);
{};
},
_check:function(){this._debug();
if(this._active.length==0&&this._queue.length==0){this._timer.stop();
}if(!this.getEnabled()){return;
}if(this._active.length>=this.getMaxConcurrentRequests()||this._queue.length==0){return;
}if(this.getMaxTotalRequests()!=null&&this._totalRequests>=this.getMaxTotalRequests()){return;
}var $0=this._queue.shift();
var $1=new qx.io.remote.Exchange($0);
this._totalRequests++;
this._active.push($1);
this._debug();
$1.addEventListener($[36],
$0._onsending,
$0);
$1.addEventListener($[41],
$0._onreceiving,
$0);
$1.addEventListener($[16],
$0._oncompleted,
$0);
$1.addEventListener($[28],
$0._onaborted,
$0);
$1.addEventListener($[29],
$0._ontimeout,
$0);
$1.addEventListener($[19],
$0._onfailed,
$0);
$1.addEventListener($[36],
this._onsending,
this);
$1.addEventListener($[16],
this._oncompleted,
this);
$1.addEventListener($[28],
this._oncompleted,
this);
$1.addEventListener($[29],
this._oncompleted,
this);
$1.addEventListener($[19],
this._oncompleted,
this);
$1._start=(new Date).valueOf();
$1.send();
if(this._queue.length>0){this._check();
}},
_remove:function($0){qx.lang.Array.remove(this._active,
$0);
$0.dispose();
this._check();
},
_activeCount:0,
_onsending:function($0){{};
},
_oncompleted:function($0){{};
this._remove($0.getTarget());
},
_oninterval:function($0){var $1=this._active;
if($1.length==0){return;
}var $2=(new Date).valueOf();
var $3;
var $4;
var $5=this.getDefaultTimeout();
var $6;
var $7;
for(var $8=$1.length-1;$8>=0;$8--){$3=$1[$8];
$4=$3.getRequest();
if($4.isAsynchronous()){$6=$4.getTimeout();
if($6==0){continue;
}
if($6==null){$6=$5;
}$7=$2-$3._start;
if($7>$6){this.warn("Timeout: transport "+$3.toHashCode());
this.warn($7+"ms > "+$6+"ms");
$3.timeout();
}}}},
_applyEnabled:function($0,
$1){if($0){this._check();
}this._timer.setEnabled($0);
},
add:function($0){$0.setState($[213]);
this._queue.push($0);
this._check();
if(this.getEnabled()){this._timer.start();
}},
abort:function($0){var $1=$0.getTransport();
if($1){$1.abort();
}else if(qx.lang.Array.contains(this._queue,
$0)){qx.lang.Array.remove(this._queue,
$0);
}}},
destruct:function(){this._disposeObjectDeep($[1477],
1);
this._disposeObjects($[202]);
this._disposeFields($[1243]);
}});




/* ID: qx.io.remote.Exchange */
qx.Class.define($[601],
{extend:qx.core.Target,
construct:function($0){arguments.callee.base.call(this);
this.setRequest($0);
$0.setTransport(this);
},
events:{"sending":$[4],
"receiving":$[4],
"completed":$[103],
"aborted":$[103],
"failed":$[103],
"timeout":$[103]},
statics:{typesOrder:[$[299],
$[320],
$[312]],
typesReady:false,
typesAvailable:{},
typesSupported:{},
registerType:function($0,
$1){qx.io.remote.Exchange.typesAvailable[$1]=$0;
},
initTypes:function(){if(qx.io.remote.Exchange.typesReady){return;
}
for(var $0 in qx.io.remote.Exchange.typesAvailable){var $1=qx.io.remote.Exchange.typesAvailable[$0];
if($1.isSupported()){qx.io.remote.Exchange.typesSupported[$0]=$1;
}}qx.io.remote.Exchange.typesReady=true;
if(qx.lang.Object.isEmpty(qx.io.remote.Exchange.typesSupported)){throw new Error("No supported transport types were found!");
}},
canHandle:function($0,
$1,
$2){if(!qx.lang.Array.contains($0.handles.responseTypes,
$2)){return false;
}
for(var $3 in $1){if(!$0.handles[$3]){return false;
}}return true;
},
_nativeMap:{0:$[140],
1:$[79],
2:$[36],
3:$[41],
4:$[16]},
wasSuccessful:function($0,
$1,
$2){if($2){switch($0){case null:case 0:return true;
case -1:return $1<4;
default:return typeof $0===$[7];
}}else{switch($0){case -1:{};
return $1<4;
case 200:case 304:return true;
case 201:case 202:case 203:case 204:case 205:return true;
case 206:{};
return $1!==4;
case 300:case 301:case 302:case 303:case 305:case 400:case 401:case 402:case 403:case 404:case 405:case 406:case 407:case 408:case 409:case 410:case 411:case 412:case 413:case 414:case 415:case 500:case 501:case 502:case 503:case 504:case 505:{};
return false;
case 12002:case 12029:case 12030:case 12031:case 12152:case 13030:{};
return false;
default:if($0>206&&$0<300){return true;
}qx.log.Logger.getClassLogger(qx.io.remote.Exchange).debug("Unknown status code: "+$0+" ("+$1+")");
return false;
}}},
statusCodeToString:function($0){switch($0){case -1:return $[1342];
case 200:return $[1866];
case 304:return $[687];
case 206:return $[725];
case 204:return $[1359];
case 300:return $[1634];
case 301:return $[1050];
case 302:return $[1009];
case 303:return $[811];
case 305:return $[660];
case 400:return $[1599];
case 401:return $[1783];
case 402:return $[1647];
case 403:return $[1424];
case 404:return $[1770];
case 405:return $[1862];
case 406:return $[913];
case 407:return $[1438];
case 408:return $[1598];
case 409:return $[1295];
case 410:return $[1779];
case 411:return $[1928];
case 412:return $[1874];
case 413:return $[1509];
case 414:return $[910];
case 415:return $[1871];
case 500:return $[966];
case 501:return $[679];
case 502:return $[833];
case 503:return $[1851];
case 504:return $[1896];
case 505:return $[861];
case 12002:return $[1214];
case 12029:return $[344];
case 12030:return $[344];
case 12031:return $[344];
case 12152:return $[945];
case 13030:return $[1739];
default:return $[1336];
}}},
properties:{request:{check:$[610],
nullable:true},
implementation:{check:$[510],
nullable:true,
apply:$[1485]},
state:{check:[$[79],
$[36],
$[41],
$[16],
$[28],
$[29],
$[19]],
init:$[79],
event:$[316],
apply:$[340]}},
members:{send:function(){var $0=this.getRequest();
if(!$0){return this.error("Please attach a request object first");
}qx.io.remote.Exchange.initTypes();
var $1=qx.io.remote.Exchange.typesOrder;
var $2=qx.io.remote.Exchange.typesSupported;
var $3=$0.getResponseType();
var $4={};
if($0.getAsynchronous()){$4.asynchronous=true;
}else{$4.synchronous=true;
}
if($0.getCrossDomain()){$4.crossDomain=true;
}
if($0.getFileUpload()){$4.fileUpload=true;
}for(var $5 in $0.getFormFields()){$4.programaticFormFields=true;
break;
}var $6,
$7;
for(var $8=0,
$9=$1.length;$8<$9;$8++){$6=$2[$1[$8]];
if($6){if(!qx.io.remote.Exchange.canHandle($6,
$4,
$3)){continue;
}
try{{};
$7=new $6;
this.setImplementation($7);
$7.setUseBasicHttpAuth($0.getUseBasicHttpAuth());
$7.send();
return true;
}catch(ex){return this.error("Request handler throws error",
ex);
}}}this.error("There is no transport implementation available to handle this request: "+$0);
},
abort:function(){var $0=this.getImplementation();
if($0){{};
$0.abort();
}else{{};
this.setState($[28]);
}},
timeout:function(){var $0=this.getImplementation();
if($0){this.warn("Timeout: implementation "+$0.toHashCode());
$0.timeout();
}else{this.warn("Timeout: forcing state to timeout");
this.setState($[29]);
}if(this.getRequest()){this.getRequest().setTimeout(0);
}},
_onsending:function($0){this.setState($[36]);
},
_onreceiving:function($0){this.setState($[41]);
},
_oncompleted:function($0){this.setState($[16]);
},
_onabort:function($0){this.setState($[28]);
},
_onfailed:function($0){this.setState($[19]);
},
_ontimeout:function($0){this.setState($[29]);
},
_applyImplementation:function($0,
$1){if($1){$1.removeEventListener($[36],
this._onsending,
this);
$1.removeEventListener($[41],
this._onreceiving,
this);
$1.removeEventListener($[16],
this._oncompleted,
this);
$1.removeEventListener($[28],
this._onabort,
this);
$1.removeEventListener($[29],
this._ontimeout,
this);
$1.removeEventListener($[19],
this._onfailed,
this);
}
if($0){var $2=this.getRequest();
$0.setUrl($2.getUrl());
$0.setMethod($2.getMethod());
$0.setAsynchronous($2.getAsynchronous());
$0.setUsername($2.getUsername());
$0.setPassword($2.getPassword());
$0.setParameters($2.getParameters());
$0.setFormFields($2.getFormFields());
$0.setRequestHeaders($2.getRequestHeaders());
$0.setData($2.getData());
$0.setResponseType($2.getResponseType());
$0.addEventListener($[36],
this._onsending,
this);
$0.addEventListener($[41],
this._onreceiving,
this);
$0.addEventListener($[16],
this._oncompleted,
this);
$0.addEventListener($[28],
this._onabort,
this);
$0.addEventListener($[29],
this._ontimeout,
this);
$0.addEventListener($[19],
this._onfailed,
this);
}},
_applyState:function($0,
$1){var $2=this.getRequest();
{};
switch($0){case $[36]:this.createDispatchEvent($[36]);
break;
case $[41]:this.createDispatchEvent($[41]);
break;
case $[16]:case $[28]:case $[29]:case $[19]:var $3=this.getImplementation();
if(!$3){break;
}
if(this.hasEventListeners($0)){var $4=new qx.io.remote.Response($0);
if($0==$[16]){var $5=$3.getResponseContent();
$4.setContent($5);
if($5===null){{};
$0=$[19];
}}$4.setStatusCode($3.getStatusCode());
$4.setResponseHeaders($3.getResponseHeaders());
this.dispatchEvent($4);
}this.setImplementation(null);
$3.dispose();
break;
}}},
settings:{"qx.ioRemoteDebug":false,
"qx.ioRemoteDebugData":false},
destruct:function(){var $0=this.getImplementation();
if($0){this.setImplementation(null);
$0.dispose();
}this.setRequest(null);
}});




/* ID: qx.io.remote.Response */
qx.Class.define($[103],
{extend:qx.event.type.Event,
construct:function($0){arguments.callee.base.call(this,
$0);
},
properties:{state:{check:$[6],
nullable:true},
statusCode:{check:$[6],
nullable:true},
content:{nullable:true},
responseHeaders:{check:$[97],
nullable:true}},
members:{getResponseHeader:function($0){var $1=this.getResponseHeaders();
if($1){return $1[$0]||null;
}return null;
},
getData:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1370]);
return this;
}}});




/* ID: qx.io.remote.AbstractRemoteTransport */
qx.Class.define($[510],
{type:$[82],
extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
},
events:{"created":$[4],
"configured":$[4],
"sending":$[4],
"receiving":$[4],
"completed":$[4],
"aborted":$[4],
"failed":$[4],
"timeout":$[4]},
properties:{url:{check:$[9],
nullable:true},
method:{check:$[9],
nullable:true},
asynchronous:{check:$[2],
nullable:true},
data:{check:$[9],
nullable:true},
username:{check:$[9],
nullable:true},
password:{check:$[9],
nullable:true},
state:{check:[$[140],
$[79],
$[36],
$[41],
$[16],
$[28],
$[29],
$[19]],
init:$[140],
event:$[316],
apply:$[340]},
requestHeaders:{check:$[97],
nullable:true},
parameters:{check:$[97],
nullable:true},
formFields:{check:$[97],
nullable:true},
responseType:{check:$[9],
nullable:true},
useBasicHttpAuth:{check:$[2],
nullable:true}},
members:{send:function(){throw new Error("send is abstract");
},
abort:function(){{};
this.setState($[28]);
},
timeout:function(){{};
this.setState($[29]);
},
failed:function(){{};
this.setState($[19]);
},
setRequestHeader:function($0,
$1){throw new Error("setRequestHeader is abstract");
},
getResponseHeader:function($0){throw new Error("getResponseHeader is abstract");
},
getResponseHeaders:function(){throw new Error("getResponseHeaders is abstract");
},
getStatusCode:function(){throw new Error("getStatusCode is abstract");
},
getStatusText:function(){throw new Error("getStatusText is abstract");
},
getResponseText:function(){throw new Error("getResponseText is abstract");
},
getResponseXml:function(){throw new Error("getResponseXml is abstract");
},
getFetchedLength:function(){throw new Error("getFetchedLength is abstract");
},
_applyState:function($0,
$1){{};
switch($0){case $[140]:this.createDispatchEvent($[140]);
break;
case $[79]:this.createDispatchEvent($[79]);
break;
case $[36]:this.createDispatchEvent($[36]);
break;
case $[41]:this.createDispatchEvent($[41]);
break;
case $[16]:this.createDispatchEvent($[16]);
break;
case $[28]:this.createDispatchEvent($[28]);
break;
case $[19]:this.createDispatchEvent($[19]);
break;
case $[29]:this.createDispatchEvent($[29]);
break;
}return true;
}}});




/* ID: qx.io.remote.XmlHttpTransport */
qx.Class.define($[299],
{extend:qx.io.remote.AbstractRemoteTransport,
construct:function(){arguments.callee.base.call(this);
this._req=qx.io.remote.XmlHttpTransport.createRequestObject();
this._req.onreadystatechange=qx.lang.Function.bind(this._onreadystatechange,
this);
},
events:{"created":$[4],
"configured":$[4],
"sending":$[4],
"receiving":$[4],
"completed":$[4],
"aborted":$[4],
"failed":$[4],
"timeout":$[4]},
statics:{handles:{synchronous:true,
asynchronous:true,
crossDomain:false,
fileUpload:false,
programaticFormFields:false,
responseTypes:[qx.util.Mime.TEXT,
qx.util.Mime.JAVASCRIPT,
qx.util.Mime.JSON,
qx.util.Mime.XML,
qx.util.Mime.HTML]},
requestObjects:[],
requestObjectCount:0,
isSupported:function(){return qx.net.HttpRequest.create()!=null?true:false;
},
createRequestObject:function(){return qx.net.HttpRequest.create();
},
__dummy:function(){}},
members:{_localRequest:false,
_lastReadyState:0,
getRequest:function(){return this._req;
},
send:function(){this._lastReadyState=0;
var $0=this.getRequest();
var $1=this.getMethod();
var $2=this.getAsynchronous();
var $3=this.getUrl();
var $4=(qx.core.Client.getInstance().getRunsLocally()&&!(/^http(s){0,1}\:/.test($3)));
this._localRequest=$4;
var $5=this.getParameters();
var $6=[];
for(var $7 in $5){var $8=$5[$7];
if($8 instanceof Array){for(var $9=0;$9<$8.length;$9++){$6.push(encodeURIComponent($7)+$[33]+encodeURIComponent($8[$9]));
}}else{$6.push(encodeURIComponent($7)+$[33]+encodeURIComponent($8));
}}
if($6.length>0){$3+=($3.indexOf($[149])>=0?$[60]:$[149])+$6.join($[60]);
}var $a=function($b){var $c=$[1130];
var $d=$[0];
var $e,
$f,
$g;
var $h,
$i,
$j,
$k;
var $9=0;
do{$e=$b.charCodeAt($9++);
$f=$b.charCodeAt($9++);
$g=$b.charCodeAt($9++);
$h=$e>>2;
$i=(($e&3)<<4)|($f>>4);
$j=(($f&15)<<2)|($g>>6);
$k=$g&63;
if(isNaN($f)){$j=$k=64;
}else if(isNaN($g)){$k=64;
}$d+=$c.charAt($h)+$c.charAt($i)+$c.charAt($j)+$c.charAt($k);
}while($9<$b.length);
return $d;
};
var $l=qx.lang.Function.bind(this._onreadystatechange,
this);
if(qx.core.Variant.isSet($[1],
$[20])&&this.getAsynchronous()){$0.onreadystatechange=function($m){var $n=this;
window.setTimeout(function($m){$l($m);
},
0);
};
}else{$0.onreadystatechange=$l;
}if(this.getUsername()){if(this.getUseBasicHttpAuth()){$0.open($1,
$3,
$2);
$0.setRequestHeader($[1052],
$[1413]+$a(this.getUsername()+$[1705]+this.getPassword()));
}else{$0.open($1,
$3,
$2,
this.getUsername(),
this.getPassword());
}}else{$0.open($1,
$3,
$2);
}$0.setRequestHeader($[1431],
window.location.href);
var $o=this.getRequestHeaders();
for(var $7 in $o){$0.setRequestHeader($7,
$o[$7]);
}try{{};
$0.send(this.getData());
}catch(ex){if($4){this.failedLocally();
}else{this.error("Failed to send data: "+ex,
"send");
this.failed();
}return;
}if(!$2){this._onreadystatechange();
}},
failedLocally:function(){if(this.getState()===$[19]){return;
}this.warn("Could not load from file: "+this.getUrl());
this.failed();
},
_onreadystatechange:function($0){switch(this.getState()){case $[16]:case $[28]:case $[19]:case $[29]:{};
return;
}var $1=this.getReadyState();
if($1==4){if(!qx.io.remote.Exchange.wasSuccessful(this.getStatusCode(),
$1,
this._localRequest)){return this.failed();
}}while(this._lastReadyState<$1){this.setState(qx.io.remote.Exchange._nativeMap[++this._lastReadyState]);
}},
getReadyState:function(){var $0=null;
try{$0=this._req.readyState;
}catch(ex){}return $0;
},
setRequestHeader:function($0,
$1){this._req.setRequestHeader($0,
$1);
},
getResponseHeader:function($0){var $1=null;
try{this.getRequest().getResponseHeader($0)||null;
}catch(ex){}return $1;
},
getStringResponseHeaders:function(){var $0=null;
try{var $1=this._req.getAllResponseHeaders();
if($1){$0=$1;
}}catch(ex){}return $0;
},
getResponseHeaders:function(){var $0=this.getStringResponseHeaders();
var $1={};
if($0){var $2=$0.split(/[\r\n]+/g);
for(var $3=0,
$4=$2.length;$3<$4;$3++){var $5=$2[$3].match(/^([^:]+)\s*:\s*(.+)$/i);
if($5){$1[$5[1]]=$5[2];
}}}return $1;
},
getStatusCode:function(){var $0=-1;
try{$0=this.getRequest().status;
}catch(ex){}return $0;
},
getStatusText:function(){var $0=$[0];
try{$0=this.getRequest().statusText;
}catch(ex){}return $0;
},
getResponseText:function(){var $0=null;
var $1=this.getStatusCode();
var $2=this.getReadyState();
if(qx.io.remote.Exchange.wasSuccessful($1,
$2,
this._localRequest)){try{$0=this.getRequest().responseText;
}catch(ex){}}return $0;
},
getResponseXml:function(){var $0=null;
var $1=this.getStatusCode();
var $2=this.getReadyState();
if(qx.io.remote.Exchange.wasSuccessful($1,
$2,
this._localRequest)){try{$0=this.getRequest().responseXML;
}catch(ex){}}if(typeof $0==$[38]&&$0!=null){if(!$0.documentElement){var $3=String(this.getRequest().responseText).replace(/<\?xml[^\?]*\?>/,
$[0]);
$0.loadXML($3);
}if(!$0.documentElement){throw new Error("Missing Document Element!");
}
if($0.documentElement.tagName==$[939]){throw new Error("XML-File is not well-formed!");
}}else{throw new Error("Response was not a valid xml document ["+this.getRequest().responseText+"]");
}return $0;
},
getFetchedLength:function(){var $0=this.getResponseText();
return typeof $0==$[8]?$0.length:0;
},
getResponseContent:function(){if(this.getState()!==$[16]){{};
return null;
}{};
var $0=this.getResponseText();
switch(this.getResponseType()){case qx.util.Mime.TEXT:case qx.util.Mime.HTML:{};
return $0;
case qx.util.Mime.JSON:{};
try{if($0&&$0.length>0){return qx.io.Json.parseQx($0)||null;
}else{return null;
}}catch(ex){this.error("Could not execute json: ["+$0+"]",
ex);
return $[1489]+$0+$[1782];
}case qx.util.Mime.JAVASCRIPT:{};
try{if($0&&$0.length>0){return window.eval($0)||null;
}else{return null;
}}catch(ex){this.error("Could not execute javascript: ["+$0+"]",
ex);
return null;
}case qx.util.Mime.XML:$0=this.getResponseXml();
{};
return $0||null;
default:this.warn("No valid responseType specified ("+this.getResponseType()+")!");
return null;
}},
_applyState:function($0,
$1){{};
switch($0){case $[140]:this.createDispatchEvent($[140]);
break;
case $[79]:this.createDispatchEvent($[79]);
break;
case $[36]:this.createDispatchEvent($[36]);
break;
case $[41]:this.createDispatchEvent($[41]);
break;
case $[16]:this.createDispatchEvent($[16]);
break;
case $[19]:this.createDispatchEvent($[19]);
break;
case $[28]:this.getRequest().abort();
this.createDispatchEvent($[28]);
break;
case $[29]:this.getRequest().abort();
this.createDispatchEvent($[29]);
break;
}}},
defer:function($0,
$1){qx.io.remote.Exchange.registerType(qx.io.remote.XmlHttpTransport,
$[299]);
},
destruct:function(){var $0=this.getRequest();
if($0){$0.onreadystatechange=qx.io.remote.XmlHttpTransport.__dummy;
switch($0.readyState){case 1:case 2:case 3:$0.abort();
}}this._disposeFields($[1618]);
}});




/* ID: qx.net.HttpRequest */
qx.Class.define($[1502],
{statics:{create:qx.core.Variant.select($[1],
{"default":function(){return new XMLHttpRequest;
},
"mshtml":qx.lang.Object.select(location.protocol!==$[512]&&window.XMLHttpRequest?$[946]:$[1847],
{"native":function(){return new XMLHttpRequest;
},
"activeX":function(){if(this.__server){return new ActiveXObject(this.__server);
}var $0=[$[1479],
$[1920],
$[1889],
$[1800],
$[1690]];
var $1;
var $2;
for(var $3=0,
$4=$0.length;$3<$4;$3++){$2=$0[$3];
try{$1=new ActiveXObject($2);
break;
}catch(ex){$1=null;
}}
if($1){this.__server=$2;
}return $1;
}})})}});




/* ID: qx.io.Json */
qx.Class.define($[1900],
{statics:{BEAUTIFYING_INDENT:"  ",
BEAUTIFYING_LINE_END:"\n",
__map:{"function":$[1554],
"boolean":$[983],
"number":$[1158],
"string":$[1364],
"object":$[1211],
"undefined":$[1605]},
__convertFunction:function($0){return String($0);
},
__convertBoolean:function($0){return String($0);
},
__convertNumber:function($0){return isFinite($0)?String($0):$[345];
},
__convertString:function($0){var $1;
if(/["\\\x00-\x1f]/.test($0)){$1=$0.replace(/([\x00-\x1f\\"])/g,
qx.io.Json.__convertStringHelper);
}else{$1=$0;
}return $[119]+$1+$[119];
},
__convertStringEscape:{'\b':$[1204],
'\t':$[1811],
'\n':$[1578],
'\f':$[791],
'\r':$[1015],
'"':$[1858],
'\\':$[718]},
__convertStringHelper:function($0,
$1){var $2=qx.io.Json.__convertStringEscape[$1];
if($2){return $2;
}$2=$1.charCodeAt();
return $[1006]+Math.floor($2/16).toString(16)+($2%16).toString(16);
},
__convertArray:function($0){var $1=[],
$2=true,
$3,
$4;
var $5=qx.io.Json.__beautify;
$1.push($[606]);
if($5){qx.io.Json.__indent+=qx.io.Json.BEAUTIFYING_INDENT;
$1.push(qx.io.Json.__indent);
}
for(var $6=0,
$7=$0.length;$6<$7;$6++){$4=$0[$6];
$3=this.__map[typeof $4];
if($3){$4=this[$3]($4);
if(typeof $4==$[8]){if(!$2){$1.push($[17]);
if($5){$1.push(qx.io.Json.__indent);
}}$1.push($4);
$2=false;
}}}
if($5){qx.io.Json.__indent=qx.io.Json.__indent.substring(0,
qx.io.Json.__indent.length-qx.io.Json.BEAUTIFYING_INDENT.length);
$1.push(qx.io.Json.__indent);
}$1.push($[106]);
return $1.join($[0]);
},
__convertDate:function($0){var $1=$0.getUTCFullYear()+$[17]+$0.getUTCMonth()+$[17]+$0.getUTCDate()+$[17]+$0.getUTCHours()+$[17]+$0.getUTCMinutes()+$[17]+$0.getUTCSeconds()+$[17]+$0.getUTCMilliseconds();
return $[1604]+$1+$[1227];
},
__convertMap:function($0){var $1=[],
$2=true,
$3,
$4;
var $5=qx.io.Json.__beautify;
$1.push($[313]);
if($5){qx.io.Json.__indent+=qx.io.Json.BEAUTIFYING_INDENT;
$1.push(qx.io.Json.__indent);
}
for(var $6 in $0){$4=$0[$6];
$3=this.__map[typeof $4];
if($3){$4=this[$3]($4);
if(typeof $4==$[8]){if(!$2){$1.push($[17]);
if($5){$1.push(qx.io.Json.__indent);
}}$1.push(this.__convertString($6),
$[50],
$4);
$2=false;
}}}
if($5){qx.io.Json.__indent=qx.io.Json.__indent.substring(0,
qx.io.Json.__indent.length-qx.io.Json.BEAUTIFYING_INDENT.length);
$1.push(qx.io.Json.__indent);
}$1.push($[199]);
return $1.join($[0]);
},
__convertObject:function($0){if($0){var $1=$0.constructor.name;
if($0 instanceof Array||$1==$[467]){return this.__convertArray($0);
}else if($0 instanceof Date||$1==$[1711]){return this.__convertDate($0);
}else if($0 instanceof Object||$1==$[97]){return this.__convertMap($0);
}return $[0];
}return $[345];
},
__convertUndefined:function($0){if(qx.core.Setting.get($[1620])){return $[345];
}},
stringify:function($0,
$1){this.__beautify=$1;
this.__indent=this.BEAUTIFYING_LINE_END;
var $2=this[this.__map[typeof $0]]($0);
if(typeof $2!=$[8]){$2=null;
}if(qx.core.Setting.get($[474])){qx.log.Logger.getClassLogger(qx.io.Json).debug("JSON request: "+$2);
}return $2;
},
parse:function($0){if(!(/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test($0.replace(/"(\\.|[^"\\])*"/g,
$[0])))){throw new Error("Could not parse JSON string!");
}
try{return eval($[100]+$0+$[44]);
}catch(ex){throw new Error("Could not evaluate JSON string: "+ex.message);
}},
parseQx:function($0){if(qx.core.Setting.get($[474])){qx.log.Logger.getClassLogger(qx.io.Json).debug("JSON response: "+$0);
}var $1=($0&&$0.length>0)?eval($[584]+$0+$[254]):null;
return $1;
}},
settings:{"qx.jsonEncodeUndefined":true,
"qx.jsonDebugging":false}});




/* ID: qx.io.remote.IframeTransport */
qx.Class.define($[320],
{extend:qx.io.remote.AbstractRemoteTransport,
construct:function(){arguments.callee.base.call(this);
var $0=(new Date).valueOf();
var $1=$[1507]+$0;
var $2=$[1385]+$0;
if(qx.core.Variant.isSet($[1],
$[20])){this._frame=document.createElement($[976]+$1+$[1893]);
}else{this._frame=document.createElement($[334]);
}this._frame.src=$[654];
this._frame.id=this._frame.name=$1;
this._frame.onload=qx.lang.Function.bind(this._onload,
this);
this._frame.style.display=$[11];
document.body.appendChild(this._frame);
this._form=document.createElement($[761]);
this._form.target=$1;
this._form.id=this._form.name=$2;
this._form.style.display=$[11];
document.body.appendChild(this._form);
this._data=document.createElement($[311]);
this._data.id=this._data.name=$[814];
this._form.appendChild(this._data);
this._frame.onreadystatechange=qx.lang.Function.bind(this._onreadystatechange,
this);
},
statics:{handles:{synchronous:false,
asynchronous:true,
crossDomain:false,
fileUpload:true,
programaticFormFields:true,
responseTypes:[qx.util.Mime.TEXT,
qx.util.Mime.JAVASCRIPT,
qx.util.Mime.JSON,
qx.util.Mime.XML,
qx.util.Mime.HTML]},
isSupported:function(){return true;
},
_numericMap:{"uninitialized":1,
"loading":2,
"loaded":2,
"interactive":3,
"complete":4}},
members:{_lastReadyState:0,
send:function(){var $0=this.getMethod();
var $1=this.getUrl();
var $2=this.getParameters();
var $3=[];
for(var $4 in $2){var $5=$2[$4];
if($5 instanceof Array){for(var $6=0;$6<$5.length;$6++){$3.push(encodeURIComponent($4)+$[33]+encodeURIComponent($5[$6]));
}}else{$3.push(encodeURIComponent($4)+$[33]+encodeURIComponent($5));
}}
if($3.length>0){$1+=($1.indexOf($[149])>=0?$[60]:$[149])+$3.join($[60]);
}var $7=this.getFormFields();
for(var $4 in $7){var $8=document.createElement($[311]);
$8.name=$4;
$8.appendChild(document.createTextNode($7[$4]));
this._form.appendChild($8);
}this._form.action=$1;
this._form.method=$0;
this._data.appendChild(document.createTextNode(this.getData()));
this._form.submit();
this.setState($[36]);
},
_onload:function($0){if(this._form.src){return;
}this._switchReadyState(qx.io.remote.IframeTransport._numericMap.complete);
},
_onreadystatechange:function($0){this._switchReadyState(qx.io.remote.IframeTransport._numericMap[this._frame.readyState]);
},
_switchReadyState:function($0){switch(this.getState()){case $[16]:case $[28]:case $[19]:case $[29]:this.warn("Ignore Ready State Change");
return;
}while(this._lastReadyState<$0){this.setState(qx.io.remote.Exchange._nativeMap[++this._lastReadyState]);
}},
setRequestHeader:function($0,
$1){},
getResponseHeader:function($0){return null;
},
getResponseHeaders:function(){return {};
},
getStatusCode:function(){return 200;
},
getStatusText:function(){return $[0];
},
getIframeWindow:function(){return qx.html.Iframe.getWindow(this._frame);
},
getIframeDocument:function(){return qx.html.Iframe.getDocument(this._frame);
},
getIframeBody:function(){return qx.html.Iframe.getBody(this._frame);
},
getIframeTextContent:function(){var $0=this.getIframeBody();
if(!$0){return null;
}
if(!$0.firstChild){return $[0];
}if($0.firstChild.tagName&&$0.firstChild.tagName.toLowerCase()==$[651]){return $0.firstChild.innerHTML;
}else{return $0.innerHTML;
}},
getIframeHtmlContent:function(){var $0=this.getIframeBody();
return $0?$0.innerHTML:null;
},
getFetchedLength:function(){return 0;
},
getResponseContent:function(){if(this.getState()!==$[16]){{};
return null;
}{};
var $0=this.getIframeTextContent();
switch(this.getResponseType()){case qx.util.Mime.TEXT:{};
return $0;
break;
case qx.util.Mime.HTML:$0=this.getIframeHtmlContent();
{};
return $0();
break;
case qx.util.Mime.JSON:$0=this.getIframeHtmlContent();
{};
try{return $0&&$0.length>0?qx.io.Json.parseQx($0):null;
}catch(ex){return this.error("Could not execute json: ("+$0+")",
ex);
}case qx.util.Mime.JAVASCRIPT:$0=this.getIframeHtmlContent();
{};
try{return $0&&$0.length>0?window.eval($0):null;
}catch(ex){return this.error("Could not execute javascript: ("+$0+")",
ex);
}case qx.util.Mime.XML:$0=this.getIframeDocument();
{};
return $0;
default:this.warn("No valid responseType specified ("+this.getResponseType()+")!");
return null;
}}},
defer:function($0,
$1,
$2){qx.io.remote.Exchange.registerType(qx.io.remote.IframeTransport,
$[320]);
},
destruct:function(){if(this._frame){this._frame.onload=null;
this._frame.onreadystatechange=null;
if(qx.core.Variant.isSet($[1],
$[25])){this._frame.src=qx.io.Alias.getInstance().resolve($[204]);
}document.body.removeChild(this._frame);
}
if(this._form){document.body.removeChild(this._form);
}this._disposeFields($[592],
$[1878]);
}});




/* ID: qx.html.Iframe */
qx.Class.define($[1644],
{statics:{getWindow:qx.core.Variant.select($[1],
{"mshtml":function($0){try{return $0.contentWindow;
}catch(ex){return null;
}},
"default":function($0){try{var $1=qx.html.Iframe.getDocument($0);
return $1?$1.defaultView:null;
}catch(ex){return null;
}}}),
getDocument:qx.core.Variant.select($[1],
{"mshtml":function($0){try{var $1=qx.html.Iframe.getWindow($0);
return $1?$1.document:null;
}catch(ex){return null;
}},
"default":function($0){try{return $0.contentDocument;
}catch(ex){return null;
}}}),
getBody:function($0){var $1=qx.html.Iframe.getDocument($0);
return $1?$1.getElementsByTagName($[137])[0]:null;
}}});




/* ID: qx.io.remote.ScriptTransport */
qx.Class.define($[312],
{extend:qx.io.remote.AbstractRemoteTransport,
construct:function(){arguments.callee.base.call(this);
var $0=++qx.io.remote.ScriptTransport._uniqueId;
if($0>=2000000000){qx.io.remote.ScriptTransport._uniqueId=$0=1;
}this._element=null;
this._uniqueId=$0;
},
statics:{_uniqueId:0,
_instanceRegistry:{},
ScriptTransport_PREFIX:$[1763],
ScriptTransport_ID_PARAM:$[2046],
ScriptTransport_DATA_PARAM:$[690],
handles:{synchronous:false,
asynchronous:true,
crossDomain:true,
fileUpload:false,
programaticFormFields:false,
responseTypes:[qx.util.Mime.TEXT,
qx.util.Mime.JAVASCRIPT,
qx.util.Mime.JSON]},
isSupported:function(){return true;
},
_numericMap:{"uninitialized":1,
"loading":2,
"loaded":2,
"interactive":3,
"complete":4},
_requestFinished:function($0,
$1){var $2=qx.io.remote.ScriptTransport._instanceRegistry[$0];
if($2==null){{};
}else{$2._responseContent=$1;
$2._switchReadyState(qx.io.remote.ScriptTransport._numericMap.complete);
}}},
members:{_lastReadyState:0,
send:function(){var $0=this.getUrl();
$0+=($0.indexOf($[149])>=0?$[60]:$[149])+qx.io.remote.ScriptTransport.ScriptTransport_ID_PARAM+$[33]+this._uniqueId;
var $1=this.getParameters();
var $2=[];
for(var $3 in $1){if($3.indexOf(qx.io.remote.ScriptTransport.ScriptTransport_PREFIX)==0){this.error("Illegal parameter name. The following prefix is used internally by qooxdoo): "+qx.io.remote.ScriptTransport.ScriptTransport_PREFIX);
}var $4=$1[$3];
if($4 instanceof Array){for(var $5=0;$5<$4.length;$5++){$2.push(encodeURIComponent($3)+$[33]+encodeURIComponent($4[$5]));
}}else{$2.push(encodeURIComponent($3)+$[33]+encodeURIComponent($4));
}}
if($2.length>0){$0+=$[60]+$2.join($[60]);
}vData=this.getData();
if(vData!=null){$0+=$[60]+qx.io.remote.ScriptTransport.ScriptTransport_DATA_PARAM+$[33]+encodeURIComponent(vData);
}qx.io.remote.ScriptTransport._instanceRegistry[this._uniqueId]=this;
this._element=document.createElement($[839]);
this._element.charset=$[1669];
this._element.src=$0;
{};
document.body.appendChild(this._element);
},
_switchReadyState:function($0){switch(this.getState()){case $[16]:case $[28]:case $[19]:case $[29]:this.warn("Ignore Ready State Change");
return;
}while(this._lastReadyState<$0){this.setState(qx.io.remote.Exchange._nativeMap[++this._lastReadyState]);
}},
setRequestHeader:function($0,
$1){},
getResponseHeader:function($0){return null;
},
getResponseHeaders:function(){return {};
},
getStatusCode:function(){return 200;
},
getStatusText:function(){return $[0];
},
getFetchedLength:function(){return 0;
},
getResponseContent:function(){if(this.getState()!==$[16]){{};
return null;
}{};
switch(this.getResponseType()){case qx.util.Mime.TEXT:case qx.util.Mime.JSON:case qx.util.Mime.JAVASCRIPT:{};
return this._responseContent||null;
default:this.warn("No valid responseType specified ("+this.getResponseType()+")!");
return null;
}}},
defer:function($0,
$1,
$2){qx.io.remote.Exchange.registerType(qx.io.remote.ScriptTransport,
$[312]);
},
destruct:function(){if(this._element){delete qx.io.remote.ScriptTransport._instanceRegistry[this._uniqueId];
document.body.removeChild(this._element);
}this._disposeFields($[273]);
}});




/* ID: Tr.Server */
qx.Class.define($[1257],
{extend:qx.io.remote.Rpc,
type:$[24],
construct:function($0){with(this){base(arguments);
setTimeout(7000000);
setUrl($[587]);
setServiceName($[1822]);
setCrossDomain(true);
}return this;
},
members:{getBaseUrl:function(){return this.__base_url;
},
setLocalUrl:function($0){if(document.location.host===$[263]){with(this){setUrl($0+$[587]);
}}}}});




/* ID: qx.ui.layout.BoxLayout */
qx.Class.define($[878],
{extend:qx.ui.core.Parent,
construct:function($0){arguments.callee.base.call(this);
if($0!=null){this.setOrientation($0);
}else{this.initOrientation();
}},
statics:{STR_REVERSED:"-reversed"},
properties:{orientation:{check:[$[167],
$[178]],
init:$[167],
apply:$[1791],
event:$[2032]},
spacing:{check:$[6],
init:0,
themeable:true,
apply:$[705],
event:$[1802]},
horizontalChildrenAlign:{check:[$[13],
$[52],
$[14]],
init:$[13],
themeable:true,
apply:$[1292]},
verticalChildrenAlign:{check:[$[23],
$[30],
$[22]],
init:$[23],
themeable:true,
apply:$[1209]},
reverseChildrenOrder:{check:$[2],
init:false,
apply:$[1978]},
stretchChildrenOrthogonalAxis:{check:$[2],
init:true,
apply:$[930]},
useAdvancedFlexAllocation:{check:$[2],
init:false,
apply:$[1826]},
accumulatedChildrenOuterWidth:{_cached:true,
defaultValue:null},
accumulatedChildrenOuterHeight:{_cached:true,
defaultValue:null}},
members:{_createLayoutImpl:function(){return this.getOrientation()==$[178]?new qx.ui.layout.impl.VerticalBoxLayoutImpl(this):new qx.ui.layout.impl.HorizontalBoxLayoutImpl(this);
},
_layoutHorizontal:false,
_layoutVertical:false,
_layoutMode:$[13],
isHorizontal:function(){return this._layoutHorizontal;
},
isVertical:function(){return this._layoutVertical;
},
getLayoutMode:function(){if(this._layoutMode==null){this._updateLayoutMode();
}return this._layoutMode;
},
_updateLayoutMode:function(){this._layoutMode=this._layoutVertical?this.getVerticalChildrenAlign():this.getHorizontalChildrenAlign();
if(this.getReverseChildrenOrder()){this._layoutMode+=qx.ui.layout.BoxLayout.STR_REVERSED;
}},
_invalidateLayoutMode:function(){this._layoutMode=null;
},
_applyOrientation:function($0,
$1){this._layoutHorizontal=$0==$[167];
this._layoutVertical=$0==$[178];
if(this._layoutImpl){this._layoutImpl.dispose();
this._layoutImpl=null;
}
if($0){this._layoutImpl=this._createLayoutImpl();
}this._doLayoutOrder($0,
$1);
this.addToQueueRuntime($[1607]);
},
_applySpacing:function($0,
$1){this._doLayout();
this.addToQueueRuntime($[1903]);
},
_applyHorizontalChildrenAlign:function($0,
$1){this._doLayoutOrder();
this.addToQueueRuntime($[1731]);
},
_applyVerticalChildrenAlign:function($0,
$1){this._doLayoutOrder();
this.addToQueueRuntime($[1447]);
},
_applyReverseChildrenOrder:function($0,
$1){this._doLayoutOrder();
this.addToQueueRuntime($[1045]);
},
_applyStretchChildrenOrthogonalAxis:function($0,
$1){this.addToQueueRuntime($[1760]);
},
_applyUseAdvancedFlexAllocation:function($0,
$1){this.addToQueueRuntime($[2029]);
},
_doLayoutOrder:function(){this._invalidateLayoutMode();
this._doLayout();
},
_doLayout:function(){this._invalidatePreferredInnerDimensions();
this._invalidateAccumulatedChildrenOuterWidth();
this._invalidateAccumulatedChildrenOuterHeight();
},
_computeAccumulatedChildrenOuterWidth:function(){var $0=this.getVisibleChildren(),
$1,
$2=-1,
$3=this.getSpacing(),
$4=-$3;
while($1=$0[++$2]){$4+=$1.getOuterWidth()+$3;
}return $4;
},
_computeAccumulatedChildrenOuterHeight:function(){var $0=this.getVisibleChildren(),
$1,
$2=-1,
$3=this.getSpacing(),
$4=-$3;
while($1=$0[++$2]){$4+=$1.getOuterHeight()+$3;
}return $4;
},
_recomputeChildrenStretchingX:function(){var $0=this.getVisibleChildren(),
$1,
$2=-1;
while($1=$0[++$2]){if($1._recomputeStretchingX()&&$1._recomputeBoxWidth()){$1._recomputeOuterWidth();
}}},
_recomputeChildrenStretchingY:function(){var $0=this.getVisibleChildren(),
$1,
$2=-1;
while($1=$0[++$2]){if($1._recomputeStretchingY()&&$1._recomputeBoxHeight()){$1._recomputeOuterHeight();
}}}}});




/* ID: qx.ui.layout.impl.VerticalBoxLayoutImpl */
qx.Class.define($[1035],
{extend:qx.ui.layout.impl.LayoutImpl,
properties:{enableFlexSupport:{check:$[2],
init:true}},
members:{computeChildBoxWidth:function($0){if(this.getWidget().getStretchChildrenOrthogonalAxis()&&$0._computedWidthTypeNull&&$0.getAllowStretchX()){return this.getWidget().getInnerWidth();
}return $0.getWidthValue()||$0._computeBoxWidthFallback();
},
computeChildBoxHeight:function($0){return $0.getHeightValue()||$0._computeBoxHeightFallback();
},
computeChildrenFlexHeight:function(){if(this._childrenFlexHeightComputed||!this.getEnableFlexSupport()){return;
}this._childrenFlexHeightComputed=true;
var $0=this.getWidget();
var $1=$0.getVisibleChildren();
var $2=$1.length;
var $3;
var $4=[];
var $5=$0.getInnerHeight();
var $6=$0.getSpacing()*($2-1);
var $7;
for($7=0;$7<$2;$7++){$3=$1[$7];
if($3._computedHeightTypeFlex){$4.push($3);
if($0._computedHeightTypeAuto){$6+=$3.getPreferredBoxHeight();
}}else{$6+=$3.getOuterHeight();
}}var $8=$5-$6;
var $9=$4.length;
var $a=0;
for($7=0;$7<$9;$7++){$a+=$4[$7]._computedHeightParsed;
}var $b=$8/$a;
if(!$0.getUseAdvancedFlexAllocation()){for($7=0;$7<$9;$7++){$3=$4[$7];
$3._computedHeightFlexValue=Math.round($3._computedHeightParsed*$b);
$6+=$3._computedHeightFlexValue;
}}else{var $c=0;
var $d,
$9,
$e,
$f,
$g,
$h;
for($7=0;$7<$9;$7++){$3=$4[$7];
$h=$3._computedHeightFlexValue=$3._computedHeightParsed*$b;
$c+=$h-qx.lang.Number.limit($h,
$3.getMinHeightValue(),
$3.getMaxHeightValue());
}$c=Math.round($c);
if($c==0){for($7=0;$7<$9;$7++){$3=$4[$7];
$3._computedHeightFlexValue=Math.round($3._computedHeightFlexValue);
$6+=$3._computedHeightFlexValue;
}}else{var $i=$c>0;
for($7=$9-1;$7>=0;$7--){$3=$4[$7];
if($i){$e=($3.getMaxHeightValue()||Infinity)-$3._computedHeightFlexValue;
if($e>0){$3._allocationLoops=Math.floor($e/$3._computedHeightParsed);
}else{qx.lang.Array.removeAt($4,
$7);
$3._computedHeightFlexValue=Math.round($3._computedHeightFlexValue);
$6+=Math.round($3._computedHeightFlexValue+$e);
}}else{$e=qx.util.Validation.isValidNumber($3.getMinHeightValue())?$3._computedHeightFlexValue-$3.getMinHeightValue():$3._computedHeightFlexValue;
if($e>0){$3._allocationLoops=Math.floor($e/$3._computedHeightParsed);
}else{qx.lang.Array.removeAt($4,
$7);
$3._computedHeightFlexValue=Math.round($3._computedHeightFlexValue);
$6+=Math.round($3._computedHeightFlexValue-$e);
}}}while($c!=0&&$9>0){$9=$4.length;
$d=Infinity;
$g=0;
for($7=0;$7<$9;$7++){$d=Math.min($d,
$4[$7]._allocationLoops);
$g+=$4[$7]._computedHeightParsed;
}$f=Math.min($g*$d,
$c);
$c-=$f;
for($7=$9-1;$7>=0;$7--){$3=$4[$7];
$3._computedHeightFlexValue+=$f/$g*$3._computedHeightParsed;
if($3._allocationLoops==$d){$3._computedHeightFlexValue=Math.round($3._computedHeightFlexValue);
$6+=$3._computedHeightFlexValue;
delete $3._allocationLoops;
qx.lang.Array.removeAt($4,
$7);
}else{if($c==0){$3._computedHeightFlexValue=Math.round($3._computedHeightFlexValue);
$6+=$3._computedHeightFlexValue;
delete $3._allocationLoops;
}else{$3._allocationLoops-=$d;
}}}}}}$3._computedHeightFlexValue+=$5-$6;
},
invalidateChildrenFlexHeight:function(){delete this._childrenFlexHeightComputed;
},
computeChildrenNeededHeight:function(){var $0=this.getWidget();
return qx.ui.layout.impl.LayoutImpl.prototype.computeChildrenNeededHeight_sum.call(this)+(($0.getVisibleChildrenLength()-1)*$0.getSpacing());
},
updateSelfOnChildOuterHeightChange:function($0){this.getWidget()._invalidateAccumulatedChildrenOuterHeight();
},
updateChildOnInnerWidthChange:function($0){var $1=$0._recomputePercentX();
var $2=$0._recomputeStretchingX();
if(($0.getHorizontalAlign()||this.getWidget().getHorizontalChildrenAlign())==$[52]){$0.addToLayoutChanges($[107]);
}return $1||$2;
},
updateChildOnInnerHeightChange:function($0){if(this.getWidget().getVerticalChildrenAlign()==$[30]){$0.addToLayoutChanges($[123]);
}var $1=$0._recomputePercentY();
var $2=$0._recomputeFlexY();
return $1||$2;
},
updateSelfOnJobQueueFlush:function($0){if($0.addChild||$0.removeChild){this.getWidget()._invalidateAccumulatedChildrenOuterHeight();
}},
updateChildrenOnJobQueueFlush:function($0){var $1=false,
$2=false;
var $3=this.getWidget();
if($0.orientation){$1=$2=true;
}if($0.spacing||$0.orientation||$0.reverseChildrenOrder||$0.verticalChildrenAlign){$3._addChildrenToLayoutQueue($[123]);
}
if($0.horizontalChildrenAlign){$3._addChildrenToLayoutQueue($[107]);
}
if($0.stretchChildrenOrthogonalAxis){$1=true;
}if($1){$3._recomputeChildrenStretchingX();
$3._addChildrenToLayoutQueue($[26]);
}
if($2){$3._recomputeChildrenStretchingY();
$3._addChildrenToLayoutQueue($[32]);
}return true;
},
updateChildrenOnRemoveChild:function($0,
$1){var $2=this.getWidget(),
$3=$2.getVisibleChildren(),
$4=$3.length,
$5,
$6=-1;
if(this.getEnableFlexSupport()){for(var $6=0;$6<$4;$6++){$5=$3[$6];
if($5.getHasFlexY()){$1=Math.min($1,
$6);
break;
}}$6=-1;
}switch($2.getLayoutMode()){case $[22]:case $[240]:while(($5=$3[++$6])&&$6<$1){$5.addToLayoutChanges($[123]);
}break;
case $[30]:case $[234]:while($5=$3[++$6]){$5.addToLayoutChanges($[123]);
}break;
default:$6+=$1;
while($5=$3[++$6]){$5.addToLayoutChanges($[123]);
}}},
updateChildrenOnMoveChild:function($0,
$1,
$2){var $3=this.getWidget().getVisibleChildren();
var $4=Math.min($1,
$2);
var $5=Math.max($1,
$2)+1;
for(var $6=$4;$6<$5;$6++){$3[$6].addToLayoutChanges($[123]);
}},
flushChildrenQueue:function($0){var $1=this.getWidget(),
$2=$1.getVisibleChildren(),
$3=$2.length,
$4,
$5;
if(this.getEnableFlexSupport()){this.invalidateChildrenFlexHeight();
for($5=0;$5<$3;$5++){$4=$2[$5];
if($4.getHasFlexY()){$4._computedHeightValue=null;
if($4._recomputeBoxHeight()){$4._recomputeOuterHeight();
$4._recomputeInnerHeight();
}$0[$4.toHashCode()]=$4;
$4._layoutChanges.height=true;
}}}
switch($1.getLayoutMode()){case $[22]:case $[240]:for(var $5=$3-1;$5>=0&&!$0[$2[$5].toHashCode()];$5--){}for(var $6=0;$6<=$5;$6++){$1._layoutChild($4=$2[$6]);
}break;
case $[30]:case $[234]:$5=-1;
while($4=$2[++$5]){$1._layoutChild($4);
}break;
default:$5=-1;
var $7=false;
while($4=$2[++$5]){if($7||$0[$4.toHashCode()]){$1._layoutChild($4);
$7=true;
}}}},
layoutChild:function($0,
$1){this.layoutChild_sizeX($0,
$1);
this.layoutChild_sizeY($0,
$1);
this.layoutChild_sizeLimitX($0,
$1);
this.layoutChild_sizeLimitY($0,
$1);
this.layoutChild_locationX($0,
$1);
this.layoutChild_locationY($0,
$1);
this.layoutChild_marginX($0,
$1);
this.layoutChild_marginY($0,
$1);
},
layoutChild_sizeX:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function($0,
$1){if($1.initial||$1.width||$1.minWidth||$1.maxWidth){if(($0._isWidthEssential()&&(!$0._computedWidthTypeNull||!$0._computedMinWidthTypeNull||!$0._computedMaxWidthTypeNull))||($0.getAllowStretchX()&&this.getWidget().getStretchChildrenOrthogonalAxis())){$0._renderRuntimeWidth($0.getBoxWidth());
}else{$0._resetRuntimeWidth();
}}},
"default":function($0,
$1){if($1.initial||$1.width){if($0._isWidthEssential()&&!$0._computedWidthTypeNull){$0._renderRuntimeWidth($0.getWidthValue());
}else{$0._resetRuntimeWidth();
}}}}),
layoutChild_sizeY:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function($0,
$1){if($1.initial||$1.height||$1.minHeight||$1.maxHeight){if($0._isHeightEssential()&&(!$0._computedHeightTypeNull||!$0._computedMinHeightTypeNull||!$0._computedMaxHeightTypeNull)){$0._renderRuntimeHeight($0.getBoxHeight());
}else{$0._resetRuntimeHeight();
}}},
"default":function($0,
$1){if($1.initial||$1.height){if($0._isHeightEssential()&&!$0._computedHeightTypeNull){$0._renderRuntimeHeight($0.getHeightValue());
}else{$0._resetRuntimeHeight();
}}}}),
layoutChild_locationY:function($0,
$1){var $2=this.getWidget();
if($2.getFirstVisibleChild()==$0){switch($2.getLayoutMode()){case $[22]:case $[240]:var $3=$2.getPaddingBottom()+$2.getAccumulatedChildrenOuterHeight()-$0.getOuterHeight();
break;
case $[30]:case $[234]:var $3=$2.getPaddingTop()+Math.round(($2.getInnerHeight()-$2.getAccumulatedChildrenOuterHeight())/2);
break;
default:var $3=$2.getPaddingTop();
}}else{var $4=$0.getPreviousVisibleSibling();
switch($2.getLayoutMode()){case $[22]:case $[240]:var $3=$4._cachedLocationVertical-$0.getOuterHeight()-$2.getSpacing();
break;
default:var $3=$4._cachedLocationVertical+$4.getOuterHeight()+$2.getSpacing();
}}$0._cachedLocationVertical=$3;
switch(this.getWidget().getLayoutMode()){case $[22]:case $[1484]:case $[234]:$3+=!$0._computedBottomTypeNull?$0.getBottomValue():!$0._computedTopTypeNull?-($0.getTopValue()):0;
$0._resetRuntimeTop();
$0._renderRuntimeBottom($3);
break;
default:$3+=!$0._computedTopTypeNull?$0.getTopValue():!$0._computedBottomTypeNull?-($0.getBottomValue()):0;
$0._resetRuntimeBottom();
$0._renderRuntimeTop($3);
}},
layoutChild_locationX:function($0,
$1){var $2=this.getWidget();
if(qx.core.Variant.isSet($[1],
$[25])){if($0.getAllowStretchX()&&$2.getStretchChildrenOrthogonalAxis()&&$0._computedWidthTypeNull){$0._renderRuntimeLeft($2.getPaddingLeft()||0);
$0._renderRuntimeRight($2.getPaddingRight()||0);
return;
}}var $3=$0.getHorizontalAlign()||$2.getHorizontalChildrenAlign();
var $4=$3==$[52]?Math.round(($2.getInnerWidth()-$0.getOuterWidth())/2):0;
if($3==$[14]){$4+=$2.getPaddingRight();
if(!$0._computedRightTypeNull){$4+=$0.getRightValue();
}else if(!$0._computedLeftTypeNull){$4-=$0.getLeftValue();
}$0._resetRuntimeLeft();
$0._renderRuntimeRight($4);
}else{$4+=$2.getPaddingLeft();
if(!$0._computedLeftTypeNull){$4+=$0.getLeftValue();
}else if(!$0._computedRightTypeNull){$4-=$0.getRightValue();
}$0._resetRuntimeRight();
$0._renderRuntimeLeft($4);
}}}});




/* ID: qx.util.Validation */
qx.Class.define($[1724],
{statics:{isValid:function($0){switch(typeof $0){case $[7]:return false;
case $[38]:return $0!==null;
case $[8]:return $0!==$[0];
case $[54]:return !isNaN($0);
case $[51]:case $[62]:return true;
}return false;
},
isInvalid:function($0){switch(typeof $0){case $[7]:return true;
case $[38]:return $0===null;
case $[8]:return $0===$[0];
case $[54]:return isNaN($0);
case $[51]:case $[62]:return false;
}return true;
},
isValidNumber:function($0){return typeof $0===$[54]&&!isNaN($0);
},
isInvalidNumber:function($0){return typeof $0!==$[54]||isNaN($0);
},
isValidString:function($0){return typeof $0===$[8]&&$0!==$[0];
},
isInvalidString:function($0){return typeof $0!==$[8]||$0===$[0];
},
isValidArray:function($0){return typeof $0===$[38]&&$0!==null&&$0 instanceof Array;
},
isInvalidArray:function($0){return typeof $0!==$[38]||$0===null||!($0 instanceof Array);
},
isValidObject:function($0){return typeof $0===$[38]&&$0!==null&&!($0 instanceof Array);
},
isInvalidObject:function($0){return typeof $0!==$[38]||$0===null||$0 instanceof Array;
},
isValidNode:function($0){return typeof $0===$[38]&&$0!==null;
},
isInvalidNode:function($0){return typeof $0!==$[38]||$0===null;
},
isValidElement:function($0){return typeof $0===$[38]&&$0!==null||$0.nodeType!==1;
},
isInvalidElement:function($0){return typeof $0!==$[38]||$0===null||$0.nodeType!==1;
},
isValidFunction:function($0){return typeof $0===$[51];
},
isInvalidFunction:function($0){return typeof $0!==$[51];
},
isValidBoolean:function($0){return typeof $0===$[62];
},
isInvalidBoolean:function($0){return typeof $0!==$[62];
},
isValidStringOrNumber:function($0){switch(typeof $0){case $[8]:return $0!==$[0];
case $[54]:return !isNaN($0);
}return false;
},
isInvalidStringOrNumber:function($0){switch(typeof $0){case $[8]:return $0===$[0];
case $[54]:return isNaN($0);
}return false;
}}});




/* ID: qx.ui.layout.impl.HorizontalBoxLayoutImpl */
qx.Class.define($[1659],
{extend:qx.ui.layout.impl.LayoutImpl,
properties:{enableFlexSupport:{check:$[2],
init:true}},
members:{computeChildBoxWidth:function($0){return $0.getWidthValue()||$0._computeBoxWidthFallback();
},
computeChildBoxHeight:function($0){if(this.getWidget().getStretchChildrenOrthogonalAxis()&&$0._computedHeightTypeNull&&$0.getAllowStretchY()){return this.getWidget().getInnerHeight();
}return $0.getHeightValue()||$0._computeBoxHeightFallback();
},
computeChildrenFlexWidth:function(){if(this._childrenFlexWidthComputed||!this.getEnableFlexSupport()){return;
}this._childrenFlexWidthComputed=true;
var $0=this.getWidget();
var $1=$0.getVisibleChildren();
var $2=$1.length;
var $3;
var $4=[];
var $5=$0.getInnerWidth();
var $6=$0.getSpacing()*($2-1);
var $7;
for($7=0;$7<$2;$7++){$3=$1[$7];
if($3._computedWidthTypeFlex){$4.push($3);
if($0._computedWidthTypeAuto){$6+=$3.getPreferredBoxWidth();
}}else{$6+=$3.getOuterWidth();
}}var $8=$5-$6;
var $9=$4.length;
var $a=0;
for($7=0;$7<$9;$7++){$a+=$4[$7]._computedWidthParsed;
}var $b=$8/$a;
if(!$0.getUseAdvancedFlexAllocation()){for($7=0;$7<$9;$7++){$3=$4[$7];
$3._computedWidthFlexValue=Math.round($3._computedWidthParsed*$b);
$6+=$3._computedWidthFlexValue;
}}else{var $c=0;
var $d,
$9,
$e,
$f,
$g,
$h;
for($7=0;$7<$9;$7++){$3=$4[$7];
$h=$3._computedWidthFlexValue=$3._computedWidthParsed*$b;
$c+=$h-qx.lang.Number.limit($h,
$3.getMinWidthValue(),
$3.getMaxWidthValue());
}$c=Math.round($c);
if($c==0){for($7=0;$7<$9;$7++){$3=$4[$7];
$3._computedWidthFlexValue=Math.round($3._computedWidthFlexValue);
$6+=$3._computedWidthFlexValue;
}}else{var $i=$c>0;
for($7=$9-1;$7>=0;$7--){$3=$4[$7];
if($i){$e=($3.getMaxWidthValue()||Infinity)-$3._computedWidthFlexValue;
if($e>0){$3._allocationLoops=Math.floor($e/$3._computedWidthParsed);
}else{qx.lang.Array.removeAt($4,
$7);
$3._computedWidthFlexValue=Math.round($3._computedWidthFlexValue);
$6+=Math.round($3._computedWidthFlexValue+$e);
}}else{$e=qx.util.Validation.isValidNumber($3.getMinWidthValue())?$3._computedWidthFlexValue-$3.getMinWidthValue():$3._computedWidthFlexValue;
if($e>0){$3._allocationLoops=Math.floor($e/$3._computedWidthParsed);
}else{qx.lang.Array.removeAt($4,
$7);
$3._computedWidthFlexValue=Math.round($3._computedWidthFlexValue);
$6+=Math.round($3._computedWidthFlexValue-$e);
}}}while($c!=0&&$9>0){$9=$4.length;
$d=Infinity;
$g=0;
for($7=0;$7<$9;$7++){$d=Math.min($d,
$4[$7]._allocationLoops);
$g+=$4[$7]._computedWidthParsed;
}$f=Math.min($g*$d,
$c);
$c-=$f;
for($7=$9-1;$7>=0;$7--){$3=$4[$7];
$3._computedWidthFlexValue+=$f/$g*$3._computedWidthParsed;
if($3._allocationLoops==$d){$3._computedWidthFlexValue=Math.round($3._computedWidthFlexValue);
$6+=$3._computedWidthFlexValue;
delete $3._allocationLoops;
qx.lang.Array.removeAt($4,
$7);
}else{if($c==0){$3._computedWidthFlexValue=Math.round($3._computedWidthFlexValue);
$6+=$3._computedWidthFlexValue;
delete $3._allocationLoops;
}else{$3._allocationLoops-=$d;
}}}}}}$3._computedWidthFlexValue+=$5-$6;
},
invalidateChildrenFlexWidth:function(){delete this._childrenFlexWidthComputed;
},
computeChildrenNeededWidth:function(){var $0=this.getWidget();
return qx.ui.layout.impl.LayoutImpl.prototype.computeChildrenNeededWidth_sum.call(this)+(($0.getVisibleChildrenLength()-1)*$0.getSpacing());
},
updateSelfOnChildOuterWidthChange:function($0){this.getWidget()._invalidateAccumulatedChildrenOuterWidth();
},
updateChildOnInnerWidthChange:function($0){if(this.getWidget().getHorizontalChildrenAlign()==$[52]){$0.addToLayoutChanges($[107]);
}var $1=$0._recomputePercentX();
var $2=$0._recomputeFlexX();
return $1||$2;
},
updateChildOnInnerHeightChange:function($0){var $1=$0._recomputePercentY();
var $2=$0._recomputeStretchingY();
if(($0.getVerticalAlign()||this.getWidget().getVerticalChildrenAlign())==$[30]){$0.addToLayoutChanges($[123]);
}return $1||$2;
},
updateSelfOnJobQueueFlush:function($0){if($0.addChild||$0.removeChild){this.getWidget()._invalidateAccumulatedChildrenOuterWidth();
}},
updateChildrenOnJobQueueFlush:function($0){var $1=false,
$2=false;
var $3=this.getWidget();
if($0.orientation){$1=$2=true;
}if($0.spacing||$0.orientation||$0.reverseChildrenOrder||$0.horizontalChildrenAlign){$3._addChildrenToLayoutQueue($[107]);
}
if($0.verticalChildrenAlign){$3._addChildrenToLayoutQueue($[123]);
}
if($0.stretchChildrenOrthogonalAxis){$2=true;
}if($1){$3._recomputeChildrenStretchingX();
$3._addChildrenToLayoutQueue($[26]);
}
if($2){$3._recomputeChildrenStretchingY();
$3._addChildrenToLayoutQueue($[32]);
}return true;
},
updateChildrenOnRemoveChild:function($0,
$1){var $2=this.getWidget(),
$3=$2.getVisibleChildren(),
$4=$3.length,
$5,
$6=-1;
if(this.getEnableFlexSupport()){for($6=0;$6<$4;$6++){$5=$3[$6];
if($5.getHasFlexX()){$1=Math.min($1,
$6);
break;
}}$6=-1;
}switch($2.getLayoutMode()){case $[14]:case $[231]:while(($5=$3[++$6])&&$6<$1){$5.addToLayoutChanges($[107]);
}break;
case $[52]:case $[249]:while($5=$3[++$6]){$5.addToLayoutChanges($[107]);
}break;
default:$6+=$1;
while($5=$3[++$6]){$5.addToLayoutChanges($[107]);
}}},
updateChildrenOnMoveChild:function($0,
$1,
$2){var $3=this.getWidget().getVisibleChildren();
var $4=Math.min($1,
$2);
var $5=Math.max($1,
$2)+1;
for(var $6=$4;$6<$5;$6++){$3[$6].addToLayoutChanges($[107]);
}},
flushChildrenQueue:function($0){var $1=this.getWidget(),
$2=$1.getVisibleChildren(),
$3=$2.length,
$4,
$5;
if(this.getEnableFlexSupport()){this.invalidateChildrenFlexWidth();
for($5=0;$5<$3;$5++){$4=$2[$5];
if($4.getHasFlexX()){$4._computedWidthValue=null;
if($4._recomputeBoxWidth()){$4._recomputeOuterWidth();
$4._recomputeInnerWidth();
}$0[$4.toHashCode()]=$4;
$4._layoutChanges.width=true;
}}}
switch($1.getLayoutMode()){case $[14]:case $[231]:for(var $5=$3-1;$5>=0&&!$0[$2[$5].toHashCode()];$5--){}for(var $6=0;$6<=$5;$6++){$1._layoutChild($4=$2[$6]);
}break;
case $[52]:case $[249]:$5=-1;
while($4=$2[++$5]){$1._layoutChild($4);
}break;
default:$5=-1;
var $7=false;
while($4=$2[++$5]){if($7||$0[$4.toHashCode()]){$1._layoutChild($4);
$7=true;
}}}},
layoutChild:function($0,
$1){this.layoutChild_sizeX($0,
$1);
this.layoutChild_sizeY($0,
$1);
this.layoutChild_sizeLimitX($0,
$1);
this.layoutChild_sizeLimitY($0,
$1);
this.layoutChild_locationX($0,
$1);
this.layoutChild_locationY($0,
$1);
this.layoutChild_marginX($0,
$1);
this.layoutChild_marginY($0,
$1);
},
layoutChild_sizeX:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function($0,
$1){if($1.initial||$1.width||$1.minWidth||$1.maxWidth){if($0._isWidthEssential()&&(!$0._computedWidthTypeNull||!$0._computedMinWidthTypeNull||!$0._computedMaxWidthTypeNull)){$0._renderRuntimeWidth($0.getBoxWidth());
}else{$0._resetRuntimeWidth();
}}},
"default":function($0,
$1){if($1.initial||$1.width){if($0._isWidthEssential()&&!$0._computedWidthTypeNull){$0._renderRuntimeWidth($0.getWidthValue());
}else{$0._resetRuntimeWidth();
}}}}),
layoutChild_sizeY:qx.core.Variant.select($[1],
{"mshtml|opera|webkit":function($0,
$1){if($1.initial||$1.height||$1.minHeight||$1.maxHeight){if(($0._isHeightEssential()&&(!$0._computedHeightTypeNull||!$0._computedMinHeightTypeNull||!$0._computedMaxHeightTypeNull))||($0.getAllowStretchY()&&this.getWidget().getStretchChildrenOrthogonalAxis())){$0._renderRuntimeHeight($0.getBoxHeight());
}else{$0._resetRuntimeHeight();
}}},
"default":function($0,
$1){if($1.initial||$1.height){if($0._isHeightEssential()&&!$0._computedHeightTypeNull){$0._renderRuntimeHeight($0.getHeightValue());
}else{$0._resetRuntimeHeight();
}}}}),
layoutChild_locationX:function($0,
$1){var $2=this.getWidget();
if($2.getFirstVisibleChild()==$0){switch($2.getLayoutMode()){case $[14]:case $[231]:var $3=$2.getPaddingRight()+$2.getAccumulatedChildrenOuterWidth()-$0.getOuterWidth();
break;
case $[52]:case $[249]:var $3=$2.getPaddingLeft()+Math.round(($2.getInnerWidth()-$2.getAccumulatedChildrenOuterWidth())/2);
break;
default:var $3=$2.getPaddingLeft();
}}else{var $4=$0.getPreviousVisibleSibling();
switch($2.getLayoutMode()){case $[14]:case $[231]:var $3=$4._cachedLocationHorizontal-$0.getOuterWidth()-$2.getSpacing();
break;
default:var $3=$4._cachedLocationHorizontal+$4.getOuterWidth()+$2.getSpacing();
}}$0._cachedLocationHorizontal=$3;
switch($2.getLayoutMode()){case $[14]:case $[1271]:case $[249]:$3+=!$0._computedRightTypeNull?$0.getRightValue():!$0._computedLeftTypeNull?-($0.getLeftValue()):0;
$0._resetRuntimeLeft();
$0._renderRuntimeRight($3);
break;
default:$3+=!$0._computedLeftTypeNull?$0.getLeftValue():!$0._computedRightTypeNull?-($0.getRightValue()):0;
$0._resetRuntimeRight();
$0._renderRuntimeLeft($3);
}},
layoutChild_locationY:function($0,
$1){var $2=this.getWidget();
if(qx.core.Variant.isSet($[1],
$[25])){if($0.getAllowStretchY()&&$2.getStretchChildrenOrthogonalAxis()&&$0._computedHeightTypeNull){$0._renderRuntimeTop($2.getPaddingTop()||0);
$0._renderRuntimeBottom($2.getPaddingBottom()||0);
return;
}}var $3=$0.getVerticalAlign()||$2.getVerticalChildrenAlign();
var $4=$3==$[30]?Math.round(($2.getInnerHeight()-$0.getOuterHeight())/2):0;
if($3==$[22]){$4+=$2.getPaddingBottom();
if(!$0._computedBottomTypeNull){$4+=$0.getBottomValue();
}else if(!$0._computedTopTypeNull){$4-=$0.getTopValue();
}$0._resetRuntimeTop();
$0._renderRuntimeBottom($4);
}else{$4+=$2.getPaddingTop();
if(!$0._computedTopTypeNull){$4+=$0.getTopValue();
}else if(!$0._computedBottomTypeNull){$4-=$0.getBottomValue();
}$0._resetRuntimeBottom();
$0._renderRuntimeTop($4);
}}}});




/* ID: qx.ui.layout.VerticalBoxLayout */
qx.Class.define($[1990],
{extend:qx.ui.layout.BoxLayout,
properties:{orientation:{refine:true,
init:$[178]}}});




/* ID: qx.ui.layout.HorizontalBoxLayout */
qx.Class.define($[1120],
{extend:qx.ui.layout.BoxLayout});




/* ID: qx.ui.basic.Atom */
qx.Class.define($[1277],
{extend:qx.ui.layout.BoxLayout,
construct:function($0,
$1,
$2,
$3,
$4){arguments.callee.base.call(this);
this.getLayoutImpl().setEnableFlexSupport(false);
if($0!==undefined){this.setLabel($0);
}if(qx.Class.isDefined($[408])&&$4!=null&&$2!=null&&$3!=null&&qx.ui.embed.Flash.getPlayerVersion().getMajor()>0){this._flashMode=true;
this.setIcon($4);
}else if($1!=null){this.setIcon($1);
}
if($1||$4){if($2!=null){this.setIconWidth($2);
}
if($3!=null){this.setIconHeight($3);
}}this.initWidth();
this.initHeight();
},
properties:{orientation:{refine:true,
init:$[167]},
allowStretchX:{refine:true,
init:false},
allowStretchY:{refine:true,
init:false},
appearance:{refine:true,
init:$[1582]},
stretchChildrenOrthogonalAxis:{refine:true,
init:false},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
horizontalChildrenAlign:{refine:true,
init:$[52]},
verticalChildrenAlign:{refine:true,
init:$[30]},
spacing:{refine:true,
init:4},
label:{apply:$[382],
nullable:true,
dispose:true,
check:$[488]},
icon:{check:$[9],
apply:$[287],
nullable:true,
themeable:true},
disabledIcon:{check:$[9],
apply:$[1921],
nullable:true,
themeable:true},
show:{init:$[141],
check:[$[141],
$[180],
$[169],
$[11]],
themeable:true,
nullable:true,
inheritable:true,
apply:$[1519],
event:$[294]},
iconPosition:{init:$[13],
check:[$[23],
$[14],
$[22],
$[13]],
themeable:true,
apply:$[1558]},
iconWidth:{check:$[6],
themeable:true,
apply:$[1241],
nullable:true},
iconHeight:{check:$[6],
themeable:true,
apply:$[1803],
nullable:true}},
members:{_flashMode:false,
_labelObject:null,
_iconObject:null,
_createLabel:function(){var $0=this._labelObject=new qx.ui.basic.Label(this.getLabel());
$0.setAnonymous(true);
$0.setCursor($[43]);
this.addAt($0,
this._iconObject?1:0);
},
_createIcon:function(){if(this._flashMode&&qx.Class.isDefined($[408])){var $0=this._iconObject=new qx.ui.embed.Flash(this.getIcon());
}else{var $0=this._iconObject=new qx.ui.basic.Image();
}$0.setAnonymous(true);
var $1=this.getIconWidth();
if($1!==null){this._iconObject.setWidth($1);
}var $2=this.getIconWidth();
if($2!==null){this._iconObject.setHeight($2);
}this._updateIcon();
this.addAt($0,
0);
},
_updateIcon:function(){var $0=this.getIcon();
if(this._iconObject&&this.getIcon&&this.getDisabledIcon){var $1=this.getDisabledIcon();
if($1){if(this.getEnabled()){$0?this._iconObject.setSource($0):this._iconObject.resetSource();
}else{$1?this._iconObject.setSource($1):this._iconObject.resetSource();
}this._iconObject.setEnabled(true);
}else{$0?this._iconObject.setSource($0):this._iconObject.resetSource();
this._iconObject.resetEnabled();
}}},
getLabelObject:function(){return this._labelObject;
},
getIconObject:function(){return this._iconObject;
},
_applyIconPosition:function($0,
$1){switch($0){case $[23]:case $[22]:this.setOrientation($[178]);
this.setReverseChildrenOrder($0==$[22]);
break;
default:this.setOrientation($[167]);
this.setReverseChildrenOrder($0==$[14]);
break;
}},
_applyShow:function($0,
$1){this._handleIcon();
this._handleLabel();
},
_applyLabel:function($0,
$1){if(this._labelObject){$0?this._labelObject.setText($0):this._labelObject.resetText();
}this._handleLabel();
},
_applyIcon:function($0,
$1){this._updateIcon();
this._handleIcon();
},
_applyDisabledIcon:function($0,
$1){this._updateIcon();
this._handleIcon();
},
_applyIconWidth:function($0,
$1){if(this._iconObject){this._iconObject.setWidth($0);
}},
_applyIconHeight:function($0,
$1){if(this._iconObject){this._iconObject.setHeight($0);
}},
_iconIsVisible:false,
_labelIsVisible:false,
_handleLabel:function(){switch(this.getShow()){case $[180]:case $[141]:case $[127]:this._labelIsVisible=!!this.getLabel();
break;
default:this._labelIsVisible=false;
}
if(this._labelIsVisible){this._labelObject?this._labelObject.setDisplay(true):this._createLabel();
}else if(this._labelObject){this._labelObject.setDisplay(false);
}},
_handleIcon:function(){switch(this.getShow()){case $[169]:case $[141]:case $[127]:this._iconIsVisible=!!this.getIcon();
break;
default:this._iconIsVisible=false;
}
if(this._iconIsVisible){this._iconObject?this._iconObject.setDisplay(true):this._createIcon();
}else if(this._iconObject){this._iconObject.setDisplay(false);
}}},
destruct:function(){this._disposeObjects($[553],
$[348]);
}});




/* ID: qx.ui.basic.Label */
qx.Class.define($[1433],
{extend:qx.ui.basic.Terminator,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
if($2!=null){this.setMode($2);
}
if($0!=null){this.setText($0);
}
if($1!=null){this.setMnemonic($1);
}this.initWidth();
this.initHeight();
this.initSelectable();
this.initCursor();
this.initWrap();
},
statics:{_getMeasureNode:function(){var $0=this._measureNode;
if(!$0){$0=document.createElement($[101]);
var $1=$0.style;
$1.width=$1.height=$[3];
$1.visibility=$[21];
$1.position=$[63];
$1.zIndex=$[1455];
document.body.appendChild($0);
this._measureNode=$0;
}return $0;
}},
properties:{appearance:{refine:true,
init:$[180]},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
allowStretchX:{refine:true,
init:false},
allowStretchY:{refine:true,
init:false},
selectable:{refine:true,
init:false},
cursor:{refine:true,
init:$[43]},
text:{apply:$[270],
init:$[0],
dispose:true,
event:$[868],
check:$[488]},
wrap:{check:$[2],
init:false,
nullable:true,
apply:$[458]},
textAlign:{check:[$[13],
$[52],
$[14],
$[419]],
nullable:true,
themeable:true,
apply:$[515]},
textOverflow:{check:$[2],
init:true,
apply:$[270]},
mode:{check:[$[336],
$[186],
$[3]],
init:$[3],
apply:$[270]},
mnemonic:{check:$[9],
nullable:true,
apply:$[1369]}},
members:{_content:$[0],
_isHtml:false,
setHtml:function($0){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1449]);
this.setText($0);
},
getHtml:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1097]);
return this.getText();
},
_applyTextAlign:function($0,
$1){$0===null?this.removeStyleProperty($[625]):this.setStyleProperty($[625],
$0);
},
_applyFont:function($0,
$1){qx.theme.manager.Font.getInstance().connect(this._styleFont,
this,
$0);
},
_styleFont:function($0){this._invalidatePreferredInnerDimensions();
$0?$0.render(this):qx.ui.core.Font.reset(this);
},
_applyTextColor:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleTextColor,
this,
$0);
},
_styleTextColor:function($0){$0?this.setStyleProperty($[324],
$0):this.removeStyleProperty($[324]);
},
_applyWrap:function($0,
$1){$0==null?this.removeStyleProperty($[468]):this.setStyleProperty($[468],
$0?$[171]:$[700]);
},
_applyText:function($0,
$1){qx.locale.Manager.getInstance().connect(this._syncText,
this,
this.getText());
},
_syncText:function($0){var $1=this.getMode();
if($1===$[3]){$1=qx.util.Validation.isValidString($0)&&$0.match(/<.*>/)?$[336]:$[186];
}
switch($1){case $[186]:var $2=qx.html.String.escape($0).replace(/(^ | $)/g,
$[1396]).replace(/  /g,
$[1203]);
this._isHtml=$2!==$0;
this._content=$2;
break;
case $[336]:this._isHtml=true;
this._content=$0;
break;
}
if(this._isCreated){this._renderContent();
}},
_applyMnemonic:function($0,
$1){this._mnemonicTest=$0?new RegExp($[2004]+$0+$[1450]+$0+$[1344]+$0+$[1962]+$0+$[44],
$[1461]):null;
if(this._isCreated){this._renderContent();
}},
_computeObjectNeededDimensions:function(){var $0=arguments.callee.self._getMeasureNode();
var $1=$0.style;
var $2=this._styleProperties;
$1.fontFamily=$2.fontFamily||$[0];
$1.fontSize=$2.fontSize||$[0];
$1.fontWeight=$2.fontWeight||$[0];
$1.fontStyle=$2.fontStyle||$[0];
if(this._isHtml){$0.innerHTML=this._content;
}else{$0.innerHTML=$[0];
qx.dom.Element.setTextContent($0,
this._content);
}this._cachedPreferredInnerWidth=$0.scrollWidth;
this._cachedPreferredInnerHeight=$0.scrollHeight;
},
_computePreferredInnerWidth:function(){this._computeObjectNeededDimensions();
return this._cachedPreferredInnerWidth;
},
_computePreferredInnerHeight:function(){this._computeObjectNeededDimensions();
return this._cachedPreferredInnerHeight;
},
__patchTextOverflow:function($0,
$1){return ($[1053]+($1-14)+$[681]+$0+$[1367]);
},
_postApply:function(){var $0=this._content;
var $1=this._getTargetNode();
if($0==null){$1.innerHTML=$[0];
return;
}
if(this.getMnemonic()){if(this._mnemonicTest.test($0)){$0=RegExp.$1+$[1028]+RegExp.$7+$[799]+RegExp.rightContext;
this._isHtml=true;
}else{$0+=$[1860]+this.getMnemonic()+$[44];
}}var $2=$1.style;
if(this.getTextOverflow()&&!this.getWrap()){if(this.getInnerWidth()<this.getPreferredInnerWidth()){$2.overflow=$[21];
if(qx.core.Variant.isSet($[1],
$[396])){$2.textOverflow=$[373];
}else if(qx.core.Variant.isSet($[1],
$[142])){$2.OTextOverflow=$[373];
}else{$0=this.__patchTextOverflow($0,
this.getInnerWidth());
this._isHtml=true;
}}else{$2.overflow=$[0];
if(qx.core.Variant.isSet($[1],
$[396])){$2.textOverflow=$[0];
}else if(qx.core.Variant.isSet($[1],
$[142])){$2.OTextOverflow=$[0];
}}}
if(this._isHtml){$1.innerHTML=$0;
}else{$1.innerHTML=$[0];
qx.dom.Element.setTextContent($1,
$0);
}}}});




/* ID: qx.locale.Manager */
qx.Class.define($[797],
{type:$[24],
extend:qx.util.manager.Value,
construct:function(){arguments.callee.base.call(this);
this._translationCatalog={};
this.setLocale(qx.core.Client.getInstance().getLocale()||this._defaultLocale);
},
statics:{tr:function($0,
$1){var $2=qx.lang.Array.fromArguments(arguments);
$2.splice(0,
1);
return new qx.locale.LocalizedString($0,
$2);
},
trn:function($0,
$1,
$2,
$3){var $4=qx.lang.Array.fromArguments(arguments);
$4.splice(0,
3);
if($2>1){return new qx.locale.LocalizedString($1,
$4);
}else{return new qx.locale.LocalizedString($0,
$4);
}},
trc:function($0,
$1,
$2){var $3=qx.lang.Array.fromArguments(arguments);
$3.splice(0,
2);
return new qx.locale.LocalizedString($1,
$3);
},
marktr:function($0){return $0;
}},
properties:{locale:{check:$[9],
nullable:true,
apply:$[688],
event:$[308]}},
members:{_defaultLocale:$[832],
getLanguage:function(){return this._language;
},
getTerritory:function(){return this.getLocale().split($[84])[1]||$[0];
},
getAvailableLocales:function(){var $0=[];
for(var $1 in this._translationCatalog){if($1!=this._defaultLocale){$0.push($1);
}}return $0;
},
_extractLanguage:function($0){var $1;
var $2=$0.indexOf($[84]);
if($2==-1){$1=$0;
}else{$1=$0.substring(0,
$2);
}return $1;
},
_applyLocale:function($0,
$1){this._locale=$0;
var $2=$0.indexOf($[84]);
this._language=this._extractLanguage($0);
this._updateObjects();
},
addTranslation:function($0,
$1){if(this._translationCatalog[$0]){for(var $2 in $1){this._translationCatalog[$0][$2]=$1[$2];
}}else{this._translationCatalog[$0]=$1;
}},
addTranslationFromClass:function($0,
$1){this.addTranslation($0.substring($0.lastIndexOf($[47])+1),
$1);
},
translate:function($0,
$1,
$2){var $3;
if($2){var $4=this._extractLanguage($2);
}else{$2=this._locale;
$4=this._language;
}
if(!$3&&this._translationCatalog[$2]){$3=this._translationCatalog[$2][$0];
}
if(!$3&&this._translationCatalog[$4]){$3=this._translationCatalog[$4][$0];
}
if(!$3&&this._translationCatalog[this._defaultLocale]){$3=this._translationCatalog[this._defaultLocale][$0];
}
if(!$3){$3=$0;
}
if($1.length>0){$3=qx.lang.String.format($3,
$1);
}return $3;
},
isDynamic:function($0){return $0 instanceof qx.locale.LocalizedString;
},
resolveDynamic:function($0){return $0.toString();
}},
destruct:function(){this._disposeFields($[1098]);
}});




/* ID: qx.locale.LocalizedString */
qx.Class.define($[1092],
{extend:qx.core.Object,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
this.setId($0);
this._locale=$2;
var $3=[];
for(var $4=0;$4<$1.length;$4++){var $5=$1[$4];
if($5 instanceof qx.locale.LocalizedString){$3.push($5);
}else{$3.push($5+$[0]);
}}this.setArgs($3);
},
properties:{id:{check:$[9],
nullable:true},
args:{nullable:true,
dispose:true}},
members:{_autoDispose:false,
toString:function(){return qx.locale.Manager.getInstance().translate(this.getId(),
this.getArgs(),
this._locale);
}}});




/* ID: qx.dom.Element */
qx.Class.define($[838],
{statics:{cleanWhitespace:function($0){for(var $1=0;$1<$0.childNodes.length;$1++){var $2=$0.childNodes[$1];
if($2.nodeType==qx.dom.Node.TEXT&&!/\S/.test($2.nodeValue)){$0.removeChild($2);
}}},
isEmpty:function($0){return $0.innerHTML.match(/^\s*$/);
},
getTextContent:qx.lang.Object.select(qx.core.Client.getInstance().supportsTextContent()?$[575]:qx.core.Client.getInstance().supportsInnerText()?$[571]:$[43],
{innerText:function($0){return $0.innerText||$0.text;
},
textContent:function($0){return $0.textContent;
},
"default":function(){throw new Error("This browser does not support any form of text content handling!");
}}),
setTextContent:qx.lang.Object.select(qx.core.Client.getInstance().supportsTextContent()?$[575]:qx.core.Client.getInstance().supportsInnerText()?$[571]:$[43],
{innerText:function($0,
$1){$0.innerText=$1;
},
textContent:function($0,
$1){$0.textContent=$1;
},
"default":function(){throw new Error("This browser does not support any form of text content handling!");
}})}});




/* ID: qx.ui.basic.Image */
qx.Class.define($[905],
{extend:qx.ui.basic.Terminator,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
this._blank=qx.io.Alias.getInstance().resolve($[204]);
if($0!=null){this.setSource($0);
}if($1!=null){this.setWidth($1);
}else{this.initWidth();
}
if($2!=null){this.setHeight($2);
}else{this.initHeight();
}this.initSelectable();
},
events:{"error":$[4]},
properties:{allowStretchX:{refine:true,
init:false},
allowStretchY:{refine:true,
init:false},
selectable:{refine:true,
init:false},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
appearance:{refine:true,
init:$[1247]},
source:{check:$[9],
apply:$[994],
event:$[1150],
nullable:true,
themeable:true},
preloader:{check:$[470],
apply:$[766],
nullable:true},
loaded:{check:$[2],
init:false,
apply:$[1494]},
resizeToInner:{check:$[2],
init:false}},
members:{_onload:function(){this.setLoaded(true);
},
_onerror:function(){this.warn("Could not load: "+this.getSource());
this.setLoaded(false);
if(this.hasEventListeners($[78])){this.dispatchEvent(new qx.event.type.Event($[78]),
true);
}},
_beforeAppear:function(){var $0=this.getSource();
if($0){qx.io.image.Manager.getInstance().show($0);
this._registeredAsVisible=true;
}return arguments.callee.base.call(this);
},
_beforeDisappear:function(){var $0=this.getSource();
if($0&&this._registeredAsVisible){qx.io.image.Manager.getInstance().hide($0);
delete this._registeredAsVisible;
}return arguments.callee.base.call(this);
},
_applySource:function($0,
$1){var $2=qx.io.image.Manager.getInstance();
if($1){$2.remove($1);
if(this._registeredAsVisible){$2.hide($1);
delete this._registeredAsVisible;
}}
if($0){$2.add($0);
if(this.isSeeable()){this._registeredAsVisible=true;
$2.show($0);
}}
if(this.isCreated()){this._connect();
}},
_connect:function(){var $0=qx.io.Alias.getInstance();
$0.connect(this._syncSource,
this,
this.getSource());
},
_syncSource:function($0){if($0===null){this.setPreloader(null);
}else{var $1=qx.io.image.PreloaderManager.getInstance().create($0);
this.setPreloader($1);
}},
_applyPreloader:function($0,
$1){if($1){$1.removeEventListener($[94],
this._onload,
this);
$1.removeEventListener($[78],
this._onerror,
this);
}var $2=qx.io.image.Manager.getInstance();
if($0){this.setLoaded(false);
if($0.isErroneous()){this._onerror();
}else if($0.isLoaded()){this.setLoaded(true);
}else{$0.addEventListener($[94],
this._onload,
this);
$0.addEventListener($[78],
this._onerror,
this);
}}else{this.setLoaded(false);
}},
_applyLoaded:function($0,
$1){if($0&&this.isCreated()){this._renderContent();
}else if(!$0){this._invalidatePreferredInnerWidth();
this._invalidatePreferredInnerHeight();
}},
_applyElement:function($0,
$1){if($0){if(!this._image){try{if(qx.core.Variant.isSet($[1],
$[160])){this._image=document.createElement($[1135]);
}else{this._image=new Image;
}this._image.style.border=$[487];
this._image.style.verticalAlign=$[23];
this._image.alt=$[0];
this._image.title=$[0];
}catch(ex){this.error("Failed while creating image #1",
ex);
}
if(qx.core.Variant.isSet($[1],
$[403])){this._styleEnabled();
}}$0.appendChild(this._image);
}arguments.callee.base.call(this,
$0,
$1);
if($0&&this.getSource()){this._connect();
}},
_postApply:function(){this._postApplyDimensions();
this._updateContent();
},
_applyEnabled:function($0,
$1){if(this._image){this._styleEnabled();
}return arguments.callee.base.call(this,
$0,
$1);
},
_updateContent:qx.core.Variant.select($[1],
{"mshtml":function(){var $0=this._image;
var $1=this.getPreloader();
var $2=$1&&$1.isLoaded()?$1.getSource():this._blank;
if($1&&$1.getIsPng()&&this.getEnabled()){$0.src=this._blank;
$0.style.filter=$[753]+$2+$[1965];
}else{$0.src=$2;
$0.style.filter=this.getEnabled()?$[0]:$[714];
}},
"default":function(){var $0=this.getPreloader();
var $1=$0&&$0.isLoaded()?$0.getSource():this._blank;
this._image.src=$1;
}}),
_resetContent:qx.core.Variant.select($[1],
{"mshtml":function(){this._image.src=this._blank;
this._image.style.filter=$[0];
},
"default":function(){this._image.src=this._blank;
}}),
_styleEnabled:qx.core.Variant.select($[1],
{"mshtml":function(){this._updateContent();
},
"default":function(){if(this._image){var $0=this.getEnabled()===false?0.3:$[0];
var $1=this._image.style;
$1.opacity=$1.KhtmlOpacity=$1.MozOpacity=$0;
}}}),
_computePreferredInnerWidth:function(){var $0=this.getPreloader();
return $0?$0.getWidth():0;
},
_computePreferredInnerHeight:function(){var $0=this.getPreloader();
return $0?$0.getHeight():0;
},
_renderContent:function(){arguments.callee.base.call(this);
qx.ui.core.Widget.flushGlobalQueues();
},
_postApplyDimensions:qx.core.Variant.select($[1],
{"mshtml":function(){try{var $0=this._image.style;
if(this.getResizeToInner()){$0.pixelWidth=this.getInnerWidth();
$0.pixelHeight=this.getInnerHeight();
}else{$0.pixelWidth=this.getPreferredInnerWidth();
$0.pixelHeight=this.getPreferredInnerHeight();
}}catch(ex){this.error("postApplyDimensions failed",
ex);
}},
"default":function(){try{var $0=this._image;
if(this.getResizeToInner()){$0.width=this.getInnerWidth();
$0.height=this.getInnerHeight();
}else{$0.width=this.getPreferredInnerWidth();
$0.height=this.getPreferredInnerHeight();
}}catch(ex){this.error("postApplyDimensions failed",
ex);
}}}),
_changeInnerWidth:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){if(this.getResizeToInner()){this._image.style.pixelWidth=$0;
}},
"default":function($0,
$1){if(this.getResizeToInner()){this._image.width=$0;
}}}),
_changeInnerHeight:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){if(this.getResizeToInner()){this._image.style.pixelHeight=$0;
}},
"default":function($0,
$1){if(this.getResizeToInner()){this._image.height=$0;
}}})},
destruct:function(){if(this._image){this._image.style.filter=$[0];
}this._disposeFields($[1580]);
}});




/* ID: qx.ui.basic.HorizontalSpacer */
qx.Class.define($[2035],
{extend:qx.ui.basic.Terminator,
construct:function(){arguments.callee.base.call(this);
this.initWidth();
},
properties:{width:{refine:true,
init:$[87]}}});




/* ID: Tr.ui.ActionButton */
qx.Class.define($[1528],
{extend:qx.ui.layout.VerticalBoxLayout,
construct:function(){arguments.callee.base.call(this);
this.set({height:$[129],
width:$[129],
horizontalChildrenAlign:$[794]});
var $0=new qx.ui.layout.HorizontalBoxLayout;
$0.set({height:$[129],
width:$[129],
verticalChildrenAlign:$[902]});
var $1=new qx.ui.basic.Label(this.tr($[589]));
$1.set({paddingRight:6});
$0.add($1);
var $2=new qx.ui.form.TextField();
$2.set({width:200,
height:$[129],
border:$[164],
padding:1});
$0.add($2);
this.__host=$2;
var $3=new qx.ui.basic.Label(this.tr($[958]));
$3.set({paddingRight:6,
paddingLeft:12});
$0.add($3);
var $4=new qx.ui.form.Spinner(1,
2,
60);
$4.set({border:$[164],
width:45});
$0.add($4);
this.__delay=$4;
var $5=new qx.ui.basic.Label(this.tr($[1960]));
$5.set({paddingRight:6,
paddingLeft:12});
$0.add($5);
var $6=new qx.ui.form.Spinner(1,
20,
200);
$6.set({border:$[164],
width:45});
$0.add($6);
this.__rounds=$6;
var $7=new qx.ui.form.Button($[263]);
this.__button=$7;
$7.set({marginLeft:10,
width:60,
height:$[129],
border:$[164],
padding:2});
$0.add($7);
this.add($0);
var $8=new qx.ui.basic.Atom();
$8.set({marginTop:3,
padding:3,
textColor:'red',
width:'100%',
height:'auto',
backgroundColor:'#f0f0f0',
visibility:false});
qx.event.message.Bus.subscribe($[532],
this.__set_info,
this);
this.add($8);
this.__info=$8;
qx.event.message.Bus.subscribe($[139],
this.__set_status,
this);
qx.event.message.Bus.dispatch($[139],
$[215]);
var $9=function($a){qx.event.message.Bus.dispatch($[615],
{action:$7.getUserData($[181]),
host:$2.getValue(),
delay:$4.getValue(),
rounds:$6.getValue()});
};
$2.addEventListener($[319],
$9);
$7.addEventListener($[319],
$9);
var $b=qx.client.History.getInstance();
var $c=function($a){var $d=$a.getData();
$2.setValue($d);
$b.addToHistory($d,
$[389]+$d);
$9();
};
$b.addEventListener($[1679],
$c);
var $e=qx.client.History.getInstance().getState();
if($e){$2.setValue($e);
$b.addToHistory($e,
$[389]+$e);
qx.client.Timer.once($9,
this,
0);
}},
members:{__set_info:function($0){this.__info.set({label:$0.getData(),
visibility:true});
},
__set_status:function($0){var $1=this.__host;
var $2=this.__rounds;
var $3=this.__delay;
with(this.__button){switch($0.getData()){case $[496]:if(getUserData($[181])==$[286]){setLabel(this.tr($[965]));
this.__info.setVisibility(false);
border:$[164];
setEnabled(false);
$1.setEnabled(false);
$2.setEnabled(false);
$3.setEnabled(false);
}break;
case $[521]:if(getUserData($[181])==$[331]){setLabel(this.tr($[1637]));
setEnabled(false);
$1.setEnabled(false);
$2.setEnabled(false);
$3.setEnabled(false);
}break;
case $[215]:setUserData($[181],
$[286]);
setLabel(this.tr($[1910]));
setEnabled(true);
$1.setEnabled(true);
$2.setEnabled(true);
$3.setEnabled(true);
break;
case $[410]:setUserData($[181],
$[331]);
setLabel(this.tr($[1223]));
setEnabled(true);
$1.setEnabled(false);
$2.setEnabled(false);
$3.setEnabled(false);
break;
default:alert('Unknown Status Message: '+$0.getData());
}}}}});




/* ID: qx.ui.form.TextField */
qx.Class.define($[672],
{extend:qx.ui.basic.Terminator,
construct:function($0){arguments.callee.base.call(this);
if($0!=null){this.setValue($0);
}this.initHideFocus();
this.initWidth();
this.initHeight();
this.initTabIndex();
this.initSpellCheck();
this.__oninput=qx.lang.Function.bindEvent(this._oninputDom,
this);
this.addEventListener($[214],
this._onblur);
this.addEventListener($[256],
this._onfocus);
this.addEventListener($[128],
this._oninput);
},
statics:{createRegExpValidator:function($0){return function($1){return $0.test($1);
};
}},
events:{"input":$[42]},
properties:{allowStretchX:{refine:true,
init:true},
allowStretchY:{refine:true,
init:false},
appearance:{refine:true,
init:$[157]},
tabIndex:{refine:true,
init:1},
hideFocus:{refine:true,
init:true},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
selectable:{refine:true,
init:true},
value:{init:$[0],
nullable:true,
event:$[190],
apply:$[388]},
textAlign:{check:[$[13],
$[52],
$[14],
$[419]],
nullable:true,
themeable:true,
apply:$[515]},
spellCheck:{check:$[2],
init:false,
apply:$[1625]},
liveUpdate:{check:$[2],
init:false},
maxLength:{check:$[6],
apply:$[1131],
nullable:true},
readOnly:{check:$[2],
apply:$[990],
init:false},
validator:{check:$[68],
event:$[1549],
nullable:true}},
members:{_inputTag:$[128],
_inputType:$[186],
_inputOverflow:$[21],
_applyElement:function($0,
$1){arguments.callee.base.call(this,
$0,
$1);
if($0){var $2=this._inputElement=document.createElement(this._inputTag);
if(this._inputType){$2.type=this._inputType;
}$2.autoComplete=$[102];
$2.setAttribute($[746],
$[102]);
$2.disabled=this.getEnabled()===false;
$2.readOnly=this.getReadOnly();
$2.value=this.getValue()?this.getValue():$[0];
if(this.getMaxLength()!=null){$2.maxLength=this.getMaxLength();
}var $3=$2.style;
$3.padding=$3.margin=0;
$3.border=$[487];
$3.background=$[235];
$3.overflow=this._inputOverflow;
$3.outline=$[11];
$3.resize=$[11];
$3.WebkitAppearance=$[11];
$3.MozAppearance=$[11];
if(qx.core.Variant.isSet($[1],
$[403])){$3.margin=$[569];
}this._renderFont();
this._renderTextColor();
this._renderTextAlign();
this._renderCursor();
this._renderSpellCheck();
if(qx.core.Variant.isSet($[1],
$[20])){$2.onpropertychange=this.__oninput;
}else{$2.addEventListener($[128],
this.__oninput,
false);
}$0.appendChild($2);
}},
_postApply:function(){this._syncFieldWidth();
this._syncFieldHeight();
},
_changeInnerWidth:function($0,
$1){this._syncFieldWidth();
},
_changeInnerHeight:function($0,
$1){this._syncFieldHeight();
},
_syncFieldWidth:function(){this._inputElement.style.width=this.getInnerWidth()+$[46];
},
_syncFieldHeight:function(){this._inputElement.style.height=(this.getInnerHeight()-2)+$[46];
},
_applyCursor:function($0,
$1){if(this._inputElement){this._renderCursor();
}},
_renderCursor:function(){var $0=this._inputElement.style;
var $1=this.getCursor();
if($1){if($1==$[318]&&qx.core.Client.getInstance().isMshtml()){$0.cursor=$[217];
}else{$0.cursor=$1;
}}else{$0.cursor=$[0];
}},
_applyTextAlign:function($0,
$1){if(this._inputElement){this._renderTextAlign();
}},
_renderTextAlign:function(){this._inputElement.style.textAlign=this.getTextAlign()||$[0];
},
_applySpellCheck:function($0,
$1){if(this._inputElement){this._renderSpellCheck();
}},
_renderSpellCheck:function(){this._inputElement.spellcheck=this.getSpellCheck();
},
_applyEnabled:function($0,
$1){if(this._inputElement){this._inputElement.disabled=$0===false;
}return arguments.callee.base.call(this,
$0,
$1);
},
_applyValue:function($0,
$1){this._inValueProperty=true;
if(this._inputElement){if($0===null){$0=$[0];
}
if(this._inputElement.value!==$0){this._inputElement.value=$0;
}}delete this._inValueProperty;
},
_applyMaxLength:function($0,
$1){if(this._inputElement){this._inputElement.maxLength=$0==null?$[0]:$0;
}},
_applyReadOnly:function($0,
$1){if(this._inputElement){this._inputElement.readOnly=$0;
}
if($0){this.addState($[590]);
}else{this.removeState($[590]);
}},
_applyTextColor:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleTextColor,
this,
$0);
},
_styleTextColor:function($0){this.__textColor=$0;
this._renderTextColor();
},
_renderTextColor:function(){var $0=this._inputElement;
if($0){$0.style.color=this.__textColor||$[0];
}},
_applyFont:function($0,
$1){qx.theme.manager.Font.getInstance().connect(this._styleFont,
this,
$0);
},
_styleFont:function($0){this.__font=$0;
this._renderFont();
},
_renderFont:function(){var $0=this._inputElement;
if($0){var $1=this.__font;
$1?$1.renderElement($0):qx.ui.core.Font.resetElement($0);
}},
_visualizeFocus:function(){arguments.callee.base.call(this);
if(!qx.event.handler.FocusHandler.mouseFocus&&this.getEnableElementFocus()){try{this._inputElement.focus();
}catch(ex){}}},
_visualizeBlur:function(){arguments.callee.base.call(this);
if(!qx.event.handler.FocusHandler.mouseFocus){try{this._inputElement.blur();
}catch(ex){}}},
getComputedValue:function(){if(this._inputElement){return this._inputElement.value;
}return this.getValue();
},
getInputElement:function(){return this._inputElement||null;
},
isValid:function(){var $0=this.getValidator();
return !$0||$0(this.getValue());
},
isComputedValid:function(){var $0=this.getValidator();
return !$0||$0(this.getComputedValue());
},
_computePreferredInnerWidth:function(){return 120;
},
_computePreferredInnerHeight:function(){return 16;
},
_ieFirstInputFix:qx.core.Variant.select($[1],
{"mshtml":function(){this._inValueProperty=true;
this._inputElement.value=this.getValue()===null?$[0]:this.getValue();
this._firstInputFixApplied=true;
delete this._inValueProperty;
},
"default":null}),
_afterAppear:qx.core.Variant.select($[1],
{"mshtml":function(){arguments.callee.base.call(this);
if(!this._firstInputFixApplied&&this._inputElement){qx.client.Timer.once(this._ieFirstInputFix,
this,
1);
}},
"default":function(){arguments.callee.base.call(this);
}}),
_firstInputFixApplied:false,
_textOnFocus:null,
_oninputDom:qx.core.Variant.select($[1],
{"mshtml":function($0){if(!this._inValueProperty&&$0.propertyName===$[379]){this.createDispatchDataEvent($[128],
this.getComputedValue());
}},
"default":function($0){this.createDispatchDataEvent($[128],
this.getComputedValue());
}}),
_ontabfocus:function(){this.selectAll();
},
_onfocus:function(){this._textOnFocus=this.getComputedValue();
},
_onblur:function(){var $0=this.getComputedValue().toString();
if(this._textOnFocus!=$0){this.setValue($0);
}this.setSelectionLength(0);
},
_oninput:function(){if(!this.isLiveUpdate()){return;
}var $0=this.getComputedValue().toString();
this.setValue($0);
},
__getRange:qx.core.Variant.select($[1],
{"mshtml":function(){this._visualPropertyCheck();
return this._inputElement.createTextRange();
},
"default":null}),
__getSelectionRange:qx.core.Variant.select($[1],
{"mshtml":function(){this._visualPropertyCheck();
return this.getTopLevelWidget().getDocumentElement().selection.createRange();
},
"default":null}),
setSelectionStart:qx.core.Variant.select($[1],
{"mshtml":function($0){this._visualPropertyCheck();
var $1=this._inputElement.value;
var $2=0;
while($2<$0){$2=$1.indexOf($[640],
$2);
if($2==-1){break;
}$0--;
$2++;
}var $3=this.__getRange();
$3.collapse();
$3.move($[449],
$0);
$3.select();
},
"default":function($0){this._visualPropertyCheck();
this._inputElement.selectionStart=$0;
}}),
getSelectionStart:qx.core.Variant.select($[1],
{"mshtml":function(){this._visualPropertyCheck();
var $0=this.__getSelectionRange();
if(!this._inputElement.contains($0.parentElement())){return -1;
}var $1=this.__getRange();
$1.setEndPoint($[1631],
$0);
return $1.text.length;
},
"default":function(){this._visualPropertyCheck();
return this._inputElement.selectionStart;
}}),
setSelectionLength:qx.core.Variant.select($[1],
{"mshtml":function($0){this._visualPropertyCheck();
var $1=this.__getSelectionRange();
if(!this._inputElement.contains($1.parentElement())){return;
}$1.collapse();
$1.moveEnd($[449],
$0);
$1.select();
},
"default":function($0){this._visualPropertyCheck();
var $1=this._inputElement;
if(qx.util.Validation.isValidString($1.value)){$1.selectionEnd=$1.selectionStart+$0;
}}}),
getSelectionLength:qx.core.Variant.select($[1],
{"mshtml":function(){this._visualPropertyCheck();
var $0=this.__getSelectionRange();
if(!this._inputElement.contains($0.parentElement())){return 0;
}return $0.text.length;
},
"default":function(){this._visualPropertyCheck();
var $0=this._inputElement;
return $0.selectionEnd-$0.selectionStart;
}}),
setSelectionText:qx.core.Variant.select($[1],
{"mshtml":function($0){this._visualPropertyCheck();
var $1=this.getSelectionStart();
var $2=this.__getSelectionRange();
if(!this._inputElement.contains($2.parentElement())){return;
}$2.text=$0;
this.setValue(this._inputElement.value);
this.setSelectionStart($1);
this.setSelectionLength($0.length);
},
"default":function($0){this._visualPropertyCheck();
var $1=this._inputElement;
var $2=$1.value;
var $3=$1.selectionStart;
var $4=$2.substr(0,
$3);
var $5=$2.substr($1.selectionEnd);
var $6=$1.value=$4+$0+$5;
$1.selectionStart=$3;
$1.selectionEnd=$3+$0.length;
this.setValue($6);
}}),
getSelectionText:qx.core.Variant.select($[1],
{"mshtml":function(){this._visualPropertyCheck();
var $0=this.__getSelectionRange();
if(!this._inputElement.contains($0.parentElement())){return $[0];
}return $0.text;
},
"default":function(){this._visualPropertyCheck();
return this._inputElement.value.substr(this.getSelectionStart(),
this.getSelectionLength());
}}),
selectAll:function(){this._visualPropertyCheck();
if(this.getValue()!=null){this.setSelectionStart(0);
this.setSelectionLength(this._inputElement.value.length);
}this._inputElement.select();
this._inputElement.focus();
},
selectFromTo:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){this._visualPropertyCheck();
this.setSelectionStart($0);
this.setSelectionLength($1-$0);
},
"default":function($0,
$1){this._visualPropertyCheck();
var $2=this._inputElement;
$2.selectionStart=$0;
$2.selectionEnd=$1;
}})},
destruct:function(){if(this._inputElement){if(qx.core.Variant.isSet($[1],
$[20])){this._inputElement.onpropertychange=null;
}else{this._inputElement.removeEventListener($[128],
this.__oninput,
false);
}}this._disposeFields($[1933],
$[1551],
$[1624]);
}});




/* ID: qx.ui.form.Spinner */
qx.Class.define($[1365],
{extend:qx.ui.layout.HorizontalBoxLayout,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
if(qx.core.Variant.isSet($[1],
$[20])){this.setStyleProperty($[222],
$[59]);
}this._textfield=new qx.ui.form.TextField;
this._textfield.setBorder(null);
this._textfield.setWidth($[87]);
this._textfield.setAllowStretchY(true);
this._textfield.setHeight(null);
this._textfield.setVerticalAlign($[30]);
this._textfield.setAppearance($[1754]);
this.add(this._textfield);
this._buttonlayout=new qx.ui.layout.VerticalBoxLayout;
this._buttonlayout.setWidth($[3]);
this.add(this._buttonlayout);
this._upbutton=new qx.ui.basic.Image;
this._upbutton.setAppearance($[1358]);
this._upbutton.setHeight($[87]);
this._buttonlayout.add(this._upbutton);
this._downbutton=new qx.ui.basic.Image;
this._downbutton.setAppearance($[1153]);
this._downbutton.setHeight($[87]);
this._buttonlayout.add(this._downbutton);
this._timer=new qx.client.Timer(this.getInterval());
this.setManager(new qx.util.range.Range());
this.initWrap();
this.addEventListener($[57],
this._onkeypress,
this);
this.addEventListener($[45],
this._onkeydown,
this);
this.addEventListener($[146],
this._onkeyup,
this);
this.addEventListener($[238],
this._onmousewheel,
this);
this._textfield.addEventListener($[128],
this._oninput,
this);
this._textfield.addEventListener($[214],
this._onblur,
this);
this._upbutton.addEventListener($[18],
this._onmousedown,
this);
this._downbutton.addEventListener($[18],
this._onmousedown,
this);
this._timer.addEventListener($[67],
this._oninterval,
this);
if($0!=null){this.setMin($0);
}
if($2!=null){this.setMax($2);
}
if($1!=null){this.setValue($1);
}this._checkValue=this.__checkValue;
this.initWidth();
this.initHeight();
},
events:{"change":$[42]},
properties:{appearance:{refine:true,
init:$[1570]},
width:{refine:true,
init:60},
height:{refine:true,
init:22},
incrementAmount:{check:$[6],
init:1,
apply:$[992]},
wheelIncrementAmount:{check:$[6],
init:1},
pageIncrementAmount:{check:$[6],
init:10},
interval:{check:$[6],
init:100},
firstInterval:{check:$[6],
init:500},
minTimer:{check:$[6],
init:20},
timerDecrease:{check:$[6],
init:2},
amountGrowth:{check:$[12],
init:1.01},
wrap:{check:$[2],
init:false,
apply:$[458]},
editable:{check:$[2],
init:true,
apply:$[698]},
manager:{check:$[629],
apply:$[1409],
dispose:true},
checkValueFunction:{apply:$[961]}},
members:{_applyIncrementAmount:function($0,
$1){this._computedIncrementAmount=$0;
},
_applyEditable:function($0,
$1){if(this._textfield){this._textfield.setReadOnly(!$0);
}},
_applyWrap:function($0,
$1){this.getManager().setWrap($0);
this._onchange();
},
_applyManager:function($0,
$1){if($1){$1.removeEventListener($[134],
this._onchange,
this);
}
if($0){$0.addEventListener($[134],
this._onchange,
this);
}this._onchange();
},
_applyCheckValueFunction:function($0,
$1){this._checkValue=$0;
},
_computePreferredInnerWidth:function(){return 50;
},
_computePreferredInnerHeight:function(){return 14;
},
_onkeypress:function($0){var $1=$0.getKeyIdentifier();
if($1==$[110]&&!$0.isAltPressed()){this._checkValue(true,
false,
false);
this._textfield.selectAll();
}else{switch($1){case $[116]:case $[155]:case $[147]:case $[148]:case $[633]:case $[399]:case $[560]:case $[245]:case $[284]:case $[561]:case $[271]:case $[227]:case $[266]:case $[126]:case $[177]:case $[192]:case $[253]:break;
default:if($1>=$[56]&&$1<=$[229]){return;
}if($0.getModifiers()==0){$0.preventDefault();
}}}},
_onkeydown:function($0){var $1=$0.getKeyIdentifier();
if(this._intervalIncrease==null){switch($1){case $[116]:case $[155]:this._intervalIncrease=$1==$[116];
this._intervalMode=$[1091];
this._resetIncrements();
this._checkValue(true,
false,
false);
this._increment();
this._timer.startWith(this.getFirstInterval());
break;
case $[126]:case $[177]:this._intervalIncrease=$1==$[126];
this._intervalMode=$[486];
this._resetIncrements();
this._checkValue(true,
false,
false);
this._pageIncrement();
this._timer.startWith(this.getFirstInterval());
break;
}}},
_onkeyup:function($0){if(this._intervalIncrease!=null){switch($0.getKeyIdentifier()){case $[116]:case $[155]:case $[126]:case $[177]:this._timer.stop();
this._intervalIncrease=null;
this._intervalMode=null;
}}},
_onmousedown:function($0){if(!$0.isLeftButtonPressed()){return;
}this._checkValue(true);
var $1=$0.getCurrentTarget();
$1.addState($[31]);
$1.addEventListener($[39],
this._onmouseup,
this);
$1.addEventListener($[113],
this._onmouseup,
this);
this._intervalIncrease=$1==this._upbutton;
this._resetIncrements();
this._increment();
this._textfield.selectAll();
this._timer.setInterval(this.getFirstInterval());
this._timer.start();
},
_onmouseup:function($0){var $1=$0.getCurrentTarget();
$1.removeState($[31]);
$1.removeEventListener($[39],
this._onmouseup,
this);
$1.removeEventListener($[113],
this._onmouseup,
this);
this._textfield.selectAll();
this._textfield.setFocused(true);
this._timer.stop();
this._intervalIncrease=null;
},
_onmousewheel:function($0){if(this.getManager().incrementValue){this.getManager().incrementValue(this.getWheelIncrementAmount()*$0.getWheelDelta());
}else{var $1=this.getManager().getValue()+(this.getWheelIncrementAmount()*$0.getWheelDelta());
$1=this.getManager().limit($1);
this.getManager().setValue($1);
}this._textfield.selectAll();
},
_oninput:function($0){this._checkValue(true,
true);
},
_onchange:function($0){var $1=this.getManager().getValue();
this._textfield.setValue(String($1));
if($1==this.getMin()&&!this.getWrap()){this._downbutton.removeState($[31]);
this._downbutton.setEnabled(false);
this._timer.stop();
}else{this._downbutton.resetEnabled();
}
if($1==this.getMax()&&!this.getWrap()){this._upbutton.removeState($[31]);
this._upbutton.setEnabled(false);
this._timer.stop();
}else{this._upbutton.resetEnabled();
}this.createDispatchDataEvent($[134],
$1);
},
_onblur:function($0){this._checkValue(false);
},
setValue:function($0){this.getManager().setValue(this.getManager().limit($0));
},
getValue:function(){this._checkValue(true);
return this.getManager().getValue();
},
resetValue:function(){this.getManager().resetValue();
},
setMax:function($0){return this.getManager().setMax($0);
},
getMax:function(){return this.getManager().getMax();
},
setMin:function($0){return this.getManager().setMin($0);
},
getMin:function(){return this.getManager().getMin();
},
_intervalIncrease:null,
_oninterval:function($0){this._timer.stop();
this.setInterval(Math.max(this.getMinTimer(),
this.getInterval()-this.getTimerDecrease()));
if(this._intervalMode==$[486]){this._pageIncrement();
}else{if(this.getInterval()==this.getMinTimer()){this._computedIncrementAmount=this.getAmountGrowth()*this._computedIncrementAmount;
}this._increment();
}var $1=this.getManager().getWrap();
switch(this._intervalIncrease){case true:if(this.getValue()==this.getMax()&&!$1){return;
}case false:if(this.getValue()==this.getMin()&&!$1){return;
}}this._timer.restartWith(this.getInterval());
},
__checkValue:function($0,
$1){var $2=this._textfield.getInputElement();
if(!$2){return;
}
if($2.value==$[0]){if(!$0){this.setValue(this.getMax());
this.resetValue();
return;
}}else{var $3=$2.value;
if($3.length>1){while($3.charAt(0)==$[56]){$3=$3.substr(1,
$3.length);
}var $4=parseInt($3)||0;
if($4!=$2.value){$2.value=$4;
return;
}}if($3==$[96]&&$0&&this.getMin()<0){if($2.value!=$3){$2.value=$3;
}return;
}$3=parseInt($3);
var $5=true;
var $6=this.getManager().limit($3);
if(isNaN($6)){$6=this.getManager().getValue();
}if($0&&$3==$[0]){$5=false;
}else if(!isNaN($3)){if($1){if($3>$6&&!($3>0&&$6<=0)&&String($3).length<String($6).length){$5=false;
}else if($3<$6&&!($3<0&&$6>=0)&&String($3).length<String($6).length){$5=false;
}}}if($5&&$2.value!=$6){$2.value=$6;
}if(!$1){this.getManager().setValue($6);
}}},
_increment:function(){if(this.getManager().incrementValue){this.getManager().incrementValue((this._intervalIncrease?1:-1)*this._computedIncrementAmount);
}else{var $0=this.getManager().getValue()+((this._intervalIncrease?1:-1)*this._computedIncrementAmount);
$0=this.getManager().limit($0);
this.getManager().setValue($0);
}},
_pageIncrement:function(){if(this.getManager().pageIncrementValue){this.getManager().pageIncrementValue();
}else{var $0=this.getManager().getValue()+((this._intervalIncrease?1:-1)*this.getPageIncrementAmount());
$0=this.getManager().limit($0);
this.getManager().setValue($0);
}},
_resetIncrements:function(){this._computedIncrementAmount=this.getIncrementAmount();
this.resetInterval();
}},
destruct:function(){this._disposeObjects($[1907],
$[920],
$[1349],
$[1987],
$[202]);
}});




/* ID: qx.util.range.IRange */
qx.Interface.define($[629],
{properties:{value:{},
min:{},
max:{},
wrap:{}},
members:{limit:function($0){return true;
}}});




/* ID: qx.util.range.Range */
qx.Class.define($[1496],
{extend:qx.core.Target,
implement:[qx.util.range.IRange],
events:{"change":$[4]},
properties:{value:{check:$[1982],
nullable:true,
init:0,
event:$[134]},
min:{check:$[12],
apply:$[929],
event:$[134],
init:0},
max:{check:$[12],
apply:$[872],
event:$[134],
init:100},
wrap:{check:$[2],
init:false}},
members:{_applyMax:function($0,
$1){this.setValue(Math.min(this.getValue(),
$0));
},
_applyMin:function($0,
$1){this.setValue(Math.max(this.getValue(),
$0));
},
limit:function($0){if(this.getWrap()){var $0=Math.round($0);
if($0<this.getMin()){return (this.getMax()-(this.getMin()-$0))+1;
}
if($0>this.getMax()){return (this.getMin()+($0-this.getMax()))-1;
}}
if($0<this.getMin()){return this.getMin();
}
if($0>this.getMax()){return this.getMax();
}return Math.round($0);
}}});




/* ID: qx.ui.form.Button */
qx.Class.define($[326],
{extend:qx.ui.basic.Atom,
construct:function($0,
$1,
$2,
$3,
$4){arguments.callee.base.call(this,
$0,
$1,
$2,
$3,
$4);
this.initTabIndex();
this.addEventListener($[86],
this._onmouseover);
this.addEventListener($[113],
this._onmouseout);
this.addEventListener($[18],
this._onmousedown);
this.addEventListener($[39],
this._onmouseup);
this.addEventListener($[45],
this._onkeydown);
this.addEventListener($[146],
this._onkeyup);
},
properties:{appearance:{refine:true,
init:$[156]},
tabIndex:{refine:true,
init:1}},
members:{_onmouseover:function($0){if($0.getTarget()!=this){return;
}
if(this.hasState($[55])){this.removeState($[55]);
this.addState($[31]);
}this.addState($[64]);
},
_onmouseout:function($0){if($0.getTarget()!=this){return;
}this.removeState($[64]);
if(this.hasState($[31])){this.setCapture(true);
this.removeState($[31]);
this.addState($[55]);
}},
_onmousedown:function($0){if($0.getTarget()!=this||!$0.isLeftButtonPressed()){return;
}this.removeState($[55]);
this.addState($[31]);
},
_onmouseup:function($0){this.setCapture(false);
var $1=this.hasState($[31]);
var $2=this.hasState($[55]);
if($1){this.removeState($[31]);
}
if($2){this.removeState($[55]);
}
if(!$2){this.addState($[64]);
if($1){this.execute();
}}},
_onkeydown:function($0){switch($0.getKeyIdentifier()){case $[110]:case $[248]:this.removeState($[55]);
this.addState($[31]);
}},
_onkeyup:function($0){switch($0.getKeyIdentifier()){case $[110]:case $[248]:if(this.hasState($[31])){this.removeState($[55]);
this.removeState($[31]);
this.execute();
}}}}});




/* ID: qx.event.message.Bus */
qx.Class.define($[1374],
{statics:{__subscriptions:{},
getSubscriptions:function(){return this.__subscriptions;
},
subscribe:function($0,
$1,
$2){if(!$0||typeof $1!=$[51]){this.error("Invalid parameters!");
return false;
}var $3=this.getSubscriptions();
if(this.checkSubscription($0)){if(this.checkSubscription($0,
$1,
$2)){this.warn("Object method already subscribed to "+$0);
return false;
}$3[$0].push({subscriber:$1,
context:$2||null});
return true;
}else{$3[$0]=[{subscriber:$1,
context:$2||null}];
return true;
}},
checkSubscription:function($0,
$1,
$2){var $3=this.getSubscriptions();
if(!$3[$0]||$3[$0].length==0){return false;
}
if($1){for(var $4=0;$4<$3[$0].length;$4++){if($3[$0][$4].subscriber==$1&&$3[$0][$4].context==($2||null)){return true;
}}return false;
}return true;
},
unsubscribe:function($0,
$1,
$2){var $3=this.getSubscriptions();
if(!$3[$0]){return false;
}
if($1){for(var $4=0;$4<$3[$0].length;$4++){if($3[$0][$4].subscriber==$1&&$3[$0][$4].context==($2||null)){$3[$0].splice($4,
1);
return true;
}}}$3[$0]=null;
return true;
},
dispatch:function($0){if(typeof $0==$[8]){var $1=typeof arguments[1]!=$[7]?arguments[1]:true;
$0=new qx.event.message.Message($0,
$1);
}var $2=this.getSubscriptions();
var $3=$0.getName();
for(var $4 in $2){var $5=$4.indexOf($[153]);
if($5>-1){if($5==1||$4.substr(0,
$5)==$3.substr(0,
$5)){for(var $6=0;$6<$2[$4].length;$6++){var $7=$2[$4][$6].subscriber;
var $8=$2[$4][$6].context;
$7.call($8,
$0);
}}}else{if($4==$3){for(var $6=0;$6<$2[$3].length;$6++){var $7=$2[$3][$6].subscriber;
var $8=$2[$3][$6].context;
$7.call($8,
$0);
}return true;
}}}}}});




/* ID: qx.event.message.Message */
qx.Class.define($[1919],
{extend:qx.core.Object,
construct:function($0,
$1){arguments.callee.base.call(this);
this.setName($0);
this.setData($1);
},
properties:{name:{_fast:true,
setOnlyOnce:true,
check:$[9]},
data:{_fast:true},
sender:{_fast:true,
setOnlyOnce:true,
check:$[97]}},
destruct:function(){this._disposeFields($[476],
$[1352]);
}});




/* ID: qx.client.History */
qx.Class.define($[1597],
{type:$[24],
extend:qx.core.Target,
construct:qx.core.Variant.select($[1],
{"mshtml":function(){arguments.callee.base.call(this);
this._iframe=document.createElement($[334]);
this._iframe.style.visibility=$[21];
this._iframe.style.position=$[63];
this._iframe.style.left=$[630];
this._iframe.style.top=$[630];
document.body.appendChild(this._iframe);
var $0=qx.io.Alias.getInstance().resolve($[1325]);
this._iframe.src=$0;
this._titles={};
this._state=decodeURIComponent(this.__getHash());
this._locationState=decodeURIComponent(this.__getHash());
this.__waitForIFrame(function(){this.__storeState(this._state);
this.__startTimer();
},
this);
},
"default":function(){arguments.callee.base.call(this);
this._titles={};
this._state=this.__getState();
this.__startTimer();
}}),
events:{"request":$[42]},
properties:{timeoutInterval:{check:$[12],
init:100,
apply:$[657]}},
members:{init:function(){qx.log.Logger.deprecatedMethodWarning(arguments.callee,
$[1068]);
},
addToHistory:function($0,
$1){if($1!=null){document.title=$1;
this._titles[$0]=$1;
}
if($0!=this._state){top.location.hash=$[298]+encodeURIComponent($0);
this.__storeState($0);
}},
getState:function(){return this._state;
},
navigateBack:function(){qx.client.Timer.once(function(){history.back();
},
0);
},
navigateForward:function(){qx.client.Timer.once(function(){history.forward();
},
0);
},
_applyTimeoutInterval:function($0){this._timer.setInterval($0);
},
__onHistoryLoad:function($0){this._state=$0;
this.createDispatchDataEvent($[1366],
$0);
if(this._titles[$0]!=null){document.title=this._titles[$0];
}},
__startTimer:function(){this._timer=new qx.client.Timer(this.getTimeoutInterval());
this._timer.addEventListener($[67],
function($0){var $1=this.__getState();
if($1!=this._state){this.__onHistoryLoad($1);
}},
this);
this._timer.start();
},
__getHash:function(){var $0=top.location.href;
var $1=$0.indexOf($[298]);
return $1>=0?$0.substring($1+1):$[0];
},
__getState:qx.core.Variant.select($[1],
{"mshtml":function(){var $0=decodeURIComponent(this.__getHash());
if($0!=this._locationState){this._locationState=$0;
this.__storeState($0);
return $0;
}var $1=this._iframe.contentWindow.document;
var $2=$1.getElementById($[2044]);
var $3=$2?decodeURIComponent($2.innerText):$[0];
return $3;
},
"default":function(){return decodeURIComponent(this.__getHash());
}}),
__storeState:qx.core.Variant.select($[1],
{"mshtml":function($0){var $1=$[1416]+encodeURIComponent($0)+$[1677];
try{var $2=this._iframe.contentWindow.document;
$2.open();
$2.write($1);
$2.close();
}catch(e){return false;
}return true;
},
"default":function($0){qx.client.Timer.once(function(){top.location.hash=$[298]+encodeURIComponent($0);
},
this,
0);
return true;
}}),
__waitForIFrame:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){if(!this._iframe.contentWindow||!this._iframe.contentWindow.document){qx.client.Timer.once(function(){this.__waitForIFrame($0,
$1);
},
this,
10);
return;
}$0.call($1||window);
},
"default":null})},
destruct:function(){this._timer.stop();
this._disposeObjects($[202]);
this._disposeFields($[747],
$[1253]);
}});




/* ID: qx.ui.table.Table */
qx.Class.define($[1011],
{extend:qx.ui.layout.VerticalBoxLayout,
construct:function($0,
$1){arguments.callee.base.call(this);
if(!$1){$1={};
}
if($1.selectionManager){this.setNewSelectionManager($1.selectionManager);
}
if($1.selectionModel){this.setNewSelectionModel($1.selectionModel);
}
if($1.tableColumnModel){this.setNewTableColumnModel($1.tableColumnModel);
}
if($1.tablePane){this.setNewTablePane($1.tablePane);
}
if($1.tablePaneHeader){this.setNewTablePaneHeader($1.tablePaneHeader);
}
if($1.tablePaneScroller){this.setNewTablePaneScroller($1.tablePaneScroller);
}
if($1.tablePaneModel){this.setNewTablePaneModel($1.tablePaneModel);
}this._scrollerParent=new qx.ui.layout.HorizontalBoxLayout;
this._scrollerParent.setDimension($[80],
$[87]);
this._scrollerParent.setSpacing(1);
this._statusBar=new qx.ui.basic.Label;
this._statusBar.setAppearance($[1592]);
this._statusBar.setDimension($[80],
$[3]);
this.add(this._scrollerParent,
this._statusBar);
this._columnVisibilityBt=new qx.ui.form.Button;
this._columnVisibilityBt.setAppearance($[1138]);
this._columnVisibilityBt.addEventListener($[117],
this._onColumnVisibilityBtExecuted,
this);
this.setDataRowRenderer(new qx.ui.table.rowrenderer.Default());
this._selectionManager=this.getNewSelectionManager()(this);
this.setSelectionModel(this.getNewSelectionModel()(this));
this.setTableColumnModel(this.getNewTableColumnModel()(this));
if($0!=null){this.setTableModel($0);
}this.setMetaColumnCounts([-1]);
this.setTabIndex(1);
this.addEventListener($[45],
this._onkeydown);
this.addEventListener($[57],
this._onkeypress);
this.addEventListener($[463],
this._onFocusChanged);
this._focusedCol=0;
this._focusedRow=0;
qx.locale.Manager.getInstance().addEventListener($[308],
this._onChangeLocale,
this);
},
events:{"columnVisibilityMenuCreateStart":$[42],
"columnVisibilityMenuCreateEnd":$[42],
"tableWidthChanged":$[42],
"verticalScrollBarChanged":$[42],
"cellClick":$[150],
"cellDblclick":$[150],
"cellContextmenu":$[150]},
statics:{__redirectEvents:{cellClick:1,
cellDblclick:1,
cellContextmenu:1}},
properties:{selectionModel:{check:$[292],
apply:$[1415],
event:$[1654]},
tableModel:{check:$[627],
apply:$[1379],
event:$[730],
nullable:true},
tableColumnModel:{check:$[377],
apply:$[1873],
event:$[1420]},
rowHeight:{check:$[12],
init:18,
event:$[1759]},
statusBarVisible:{check:$[2],
init:true,
apply:$[1408]},
columnVisibilityButtonVisible:{check:$[2],
init:true,
apply:$[1723]},
metaColumnCounts:{check:$[97],
apply:$[877]},
focusCellOnMouseMove:{check:$[2],
init:false,
apply:$[1709]},
showCellFocusIndicator:{check:$[2],
init:true,
apply:$[364]},
keepFirstVisibleRowComplete:{check:$[2],
init:true,
apply:$[1686]},
alwaysUpdateCells:{check:$[2],
init:false},
headerCellHeight:{check:$[6],
init:16,
apply:$[1680],
event:$[701]},
dataRowRenderer:{check:$[609],
init:null,
nullable:true,
apply:$[1943],
event:$[1112]},
modalCellEditorPreOpenFunction:{check:$[68],
init:null,
nullable:true},
newSelectionManager:{check:$[68],
init:function($0){return new qx.ui.table.selection.Manager($0);
}},
newSelectionModel:{check:$[68],
init:function($0){return new qx.ui.table.selection.Model($0);
}},
newTableColumnModel:{check:$[68],
init:function($0){return new qx.ui.table.columnmodel.Basic($0);
}},
newTablePane:{check:$[68],
init:function($0){return new qx.ui.table.pane.Pane($0);
}},
newTablePaneHeader:{check:$[68],
init:function($0){return new qx.ui.table.pane.Header($0);
}},
newTablePaneScroller:{check:$[68],
init:function($0){return new qx.ui.table.pane.Scroller($0);
}},
newTablePaneModel:{check:$[68],
init:function($0){return new qx.ui.table.pane.Model($0);
}}},
members:{_applySelectionModel:function($0,
$1){this._selectionManager.setSelectionModel($0);
if($1!=null){$1.removeEventListener($[341],
this._onSelectionChanged,
this);
}$0.addEventListener($[341],
this._onSelectionChanged,
this);
},
_applyTableModel:function($0,
$1){this.getTableColumnModel().init($0.getColumnCount(),
this);
if($1!=null){$1.removeEventListener(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED,
this._onTableModelMetaDataChanged,
this);
$1.removeEventListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
this._onTableModelDataChanged,
this);
}$0.addEventListener(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED,
this._onTableModelMetaDataChanged,
this);
$0.addEventListener(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
this._onTableModelDataChanged,
this);
this._updateStatusBar();
},
_applyTableColumnModel:function($0,
$1){if($1!=null){$1.removeEventListener($[224],
this._onColVisibilityChanged,
this);
$1.removeEventListener($[236],
this._onColWidthChanged,
this);
$1.removeEventListener($[329],
this._onColOrderChanged,
this);
}$0.addEventListener($[224],
this._onColVisibilityChanged,
this);
$0.addEventListener($[236],
this._onColWidthChanged,
this);
$0.addEventListener($[329],
this._onColOrderChanged,
this);
var $2=this.getTableModel();
if($2){$0.init($2.getColumnCount(),
this);
}var $3=this._getPaneScrollerArr();
for(var $4=0;$4<$3.length;$4++){var $5=$3[$4];
var $6=$5.getTablePaneModel();
$6._tableColumnModel=$0;
}},
_applyStatusBarVisible:function($0,
$1){this._statusBar.setDisplay($0);
if($0){this._updateStatusBar();
}},
_applyColumnVisibilityButtonVisible:function($0,
$1){this._columnVisibilityBt.setDisplay($0);
},
_applyMetaColumnCounts:function($0,
$1){var $2=$0;
var $3=this._getPaneScrollerArr();
this._cleanUpMetaColumns($2.length);
var $4=0;
for(var $5=0;$5<$3.length;$5++){var $6=$3[$5];
var $7=$6.getTablePaneModel();
$7.setFirstColumnX($4);
$7.setMaxColumnCount($2[$5]);
$4+=$2[$5];
}if($2.length>$3.length){var $8=this.getSelectionModel();
var $9=this.getTableModel();
var $a=this.getTableColumnModel();
for(var $5=$3.length;$5<$2.length;$5++){var $7=this.getNewTablePaneModel()($a);
$7.setFirstColumnX($4);
$7.setMaxColumnCount($2[$5]);
$4+=$2[$5];
var $6=this.getNewTablePaneScroller()(this);
$6.setTablePaneModel($7);
$6.addEventListener($[430],
this._onScrollY,
this);
this._scrollerParent.add($6);
}}for(var $5=0;$5<$3.length;$5++){var $6=$3[$5];
var $b=($5==($3.length-1));
$6.getHeader().setHeight(this.getHeaderCellHeight());
$6.setTopRightWidget($b?this._columnVisibilityBt:null);
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
_applyFocusCellOnMouseMove:function($0,
$1){var $2=this._getPaneScrollerArr();
for(var $3=0;$3<$2.length;$3++){$2[$3].setFocusCellOnMouseMove($0);
}},
_applyShowCellFocusIndicator:function($0,
$1){var $2=this._getPaneScrollerArr();
for(var $3=0;$3<$2.length;$3++){$2[$3].setShowCellFocusIndicator($0);
}},
_applyKeepFirstVisibleRowComplete:function($0,
$1){var $2=this._getPaneScrollerArr();
for(var $3=0;$3<$2.length;$3++){$2[$3]._onKeepFirstVisibleRowCompleteChanged();
}},
_applyHeaderCellHeight:function($0,
$1){var $2=this._getPaneScrollerArr();
for(var $3=0;$3<$2.length;$3++){$2[$3].getHeader().setHeight($0);
}},
_applyDataRowRenderer:function($0,
$1){if(this._dataRowRenderer!=null){this._dataRowRenderer.setParent(null);
this._dataRowRenderer.dispose();
this._dataRowRenderer=null;
}$0.setParent(this);
this._dataRowRenderer=$0;
},
_getSelectionManager:function(){return this._selectionManager;
},
_getPaneScrollerArr:function(){return this._scrollerParent.getChildren();
},
getPaneScroller:function($0){return this._getPaneScrollerArr()[$0];
},
_cleanUpMetaColumns:function($0){var $1=this._getPaneScrollerArr();
if($1!=null){for(var $2=$1.length-1;$2>=$0;$2--){$1[$2].dispose();
}}},
_onChangeLocale:function($0){this.postponedUpdateContent();
this._updateStatusBar();
},
_onSelectionChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onSelectionChanged($0);
}this._updateStatusBar();
},
_onTableModelMetaDataChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onTableModelMetaDataChanged($0);
}this._updateStatusBar();
},
_onTableModelDataChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onTableModelDataChanged($0);
}var $3=this.getTableModel().getRowCount();
if($3!=this._lastRowCount){this._lastRowCount=$3;
this._updateScrollBarVisibility();
this._updateStatusBar();
}},
_onScrollY:function($0){if(!this._internalChange){this._internalChange=true;
var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2].setScrollY($0.getValue());
}this._internalChange=false;
}},
_onkeydown:function($0){if(!this.getEnabled()){return;
}var $1=$0.getKeyIdentifier();
var $2=false;
var $3=this._focusedRow;
if(this.isEditing()){if($0.getModifiers()==0){$2=true;
switch($1){case $[110]:this.stopEditing();
var $3=this._focusedRow;
this.moveFocusedCell(0,
1);
if(this._focusedRow!=$3){$2=this.startEditing();
}break;
case $[245]:this.cancelEditing();
this.focus();
break;
default:$2=false;
break;
}}}else{$2=true;
switch($1){case $[227]:this.setFocusedCell(this._focusedCol,
0,
true);
break;
case $[266]:var $4=this.getTableModel().getRowCount();
this.setFocusedCell(this._focusedCol,
$4-1,
true);
break;
default:$2=false;
break;
}if($0.getModifiers()==0){$2=true;
switch($1){case $[275]:case $[110]:$2=this.startEditing();
break;
default:$2=false;
break;
}}else if($0.isCtrlPressed()){$2=true;
switch($1){case $[205]:var $4=this.getTableModel().getRowCount();
if($4>0){this.getSelectionModel().setSelectionInterval(0,
$4-1);
}break;
default:$2=false;
break;
}}}
if($3!=this._focusedRow){this._selectionManager.handleMoveKeyDown(this._focusedRow,
$0);
}
if($2){$0.preventDefault();
$0.stopPropagation();
}},
_onkeypress:function($0){if(!this.getEnabled()){return;
}
if(this.isEditing()){return;
}var $1=this._focusedRow;
var $2=true;
var $3=$0.getKeyIdentifier();
switch($3){case $[248]:this._selectionManager.handleSelectKeyDown(this._focusedRow,
$0);
break;
case $[147]:this.moveFocusedCell(-1,
0);
break;
case $[148]:this.moveFocusedCell(1,
0);
break;
case $[116]:this.moveFocusedCell(0,
-1);
break;
case $[155]:this.moveFocusedCell(0,
1);
break;
case $[126]:case $[177]:var $4=this.getPaneScroller(0);
var $5=$4.getTablePane();
var $6=$5.getVisibleRowCount()-1;
var $7=this.getRowHeight();
var $8=($3==$[126])?-1:1;
$4.setScrollY($4.getScrollY()+$8*$6*$7);
this.moveFocusedCell(0,
$8*$6);
break;
default:$2=false;
}
if($1!=this._focusedRow){this._selectionManager.handleMoveKeyDown(this._focusedRow,
$0);
}
if($2){$0.preventDefault();
$0.stopPropagation();
}},
_onFocusChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onFocusChanged($0);
}},
_onColVisibilityChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onColVisibilityChanged($0);
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
_onColWidthChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onColWidthChanged($0);
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
_onColOrderChanged:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){$1[$2]._onColOrderChanged($0);
}this._updateScrollerWidths();
this._updateScrollBarVisibility();
},
getTablePaneScrollerAtPageX:function($0){var $1=this._getMetaColumnAtPageX($0);
return ($1!=-1)?this.getPaneScroller($1):null;
},
setFocusedCell:function($0,
$1,
$2){if(!this.isEditing()&&($0!=this._focusedCol||$1!=this._focusedRow)){this._focusedCol=$0;
this._focusedRow=$1;
var $3=this._getPaneScrollerArr();
for(var $4=0;$4<$3.length;$4++){$3[$4].setFocusedCell($0,
$1);
}
if($2){this.scrollCellVisible($0,
$1);
}}},
getFocusedColumn:function(){return this._focusedCol;
},
getFocusedRow:function(){return this._focusedRow;
},
moveFocusedCell:function($0,
$1){var $2=this._focusedCol;
var $3=this._focusedRow;
if($0!=0){var $4=this.getTableColumnModel();
var $5=$4.getVisibleX($2);
var $6=$4.getVisibleColumnCount();
$5=qx.lang.Number.limit($5+$0,
0,
$6-1);
$2=$4.getVisibleColumnAtX($5);
}
if($1!=0){var $7=this.getTableModel();
$3=qx.lang.Number.limit($3+$1,
0,
$7.getRowCount()-1);
}this.setFocusedCell($2,
$3,
true);
},
scrollCellVisible:function($0,
$1){var $2=this.getTableColumnModel();
var $3=$2.getVisibleX($0);
var $4=this._getMetaColumnAtColumnX($3);
if($4!=-1){this.getPaneScroller($4).scrollCellVisible($0,
$1);
}},
isEditing:function(){if(this._focusedCol!=null){var $0=this.getTableColumnModel().getVisibleX(this._focusedCol);
var $1=this._getMetaColumnAtColumnX($0);
return this.getPaneScroller($1).isEditing();
}},
startEditing:function(){if(this._focusedCol!=null){var $0=this.getTableColumnModel().getVisibleX(this._focusedCol);
var $1=this._getMetaColumnAtColumnX($0);
return this.getPaneScroller($1).startEditing();
}return false;
},
stopEditing:function(){if(this._focusedCol!=null){var $0=this.getTableColumnModel().getVisibleX(this._focusedCol);
var $1=this._getMetaColumnAtColumnX($0);
this.getPaneScroller($1).stopEditing();
}},
cancelEditing:function(){if(this._focusedCol!=null){var $0=this.getTableColumnModel().getVisibleX(this._focusedCol);
var $1=this._getMetaColumnAtColumnX($0);
this.getPaneScroller($1).cancelEditing();
}},
postponedUpdateContent:function(){if(!this._updateContentPlanned){qx.client.Timer.once(function(){if(this.getDisposed()){return;
}this.updateContent();
this._updateContentPlanned=false;
qx.ui.core.Widget.flushGlobalQueues();
},
this,
0);
this._updateContentPlanned=true;
}},
updateContent:function(){var $0=this._getPaneScrollerArr();
for(var $1=0;$1<$0.length;$1++){$0[$1]._tablePane._updateContent();
}},
_getMetaColumnAtPageX:function($0){var $1=this._getPaneScrollerArr();
for(var $2=0;$2<$1.length;$2++){var $3=$1[$2].getElement();
if($0>=qx.bom.element.Location.getLeft($3)&&$0<=qx.bom.element.Location.getRight($3)){return $2;
}}return -1;
},
_getMetaColumnAtColumnX:function($0){var $1=this.getMetaColumnCounts();
var $2=0;
for(var $3=0;$3<$1.length;$3++){var $4=$1[$3];
$2+=$4;
if($4==-1||$0<$2){return $3;
}}return -1;
},
_updateStatusBar:function(){if(this.getStatusBarVisible()){var $0=this.getSelectionModel().getSelectedCount();
var $1=this.getTableModel().getRowCount();
var $2;
if($0==0){$2=$1+(($1==1)?$[637]:$[555]);
}else{$2=$0+$[2036]+$1+(($1==1)?$[637]:$[555])+$[1337];
}this._statusBar.setText($2);
}},
_updateScrollerWidths:function(){var $0=this._getPaneScrollerArr();
for(var $1=0;$1<$0.length;$1++){var $2=($1==($0.length-1));
var $3=$2?$[87]:$0[$1].getTablePaneModel().getTotalWidth();
$0[$1].setWidth($3);
}},
_updateScrollBarVisibility:function(){if(this.isSeeable()){var $0=qx.ui.table.pane.Scroller.HORIZONTAL_SCROLLBAR;
var $1=qx.ui.table.pane.Scroller.VERTICAL_SCROLLBAR;
var $2=this._getPaneScrollerArr();
var $3=false;
var $4=false;
for(var $5=0;$5<$2.length;$5++){var $6=($5==($2.length-1));
var $7=$2[$5].getNeededScrollBars($3,
!$6);
if($7&$0){$3=true;
}
if($6&&($7&$1)){$4=true;
}}for(var $5=0;$5<$2.length;$5++){var $6=($5==($2.length-1));
var $8;
$2[$5].setHorizontalScrollBarVisible($3);
if($6){$8=$2[$5].getVerticalScrollBarVisible();
}$2[$5].setVerticalScrollBarVisible($6&&$4);
if($6&&$4!=$8){this.createDispatchDataEvent($[527],
$4);
}}}},
_onColumnVisibilityBtExecuted:function(){if((this._columnVisibilityMenuCloseTime==null)||(new Date().getTime()>this._columnVisibilityMenuCloseTime+200)){this._toggleColumnVisibilityMenu();
}},
_toggleColumnVisibilityMenu:function(){if(!this.getEnabled()){return;
}var $0=new qx.ui.menu.Menu;
$0.addEventListener($[176],
function($1){this._cleanupColumnVisibilityMenu();
this._columnVisibilityMenuCloseTime=new Date().getTime();
},
this);
var $2=this.getTableModel();
var $3=this.getTableColumnModel();
var $4={table:this,
menu:$0};
this.createDispatchDataEvent($[736],
$4,
true);
for(var $5=0;$5<$3.getOverallColumnCount();$5++){var $6=$3.getOverallColumnAtX($5);
var $7=$3.isColumnVisible($6);
var $8={col:$6};
var $9=new qx.ui.menu.CheckBox($2.getColumnName($6),
null,
$7);
var $a=this._createColumnVisibilityCheckBoxHandler($6);
$9._handler=$a;
$9.addEventListener($[117],
$a,
this);
$0.add($9);
}var $4={table:this,
menu:$0};
this.createDispatchDataEvent($[374],
$4,
true);
$0.setParent(this.getTopLevelWidget());
this._columnVisibilityMenu=$0;
var $b=this._columnVisibilityBt.getElement();
$0.setRestrictToPageOnOpen(false);
$0.setTop(qx.bom.element.Location.getBottom($b));
$0.setLeft(-1000);
var $c=this;
window.setTimeout(function(){if($c.getDisposed()){return;
}$0.show();
qx.ui.core.Widget.flushGlobalQueues();
$0.setLeft(qx.bom.element.Location.getRight($b)-$0.getOffsetWidth());
},
0);
},
_cleanupColumnVisibilityMenu:function(){if(this._columnVisibilityMenu!=null&&!this._columnVisibilityMenu.getDisposed()){var $0=this._columnVisibilityMenu.getParent();
if($0){$0.remove(this._columnVisibilityMenu);
}this._columnVisibilityMenu.dispose();
this._columnVisibilityMenu=null;
}},
_createColumnVisibilityCheckBoxHandler:function($0){return function($1){var $2=this.getTableColumnModel();
$2.setColumnVisible($0,
!$2.isColumnVisible($0));
};
},
setColumnWidth:function($0,
$1){this.getTableColumnModel().setColumnWidth($0,
$1);
},
_changeInnerWidth:function($0,
$1){var $2=this;
window.setTimeout(function(){if($2.getDisposed()){return;
}$2.createDispatchEvent($[519]);
$2._updateScrollerWidths();
$2._updateScrollBarVisibility();
qx.ui.core.Widget.flushGlobalQueues();
},
0);
return arguments.callee.base.call(this,
$0,
$1);
},
_changeInnerHeight:function($0,
$1){var $2=this;
window.setTimeout(function(){if($2.getDisposed()){return;
}$2._updateScrollBarVisibility();
qx.ui.core.Widget.flushGlobalQueues();
},
0);
return arguments.callee.base.call(this,
$0,
$1);
},
_afterAppear:function(){arguments.callee.base.call(this);
this._updateScrollBarVisibility();
},
addEventListener:function($0,
$1,
$2){if(arguments.callee.self.__redirectEvents[$0]){for(var $3=0,
$4=this._getPaneScrollerArr();$3<$4.length;$3++){$4[$3].addEventListener.apply($4[$3],
arguments);
}}else{arguments.callee.base.apply(this,
arguments);
}},
removeEventListener:function($0,
$1,
$2){if(arguments.callee.self.__redirectEvents[$0]){for(var $3=0,
$4=this._getPaneScrollerArr();$3<$4.length;$3++){$4[$3].removeEventListener.apply($4[$3],
arguments);
}}else{arguments.callee.base.apply(this,
arguments);
}}},
destruct:function(){this._cleanUpMetaColumns(0);
this._disposeObjects($[1715],
$[1101],
$[956],
$[795],
$[801],
$[465],
$[790]);
}});




/* ID: qx.ui.table.IRowRenderer */
qx.Interface.define($[609],
{members:{updateDataRowElement:function($0,
$1){return true;
},
createRowStyle:function($0){return true;
},
getRowClass:function($0){return true;
}}});




/* ID: qx.ui.table.rowrenderer.Default */
qx.Class.define($[848],
{extend:qx.ui.basic.Terminator,
implement:qx.ui.table.IRowRenderer,
construct:function(){arguments.callee.base.call(this);
this._fontStyle={};
this._fontStyleString=$[0];
this._colors={};
},
properties:{highlightFocusRow:{check:$[2],
init:true},
visualizeFocusedState:{check:$[2],
init:true},
appearance:{refine:true,
init:$[321]},
bgcolFocusedSelected:{check:$[34],
nullable:true,
themeable:true,
init:$[385],
apply:$[1854]},
bgcolFocusedSelectedBlur:{check:$[34],
nullable:true,
themeable:true,
init:$[588],
apply:$[1712]},
bgcolFocused:{check:$[34],
nullable:true,
themeable:true,
init:$[600],
apply:$[1378]},
bgcolFocusedBlur:{check:$[34],
nullable:true,
themeable:true,
init:$[355],
apply:$[2024]},
bgcolSelected:{check:$[34],
nullable:true,
themeable:true,
init:$[380],
apply:$[1984]},
bgcolSelectedBlur:{check:$[34],
nullable:true,
themeable:true,
init:$[558],
apply:$[1807]},
bgcolEven:{check:$[34],
nullable:true,
themeable:true,
init:$[443],
apply:$[2012]},
bgcolOdd:{check:$[34],
nullable:true,
themeable:true,
init:$[490],
apply:$[653]},
colSelected:{check:$[34],
nullable:true,
themeable:true,
init:$[596],
apply:$[1087]},
colNormal:{check:$[34],
nullable:true,
themeable:true,
init:$[321],
apply:$[776]}},
members:{_applyBgcolFocusedSelected:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolFocusedSelected,
this,
$0);
},
_applyBgcolFocusedSelectedBlur:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolFocusedSelectedBlur,
this,
$0);
},
_applyBgcolFocused:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolFocused,
this,
$0);
},
_applyBgcolFocusedBlur:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolFocusedBlur,
this,
$0);
},
_applyBgcolSelected:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolSelected,
this,
$0);
},
_applyBgcolSelectedBlur:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolSelectedBlur,
this,
$0);
},
_applyBgcolEven:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolEven,
this,
$0);
},
_applyBgcolOdd:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleBgcolOdd,
this,
$0);
},
_applyColSelected:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleColSelected,
this,
$0);
},
_applyColNormal:function($0,
$1){qx.theme.manager.Color.getInstance().connect(this._styleColNormal,
this,
$0);
},
_styleBgcolFocusedSelected:function($0,
$1){this._colors.bgcolFocusedSelected=$0;
this._postponedUpdateTableContent();
},
_styleBgcolFocusedSelectedBlur:function($0,
$1){this._colors.bgcolFocusedSelectedBlur=$0;
this._postponedUpdateTableContent();
},
_styleBgcolFocused:function($0,
$1){this._colors.bgcolFocused=$0;
this._postponedUpdateTableContent();
},
_styleBgcolFocusedBlur:function($0,
$1){this._colors.bgcolFocusedBlur=$0;
this._postponedUpdateTableContent();
},
_styleBgcolSelected:function($0,
$1){this._colors.bgcolSelected=$0;
this._postponedUpdateTableContent();
},
_styleBgcolSelectedBlur:function($0,
$1){this._colors.bgcolSelectedBlur=$0;
this._postponedUpdateTableContent();
},
_styleBgcolEven:function($0,
$1){this._colors.bgcolEven=$0;
this._postponedUpdateTableContent();
},
_styleBgcolOdd:function($0,
$1){this._colors.bgcolOdd=$0;
this._postponedUpdateTableContent();
},
_styleColSelected:function($0,
$1){this._colors.colSelected=$0;
this._postponedUpdateTableContent();
},
_styleColNormal:function($0,
$1){this._colors.colNormal=$0;
this._postponedUpdateTableContent();
},
setRowColors:function($0){this._noTableContentUpdate=true;
this.set($0);
delete this._noTableContentUpdate;
this._postponedUpdateTableContent();
},
getRowColors:function(){return {bgcolFocusedSelected:this.getBgcolFocusedSelected(),
bgcolFocusedSelectedBlur:this.getBgcolFocusedSelectedBlur(),
bgcolFocused:this.getBgcolFocused(),
bgcolFocusedBlur:this.getBgcolFocusedBlur(),
bgcolSelected:this.getBgcolSelected(),
bgcolSelectedBlur:this.getBgcolSelectedBlur(),
bgcolEven:this.getBgcolEven(),
bgcolOdd:this.getBgcolOdd(),
colSelected:this.getColSelected(),
colNormal:this.getColNormal()};
},
_applyFont:function($0,
$1){qx.theme.manager.Font.getInstance().connect(this._styleFont,
this,
$0);
},
_styleFont:function($0){this.__font=$0;
this._renderFont();
},
_renderFont:function(){var $0=this.__font;
if($0){$0.renderStyle(this._fontStyle);
this._fontStyleString=$0.generateStyle();
}else{qx.ui.core.Font.resetStyle(this._fontStyle);
this._fontStyleString=$[0];
}this._postponedUpdateTableContent();
},
updateDataRowElement:function($0,
$1){var $2=this._fontStyle;
var $3=$1.style;
$3.fontFamily=$2.fontFamily;
$3.fontSize=$2.fontSize;
$3.fontWeight=$2.fontWeight;
$3.fontStyle=$2.fontStyle;
$3.textDecoration=$2.textDecoration;
if($0.focusedRow&&this.getHighlightFocusRow()){if($0.table.getFocused()||!this.getVisualizeFocusedState()){$3.backgroundColor=$0.selected?this._colors.bgcolFocusedSelected:this._colors.bgcolFocused;
}else{$3.backgroundColor=$0.selected?this._colors.bgcolFocusedSelectedBlur:this._colors.bgcolFocusedBlur;
}}else{if($0.selected){if($0.table.getFocused()||!this.getVisualizeFocusedState()){$3.backgroundColor=this._colors.bgcolSelected;
}else{$3.backgroundColor=this._colors.bgcolSelectedBlur;
}}else{$3.backgroundColor=($0.row%2==0)?this._colors.bgcolEven:this._colors.bgcolOdd;
}}$3.color=$0.selected?this._colors.colSelected:this._colors.colNormal;
},
createRowStyle:function($0){var $1=[];
$1.push($[75]);
$1.push(this._fontStyleString);
$1.push($[1329]);
if($0.focusedRow&&this.getHighlightFocusRow()){if($0.table.getFocused()||!this.getVisualizeFocusedState()){$1.push($0.selected?this._colors.bgcolFocusedSelected:this._colors.bgcolFocused);
}else{$1.push($0.selected?this._colors.bgcolFocusedSelectedBlur:this._colors.bgcolFocusedBlur);
}}else{if($0.selected){if($0.table.getFocused()||!this.getVisualizeFocusedState()){$1.push(this._colors.bgcolSelected);
}else{$1.push(this._colors.bgcolSelectedBlur);
}}else{$1.push(($0.row%2==0)?this._colors.bgcolEven:this._colors.bgcolOdd);
}}$1.push($[2016]);
$1.push($0.selected?this._colors.colSelected:this._colors.colNormal);
return $1.join($[0]);
},
getRowClass:function($0){return $[0];
},
_postponedUpdateTableContent:function(){if(this._noTableContentUpdate){return;
}
if(!this._updateContentPlanned){qx.client.Timer.once(function(){if(this.getDisposed()){return;
}this._updateTableContent();
this._updateContentPlanned=false;
qx.ui.core.Widget.flushGlobalQueues();
},
this,
0);
this._updateContentPlanned=true;
}},
_updateTableContent:function(){if(this._noTableContentUpdate){return;
}var $0=this.getParent();
if($0){$0.updateContent();
}}},
destruct:function(){this._fontStyle=null;
this._colors=null;
}});




/* ID: qx.ui.table.selection.Manager */
qx.Class.define($[1114],
{extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
},
properties:{selectionModel:{check:$[292]}},
members:{handleMouseDown:function($0,
$1){if($1.isLeftButtonPressed()){var $2=this.getSelectionModel();
if(!$2.isSelectedIndex($0)){this._handleSelectEvent($0,
$1);
this._lastMouseDownHandled=true;
}else{this._lastMouseDownHandled=false;
}}else if($1.isRightButtonPressed()&&$1.getModifiers()==0){var $2=this.getSelectionModel();
if(!$2.isSelectedIndex($0)){$2.setSelectionInterval($0,
$0);
}}},
handleMouseUp:function($0,
$1){if($1.isLeftButtonPressed()&&!this._lastMouseDownHandled){this._handleSelectEvent($0,
$1);
}},
handleClick:function($0,
$1){},
handleSelectKeyDown:function($0,
$1){this._handleSelectEvent($0,
$1);
},
handleMoveKeyDown:function($0,
$1){var $2=this.getSelectionModel();
switch($1.getModifiers()){case 0:$2.setSelectionInterval($0,
$0);
break;
case qx.event.type.DomEvent.SHIFT_MASK:var $3=$2.getAnchorSelectionIndex();
if($3==-1){$2.setSelectionInterval($0,
$0);
}else{$2.setSelectionInterval($3,
$0);
}break;
}},
_handleSelectEvent:function($0,
$1){var $2=this.getSelectionModel();
if($1.isShiftPressed()){var $3=$2.getLeadSelectionIndex();
if($0!=$3||$2.isSelectionEmpty()){var $4=$2.getAnchorSelectionIndex();
if($4==-1){$4=$0;
}
if($1.isCtrlOrCommandPressed()){$2.addSelectionInterval($4,
$0);
}else{$2.setSelectionInterval($4,
$0);
}}}else if($1.isCtrlOrCommandPressed()){if($2.isSelectedIndex($0)){$2.removeSelectionInterval($0,
$0);
}else{$2.addSelectionInterval($0,
$0);
}}else{$2.setSelectionInterval($0,
$0);
}}}});




/* ID: qx.ui.table.selection.Model */
qx.Class.define($[292],
{extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
this._selectedRangeArr=[];
this._anchorSelectionIndex=-1;
this._leadSelectionIndex=-1;
this.hasBatchModeRefCount=0;
this._hadChangeEventInBatchMode=false;
},
events:{"changeSelection":$[4]},
statics:{NO_SELECTION:1,
SINGLE_SELECTION:2,
SINGLE_INTERVAL_SELECTION:3,
MULTIPLE_INTERVAL_SELECTION:4,
MULTIPLE_INTERVAL_SELECTION_TOGGLE:5},
properties:{selectionMode:{init:2,
check:[1,
2,
3,
4,
5],
apply:$[1646]}},
members:{_applySelectionMode:function($0){if($0==qx.ui.table.selection.Model.NO_SELECTION){this.clearSelection();
}},
setBatchMode:function($0){if($0){this.hasBatchModeRefCount+=1;
}else{if(this.hasBatchModeRefCount==0){throw new Error("Try to turn off batch mode althoug it was not turned on.");
}this.hasBatchModeRefCount-=1;
if(this._hadChangeEventInBatchMode){this._hadChangeEventInBatchMode=false;
this._fireChangeSelection();
}}return this.hasBatchMode();
},
hasBatchMode:function(){return this.hasBatchModeRefCount>0;
},
getAnchorSelectionIndex:function(){return this._anchorSelectionIndex;
},
getLeadSelectionIndex:function(){return this._leadSelectionIndex;
},
clearSelection:function(){if(!this.isSelectionEmpty()){this._clearSelection();
this._fireChangeSelection();
}},
isSelectionEmpty:function(){return this._selectedRangeArr.length==0;
},
getSelectedCount:function(){var $0=0;
for(var $1=0;$1<this._selectedRangeArr.length;$1++){var $2=this._selectedRangeArr[$1];
$0+=$2.maxIndex-$2.minIndex+1;
}return $0;
},
isSelectedIndex:function($0){for(var $1=0;$1<this._selectedRangeArr.length;$1++){var $2=this._selectedRangeArr[$1];
if($0>=$2.minIndex&&$0<=$2.maxIndex){return true;
}}return false;
},
getSelectedRanges:function(){var $0=[];
for(var $1=0;$1<this._selectedRangeArr.length;$1++){$0.push({minIndex:this._selectedRangeArr[$1].minIndex,
maxIndex:this._selectedRangeArr[$1].maxIndex});
}return $0;
},
iterateSelection:function($0,
$1){for(var $2=0;$2<this._selectedRangeArr.length;$2++){for(var $3=this._selectedRangeArr[$2].minIndex;$3<=this._selectedRangeArr[$2].maxIndex;$3++){$0.call($1,
$3);
}}},
setSelectionInterval:function($0,
$1){var $2=arguments.callee.self;
switch(this.getSelectionMode()){case $2.NO_SELECTION:return;
case $2.SINGLE_SELECTION:$0=$1;
break;
case $2.MULTIPLE_INTERVAL_SELECTION_TOGGLE:this.setBatchMode(true);
try{for(var $3=$0;$3<=$1;$3++){if(!this.isSelectedIndex($3)){this._addSelectionInterval($3,
$3);
}else{this.removeSelectionInterval($3,
$3);
}}}finally{this.setBatchMode(false);
}this._fireChangeSelection();
return;
}this._clearSelection();
this._addSelectionInterval($0,
$1);
this._fireChangeSelection();
},
addSelectionInterval:function($0,
$1){var $2=qx.ui.table.selection.Model;
switch(this.getSelectionMode()){case $2.NO_SELECTION:return;
case $2.MULTIPLE_INTERVAL_SELECTION:case $2.MULTIPLE_INTERVAL_SELECTION_TOGGLE:this._addSelectionInterval($0,
$1);
this._fireChangeSelection();
break;
default:this.setSelectionInterval($0,
$1);
break;
}},
removeSelectionInterval:function($0,
$1){this._anchorSelectionIndex=$0;
this._leadSelectionIndex=$1;
var $2=Math.min($0,
$1);
var $3=Math.max($0,
$1);
for(var $4=0;$4<this._selectedRangeArr.length;$4++){var $5=this._selectedRangeArr[$4];
if($5.minIndex>$3){break;
}else if($5.maxIndex>=$2){var $6=($5.minIndex>=$2)&&($5.minIndex<=$3);
var $7=($5.maxIndex>=$2)&&($5.maxIndex<=$3);
if($6&&$7){this._selectedRangeArr.splice($4,
1);
$4--;
}else if($6){$5.minIndex=$3+1;
}else if($7){$5.maxIndex=$2-1;
}else{var $8={minIndex:$3+1,
maxIndex:$5.maxIndex};
this._selectedRangeArr.splice($4+1,
0,
$8);
$5.maxIndex=$2-1;
break;
}}}this._fireChangeSelection();
},
_clearSelection:function(){this._selectedRangeArr=[];
this._anchorSelectionIndex=-1;
this._leadSelectionIndex=-1;
},
_addSelectionInterval:function($0,
$1){this._anchorSelectionIndex=$0;
this._leadSelectionIndex=$1;
var $2=Math.min($0,
$1);
var $3=Math.max($0,
$1);
var $4=0;
for(;$4<this._selectedRangeArr.length;$4++){var $5=this._selectedRangeArr[$4];
if($5.minIndex>$2){break;
}}this._selectedRangeArr.splice($4,
0,
{minIndex:$2,
maxIndex:$3});
var $6=this._selectedRangeArr[0];
for(var $7=1;$7<this._selectedRangeArr.length;$7++){var $5=this._selectedRangeArr[$7];
if($6.maxIndex+1>=$5.minIndex){$6.maxIndex=Math.max($6.maxIndex,
$5.maxIndex);
this._selectedRangeArr.splice($7,
1);
$7--;
}else{$6=$5;
}}},
_dumpRanges:function(){var $0=$[1128];
for(var $1=0;$1<this._selectedRangeArr.length;$1++){var $2=this._selectedRangeArr[$1];
$0+=$[639]+$2.minIndex+$[817]+$2.maxIndex+$[106];
}this.debug($0);
},
_fireChangeSelection:function(){if(this.hasBatchMode()){this._hadChangeEventInBatchMode=true;
}this.createDispatchEvent($[341]);
}},
destruct:function(){this._disposeFields($[1290]);
}});




/* ID: qx.ui.table.IHeaderRenderer */
qx.Interface.define($[979],
{members:{createHeaderCell:function($0){return true;
},
updateHeaderCell:function($0,
$1){return true;
}}});




/* ID: qx.ui.table.headerrenderer.Default */
qx.Class.define($[1835],
{extend:qx.core.Object,
implement:qx.ui.table.IHeaderRenderer,
statics:{STATE_SORTED:"sorted",
STATE_SORTED_ASCENDING:"sortedAscending"},
properties:{toolTip:{check:$[9],
init:null,
nullable:true}},
members:{createHeaderCell:function($0){var $1=new qx.ui.basic.Atom();
$1.setAppearance($[603]);
$1.setSelectable(false);
this.updateHeaderCell($0,
$1);
return $1;
},
updateHeaderCell:function($0,
$1){var $2=qx.ui.table.headerrenderer.Default;
$1.setLabel($0.name);
var $3=$1.getToolTip();
if(this.getToolTip()!=null){if($3==null){$3=new qx.ui.popup.ToolTip(this.getToolTip());
$1.setToolTip($3);
}else{$3.getAtom().setLabel(this.getToolTip());
}}$0.sorted?$1.addState($2.STATE_SORTED):$1.removeState($2.STATE_SORTED);
$0.sortedAscending?$1.addState($2.STATE_SORTED_ASCENDING):$1.removeState($2.STATE_SORTED_ASCENDING);
}}});




/* ID: qx.ui.popup.Popup */
qx.Class.define($[844],
{extend:qx.ui.layout.CanvasLayout,
construct:function(){arguments.callee.base.call(this);
this.setZIndex(this._minZIndex);
if(this._isFocusRoot){this.activateFocusRoot();
}this.initHeight();
this.initWidth();
if(qx.core.Setting.get($[607])){this.setRestrictToPageLeft(qx.core.Setting.get($[607]));
}
if(qx.core.Setting.get($[530])){this.setRestrictToPageRight(qx.core.Setting.get($[530]));
}
if(qx.core.Setting.get($[460])){this.setRestrictToPageTop(qx.core.Setting.get($[460]));
}
if(qx.core.Setting.get($[376])){this.setRestrictToPageBottom(qx.core.Setting.get($[376]));
}},
properties:{appearance:{refine:true,
init:$[491]},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
display:{refine:true,
init:false},
autoHide:{check:$[2],
init:true},
centered:{check:$[2],
init:false},
restrictToPageOnOpen:{check:$[2],
init:true},
restrictToPageLeft:{check:$[6],
init:0},
restrictToPageRight:{check:$[6],
init:0},
restrictToPageTop:{check:$[6],
init:0},
restrictToPageBottom:{check:$[6],
init:0}},
members:{_isFocusRoot:true,
_showTimeStamp:(new Date(0)).valueOf(),
_hideTimeStamp:(new Date(0)).valueOf(),
_beforeAppear:function(){arguments.callee.base.call(this);
if(this.getRestrictToPageOnOpen()){this._wantedLeft=this.getLeft();
if(this._wantedLeft!=null){this.setLeft(10000);
if(this.getElement()!=null){this.getElement().style.left=10000;
}}}qx.ui.popup.PopupManager.getInstance().add(this);
qx.ui.popup.PopupManager.getInstance().update(this);
this._showTimeStamp=(new Date).valueOf();
this.bringToFront();
},
_beforeDisappear:function(){arguments.callee.base.call(this);
qx.ui.popup.PopupManager.getInstance().remove(this);
this._hideTimeStamp=(new Date).valueOf();
},
_afterAppear:function(){arguments.callee.base.call(this);
if(this.getRestrictToPageOnOpen()){var $0=qx.ui.core.ClientDocument.getInstance();
var $1=$0.getClientWidth();
var $2=$0.getClientHeight();
var $3=qx.bom.Viewport.getScrollTop();
var $4=qx.bom.Viewport.getScrollLeft();
var $5=this.getRestrictToPageLeft()+$4;
var $6=this.getRestrictToPageRight()-$4;
var $7=this.getRestrictToPageTop()+$3;
var $8=this.getRestrictToPageBottom()-$3;
var $9=(this._wantedLeft==null)?this.getLeft():this._wantedLeft;
var $a=this.getTop();
var $b=this.getBoxWidth();
var $c=this.getBoxHeight();
var $d=this.getLeft();
var $e=$a;
if($9+$b>$1-$6){$9=$1-$6-$b;
}
if($a+$c>$2-$8){$a=$2-$8-$c;
}
if($9<$5){$9=$5;
}
if($a<$7){$a=$7;
}
if($9!=$d||$a!=$e){var $f=this;
window.setTimeout(function(){$f.setLeft($9);
$f.setTop($a);
},
0);
}}},
_makeActive:function(){this.getFocusRoot().setActiveChild(this);
},
_makeInactive:function(){var $0=this.getFocusRoot();
var $1=$0.getActiveChild();
if($1==this){$0.setActiveChild($0);
}},
_minZIndex:1e6,
bringToFront:function(){this.setZIndex(this._minZIndex+1000000);
this._sendTo();
},
sendToBack:function(){this.setZIndex(this._minZIndex+1);
this._sendTo();
},
_sendTo:function(){var $0=qx.lang.Object.getValues(qx.ui.popup.PopupManager.getInstance().getAll());
if(qx.Class.isDefined($[166])){var $1=qx.lang.Object.getValues(qx.ui.menu.Manager.getInstance().getAll());
var $2=$0.concat($1).sort(qx.util.Compare.byZIndex);
}else{var $2=$0.sort(qx.util.Compare.byZIndex);
}var $3=$2.length;
var $4=this._minZIndex;
for(var $5=0;$5<$3;$5++){$2[$5].setZIndex($4++);
}},
getShowTimeStamp:function(){return this._showTimeStamp;
},
getHideTimeStamp:function(){return this._hideTimeStamp;
},
positionRelativeTo:function($0,
$1,
$2){if($0 instanceof qx.ui.core.Widget){$0=$0.getElement();
}
if($0){var $3=qx.bom.element.Location.get($0);
this.setLocation($3.left+($1||0),
$3.top+($2||0));
}else{this.warn('Missing reference element');
}},
centerToBrowser:function(){var $0=qx.ui.core.ClientDocument.getInstance();
var $1=($0.getClientWidth()-this.getBoxWidth())/2;
var $2=($0.getClientHeight()-this.getBoxHeight())/2;
this.setLeft($1<0?0:$1);
this.setTop($2<0?0:$2);
}},
settings:{"qx.restrictToPageLeft":null,
"qx.restrictToPageRight":null,
"qx.restrictToPageTop":null,
"qx.restrictToPageBottom":null},
destruct:function(){this._disposeFields($[1136],
$[1335]);
}});




/* ID: qx.ui.popup.PopupManager */
qx.Class.define($[184],
{type:$[24],
extend:qx.util.manager.Object,
construct:function(){arguments.callee.base.call(this);
},
members:{update:function($0){if(!($0 instanceof qx.ui.core.Widget)){$0=null;
}var $1,
$2;
var $3=this.getAll();
for($2 in $3){$1=$3[$2];
if(!$1.getAutoHide()||$0==$1||$1.contains($0)){continue;
}
if(qx.Class.isDefined($[261])&&$0 instanceof qx.ui.popup.ToolTip&&!($1 instanceof qx.ui.popup.ToolTip)){continue;
}$1.hide();
}}}});




/* ID: qx.util.Compare */
qx.Class.define($[1275],
{statics:{byString:function($0,
$1){return $0==$1?0:$0>$1?1:-1;
},
byStringCaseInsensitive:function($0,
$1){return qx.util.Compare.byString($0.toLowerCase(),
$1.toLowerCase());
},
byStringUmlautsShort:function($0,
$1){return qx.util.Compare.byString(qx.util.Normalization.umlautsShort($0),
qx.util.Normalization.umlautsShort($1));
},
byStringUmlautsShortCaseInsensitive:function($0,
$1){return qx.util.Compare.byString(qx.util.Normalization.umlautsShort($0).toLowerCase(),
qx.util.Normalization.umlautsShort($1).toLowerCase());
},
byStringUmlautsLong:function($0,
$1){return qx.util.Compare.byString(qx.util.Normalization.umlautsLong($0),
qx.util.Normalization.umlautsLong($1));
},
byStringUmlautsLongCaseInsensitive:function($0,
$1){return qx.util.Compare.byString(qx.util.Normalization.umlautsLong($0).toLowerCase(),
qx.util.Normalization.umlautsLong($1).toLowerCase());
},
byFloat:function($0,
$1){return $0-$1;
},
byIntegerString:function($0,
$1){return parseInt($0)-parseInt($1);
},
byFloatString:function($0,
$1){return parseFloat($0)-parseFloat($1);
},
byIPv4:function($0,
$1){var $2=$0.split($[47],
4);
var $3=$1.split($[47],
4);
for(var $4=0;$4<3;$4++){$0=parseInt($2[$4]);
$1=parseInt($3[$4]);
if($0!=$1){return $0-$1;
}}return parseInt($2[3])-parseInt($3[3]);
},
byZIndex:function($0,
$1){return $0.getZIndex()-$1.getZIndex();
}},
defer:function($0){$0.byInteger=$0.byNumber=$0.byFloat;
$0.byNumberString=$0.byFloatString;
}});




/* ID: qx.util.Normalization */
qx.Class.define($[655],
{statics:{__umlautsRegExp:new RegExp($[1966],
$[315]),
__umlautsShortData:{"\xC4":$[205],
"\xD6":$[1298],
"\xDC":$[824],
"\xE4":$[350],
"\xF6":$[875],
"\xFC":$[1846],
"\xDF":$[346]},
__umlautsShort:function($0){return qx.util.Normalization.__umlautsShortData[$0];
},
umlautsShort:function($0){return $0.replace(qx.util.Normalization.__umlautsRegExp,
qx.lang.Function.bind(this.__umlautsShort,
this));
},
__umlautsLongData:{"\xC4":$[1293],
"\xD6":$[1861],
"\xDC":$[1452],
"\xE4":$[1217],
"\xF6":$[1756],
"\xFC":$[1388],
"\xDF":$[597]},
__umlautsLong:function($0){return qx.util.Normalization.__umlautsLongData[$0];
},
umlautsLong:function($0){return $0.replace(qx.util.Normalization.__umlautsRegExp,
qx.lang.Function.bind(this.__umlautsLong,
this));
}}});




/* ID: qx.bom.element.Location */
qx.Class.define($[1451],
{statics:{__style:function($0,
$1){return qx.bom.element.Style.get($0,
$1,
qx.bom.element.Style.COMPUTED_MODE,
false);
},
__num:function($0,
$1){return parseInt(qx.bom.element.Style.get($0,
$1,
qx.bom.element.Style.COMPUTED_MODE,
false))||0;
},
__computeScroll:function($0){var $1=0,
$2=0;
if(qx.core.Variant.isSet($[1],
$[20])&&$0.getBoundingClientRect){var $3=qx.dom.Node.getWindow($0);
$1-=qx.bom.Viewport.getScrollLeft($3);
$2-=qx.bom.Viewport.getScrollTop($3);
}else{var $4=qx.dom.Node.getDocument($0).body;
$0=$0.parentNode;
while($0&&$0!=$4){$1+=$0.scrollLeft;
$2+=$0.scrollTop;
$0=$0.parentNode;
}}return {left:$1,
top:$2};
},
__computeBody:qx.core.Variant.select($[1],
{"mshtml":function($0){var $1=qx.dom.Node.getDocument($0);
var $2=$1.body;
var $3=$2.offsetLeft;
var $4=$2.offsetTop;
$3-=this.__num($2,
$[83]);
$4-=this.__num($2,
$[76]);
if($1.compatMode===$[98]){$3+=this.__num($2,
$[174]);
$4+=this.__num($2,
$[168]);
}return {left:$3,
top:$4};
},
"webkit":function($0){var $1=qx.dom.Node.getDocument($0);
var $2=$1.body;
var $3=$2.offsetLeft;
var $4=$2.offsetTop;
$3+=this.__num($2,
$[83]);
$4+=this.__num($2,
$[76]);
if($1.compatMode===$[98]){$3+=this.__num($2,
$[174]);
$4+=this.__num($2,
$[168]);
}return {left:$3,
top:$4};
},
"gecko":function($0){var $1=qx.dom.Node.getDocument($0).body;
var $2=$1.offsetLeft;
var $3=$1.offsetTop;
if(qx.bom.element.Dimension.getBoxSizing($1)!==$[258]){$2+=this.__num($1,
$[83]);
$3+=this.__num($1,
$[76]);
if(!$0.getBoundingClientRect){var $4;
while($0){if(this.__style($0,
$[90])===$[63]||this.__style($0,
$[90])===$[133]){$4=true;
break;
}$0=$0.offsetParent;
}
if(!$4){$2+=this.__num($1,
$[83]);
$3+=this.__num($1,
$[76]);
}}}return {left:$2,
top:$3};
},
"default":function($0){var $1=qx.dom.Node.getDocument($0).body;
var $2=$1.offsetLeft;
var $3=$1.offsetTop;
return {left:$2,
top:$3};
}}),
__computeOffset:qx.core.Variant.select($[1],
{"mshtml|webkit":function($0){var $1=qx.dom.Node.getDocument($0);
if($0.getBoundingClientRect){var $2=$0.getBoundingClientRect();
var $3=$2.left;
var $4=$2.top;
if($1.compatMode===$[98]){$3-=this.__num($0,
$[83]);
$4-=this.__num($0,
$[76]);
}}else{var $3=$0.offsetLeft;
var $4=$0.offsetTop;
$0=$0.offsetParent;
var $5=$1.body;
while($0&&$0!=$5){$3+=$0.offsetLeft;
$4+=$0.offsetTop;
$3+=this.__num($0,
$[83]);
$4+=this.__num($0,
$[76]);
$0=$0.offsetParent;
}}return {left:$3,
top:$4};
},
"gecko":function($0){if($0.getBoundingClientRect){var $1=$0.getBoundingClientRect();
var $2=Math.round($1.left);
var $3=Math.round($1.top);
}else{var $2=0;
var $3=0;
var $4=qx.dom.Node.getDocument($0).body;
var $5=qx.bom.element.Dimension;
if($5.getBoxSizing($0)!==$[258]){$2-=this.__num($0,
$[83]);
$3-=this.__num($0,
$[76]);
}
while($0&&$0!==$4){$2+=$0.offsetLeft;
$3+=$0.offsetTop;
if($5.getBoxSizing($0)!==$[258]){$2+=this.__num($0,
$[83]);
$3+=this.__num($0,
$[76]);
}if($0.parentNode&&this.__style($0.parentNode,
$[71])!=$[1908]){$2+=this.__num($0.parentNode,
$[83]);
$3+=this.__num($0.parentNode,
$[76]);
}$0=$0.offsetParent;
}}return {left:$2,
top:$3};
},
"default":function($0){var $1=0;
var $2=0;
var $3=qx.dom.Node.getDocument($0).body;
while($0&&$0!==$3){$1+=$0.offsetLeft;
$2+=$0.offsetTop;
$0=$0.offsetParent;
}return {left:$1,
top:$2};
}}),
get:function($0,
$1){var $2=this.__computeBody($0);
if($0.tagName==$[991]){var $3=$2.left;
var $4=$2.top;
}else{var $5=this.__computeOffset($0);
var $6=this.__computeScroll($0);
var $3=$5.left+$2.left-$6.left;
var $4=$5.top+$2.top-$6.top;
}var $7=$3+$0.offsetWidth;
var $8=$4+$0.offsetHeight;
if($1){switch($1){case $[497]:$3-=this.__num($0,
$[174]);
$4-=this.__num($0,
$[168]);
$7+=this.__num($0,
$[242]);
$8+=this.__num($0,
$[257]);
break;
case $[642]:$3+=this.__num($0,
$[264]);
$4+=this.__num($0,
$[228]);
$7-=this.__num($0,
$[267]);
$8-=this.__num($0,
$[252]);
case $[720]:$3+=this.__num($0,
$[83]);
$4+=this.__num($0,
$[76]);
$7-=this.__num($0,
$[483]);
$8-=this.__num($0,
$[386]);
break;
}}return {left:$3,
top:$4,
right:$7,
bottom:$8};
},
getLeft:function($0,
$1){return this.get($0,
$1).left;
},
getTop:function($0,
$1){return this.get($0,
$1).top;
},
getRight:function($0,
$1){return this.get($0,
$1).right;
},
getBottom:function($0,
$1){return this.get($0,
$1).bottom;
},
getRelative:function($0,
$1){var $2=this.get($0);
var $3=this.get($1);
return {left:$2.left-$3.left,
top:$2.top-$3.top};
}}});




/* ID: qx.bom.element.Style */
qx.Class.define($[1113],
{statics:{__hints:{names:{"float":qx.core.Variant.isSet($[1],
$[20])?$[2026]:$[1429],
"boxSizing":qx.core.Variant.isSet($[1],
$[25])?$[1384]:$[535]},
mshtmlPixel:{width:$[1208],
height:$[932],
left:$[1594],
right:$[1213],
top:$[1514],
bottom:$[692]},
special:{clip:true,
cursor:true,
opacity:true,
overflowX:true,
overflowY:true}},
setCss:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1){$0.style.cssText=$1;
},
"default":function($0,
$1){$0.setAttribute($[48],
$1);
}}),
getCss:qx.core.Variant.select($[1],
{"mshtml":function($0){return $0.style.cssText.toLowerCase();
},
"default":function($0){return $0.getAttribute($[48]);
}}),
COMPUTED_MODE:1,
CASCADED_MODE:2,
LOCAL_MODE:3,
set:function($0,
$1,
$2,
$3){var $4=this.__hints;
$1=$4.names[$1]||$1;
$0.style[$1]=$2||$[0];
},
reset:function($0,
$1,
$2){var $3=this.__hints;
$1=$3.names[$1]||$1;
$0.style[$1]=$[0];
},
get:qx.core.Variant.select($[1],
{"mshtml":function($0,
$1,
$2,
$3){var $4=this.__hints;
$1=$4.names[$1]||$1;
switch($2){case this.LOCAL_MODE:return $0.style[$1]||$[0];
case this.CASCADED_MODE:return $0.$5[$1];
default:var $5=$0.$5[$1];
if(/^-?[\.\d]+(px)?$/i.test($5)){return $5;
}var $6=$4.mshtmlPixel[$1];
if($6){var $7=$0.style[$1];
$0.style[$1]=$5||0;
var $8=$0.style[$6]+$[46];
$0.style[$1]=$7;
return $8;
}if(/^-?[\.\d]+(em|pt|%)?$/i.test($5)){throw new Error("Untranslated computed property value: "+$1+". Only pixel values work well across different clients.");
}return $5;
}},
"default":function($0,
$1,
$2,
$3){var $4=this.__hints;
$1=$4.names[$1]||$1;
switch($2){case this.LOCAL_MODE:return $0.style[$1];
case this.CASCADED_MODE:if($0.currentStyle){return $0.currentStyle[$1];
}throw new Error("Cascaded styles are not supported in this browser!");
default:var $5=qx.dom.Node.getDocument($0);
var $6=$5.defaultView.getComputedStyle($0,
null);
return $6?$6[$1]:null;
}}})}});




/* ID: qx.bom.element.Dimension */
qx.Class.define($[768],
{statics:{getWidth:function($0){return $0.offsetWidth;
},
getHeight:function($0){return $0.offsetHeight;
},
getClientWidth:function($0){return $0.clientWidth;
},
getClientHeight:function($0){return $0.clientHeight;
},
getScrollWidth:function($0){return $0.scrollWidth;
},
getScrollHeight:function($0){return $0.scrollHeight;
},
__nativeBorderBox:{tags:{button:true,
select:true},
types:{search:true,
button:true,
submit:true,
reset:true,
checkbox:true,
radio:true}},
__usesNativeBorderBox:function($0){var $1=this.__nativeBorderBox;
return $1.tags[$0.tagName.toLowerCase()]||$1.types[$0.type];
},
setBoxSizing:qx.core.Variant.select($[1],
{"gecko":function($0,
$1){$0.style.MozBoxSizing=$1||$[0];
},
"mshtml":function($0,
$1){},
"default":function($0,
$1){$0.style.boxSizing=$1||$[0];
}}),
getBoxSizing:qx.core.Variant.select($[1],
{"gecko":function($0){return qx.bom.element.Style.get($0,
$[1147],
qx.bom.element.Style.COMPUTED_MODE,
false);
},
"mshtml":function($0){if(qx.bom.Document.isStandardMode(qx.dom.Node.getDocument($0))){if(!this.__usesNativeBorderBox($0)){return $[1865];
}}return $[258];
},
"default":function($0){return qx.bom.element.Style.get($0,
$[535],
qx.bom.element.Style.COMPUTED_MODE,
false);
}})}});




/* ID: qx.bom.Document */
qx.Class.define($[1411],
{statics:{isQuirksMode:function($0){return ($0||window).document.compatMode!==$[98];
},
isStandardMode:function($0){return ($0||window).document.compatMode===$[98];
},
getWidth:function($0){var $1=($0||window).document;
var $2=qx.bom.Viewport.getWidth($0);
var $3=$1.compatMode===$[98]?$1.documentElement.scrollWidth:$1.body.scrollWidth;
return Math.max($3,
$2);
},
getHeight:function($0){var $1=($0||window).document;
var $2=qx.bom.Viewport.getHeight($0);
var $3=$1.compatMode===$[98]?$1.documentElement.scrollHeight:$1.body.scrollHeight;
return Math.max($3,
$2);
}}});




/* ID: qx.ui.popup.PopupAtom */
qx.Class.define($[1439],
{extend:qx.ui.popup.Popup,
construct:function($0,
$1){arguments.callee.base.call(this);
this._atom=new qx.ui.basic.Atom($0,
$1);
this._atom.setParent(this);
},
members:{_isFocusRoot:false,
getAtom:function(){return this._atom;
}},
destruct:function(){this._disposeObjects($[909]);
}});




/* ID: qx.ui.popup.ToolTip */
qx.Class.define($[261],
{extend:qx.ui.popup.PopupAtom,
construct:function($0,
$1){arguments.callee.base.call(this,
$0,
$1);
this.setStyleProperty($[158],
$[1481]);
this._showTimer=new qx.client.Timer(this.getShowInterval());
this._showTimer.addEventListener($[67],
this._onshowtimer,
this);
this._hideTimer=new qx.client.Timer(this.getHideInterval());
this._hideTimer.addEventListener($[67],
this._onhidetimer,
this);
this.addEventListener($[86],
this._onmouseover);
this.addEventListener($[113],
this._onmouseover);
},
properties:{appearance:{refine:true,
init:$[1171]},
hideOnHover:{check:$[2],
init:true},
mousePointerOffsetX:{check:$[6],
init:1},
mousePointerOffsetY:{check:$[6],
init:20},
showInterval:{check:$[6],
init:1000,
apply:$[828]},
hideInterval:{check:$[6],
init:4000,
apply:$[989]},
boundToWidget:{check:$[112],
apply:$[836]}},
members:{_minZIndex:1e7,
_applyHideInterval:function($0,
$1){this._hideTimer.setInterval($0);
},
_applyShowInterval:function($0,
$1){this._showTimer.setInterval($0);
},
_applyBoundToWidget:function($0,
$1){if($0){this.setParent($0.getTopLevelWidget());
}else if($1){this.setParent(null);
}},
_beforeAppear:function(){arguments.callee.base.call(this);
this._stopShowTimer();
this._startHideTimer();
},
_beforeDisappear:function(){arguments.callee.base.call(this);
this._stopHideTimer();
},
_afterAppear:function(){arguments.callee.base.call(this);
if(this.getRestrictToPageOnOpen()){var $0=qx.ui.core.ClientDocument.getInstance();
var $1=$0.getClientWidth();
var $2=$0.getClientHeight();
var $3=parseInt(this.getRestrictToPageLeft());
var $4=parseInt(this.getRestrictToPageRight());
var $5=parseInt(this.getRestrictToPageTop());
var $6=parseInt(this.getRestrictToPageBottom());
var $7=(this._wantedLeft==null)?this.getLeft():this._wantedLeft;
var $8=this.getTop();
var $9=this.getBoxWidth();
var $a=this.getBoxHeight();
var $b=qx.event.type.MouseEvent.getPageX();
var $c=qx.event.type.MouseEvent.getPageY();
var $d=this.getLeft();
var $e=$8;
if($7+$9>$1-$4){$7=$1-$4-$9;
}
if($8+$a>$2-$6){$8=$2-$6-$a;
}
if($7<$3){$7=$3;
}
if($8<$5){$8=$5;
}if($7<=$b&&$b<=$7+$9&&$8<=$c&&$c<=$8+$a){var $f=$c-$8;
var $g=$f-$a;
var $h=$b-$7;
var $i=$h-$9;
var $j=Math.max(0,
$5-($8+$g));
var $k=Math.max(0,
$8+$a+$f-($2-$6));
var $l=Math.max(0,
$3-($7+$i));
var $m=Math.max(0,
$7+$9+$h-($1-$4));
var $n=[[0,
$g,
$j],
[0,
$f,
$k],
[$i,
0,
$l],
[$h,
0,
$m]];
$n.sort(function($o,
$p){return $o[2]-$p[2]||(Math.abs($o[0])+Math.abs($o[1]))-(Math.abs($p[0])+Math.abs($p[1]));
});
var $q=$n[0];
$7=$7+$q[0];
$8=$8+$q[1];
}
if($7!=$d||$8!=$e){var $r=this;
window.setTimeout(function(){$r.setLeft($7);
$r.setTop($8);
},
0);
}}},
_startShowTimer:function(){if(!this._showTimer.getEnabled()){this._showTimer.start();
}},
_startHideTimer:function(){if(!this._hideTimer.getEnabled()){this._hideTimer.start();
}},
_stopShowTimer:function(){if(this._showTimer.getEnabled()){this._showTimer.stop();
}},
_stopHideTimer:function(){if(this._hideTimer.getEnabled()){this._hideTimer.stop();
}},
_onmouseover:function($0){if(this.getHideOnHover()){this.hide();
}},
_onshowtimer:function($0){this.setLeft(qx.event.type.MouseEvent.getPageX()+this.getMousePointerOffsetX());
this.setTop(qx.event.type.MouseEvent.getPageY()+this.getMousePointerOffsetY());
this.show();
},
_onhidetimer:function($0){return this.hide();
}},
destruct:function(){this._disposeObjects($[815],
$[707]);
}});




/* ID: qx.ui.popup.ToolTipManager */
qx.Class.define($[165],
{type:$[24],
extend:qx.util.manager.Object,
properties:{currentToolTip:{check:$[261],
nullable:true,
apply:$[1988]}},
members:{_applyCurrentToolTip:function($0,
$1){if($1&&$1.contains($0)){return;
}if($1&&!$1.isDisposed()){$1.hide();
$1._stopShowTimer();
$1._stopHideTimer();
}if($0){$0._startShowTimer();
}},
handleMouseOver:function($0){var $1=$0.getTarget();
var $2;
if(!($1 instanceof qx.ui.core.Widget)&&$1.nodeType==1){$1=qx.event.handler.EventHandler.getTargetObject($1);
}while($1!=null&&!($2=$1.getToolTip())){$1=$1.getParent();
}if($2!=null){$2.setBoundToWidget($1);
}this.setCurrentToolTip($2);
},
handleMouseOut:function($0){var $1=$0.getTarget();
var $2=$0.getRelatedTarget();
var $3=this.getCurrentToolTip();
if($3&&($2==$3||$3.contains($2))){return;
}if($2&&$1&&$1.contains($2)){return;
}if($3&&!$2){this.setCurrentToolTip(null);
}},
handleFocus:function($0){var $1=$0.getTarget();
var $2=$1.getToolTip();
if($2!=null){$2.setBoundToWidget($1);
this.setCurrentToolTip($2);
}},
handleBlur:function($0){var $1=$0.getTarget();
if(!$1){return;
}var $2=this.getCurrentToolTip();
if($2&&$2==$1.getToolTip()){this.setCurrentToolTip(null);
}}}});




/* ID: qx.ui.table.ICellRenderer */
qx.Interface.define($[677],
{members:{createDataCellHtml:function($0,
$1){return true;
}}});




/* ID: qx.ui.table.cellrenderer.Abstract */
qx.Class.define($[2022],
{type:$[82],
implement:qx.ui.table.ICellRenderer,
extend:qx.core.Object,
construct:function(){var $0=arguments.callee.self;
if(!$0.stylesheet){$0.stylesheet=qx.html.StyleSheet.createElement($[1574]+$[884]+$[1350]+$[1660]+$[1830]+$[1137]+$[1635]+$[2002]+$[1334]+$[1151]+$[1814]+(qx.core.Variant.isSet($[1],
$[20])?$[263]:$[1089])+$[199]+$[1645]+$[1478]+$[322]+$[1368]+$[1980]+$[322]+$[1746]+$[1793]+$[322]);
}},
members:{_getCellClass:function($0){return $[641];
},
_getCellStyle:function($0){return $0.style||$[0];
},
_getContentHtml:function($0){return $0.value||$[0];
},
createDataCellHtml:function($0,
$1){$1.push($[1197],
this._getCellClass($0),
$[1142],
$[997],
$0.styleLeft,
$[513],
$[1023],
$0.styleWidth,
$[513],
this._getCellStyle($0),
$[395],
this._getContentHtml($0),
$[578]);
}}});




/* ID: qx.ui.table.cellrenderer.Default */
qx.Class.define($[1057],
{extend:qx.ui.table.cellrenderer.Abstract,
statics:{STYLEFLAG_ALIGN_RIGHT:1,
STYLEFLAG_BOLD:2,
STYLEFLAG_ITALIC:4},
properties:{useAutoAlign:{check:$[62],
init:true}},
members:{_getStyleFlags:function($0){if(this.getUseAutoAlign()){if(typeof $0.value==$[54]){return qx.ui.table.cellrenderer.Default.STYLEFLAG_ALIGN_RIGHT;
}}},
_getCellClass:function($0){var $1=arguments.callee.base.call(this,
$0);
if(!$1){return $[0];
}var $2=this._getStyleFlags($0);
if($2&qx.ui.table.cellrenderer.Default.STYLEFLAG_ALIGN_RIGHT){$1+=$[1460];
}
if($2&qx.ui.table.cellrenderer.Default.STYLEFLAG_BOLD){$1+=$[1168];
}
if($2&qx.ui.table.cellrenderer.Default.STYLEFLAG_ITALIC){$1+=$[1719];
}return $1;
},
_getContentHtml:function($0){return qx.html.String.escape(this._formatValue($0));
},
_formatValue:function($0){var $1=$0.value;
if($1==null){return $[0];
}
if(typeof $1==$[8]){return $1;
}else if(typeof $1==$[54]){if(!qx.ui.table.cellrenderer.Default._numberFormat){qx.ui.table.cellrenderer.Default._numberFormat=new qx.util.format.NumberFormat();
qx.ui.table.cellrenderer.Default._numberFormat.setMaximumFractionDigits(2);
}res=qx.ui.table.cellrenderer.Default._numberFormat.format($1);
}else if($1 instanceof Date){res=qx.util.format.DateFormat.getDateInstance().format($1);
}else{res=$1;
}return res;
}}});




/* ID: qx.util.format.Format */
qx.Class.define($[841],
{extend:qx.core.Object,
type:$[82],
construct:function(){arguments.callee.base.call(this);
},
members:{format:function($0){throw new Error("format is abstract");
},
parse:function($0){throw new Error("parse is abstract");
}}});




/* ID: qx.util.format.NumberFormat */
qx.Class.define($[391],
{extend:qx.util.format.Format,
construct:function($0){arguments.callee.base.call(this);
this._locale=$0;
},
statics:{getIntegerInstance:function(){var $0=qx.util.format.NumberFormat;
if($0._integerInstance==null){$0._integerInstance=new $0();
$0._integerInstance.setMaximumFractionDigits(0);
}return $0._integerInstance;
},
getInstance:qx.lang.Function.returnInstance},
properties:{minimumIntegerDigits:{check:$[12],
init:0},
maximumIntegerDigits:{check:$[12],
nullable:true},
minimumFractionDigits:{check:$[12],
init:0},
maximumFractionDigits:{check:$[12],
nullable:true},
groupingUsed:{check:$[2],
init:true},
prefix:{check:$[9],
init:$[0]},
postfix:{check:$[9],
init:$[0]}},
members:{format:function($0){var $1=qx.util.format.NumberFormat;
switch($0){case Infinity:return $[918];
case -Infinity:return $[934];
case NaN:return $[837];
}var $2=($0<0);
if($2){$0=-$0;
}
if(this.getMaximumFractionDigits()!=null){var $3=Math.pow(10,
this.getMaximumFractionDigits());
$0=Math.round($0*$3)/$3;
}var $4=String(Math.floor($0)).length;
var $5=$[0]+$0;
var $6=$5.substring(0,
$4);
while($6.length<this.getMinimumIntegerDigits()){$6=$[56]+$6;
}
if(this.getMaximumIntegerDigits()!=null&&$6.length>this.getMaximumIntegerDigits()){$6=$6.substring($6.length-this.getMaximumIntegerDigits());
}var $7=$5.substring($4+1);
while($7.length<this.getMinimumFractionDigits()){$7+=$[56];
}
if(this.getMaximumFractionDigits()!=null&&$7.length>this.getMaximumFractionDigits()){$7=$7.substring(0,
this.getMaximumFractionDigits());
}if(this.getGroupingUsed()){var $8=$6;
$6=$[0];
var $9;
for($9=$8.length;$9>3;$9-=3){$6=$[0]+qx.locale.Number.getGroupSeparator(this._locale)+$8.substring($9-3,
$9)+$6;
}$6=$8.substring(0,
$9)+$6;
}var $a=this.getPrefix()?this.getPrefix():$[0];
var $b=this.getPostfix()?this.getPostfix():$[0];
var $c=$a+($2?$[96]:$[0])+$6;
if($7.length>0){$c+=$[0]+qx.locale.Number.getDecimalSeparator(this._locale)+$7;
}$c+=$b;
return $c;
},
parse:function($0){var $1=qx.util.format.NumberFormat;
var $2=qx.lang.String.escapeRegexpChars(qx.locale.Number.getGroupSeparator(this._locale)+$[0]);
var $3=qx.lang.String.escapeRegexpChars(qx.locale.Number.getDecimalSeparator(this._locale)+$[0]);
var $4=new RegExp($[604]+qx.lang.String.escapeRegexpChars(this.getPrefix())+$[1979]+$[1813]+$2+$[683]+$[584]+$3+$[1964]+qx.lang.String.escapeRegexpChars(this.getPostfix())+$[162]);
var $5=$4.exec($0);
if($5==null){throw new Error("Number string '"+$0+"' does not match the number format");
}var $6=($5[1]==$[96]);
var $7=$5[2];
var $8=$5[3];
$7=$7.replace(new RegExp($2,
$[315]),
$[0]);
var $9=($6?$[96]:$[0])+$7;
if($8!=null&&$8.length!=0){$8=$8.replace(new RegExp($3),
$[0]);
$9+=$[47]+$8;
}return parseFloat($9);
}}});




/* ID: qx.locale.Number */
qx.Class.define($[1062],
{statics:{getDecimalSeparator:function($0){return new qx.locale.LocalizedString($[1834],
[],
$0);
},
getGroupSeparator:function($0){return new qx.locale.LocalizedString($[823],
[],
$0);
},
getPercentFormat:function($0){return new qx.locale.LocalizedString($[1190],
[],
$0);
}}});




/* ID: qx.util.format.DateFormat */
qx.Class.define($[1026],
{extend:qx.util.format.Format,
construct:function($0,
$1){arguments.callee.base.call(this);
if(!$1){this._locale=qx.locale.Manager.getInstance().getLocale();
}else{this._locale=$1;
}
if($0!=null){this._format=$0.toString();
}else{this._format=qx.locale.Date.getDateFormat($[200],
this._locale)+$[81]+qx.locale.Date.getDateTimeFormat($[290],
$[296],
this._locale);
}},
statics:{getDateTimeInstance:function(){var $0=qx.util.format.DateFormat;
var $1=qx.locale.Date.getDateFormat($[200])+$[81]+qx.locale.Date.getDateTimeFormat($[290],
$[296]);
if($0._dateInstance==null||$0._format!=$1){$0._dateTimeInstance=new $0();
}return $0._dateTimeInstance;
},
getDateInstance:function(){var $0=qx.util.format.DateFormat;
var $1=qx.locale.Date.getDateFormat($[225])+$[0];
if($0._dateInstance==null||$0._format!=$1){$0._dateInstance=new $0($1);
}return $0._dateInstance;
},
ASSUME_YEAR_2000_THRESHOLD:30,
LOGGING_DATE_TIME_FORMAT:"yyyy-MM-dd HH:mm:ss",
AM_MARKER:"am",
PM_MARKER:"pm",
MEDIUM_TIMEZONE_NAMES:["GMT"],
FULL_TIMEZONE_NAMES:["Greenwich Mean Time"]},
members:{__fillNumber:function($0,
$1){var $2=$[0]+$0;
while($2.length<$1){$2=$[56]+$2;
}return $2;
},
__getDayInYear:function($0){var $1=new Date($0.getTime());
var $2=$1.getDate();
while($1.getMonth()!=0){$1.setDate(-1);
$2+=$1.getDate()+1;
}return $2;
},
__thursdayOfSameWeek:function($0){return new Date($0.getTime()+(3-(($0.getDay()+6)%7))*86400000);
},
__getWeekInYear:function($0){var $1=this.__thursdayOfSameWeek($0);
var $2=$1.getFullYear();
var $3=this.__thursdayOfSameWeek(new Date($2,
0,
4));
return Math.floor(1.5+($1.getTime()-$3.getTime())/86400000/7);
},
format:function($0){var $1=qx.util.format.DateFormat;
var $2=this._locale;
var $3=$0.getFullYear();
var $4=$0.getMonth();
var $5=$0.getDate();
var $6=$0.getDay();
var $7=$0.getHours();
var $8=$0.getMinutes();
var $9=$0.getSeconds();
var $a=$0.getMilliseconds();
var $b=$0.getTimezoneOffset()/60;
this.__initFormatTree();
var $c=$[0];
for(var $d=0;$d<this.__formatTree.length;$d++){var $e=this.__formatTree[$d];
if($e.type==$[239]){$c+=$e.text;
}else{var $f=$e.character;
var $g=$e.size;
var $h=$[149];
switch($f){case $[757]:if($g==2){$h=this.__fillNumber($3%100,
2);
}else if($g==4){$h=$3;
}break;
case $[893]:$h=this.__fillNumber(this.__getDayInYear($0),
$g);
break;
case $[1258]:$h=this.__fillNumber($5,
$g);
break;
case $[1184]:$h=this.__fillNumber(this.__getWeekInYear($0),
$g);
break;
case $[1520]:if($g==2){$h=qx.locale.Date.getDayName($[170],
$6,
$2);
}else if($g==3){$h=qx.locale.Date.getDayName($[118],
$6,
$2);
}else if($g==4){$h=qx.locale.Date.getDayName($[115],
$6,
$2);
}break;
case $[780]:if($g==1||$g==2){$h=this.__fillNumber($4+1,
$g);
}else if($g==3){$h=qx.locale.Date.getMonthName($[118],
$4,
$2);
}else if($g==4){$h=qx.locale.Date.getMonthName($[115],
$4,
$2);
}break;
case $[544]:$h=($7<12)?qx.locale.Date.getAmMarker($2):qx.locale.Date.getPmMarker($2);
break;
case $[1412]:$h=this.__fillNumber($7,
$g);
break;
case $[803]:$h=this.__fillNumber(($7==0)?24:$7,
$g);
break;
case $[1501]:$h=this.__fillNumber($7%12,
$g);
break;
case $[1037]:$h=this.__fillNumber((($7%12)==0)?12:($7%12),
$g);
break;
case $[645]:$h=this.__fillNumber($8,
$g);
break;
case $[1552]:$h=this.__fillNumber($9,
$g);
break;
case $[1925]:$h=this.__fillNumber($a,
$g);
break;
case $[566]:if($g==1){$h=$[669]+(($b<0)?$[96]:$[212])+this.__fillNumber($b)+$[988];
}else if($g==2){$h=$1.MEDIUM_TIMEZONE_NAMES[$b];
}else if($g==3){$h=$1.FULL_TIMEZONE_NAMES[$b];
}break;
case $[520]:$h=(($b<0)?$[96]:$[212])+this.__fillNumber($b,
2)+$[1102];
}$c+=$h;
}}return $c;
},
parse:function($0){this.__initParseFeed();
var $1=this._parseFeed.regex.exec($0);
if($1==null){throw new Error("Date string '"+$0+"' does not match the date format: "+this._format);
}var $2={year:1970,
month:0,
day:1,
hour:0,
ispm:false,
min:0,
sec:0,
ms:0};
var $3=1;
for(var $4=0;$4<this._parseFeed.usedRules.length;$4++){var $5=this._parseFeed.usedRules[$4];
var $6=$1[$3];
if($5.field!=null){$2[$5.field]=parseInt($6,
10);
}else{$5.manipulator($2,
$6);
}$3+=($5.groups==null)?1:$5.groups;
}var $7=new Date($2.year,
$2.month,
$2.day,
($2.ispm)?($2.hour+12):$2.hour,
$2.min,
$2.sec,
$2.ms);
if($2.month!=$7.getMonth()||$2.year!=$7.getFullYear()){throw new Error("Error parsing date '"+$0+"': the value for day or month is too large");
}return $7;
},
__initFormatTree:function(){if(this.__formatTree!=null){return;
}this.__formatTree=[];
var $0;
var $1=0;
var $2=$[0];
var $3=this._format;
var $4=$[43];
var $5=0;
while($5<$3.length){var $6=$3.charAt($5);
switch($4){case $[517]:if($6==$[188]){if($5+1>=$3.length){$5++;
break;
}var $7=$3.charAt($5+1);
if($7==$[188]){$2+=$6;
$5++;
}else{$5++;
$4=$[724];
}}else{$2+=$6;
$5++;
}break;
case $[232]:if($6==$0){$1++;
$5++;
}else{this.__formatTree.push({type:$[232],
character:$0,
size:$1});
$0=null;
$1=0;
$4=$[43];
}break;
default:if(($6>=$[544]&&$6<=$[566])||($6>=$[876]&&$6<=$[520])){$0=$6;
$4=$[232];
}else if($6==$[188]){if($5+1>=$3.length){$2+=$6;
$5++;
break;
}var $7=$3.charAt($5+1);
if($7==$[188]){$2+=$6;
$5++;
}$5++;
$4=$[517];
}else{$4=$[43];
}
if($4!=$[43]){if($2.length>0){this.__formatTree.push({type:$[239],
text:$2});
$2=$[0];
}}else{$2+=$6;
$5++;
}break;
}}if($0!=null){this.__formatTree.push({type:$[232],
character:$0,
size:$1});
}else if($2.length>0){this.__formatTree.push({type:$[239],
text:$2});
}},
__initParseFeed:function(){if(this._parseFeed!=null){return ;
}var $0=qx.util.format.DateFormat;
var $1=this._format;
this.__initParseRules();
this.__initFormatTree();
var $2=[];
var $3=$[604];
for(var $4=0;$4<this.__formatTree.length;$4++){var $5=this.__formatTree[$4];
if($5.type==$[239]){$3+=qx.lang.String.escapeRegexpChars($5.text);
}else{var $6=$5.character;
var $7=$5.size;
var $8;
for(var $9=0;$9<this._parseRules.length;$9++){var $a=this._parseRules[$9];
if($6==$a.pattern.charAt(0)&&$7==$a.pattern.length){$8=$a;
break;
}}if($8==null){var $b=$[0];
for(var $c=0;$c<$7;$c++){$b+=$6;
}throw new Error("Malformed date format: "+$1+". Wildcard "+$b+" is not supported");
}else{$2.push($8);
$3+=$8.regex;
}}}$3+=$[162];
var $d;
try{$d=new RegExp($3);
}catch(exc){throw new Error("Malformed date format: "+$1);
}this._parseFeed={regex:$d,
"usedRules":$2,
pattern:$3};
},
__initParseRules:function(){var $0=qx.util.format.DateFormat;
if(this._parseRules!=null){return ;
}this._parseRules=[];
var $1=function($2,
$3){$3=parseInt($3,
10);
if($3<$0.ASSUME_YEAR_2000_THRESHOLD){$3+=2000;
}else if($3<100){$3+=1900;
}$2.year=$3;
};
var $4=function($2,
$3){$2.month=parseInt($3,
10)-1;
};
var $5=function($2,
$3){$2.ispm=($3==$0.PM_MARKER);
};
var $6=function($2,
$3){$2.hour=parseInt($3,
10)%24;
};
var $7=function($2,
$3){$2.hour=parseInt($3,
10)%12;
};
var $8=qx.locale.Date.getMonthNames($[118],
this._locale);
for(var $9=0;$9<$8.length;$9++){$8[$9]=qx.lang.String.escapeRegexpChars($8[$9].toString());
}var $a=this;
var $b=function($2,
$3){$3=qx.lang.String.escapeRegexpChars($3);
$2.month=$8.indexOf($3);
};
var $c=qx.locale.Date.getMonthNames($[115],
this._locale);
for(var $9=0;$9<$c.length;$9++){$c[$9]=qx.lang.String.escapeRegexpChars($c[$9].toString());
}var $d=function($2,
$3){$3=qx.lang.String.escapeRegexpChars($3);
$2.month=$c.indexOf($3);
};
var $e=qx.locale.Date.getDayNames($[170],
this._locale);
for(var $9=0;$9<$e.length;$9++){$e[$9]=qx.lang.String.escapeRegexpChars($e[$9].toString());
}var $f=function($2,
$3){$3=qx.lang.String.escapeRegexpChars($3);
$2.month=$e.indexOf($3);
};
var $g=qx.locale.Date.getDayNames($[118],
this._locale);
for(var $9=0;$9<$g.length;$9++){$g[$9]=qx.lang.String.escapeRegexpChars($g[$9].toString());
}var $h=function($2,
$3){$3=qx.lang.String.escapeRegexpChars($3);
$2.month=$g.indexOf($3);
};
var $i=qx.locale.Date.getDayNames($[115],
this._locale);
for(var $9=0;$9<$i.length;$9++){$i[$9]=qx.lang.String.escapeRegexpChars($i[$9].toString());
}var $j=function($2,
$3){$3=qx.lang.String.escapeRegexpChars($3);
$2.month=$i.indexOf($3);
};
this._parseRules.push({pattern:$[2041],
regex:$[760],
groups:2,
manipulator:$1});
this._parseRules.push({pattern:$[711],
regex:$[1795],
manipulator:$1});
this._parseRules.push({pattern:$[1442],
regex:$[49],
manipulator:$4});
this._parseRules.push({pattern:$[1340],
regex:$[49],
manipulator:$4});
this._parseRules.push({pattern:$[1868],
regex:$[100]+$8.join($[120])+$[44],
manipulator:$b});
this._parseRules.push({pattern:$[1212],
regex:$[100]+$c.join($[120])+$[44],
manipulator:$d});
this._parseRules.push({pattern:$[1899],
regex:$[49],
field:$[514]});
this._parseRules.push({pattern:$[2003],
regex:$[49],
field:$[514]});
this._parseRules.push({pattern:$[1423],
regex:$[100]+$e.join($[120])+$[44],
manipulator:$f});
this._parseRules.push({pattern:$[1773],
regex:$[100]+$g.join($[120])+$[44],
manipulator:$h});
this._parseRules.push({pattern:$[1788],
regex:$[100]+$i.join($[120])+$[44],
manipulator:$j});
this._parseRules.push({pattern:$[350],
regex:$[100]+$0.AM_MARKER+$[120]+$0.PM_MARKER+$[44],
manipulator:$5});
this._parseRules.push({pattern:$[769],
regex:$[49],
field:$[226]});
this._parseRules.push({pattern:$[1721],
regex:$[49],
field:$[226]});
this._parseRules.push({pattern:$[1555],
regex:$[49],
manipulator:$6});
this._parseRules.push({pattern:$[1266],
regex:$[49],
manipulator:$6});
this._parseRules.push({pattern:$[1276],
regex:$[49],
field:$[226]});
this._parseRules.push({pattern:$[1621],
regex:$[49],
field:$[226]});
this._parseRules.push({pattern:$[900],
regex:$[49],
manipulator:$7});
this._parseRules.push({pattern:$[957],
regex:$[49],
manipulator:$7});
this._parseRules.push({pattern:$[831],
regex:$[49],
field:$[522]});
this._parseRules.push({pattern:$[1055],
regex:$[49],
field:$[522]});
this._parseRules.push({pattern:$[597],
regex:$[49],
field:$[507]});
this._parseRules.push({pattern:$[346],
regex:$[49],
field:$[507]});
this._parseRules.push({pattern:$[919],
regex:$[306],
field:$[277]});
this._parseRules.push({pattern:$[1483],
regex:$[306],
field:$[277]});
this._parseRules.push({pattern:$[1024],
regex:$[306],
field:$[277]});
}},
destruct:function(){this._disposeFields($[1064],
$[1579],
$[1902],
$[1319]);
}});




/* ID: qx.locale.Date */
qx.Class.define($[1444],
{statics:{getAmMarker:function($0){return new qx.locale.LocalizedString($[1380],
[],
$0);
},
getPmMarker:function($0){return new qx.locale.LocalizedString($[1817],
[],
$0);
},
getDayNames:function($0,
$1){if($0!=$[118]&&$0!=$[170]&&$0!=$[115]){throw new Error('format must be one of "abbreviated", "narrow", "wide"');
}var $2=[$[622],
$[586],
$[618],
$[550],
$[598],
$[453],
$[552]];
var $3=[];
for(var $4=0;$4<$2.length;$4++){var $5=$[365]+$0+$[84]+$2[$4];
$3.push(new qx.locale.LocalizedString($5,
[],
$1));
}return $3;
},
getDayName:function($0,
$1,
$2){if($0!=$[118]&&$0!=$[170]&&$0!=$[115]){throw new Error('format must be one of "abbreviated", "narrow", "wide"');
}var $3=[$[622],
$[586],
$[618],
$[550],
$[598],
$[453],
$[552]];
var $4=$[365]+$0+$[84]+$3[$1];
return new qx.locale.LocalizedString($4,
[],
$2);
},
getMonthNames:function($0,
$1){if($0!=$[118]&&$0!=$[170]&&$0!=$[115]){throw new Error('format must be one of "abbreviated", "narrow", "wide"');
}var $2=[];
for(var $3=0;$3<12;$3++){var $4=$[409]+$0+$[84]+($3+1);
$2.push(new qx.locale.LocalizedString($4,
[],
$1));
}return $2;
},
getMonthName:function($0,
$1,
$2){if($0!=$[118]&&$0!=$[170]&&$0!=$[115]){throw new Error('format must be one of "abbreviated", "narrow", "wide"');
}var $3=$[409]+$0+$[84]+($1+1);
return new qx.locale.LocalizedString($3,
[],
$2);
},
getDateFormat:function($0,
$1){if($0!=$[225]&&$0!=$[278]&&$0!=$[200]&&$0!=$[332]){throw new Error('format must be one of "short", "medium", "long", "full"');
}var $2=$[1681]+$0;
return new qx.locale.LocalizedString($2,
[],
$1);
},
getDateTimeFormat:function($0,
$1,
$2){var $3=$[1748]+$0;
var $4=qx.locale.Manager.getInstance().translate($3,
[],
$2);
if($4==$3){$4=$1;
}return $4;
},
getTimeFormat:function($0,
$1){if($0!=$[225]&&$0!=$[278]&&$0!=$[200]&&$0!=$[332]){throw new Error('format must be one of "short", "medium", "long", "full"');
}var $2=$[695]+$0;
var $3=qx.locale.Manager.getInstance().translate($2,
[],
$1);
if($3!=$2){return $3;
}
switch($0){case $[225]:case $[278]:return qx.locale.Date.getDateTimeFormat($[1735],
$[2033]);
case $[200]:return qx.locale.Date.getDateTimeFormat($[290],
$[296]);
case $[332]:return qx.locale.Date.getDateTimeFormat($[1525],
$[1593]);
default:throw new Error("This case should never happen.");
}},
getWeekStart:function($0){var $1={"MV":5,
"AE":6,
"AF":6,
"BH":6,
"DJ":6,
"DZ":6,
"EG":6,
"ER":6,
"ET":6,
"IQ":6,
"IR":6,
"JO":6,
"KE":6,
"KW":6,
"LB":6,
"LY":6,
"MA":6,
"OM":6,
"QA":6,
"SA":6,
"SD":6,
"SO":6,
"TN":6,
"YE":6,
"AS":0,
"AU":0,
"AZ":0,
"BW":0,
"CA":0,
"CN":0,
"FO":0,
"GE":0,
"GL":0,
"GU":0,
"HK":0,
"IE":0,
"IL":0,
"IS":0,
"JM":0,
"JP":0,
"KG":0,
"KR":0,
"LA":0,
"MH":0,
"MN":0,
"MO":0,
"MP":0,
"MT":0,
"NZ":0,
"PH":0,
"PK":0,
"SG":0,
"TH":0,
"TT":0,
"TW":0,
"UM":0,
"US":0,
"UZ":0,
"VI":0,
"ZA":0,
"ZW":0,
"ET":0,
"MW":0,
"NG":0,
"TJ":0};
var $2=qx.locale.Date._getTerritory($0);
return $1[$2]!=null?$1[$2]:1;
},
getWeekendStart:function($0){var $1={"EG":5,
"IL":5,
"SY":5,
"IN":0,
"AE":4,
"BH":4,
"DZ":4,
"IQ":4,
"JO":4,
"KW":4,
"LB":4,
"LY":4,
"MA":4,
"OM":4,
"QA":4,
"SA":4,
"SD":4,
"TN":4,
"YE":4};
var $2=qx.locale.Date._getTerritory($0);
return $1[$2]!=null?$1[$2]:6;
},
getWeekendEnd:function($0){var $1={"AE":5,
"BH":5,
"DZ":5,
"IQ":5,
"JO":5,
"KW":5,
"LB":5,
"LY":5,
"MA":5,
"OM":5,
"QA":5,
"SA":5,
"SD":5,
"TN":5,
"YE":5,
"AF":5,
"IR":5,
"EG":6,
"IL":6,
"SY":6};
var $2=qx.locale.Date._getTerritory($0);
return $1[$2]!=null?$1[$2]:0;
},
isWeekend:function($0,
$1){var $2=qx.locale.Date.getWeekendStart($1);
var $3=qx.locale.Date.getWeekendEnd($1);
if($3>$2){return (($0>=$2)&&($0<=$3));
}else{return (($0>=$2)||($0<=$3));
}},
_getTerritory:function($0){if($0){var $1=$0.split($[84])[1]||$0;
}else{$1=qx.locale.Manager.getInstance().getTerritory()||qx.locale.Manager.getInstance().getLanguage();
}return $1.toUpperCase();
}}});




/* ID: qx.ui.table.ICellEditorFactory */
qx.Interface.define($[809],
{members:{createCellEditor:function($0){return true;
},
getCellEditorValue:function($0){return true;
}}});




/* ID: qx.ui.table.celleditor.TextField */
qx.Class.define($[1229],
{extend:qx.core.Target,
implement:qx.ui.table.ICellEditorFactory,
construct:function(){arguments.callee.base.call(this);
},
properties:{validationFunction:{check:$[68],
nullable:true,
init:null}},
members:{createCellEditor:function($0){var $1=new qx.ui.form.TextField;
$1.setAppearance($[699]);
$1.setLiveUpdate(true);
$1.originalValue=$0.value;
if($0.value===null){$0.value=$[0];
}$1.setValue($[0]+$0.value);
$1.addEventListener($[210],
function(){this.selectAll();
});
return $1;
},
getCellEditorValue:function($0){var $1=$0.getValue();
var $2=this.getValidationFunction();
if(!this._done&&$2){$1=$2($1,
$0.originalValue);
this._done=true;
}
if(typeof $0.originalValue==$[54]){$1=parseFloat($1);
}return $1;
}}});




/* ID: qx.ui.table.columnmodel.Basic */
qx.Class.define($[377],
{extend:qx.core.Target,
construct:function(){arguments.callee.base.call(this);
},
events:{"widthChanged":$[42],
"visibilityChangedPre":$[42],
"visibilityChanged":$[42],
"orderChanged":$[42]},
statics:{DEFAULT_WIDTH:100,
DEFAULT_HEADER_RENDERER:new qx.ui.table.headerrenderer.Default,
DEFAULT_DATA_RENDERER:new qx.ui.table.cellrenderer.Default,
DEFAULT_EDITOR_FACTORY:new qx.ui.table.celleditor.TextField},
members:{init:function($0){this._columnDataArr=[];
var $1=qx.ui.table.columnmodel.Basic.DEFAULT_WIDTH;
var $2=qx.ui.table.columnmodel.Basic.DEFAULT_HEADER_RENDERER;
var $3=qx.ui.table.columnmodel.Basic.DEFAULT_DATA_RENDERER;
var $4=qx.ui.table.columnmodel.Basic.DEFAULT_EDITOR_FACTORY;
this._overallColumnArr=[];
this._visibleColumnArr=[];
for(var $5=0;$5<$0;$5++){this._columnDataArr[$5]={width:$1,
headerRenderer:$2,
dataRenderer:$3,
editorFactory:$4};
this._overallColumnArr[$5]=$5;
this._visibleColumnArr[$5]=$5;
}this._colToXPosMap=null;
},
setColumnWidth:function($0,
$1){var $2=this._columnDataArr[$0].width;
if($2!=$1){this._columnDataArr[$0].width=$1;
var $3={col:$0,
newWidth:$1,
oldWidth:$2};
this.createDispatchDataEvent($[236],
$3);
}},
getColumnWidth:function($0){return this._columnDataArr[$0].width;
},
setHeaderCellRenderer:function($0,
$1){this._columnDataArr[$0].headerRenderer=$1;
},
getHeaderCellRenderer:function($0){return this._columnDataArr[$0].headerRenderer;
},
setDataCellRenderer:function($0,
$1){this._columnDataArr[$0].dataRenderer=$1;
},
getDataCellRenderer:function($0){return this._columnDataArr[$0].dataRenderer;
},
setCellEditorFactory:function($0,
$1){this._columnDataArr[$0].editorFactory=$1;
},
getCellEditorFactory:function($0){return this._columnDataArr[$0].editorFactory;
},
_getColToXPosMap:function(){if(this._colToXPosMap==null){this._colToXPosMap={};
for(var $0=0;$0<this._overallColumnArr.length;$0++){var $1=this._overallColumnArr[$0];
this._colToXPosMap[$1]={overX:$0};
}
for(var $2=0;$2<this._visibleColumnArr.length;$2++){var $1=this._visibleColumnArr[$2];
this._colToXPosMap[$1].visX=$2;
}}return this._colToXPosMap;
},
getVisibleColumnCount:function(){return this._visibleColumnArr.length;
},
getVisibleColumnAtX:function($0){return this._visibleColumnArr[$0];
},
getVisibleX:function($0){return this._getColToXPosMap()[$0].visX;
},
getOverallColumnCount:function(){return this._overallColumnArr.length;
},
getOverallColumnAtX:function($0){return this._overallColumnArr[$0];
},
getOverallX:function($0){return this._getColToXPosMap()[$0].overX;
},
isColumnVisible:function($0){return (this._getColToXPosMap()[$0].visX!=null);
},
setColumnVisible:function($0,
$1){if($1!=this.isColumnVisible($0)){if($1){var $2=this._getColToXPosMap();
var $3=$2[$0].overX;
if($3==null){throw new Error("Showing column failed: "+$0+". The column is not added to this TablePaneModel.");
}var $4;
for(var $5=$3+1;$5<this._overallColumnArr.length;$5++){var $6=this._overallColumnArr[$5];
var $7=$2[$6].visX;
if($7!=null){$4=$7;
break;
}}if($4==null){$4=this._visibleColumnArr.length;
}this._visibleColumnArr.splice($4,
0,
$0);
}else{var $8=this.getVisibleX($0);
this._visibleColumnArr.splice($8,
1);
}this._colToXPosMap=null;
if(!this._internalChange){var $9={col:$0,
visible:$1};
this.createDispatchDataEvent($[563],
$9);
this.createDispatchDataEvent($[224],
$9);
}}},
moveColumn:function($0,
$1){this._internalChange=true;
var $2=this._overallColumnArr[$0];
var $3=this.isColumnVisible($2);
if($3){this.setColumnVisible($2,
false);
}this._overallColumnArr.splice($0,
1);
this._overallColumnArr.splice($1,
0,
$2);
this._colToXPosMap=null;
if($3){this.setColumnVisible($2,
true);
}this._internalChange=false;
var $4={col:$2,
fromOverXPos:$0,
toOverXPos:$1};
this.createDispatchDataEvent($[329],
$4);
}},
destruct:function(){this._disposeFields($[1668],
$[1785],
$[1012],
$[671]);
}});




/* ID: qx.ui.table.pane.Pane */
qx.Class.define($[1969],
{extend:qx.ui.basic.Terminator,
construct:function($0){arguments.callee.base.call(this);
this._paneScroller=$0;
this._lastColCount=0;
this._lastRowCount=0;
},
properties:{appearance:{refine:true,
init:$[502]},
firstVisibleRow:{check:$[12],
init:0,
apply:$[1504]},
visibleRowCount:{check:$[12],
init:0,
apply:$[1931]},
maxCacheLines:{check:$[12],
init:1000,
apply:$[928]}},
members:{_applyFirstVisibleRow:function($0,
$1){this._updateContent(false,
$0-$1);
},
_applyVisibleRowCount:function($0,
$1){this._updateContent();
},
_afterAppear:function(){arguments.callee.base.call(this);
if(this._updateWantedWhileInvisible){this._updateContent();
this._updateWantedWhileInvisible=false;
}},
getPaneScroller:function(){return this._paneScroller;
},
getTable:function(){return this._paneScroller.getTable();
},
setFocusedCell:function($0,
$1,
$2){if($0!=this._focusedCol||$1!=this._focusedRow){var $3=this._focusedCol;
var $4=this._focusedRow;
this._focusedCol=$0;
this._focusedRow=$1;
if($1!=$4&&!$2){this._updateContent(false,
null,
$4,
true);
this._updateContent(false,
null,
$1,
true);
}}},
_onSelectionChanged:function($0){this._updateContent(false,
null,
null,
true);
},
_onFocusChanged:function($0){this._updateContent(false,
null,
null,
true);
},
_onColWidthChanged:function($0){this._updateContent(true);
},
_onColOrderChanged:function($0){this._updateContent(true);
},
_onPaneModelChanged:function($0){this._updateContent(true);
},
_onTableModelDataChanged:function($0){var $1=$0.getData?$0.getData():null;
this.__rowCacheClear();
var $2=this.getFirstVisibleRow();
var $3=this.getVisibleRowCount();
if($1==null||$1.lastRow==-1||$1.lastRow>=$2&&$1.firstRow<$2+$3){this._updateContent();
}},
_onTableModelMetaDataChanged:function($0){this._updateContent(true);
},
__rowCache:[],
__rowCacheCount:0,
_applyMaxCacheLines:function($0,
$1){if(this.__rowCacheCount>=$0&&$0!==-1){this.__rowCacheClear();
}},
__rowCacheClear:function(){this.__rowCache=[];
this.__rowCacheCount=0;
},
__rowCacheGet:function($0,
$1,
$2){if(!$1&&!$2&&this.__rowCache[$0]){return this.__rowCache[$0];
}else{return null;
}},
__rowCacheSet:function($0,
$1,
$2,
$3){if(!$2&&!$3&&!this.__rowCache[$0]){this._applyMaxCacheLines(this.getMaxCacheLines());
this.__rowCache[$0]=$1;
this.__rowCacheCount+=1;
}},
_updateContent:function($0,
$1,
$2,
$3){if($0){this.__rowCacheClear();
}
if(!this.isSeeable()){this._updateWantedWhileInvisible=true;
return;
}
if(this._layoutPending){window.clearTimeout(this._layoutPending);
this._updateAllRows();
return;
}if($1&&Math.abs($1)<=Math.min(10,
this.getVisibleRowCount())){this._scrollContent($1);
}else if($3&&!this.getTable().getAlwaysUpdateCells()){this._updateRowStyles($2);
}else{this._updateAllRows();
}},
_updateRowStyles:function($0){var $1=this.getTable();
var $2=$1.getSelectionModel();
var $3=$1.getTableModel();
var $4=$1.getDataRowRenderer();
var $5=$1.getRowHeight();
var $6=this.getFirstVisibleRow();
var $7=this.getElement();
if(!$7.firstChild){this._updateAllRows();
return;
}var $8=$7.firstChild.childNodes;
var $9={table:$1};
for(var $a=0,
$b=$8.length;$a<$b;$a++){var $c=$6+$a;
if(($0!=null)&&($c!=$0)){continue;
}$9.row=$c;
$9.selected=$2.isSelectedIndex($c);
$9.focusedRow=(this._focusedRow==$c);
$9.rowData=$3.getRowData($c);
var $d=$8[$a];
$4.updateDataRowElement($9,
$d);
}},
_getRowsHtml:function($0,
$1){var $2=this.getTable();
var $3=$2.getSelectionModel();
var $4=$2.getTableModel();
var $5=$2.getTableColumnModel();
var $6=this.getPaneScroller().getTablePaneModel();
var $7=$2.getDataRowRenderer();
$4.prefetchRows($0,
$0+$1-1);
var $8=[];
for(var $9=$0;$9<$0+$1;$9++){var $a=$3.isSelectedIndex($9);
var $b=(this._focusedRow==$9);
var $c=this.__rowCacheGet($9,
$a,
$b);
if($c){$8.push($c);
continue;
}var $d=[];
var $e=$2.getRowHeight();
var $f=$6.getColumnCount();
var $g={table:$2};
$g.styleHeight=$e;
$g.row=$9;
$g.selected=$a;
$g.focusedRow=$b;
$g.rowData=$4.getRowData($9);
$d.push($[1500]);
var $h=$7.getRowClass($g);
if($h){$d.push($[1844],
$h,
$[534]);
}var $i=$7.createRowStyle($g);
$i+=$[819]+$e+$[763]+$6.getTotalWidth()+$[289];
if($i){$d.push($[1169],
$i,
$[534]);
}$d.push($[1331]);
var $j=0;
for(var $k=0;$k<$f;$k++){var $l=$6.getColumnAtX($k);
$g.xPos=$k;
$g.col=$l;
$g.editable=$4.isColumnEditable($l);
$g.focusedCol=(this._focusedCol==$l);
$g.value=$4.getValue($l,
$9);
var $m=$5.getColumnWidth($l);
$g.styleLeft=$j;
$g.styleWidth=$m;
var $n=$5.getDataCellRenderer($l);
$n.createDataCellHtml($g,
$d);
$j+=$m;
}$d.push($[547]);
var $o=$d.join($[0]);
this.__rowCacheSet($9,
$o,
$a,
$b);
$8.push($o);
}return $8.join($[0]);
},
_scrollContent:function($0){if(!this.getElement().firstChild){this._updateAllRows();
return;
}var $1=this.getElement().firstChild;
var $2=$1.childNodes;
var $3=this.getVisibleRowCount();
var $4=this.getFirstVisibleRow();
var $5=this.getTable().getTableModel().getRowCount();
if($4+$3>$5){this._updateAllRows();
return;
}var $6=$0<0?$3+$0:0;
var $7=$0<0?0:$3-$0;
for($b=Math.abs($0)-1;$b>=0;$b--){var $8=$2[$6];
try{$1.removeChild($8);
}catch(e){break;
}}if(!this._tableContainer){this._tableContainer=document.createElement($[101]);
}var $9=$[1339];
$9+=this._getRowsHtml($4+$7,
Math.abs($0));
$9+=$[547];
this._tableContainer.innerHTML=$9;
var $a=this._tableContainer.firstChild.childNodes;
if($0>0){for(var $b=$a.length-1;$b>=0;$b--){var $8=$a[0];
$1.appendChild($8);
}}else{for(var $b=$a.length-1;$b>=0;$b--){var $8=$a[$a.length-1];
$1.insertBefore($8,
$1.firstChild);
}}this._updateRowStyles(this._focusedRow-$0);
this._updateRowStyles(this._focusedRow);
if(qx.core.Variant.isSet($[1],
$[25])){$8.offsetHeight;
}},
_updateAllRows:function(){var $0=qx.ui.table.pane.Pane;
var $1=this.getTable();
var $2=$1.getTableModel();
var $3=$1.getTableColumnModel();
var $4=this.getPaneScroller().getTablePaneModel();
var $5=$4.getColumnCount();
var $6=$1.getRowHeight();
var $7=this.getFirstVisibleRow();
var $8=this.getVisibleRowCount();
var $9=$2.getRowCount();
if($7+$8>$9){$8=Math.max(0,
$9-$7);
}var $a=$4.getTotalWidth();
var $b=[$[1918],
$[1154],
$a,
$[289],
$[1863],
$6,
$[289],
$[1876],
$[661],
$[866],
$[1532],
this._getRowsHtml($7,
$8),
$[578]];
var $c=this.getElement();
var $d=$b.join($[0]);
var $e=this;
this._layoutPending=window.setTimeout(function(){$c.innerHTML=$d;
if(qx.core.Variant.isSet($[1],
$[25])){$c.childNodes[0].offsetHeight;
}$e._layoutPending=null;
},
10);
this.setHeight($8*$6);
this._lastColCount=$5;
this._lastRowCount=$8;
}},
destruct:function(){this._disposeObjects($[361]);
}});




/* ID: qx.ui.table.pane.Header */
qx.Class.define($[1270],
{extend:qx.ui.layout.HorizontalBoxLayout,
construct:function($0){arguments.callee.base.call(this);
this._paneScroller=$0;
},
properties:{appearance:{refine:true,
init:$[367]}},
members:{getPaneScroller:function(){return this._paneScroller;
},
getTable:function(){return this._paneScroller.getTable();
},
_onColWidthChanged:function($0){var $1=$0.getData();
this.setColumnWidth($1.col,
$1.newWidth);
},
_onColOrderChanged:function($0){this._updateContent(true);
},
_onPaneModelChanged:function($0){this._updateContent(true);
},
_onTableModelMetaDataChanged:function($0){this._updateContent();
},
setColumnWidth:function($0,
$1){var $2=this.getPaneScroller().getTablePaneModel().getX($0);
var $3=this.getChildren();
if($3[$2]!=null){$3[$2].setWidth($1);
}},
setMouseOverColumn:function($0){if($0!=this._lastMouseOverColumn){var $1=this.getPaneScroller().getTablePaneModel();
var $2=this.getChildren();
if(this._lastMouseOverColumn!=null){var $3=$2[$1.getX(this._lastMouseOverColumn)];
if($3!=null){$3.removeState($[86]);
}}
if($0!=null){$2[$1.getX($0)].addState($[86]);
}this._lastMouseOverColumn=$0;
}},
showColumnMoveFeedback:function($0,
$1){var $2=this.getElement();
if(this._moveFeedback==null){var $3=this.getPaneScroller().getTablePaneModel().getX($0);
var $4=this.getChildren()[$3];
var $5=this.getTable().getTableModel();
var $6=this.getTable().getTableColumnModel();
var $7={xPos:$3,
col:$0,
name:$5.getColumnName($0)};
var $8=$6.getHeaderCellRenderer($0);
var $9=$8.createHeaderCell($7);
$9.setWidth($4.getBoxWidth());
$9.setHeight($4.getBoxHeight());
$9.setZIndex(1000000);
$9.setOpacity(0.8);
$9.setTop(qx.html.Location.getClientBoxTop($2));
this.getTopLevelWidget().add($9);
this._moveFeedback=$9;
}this._moveFeedback.setLeft(qx.bom.element.Location.getLeft($2)+$1);
},
hideColumnMoveFeedback:function(){if(this._moveFeedback!=null){this.getTopLevelWidget().remove(this._moveFeedback);
this._moveFeedback.dispose();
this._moveFeedback=null;
}},
isShowingColumnMoveFeedback:function(){return this._moveFeedback!=null;
},
_updateContent:function($0){var $1=this.getTable().getTableModel();
var $2=this.getTable().getTableColumnModel();
var $3=this.getPaneScroller().getTablePaneModel();
var $4=this.getChildren();
var $5=$4.length;
var $6=$3.getColumnCount();
var $7=$1.getSortColumnIndex();
if($0){this._cleanUpCells();
}var $8={};
$8.sortedAscending=$1.isSortAscending();
for(var $9=0;$9<$6;$9++){var $a=$3.getColumnAtX($9);
var $b=$2.getColumnWidth($a);
var $c=$2.getHeaderCellRenderer($a);
$8.xPos=$9;
$8.col=$a;
$8.name=$1.getColumnName($a);
$8.editable=$1.isColumnEditable($a);
$8.sorted=($a==$7);
var $d=$4[$9];
if($d==null){$d=$c.createHeaderCell($8);
$d.set({width:$b,
height:$[80]});
this.add($d);
}else{$c.updateHeaderCell($8,
$d);
}}},
_cleanUpCells:function(){var $0=this.getChildren();
for(var $1=$0.length-1;$1>=0;$1--){var $2=$0[$1];
this.remove($2);
$2.dispose();
}}},
destruct:function(){this._disposeObjects($[361]);
}});




/* ID: qx.ui.table.pane.Scroller */
qx.Class.define($[906],
{extend:qx.ui.layout.VerticalBoxLayout,
construct:function($0){arguments.callee.base.call(this);
this._table=$0;
this._verScrollBar=new qx.ui.basic.ScrollBar(false);
this._horScrollBar=new qx.ui.basic.ScrollBar(true);
var $1=this._verScrollBar.getPreferredBoxWidth();
this._verScrollBar.setWidth($[3]);
this._horScrollBar.setHeight($[3]);
this._horScrollBar.setPaddingRight($1);
this._horScrollBar.addEventListener($[190],
this._onScrollX,
this);
this._verScrollBar.addEventListener($[190],
this._onScrollY,
this);
this._header=this.getTable().getNewTablePaneHeader()(this);
this._header.set({width:$[3],
height:$[3]});
this._headerClipper=new qx.ui.layout.CanvasLayout;
this._headerClipper.setDimension($[87],
$[3]);
this._headerClipper.setOverflow($[21]);
this._headerClipper.add(this._header);
this._spacer=new qx.ui.basic.Terminator;
this._spacer.setWidth($1);
this._top=new qx.ui.layout.HorizontalBoxLayout;
this._top.setHeight($[3]);
this._top.add(this._headerClipper,
this._spacer);
this._tablePane=this.getTable().getNewTablePane()(this);
this._tablePane.set({width:$[3],
height:$[3]});
this._showCellFocusIndicator=this.getShowCellFocusIndicator();
this._focusIndicator=new qx.ui.layout.HorizontalBoxLayout;
this._focusIndicator.setAppearance($[636]);
this._focusIndicator.hide();
var $2=new qx.ui.basic.Terminator;
$2.setWidth(0);
this._focusIndicator.add($2);
this._paneClipper=new qx.ui.layout.CanvasLayout;
this._paneClipper.setWidth($[87]);
this._paneClipper.setOverflow($[21]);
this._paneClipper.add(this._tablePane,
this._focusIndicator);
this._paneClipper.addEventListener($[238],
this._onmousewheel,
this);
var $3=new qx.ui.layout.HorizontalBoxLayout;
$3.setHeight($[87]);
$3.add(this._paneClipper,
this._verScrollBar);
this.add(this._top,
$3,
this._horScrollBar);
this._headerClipper.addEventListener($[479],
this._onChangeCaptureHeader,
this);
this._headerClipper.addEventListener($[135],
this._onmousemoveHeader,
this);
this._paneClipper.addEventListener($[135],
this._onmousemovePane,
this);
this._headerClipper.addEventListener($[18],
this._onmousedownHeader,
this);
this._paneClipper.addEventListener($[18],
this._onmousedownPane,
this);
this._headerClipper.addEventListener($[39],
this._onmouseupHeader,
this);
this._paneClipper.addEventListener($[39],
this._onmouseupPane,
this);
this._headerClipper.addEventListener($[99],
this._onclickHeader,
this);
this._paneClipper.addEventListener($[99],
this._onclickPane,
this);
this._paneClipper.addEventListener($[196],
this._onContextMenu,
this);
this._paneClipper.addEventListener($[152],
this._ondblclickPane,
this);
this.addEventListener($[113],
this._onmouseout,
this);
this.initScrollTimeout();
},
events:{"cellClick":$[150],
"cellDblclick":$[150],
"cellContextmenu":$[150]},
statics:{MIN_COLUMN_WIDTH:10,
RESIZE_REGION_RADIUS:5,
CLICK_TOLERANCE:5,
HORIZONTAL_SCROLLBAR:1,
VERTICAL_SCROLLBAR:2,
CURSOR_RESIZE_HORIZONTAL:(qx.core.Client.getInstance().isGecko()&&(qx.core.Client.getInstance().getMajor()>1||qx.core.Client.getInstance().getMinor()>=8))?"ew-resize":"e-resize"},
events:{"changeScrollY":$[247],
"changeScrollX":$[247],
"rowdblclick":$[1879]},
properties:{horizontalScrollBarVisible:{check:$[2],
init:true,
apply:$[1937],
event:$[2031]},
verticalScrollBarVisible:{check:$[2],
init:true,
apply:$[1165],
event:$[1434]},
tablePaneModel:{check:$[638],
apply:$[644],
event:$[1749]},
liveResize:{check:$[2],
init:false},
focusCellOnMouseMove:{check:$[2],
init:false},
selectBeforeFocus:{check:$[2],
init:false},
showCellFocusIndicator:{check:$[2],
init:true,
apply:$[364]},
scrollTimeout:{check:$[6],
init:100,
apply:$[1717]}},
members:{_applyHorizontalScrollBarVisible:function($0,
$1){if($0){this._horScrollBar.setHeight($[3]);
}else{this._horScrollBar.setHeight(0);
}this._horScrollBar.setVisibility($0);
this._updateContent();
},
_applyVerticalScrollBarVisible:function($0,
$1){if($0){this._verScrollBar.setWidth($[3]);
}else{this._verScrollBar.setWidth(0);
}this._verScrollBar.setVisibility($0);
var $2=$0?this._verScrollBar.getPreferredBoxWidth():0;
this._horScrollBar.setPaddingRight($2);
this._spacer.setWidth($2);
},
_applyTablePaneModel:function($0,
$1){if($1!=null){$1.removeEventListener($[456],
this._onPaneModelChanged,
this);
}$0.addEventListener($[456],
this._onPaneModelChanged,
this);
},
_applyShowCellFocusIndicator:function($0,
$1){this._showCellFocusIndicator=$0;
if($0){this._updateFocusIndicator();
}else{if(this._focusIndicator){this._focusIndicator.hide();
}}},
getScrollY:function(){return this._verScrollBar.getValue();
},
setScrollY:function($0,
$1){this._ignoreScrollYEvent=$1;
this._verScrollBar.setValue($0);
if($1){this._updateContent();
}this._ignoreScrollYEvent=false;
},
getScrollX:function(){return this._horScrollBar.getValue();
},
setScrollX:function($0){this._horScrollBar.setValue($0);
},
getTable:function(){return this._table;
},
_onColVisibilityChanged:function($0){this._updateHorScrollBarMaximum();
this._updateFocusIndicator();
},
_onColWidthChanged:function($0){this._header._onColWidthChanged($0);
this._tablePane._onColWidthChanged($0);
var $1=$0.getData();
var $2=this.getTablePaneModel();
var $3=$2.getX($1.col);
if($3!=-1){this._updateHorScrollBarMaximum();
this._updateFocusIndicator();
}},
_onColOrderChanged:function($0){this._header._onColOrderChanged($0);
this._tablePane._onColOrderChanged($0);
this._updateHorScrollBarMaximum();
},
_onTableModelDataChanged:function($0){this._tablePane._onTableModelDataChanged($0);
var $1=this.getTable().getTableModel().getRowCount();
if($1!=this._lastRowCount){this._lastRowCount=$1;
this._updateVerScrollBarMaximum();
if(this.getFocusedRow()>=$1){if($1==0){this.setFocusedCell(null,
null);
}else{this.setFocusedCell(this.getFocusedColumn(),
$1-1);
}}}},
_onSelectionChanged:function($0){this._tablePane._onSelectionChanged($0);
},
_onFocusChanged:function($0){this.getTable().getFocused()?this._focusIndicator.addState($[434]):this._focusIndicator.removeState($[434]);
this._tablePane._onFocusChanged($0);
},
_onTableModelMetaDataChanged:function($0){this._header._onTableModelMetaDataChanged($0);
this._tablePane._onTableModelMetaDataChanged($0);
},
_onPaneModelChanged:function($0){this._header._onPaneModelChanged($0);
this._tablePane._onPaneModelChanged($0);
},
_updateHorScrollBarMaximum:function(){this._horScrollBar.setMaximum(this.getTablePaneModel().getTotalWidth());
},
_updateVerScrollBarMaximum:function(){var $0=this.getTable().getTableModel().getRowCount();
var $1=this.getTable().getRowHeight();
if(this.getTable().getKeepFirstVisibleRowComplete()){this._verScrollBar.setMaximum(($0+1)*$1);
}else{this._verScrollBar.setMaximum($0*$1);
}},
_onKeepFirstVisibleRowCompleteChanged:function(){this._updateVerScrollBarMaximum();
this._updateContent();
},
_changeInnerHeight:function($0,
$1){this._postponedUpdateContent();
return arguments.callee.base.call(this,
$0,
$1);
},
_afterAppear:function(){arguments.callee.base.call(this);
var $0=this;
this.getElement().onselectstart=qx.lang.Function.returnFalse;
this._updateContent();
this._header._updateContent();
this._updateHorScrollBarMaximum();
this._updateVerScrollBarMaximum();
},
_onScrollX:function($0){this.createDispatchChangeEvent($[1149],
$0.getValue(),
$0.getOldValue());
var $1=$0.getValue();
this._header.setLeft(-$1);
this._paneClipper.__scrollLeft=$1;
this._paneClipper.setScrollLeft($1);
},
_onScrollY:function($0){this.createDispatchChangeEvent($[430],
$0.getValue(),
$0.getOldValue());
this._postponedUpdateContent();
},
_onmousewheel:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}this._verScrollBar.setValue(this._verScrollBar.getValue()-($0.getWheelDelta()*3)*$1.getRowHeight());
if(this._lastMousePageX&&this.getFocusCellOnMouseMove()){this._focusCellAtPagePos(this._lastMousePageX,
this._lastMousePageY);
}},
__handleResizeColumn:function($0){var $1=this.getTable();
var $2=qx.ui.table.pane.Scroller.MIN_COLUMN_WIDTH;
var $3=Math.max($2,
this._lastResizeWidth+$0-this._lastResizeMousePageX);
if(this.getLiveResize()){var $4=$1.getTableColumnModel();
$4.setColumnWidth(this._resizeColumn,
$3);
}else{this._header.setColumnWidth(this._resizeColumn,
$3);
var $5=this.getTablePaneModel();
this._showResizeLine($5.getColumnLeft(this._resizeColumn)+$3);
}this._lastResizeMousePageX+=$3-this._lastResizeWidth;
this._lastResizeWidth=$3;
},
__handleMoveColumn:function($0){var $1=qx.ui.table.pane.Scroller.CLICK_TOLERANCE;
if(this._header.isShowingColumnMoveFeedback()||$0>this._lastMoveMousePageX+$1||$0<this._lastMoveMousePageX-$1){this._lastMoveColPos+=$0-this._lastMoveMousePageX;
this._header.showColumnMoveFeedback(this._moveColumn,
this._lastMoveColPos);
var $2=this._table.getTablePaneScrollerAtPageX($0);
if(this._lastMoveTargetScroller&&this._lastMoveTargetScroller!=$2){this._lastMoveTargetScroller.hideColumnMoveFeedback();
}
if($2!=null){this._lastMoveTargetX=$2.showColumnMoveFeedback($0);
}else{this._lastMoveTargetX=null;
}this._lastMoveTargetScroller=$2;
this._lastMoveMousePageX=$0;
}},
_onmousemoveHeader:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}var $2=false;
var $3=null;
var $4=$0.getPageX();
var $5=$0.getPageY();
this._lastMousePageX=$4;
this._lastMousePageY=$5;
if(this._resizeColumn!=null){this.__handleResizeColumn($4);
$2=true;
}else if(this._moveColumn!=null){this.__handleMoveColumn($4);
}else{var $6=this._getResizeColumnForPageX($4);
if($6!=-1){$2=true;
}else{var $7=$1.getTableModel();
var $8=this._getColumnForPageX($4);
if($8!=null&&$7.isColumnSortable($8)){$3=$8;
}}}this.getTopLevelWidget().setGlobalCursor($2?qx.ui.table.pane.Scroller.CURSOR_RESIZE_HORIZONTAL:null);
this._header.setMouseOverColumn($3);
},
_onmousemovePane:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}var $2=false;
var $3=$0.getPageX();
var $4=$0.getPageY();
this._lastMousePageX=$3;
this._lastMousePageY=$4;
if(this._resizeColumn!=null){this.__handleResizeColumn($3);
$2=true;
}else if(this._moveColumn!=null){this.__handleMoveColumn($3);
}else{var $5=this._getRowForPagePos($3,
$4);
if($5!=null&&this._getColumnForPageX($3)!=null){if(this.getFocusCellOnMouseMove()){this._focusCellAtPagePos($3,
$4);
}}}this.getTopLevelWidget().setGlobalCursor($2?qx.ui.table.pane.Scroller.CURSOR_RESIZE_HORIZONTAL:null);
this._header.setMouseOverColumn(null);
},
_onmousedownHeader:function($0){if(!this.getTable().getEnabled()){return;
}var $1=$0.getPageX();
var $2=this._getResizeColumnForPageX($1);
if($2!=-1){this._startResizeHeader($2,
$1);
}else{var $3=this._getColumnForPageX($1);
if($3!=null){this._startMoveHeader($3,
$1);
}}},
_startResizeHeader:function($0,
$1){var $2=this.getTable().getTableColumnModel();
this._resizeColumn=$0;
this._lastResizeMousePageX=$1;
this._lastResizeWidth=$2.getColumnWidth(this._resizeColumn);
this._headerClipper.setCapture(true);
},
_startMoveHeader:function($0,
$1){this._moveColumn=$0;
this._lastMoveMousePageX=$1;
this._lastMoveColPos=this.getTablePaneModel().getColumnLeft($0);
this._headerClipper.setCapture(true);
},
_onmousedownPane:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}
if(this.isEditing()){this.stopEditing();
}var $2=$0.getPageX();
var $3=$0.getPageY();
var $4=this._getRowForPagePos($2,
$3);
if($4!=null&&this._getColumnForPageX($2)!=null){var $5=this.getSelectBeforeFocus();
if($5){$1._getSelectionManager().handleMouseDown($4,
$0);
}if(!this.getFocusCellOnMouseMove()){this._focusCellAtPagePos($2,
$3);
}
if(!$5){$1._getSelectionManager().handleMouseDown($4,
$0);
}}},
_onmouseupHeader:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}var $2=$1.getTableColumnModel();
var $3=this.getTablePaneModel();
if(this._resizeColumn!=null){this._stopResizeHeader();
}else if(this._moveColumn!=null){this._stopMoveHeader();
}},
_onChangeCaptureHeader:function($0){if(this._resizeColumn!=null&&$0.getValue()==false){this._stopResizeHeader();
}
if(this._moveColumn!=null&&$0.getValue()==false){this._stopMoveHeader();
}},
_stopResizeHeader:function(){var $0=this.getTable().getTableColumnModel();
if(!this.getLiveResize()){this._hideResizeLine();
$0.setColumnWidth(this._resizeColumn,
this._lastResizeWidth);
}this._resizeColumn=null;
this._headerClipper.setCapture(false);
this.getTopLevelWidget().setGlobalCursor(null);
},
_stopMoveHeader:function(){var $0=this.getTable().getTableColumnModel();
var $1=this.getTablePaneModel();
this._header.hideColumnMoveFeedback();
if(this._lastMoveTargetScroller){this._lastMoveTargetScroller.hideColumnMoveFeedback();
}
if(this._lastMoveTargetX!=null){var $2=$1.getFirstColumnX()+$1.getX(this._moveColumn);
var $3=this._lastMoveTargetX;
if($3!=$2&&$3!=$2+1){var $4=$0.getVisibleColumnAtX($2);
var $5=$0.getVisibleColumnAtX($3);
var $6=$0.getOverallX($4);
var $7=($5!=null)?$0.getOverallX($5):$0.getOverallColumnCount();
if($7>$6){$7--;
}$0.moveColumn($6,
$7);
}}this._moveColumn=null;
this._lastMoveTargetX=null;
this._headerClipper.setCapture(false);
},
_onmouseupPane:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}var $2=this._getRowForPagePos($0.getPageX(),
$0.getPageY());
if($2!=-1&&$2!=null&&this._getColumnForPageX($0.getPageX())!=null){$1._getSelectionManager().handleMouseUp($2,
$0);
}},
_onclickHeader:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}var $2=$1.getTableModel();
var $3=$0.getPageX();
var $4=this._getResizeColumnForPageX($3);
if($4==-1){var $5=this._getColumnForPageX($3);
if($5!=null&&$2.isColumnSortable($5)){var $6=$2.getSortColumnIndex();
var $7=($5!=$6)?true:!$2.isSortAscending();
$2.sortByColumn($5,
$7);
$1.getSelectionModel().clearSelection();
}}},
_onclickPane:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}var $2=$1.getTableModel();
var $3=$0.getPageX();
var $4=$0.getPageY();
var $5=this._getRowForPagePos($3,
$4);
if($5!=null&&this._getColumnForPageX($3)!=null){$1._getSelectionManager().handleClick($5,
$0);
if(this.hasEventListeners($[1036])){this.dispatchEvent(new qx.ui.table.pane.CellEvent(this,
$0),
true);
}}},
_onContextMenu:function($0){if(this.hasEventListeners($[1738])){this.dispatchEvent(new qx.ui.table.pane.CellEvent(this,
$0),
true);
}},
_ondblclickPane:function($0){var $1=$0.getPageX();
var $2=$0.getPageY();
this._focusCellAtPagePos($1,
$2);
this.startEditing();
if(this.hasEventListeners($[1656])){var $3=this._getRowForPagePos($1,
$2);
if($3!=-1&&$3!=null){this.dispatchEvent(new qx.ui.table.pane.CellEvent(this,
$0),
true);
}}},
_onmouseout:function($0){var $1=this.getTable();
if(!$1.getEnabled()){return;
}if(this._resizeColumn==null){this.getTopLevelWidget().setGlobalCursor(null);
}this._header.setMouseOverColumn(null);
},
_showResizeLine:function($0){var $1=this._resizeLine;
if($1==null){$1=new qx.ui.basic.Terminator;
$1.setBackgroundColor($[1017]);
$1.setWidth(3);
this._paneClipper.add($1);
qx.ui.core.Widget.flushGlobalQueues();
this._resizeLine=$1;
}$1._renderRuntimeLeft($0-2);
$1._renderRuntimeHeight(this._paneClipper.getBoxHeight()+this._paneClipper.getScrollTop());
this._resizeLine.removeStyleProperty($[309]);
},
_hideResizeLine:function(){if(this._resizeLine){this._resizeLine.setStyleProperty($[309],
$[21]);
}},
showColumnMoveFeedback:function($0){var $1=this.getTablePaneModel();
var $2=this.getTable().getTableColumnModel();
var $3=qx.bom.element.Location.getLeft(this._tablePane.getElement());
var $4=$1.getColumnCount();
var $5=0;
var $6=0;
var $7=$3;
for(var $8=0;$8<$4;$8++){var $9=$1.getColumnAtX($8);
var $a=$2.getColumnWidth($9);
if($0<$7+$a/2){break;
}$7+=$a;
$5=$8+1;
$6=$7-$3;
}var $b=qx.bom.element.Location.getLeft(this._paneClipper.getElement());
var $c=this._paneClipper.getBoxWidth();
var $d=$b-$3;
$6=qx.lang.Number.limit($6,
$d+2,
$d+$c-1);
this._showResizeLine($6);
return $1.getFirstColumnX()+$5;
},
hideColumnMoveFeedback:function(){this._hideResizeLine();
},
_focusCellAtPagePos:function($0,
$1){var $2=this._getRowForPagePos($0,
$1);
if($2!=-1&&$2!=null){var $3=this._getColumnForPageX($0);
if($3!=null){this._table.setFocusedCell($3,
$2);
}}},
setFocusedCell:function($0,
$1){if(!this.isEditing()){this._tablePane.setFocusedCell($0,
$1,
this._updateContentPlanned);
this._focusedCol=$0;
this._focusedRow=$1;
if(!this._updateContentPlanned){this._updateFocusIndicator();
}}},
getFocusedColumn:function(){return this._focusedCol;
},
getFocusedRow:function(){return this._focusedRow;
},
scrollCellVisible:function($0,
$1){var $2=this.getTablePaneModel();
var $3=$2.getX($0);
if($3!=-1){var $4=this.getTable().getTableColumnModel();
var $5=$2.getColumnLeft($0);
var $6=$4.getColumnWidth($0);
var $7=this.getTable().getRowHeight();
var $8=$1*$7;
var $9=this.getScrollX();
var $a=this.getScrollY();
var $b=this._paneClipper.getBoxWidth();
var $c=this._paneClipper.getBoxHeight();
var $d=Math.min($5,
$5+$6-$b);
var $e=$5;
this.setScrollX(Math.max($d,
Math.min($e,
$9)));
var $f=$8+$7-$c;
if(this.getTable().getKeepFirstVisibleRowComplete()){$f+=$7-1;
}var $g=$8;
this.setScrollY(Math.max($f,
Math.min($g,
$a)),
true);
}},
isEditing:function(){return this._cellEditor!=null;
},
startEditing:function(){var $0=this.getTable();
var $1=$0.getTableModel();
var $2=this._focusedCol;
if(!this.isEditing()&&($2!=null)&&$1.isColumnEditable($2)){var $3=this._focusedRow;
var $4=this.getTablePaneModel().getX($2);
var $5=$1.getValue($2,
$3);
this._cellEditorFactory=$0.getTableColumnModel().getCellEditorFactory($2);
var $6={col:$2,
row:$3,
xPos:$4,
value:$5,
table:$0};
this._cellEditor=this._cellEditorFactory.createCellEditor($6);
if(this._cellEditor===null){return false;
}else if(this._cellEditor instanceof qx.ui.window.Window){this._cellEditor.setModal(true);
this._cellEditor.setShowClose(false);
this._cellEditor.addToDocument();
this._cellEditor.addEventListener($[176],
this._onCellEditorModalWindowClose,
this);
var $7=$0.getModalCellEditorPreOpenFunction();
if($7!=null){$7(this._cellEditor,
$6);
}this._cellEditor.open();
}else{this._cellEditor.set({width:$[80],
height:$[80]});
this._focusIndicator.addEventListener($[18],
function($8){$8.stopPropagation();
});
this._focusIndicator.add(this._cellEditor);
this._focusIndicator.addState($[567]);
qx.client.Timer.once(function(){if(this.getDisposed()){return;
}this._cellEditor.focus();
},
this,
0);
}return true;
}return false;
},
stopEditing:function(){this.flushEditor();
this.cancelEditing();
},
flushEditor:function(){if(this.isEditing()){var $0=this._cellEditorFactory.getCellEditorValue(this._cellEditor);
this.getTable().getTableModel().setValue(this._focusedCol,
this._focusedRow,
$0);
this._table.focus();
}},
cancelEditing:function(){if(this.isEditing()&&!this._cellEditor.pendingDispose){if(this._cellEditorIsModalWindow){qx.client.Timer.once(function(){var $0=qx.ui.core.ClientDocument.getInstance();
$0.remove(this._cellEditor);
this._cellEditor.removeEventListener($[176],
_onCellEditorModalWindowClose,
this);
this._cellEditor.dispose();
this._cellEditor=null;
this._cellEditorFactory=null;
},
this,
0);
this._cellEditor.pendingDispose=true;
}else{this._focusIndicator.remove(this._cellEditor);
this._focusIndicator.removeState($[567]);
this._cellEditor.dispose();
this._cellEditor=null;
this._cellEditorFactory=null;
}}},
_onCellEditorModalWindowClose:function($0){this.stopEditing();
},
_getColumnForPageX:function($0){var $1=qx.bom.element.Location.getLeft(this._header.getElement());
var $2=this.getTable().getTableColumnModel();
var $3=this.getTablePaneModel();
var $4=$3.getColumnCount();
var $5=$1;
for(var $6=0;$6<$4;$6++){var $7=$3.getColumnAtX($6);
var $8=$2.getColumnWidth($7);
$5+=$8;
if($0<$5){return $7;
}}return null;
},
_getResizeColumnForPageX:function($0){var $1=qx.bom.element.Location.getLeft(this._header.getElement());
var $2=this.getTable().getTableColumnModel();
var $3=this.getTablePaneModel();
var $4=$3.getColumnCount();
var $5=$1;
var $6=qx.ui.table.pane.Scroller.RESIZE_REGION_RADIUS;
for(var $7=0;$7<$4;$7++){var $8=$3.getColumnAtX($7);
var $9=$2.getColumnWidth($8);
$5+=$9;
if($0>=($5-$6)&&$0<=($5+$6)){return $8;
}}return -1;
},
_getRowForPagePos:function($0,
$1){var $2=this._paneClipper.getElement();
var $3=qx.bom.element.Location.get($2);
if($0<$3.left||$0>$3.right){return null;
}
if($1>=$3.top&&$1<=$3.bottom){var $4=this.getTable().getRowHeight();
var $5=this._verScrollBar.getValue();
if(this.getTable().getKeepFirstVisibleRowComplete()){$5=Math.floor($5/$4)*$4;
}var $6=$5+$1-$3.top;
var $7=Math.floor($6/$4);
var $8=this.getTable().getTableModel().getRowCount();
return ($7<$8)?$7:null;
}var $9=qx.bom.element.Location.get(this._headerClipper.getElement());
if($1>=$9.top&&$1<=$9.bottom&&$0<=$9.right){return -1;
}return null;
},
setTopRightWidget:function($0){var $1=this._topRightWidget;
if($1!=null){this._top.remove($1);
}
if($0!=null){this._top.remove(this._spacer);
this._top.add($0);
}else if($1!=null){this._top.add(this._spacer);
}this._topRightWidget=$0;
},
getHeader:function(){return this._header;
},
getTablePane:function(){return this._tablePane;
},
getNeededScrollBars:function($0,
$1){var $2=this._verScrollBar.getPreferredBoxWidth();
var $3=this._paneClipper.getInnerWidth();
if(this.getVerticalScrollBarVisible()){$3+=$2;
}var $4=this._paneClipper.getInnerHeight();
if(this.getHorizontalScrollBarVisible()){$4+=$2;
}var $5=this.getTablePaneModel().getTotalWidth();
var $6=this.getTable().getRowHeight()*this.getTable().getTableModel().getRowCount();
var $7=false;
var $8=false;
if($5>$3){$7=true;
if($6>$4-$2){$8=true;
}}else if($6>$4){$8=true;
if(!$1&&($5>$3-$2)){$7=true;
}}var $9=qx.ui.table.pane.Scroller.HORIZONTAL_SCROLLBAR;
var $a=qx.ui.table.pane.Scroller.VERTICAL_SCROLLBAR;
return (($0||$7)?$9:0)|(($1||!$8)?0:$a);
},
_applyScrollTimeout:function($0,
$1){if(this._updateInterval){window.clearInterval(this._updateInterval);
this._updateInterval=null;
}else{if(!this._onintervalWrapper){this._onintervalWrapper=qx.lang.Function.bind(this._oninterval,
this);
}this._updateInterval=window.setInterval(this._onintervalWrapper,
$0);
}},
_postponedUpdateContent:function(){this._updateContentPlanned=true;
},
_oninterval:function(){if(this._updateContentPlanned&&!this._tablePane._layoutPending){this._updateContentPlanned=false;
this._updateContent();
}},
_updateContent:function(){if(!this.isSeeable()){return;
}var $0=this._paneClipper.getInnerHeight();
var $1=this._horScrollBar.getValue();
var $2=this._verScrollBar.getValue();
var $3=this.getTable().getRowHeight();
var $4=Math.floor($2/$3);
var $5=this._tablePane.getFirstVisibleRow();
this._tablePane.setFirstVisibleRow($4);
var $6=Math.ceil($0/$3);
var $7=0;
var $8=this.getTable().getKeepFirstVisibleRowComplete();
if(!$8){$6++;
$7=$2%$3;
}this._tablePane.setVisibleRowCount($6);
if($4!=$5){this._updateFocusIndicator();
}this._header.setLeft(-$1);
if(this._paneClipper.__scrollLeft!=$1){this._paneClipper.__scrollLeft=$1;
this._paneClipper.setScrollLeft($1);
}if(!$8){this._paneClipper.setScrollTop($7);
}},
_updateFocusIndicator:function(){if(!this._showCellFocusIndicator){return;
}var $0=this.getTable();
if(!$0.getEnabled()){return;
}
if(this._focusedCol==null){this._focusIndicator.hide();
}else{var $1=this.getTablePaneModel().getX(this._focusedCol);
if($1==-1){this._focusIndicator.hide();
}else{var $2=$0.getTableColumnModel();
var $3=this.getTablePaneModel();
var $4=this._tablePane.getFirstVisibleRow();
var $5=$0.getRowHeight();
this._focusIndicator.setHeight($5+3);
this._focusIndicator.setWidth($2.getColumnWidth(this._focusedCol)+3);
this._focusIndicator.setTop((this._focusedRow-$4)*$5-2);
this._focusIndicator.setLeft($3.getColumnLeft(this._focusedCol)-2);
this._focusIndicator.show();
}}}},
destruct:function(){if(this.getElement()!=null){this.getElement().onselectstart=null;
}this._disposeObjects($[1881],
$[1541],
$[1383],
$[1991],
$[912],
$[1845],
$[1630],
$[1010],
$[1652],
$[363],
$[1289],
$[771]);
}});




/* ID: qx.ui.basic.ScrollBar */
qx.Class.define($[891],
{extend:qx.ui.layout.CanvasLayout,
construct:function($0){arguments.callee.base.call(this,
$0?$[167]:$[178]);
this._horizontal=($0==true);
this._scrollBar=new qx.ui.basic.ScrollArea;
if(qx.core.Variant.isSet($[1],
$[25])){this._scrollBar.setStyleProperty($[90],
$[0]);
}this._scrollBar.setOverflow($0?$[122]:$[104]);
this._scrollBar.addEventListener($[40],
this._onscroll,
this);
this._scrollContent=new qx.ui.basic.Terminator;
if(qx.core.Variant.isSet($[1],
$[25])){this._scrollContent.setStyleProperty($[90],
$[0]);
}this._scrollBar.add(this._scrollContent);
if(this._horizontal){this._scrollContent.setHeight(5);
this._scrollBar.setWidth($[80]);
this._scrollBar.setHeight(this._getScrollBarWidth());
if(qx.core.Variant.isSet($[1],
$[20])){this.setHeight(this._getScrollBarWidth());
this.setOverflow($[21]);
this._scrollBar.setHeight(this._getScrollBarWidth()+1);
this._scrollBar.setTop(-1);
}}else{this._scrollContent.setWidth(5);
this._scrollBar.setHeight($[80]);
this._scrollBar.setWidth(this._getScrollBarWidth());
if(qx.core.Variant.isSet($[1],
$[20])){this.setWidth(this._getScrollBarWidth());
this.setOverflow($[21]);
this._scrollBar.setWidth(this._getScrollBarWidth()+1);
this._scrollBar.setLeft(-1);
}}this.add(this._scrollBar);
this._blocker=new qx.ui.basic.Terminator();
this._blocker.set({left:0,
top:0,
height:$[80],
width:$[80],
display:!this.getEnabled()});
this._blocker.setAppearance($[954]);
this.add(this._blocker);
this.setMaximum(0);
},
statics:{EVENT_DELAY:250},
properties:{value:{check:$[12],
init:0,
apply:$[388],
event:$[190],
transform:$[2028]},
maximum:{check:$[6],
apply:$[1670]},
mergeEvents:{check:$[2],
init:false}},
members:{_checkValue:function($0){var $1=!this.getElement()?0:(this._horizontal?this.getInnerWidth():this.getInnerHeight());
return Math.max(0,
Math.min(this.getMaximum()-$1,
$0));
},
_applyValue:function($0,
$1){if(!this._internalValueChange&&this._isCreated){this._positionKnob($0);
}},
_applyMaximum:function($0,
$1){if(this._horizontal){this._scrollContent.setWidth($0);
}else{this._scrollContent.setHeight($0);
}this.setValue(this._checkValue(this.getValue()));
},
_applyVisibility:function($0,
$1){if(!$0){this._positionKnob(0);
}else{this._positionKnob(this.getValue());
}return arguments.callee.base.call(this,
$0,
$1);
},
_computePreferredInnerWidth:function(){return this._horizontal?0:this._getScrollBarWidth();
},
_computePreferredInnerHeight:function(){return this._horizontal?this._getScrollBarWidth():0;
},
_applyEnabled:function($0){arguments.callee.base.call(this);
this._blocker.setDisplay(!this.getEnabled());
},
_getScrollBarWidth:function(){if(qx.ui.basic.ScrollBar._scrollBarWidth==null){var $0=document.createElement($[101]);
$0.style.width=$[274];
$0.style.height=$[274];
$0.style.overflow=$[40];
$0.style.visibility=$[21];
document.body.appendChild($0);
qx.ui.basic.ScrollBar._scrollBarWidth=$0.offsetWidth-$0.clientWidth;
document.body.removeChild($0);
}return qx.ui.basic.ScrollBar._scrollBarWidth;
},
_onscroll:function($0){var $1=this._horizontal?this._scrollBar.getScrollLeft():this._scrollBar.getScrollTop();
if(this.getMergeEvents()){this._lastScrollEventValue=$1;
window.clearTimeout(this._setValueTimerId);
var $2=this;
this._setValueTimerId=window.setTimeout(function(){$2._internalValueChange=true;
$2.setValue($2._lastScrollEventValue);
$2._internalValueChange=false;
qx.ui.core.Widget.flushGlobalQueues();
},
qx.ui.basic.ScrollBar.EVENT_DELAY);
}else{this._internalValueChange=true;
this.setValue($1);
this._internalValueChange=false;
qx.ui.core.Widget.flushGlobalQueues();
}},
_positionKnob:function($0){if(this.isCreated()){if(this._horizontal){this._scrollBar.setScrollLeft($0);
}else{this._scrollBar.setScrollTop($0);
}}},
_afterAppear:function(){arguments.callee.base.call(this);
this._positionKnob(this.getValue());
}},
destruct:function(){this._disposeObjects($[2025],
$[944],
$[568]);
}});




/* ID: qx.ui.basic.ScrollArea */
qx.Class.define($[1435],
{extend:qx.ui.layout.CanvasLayout,
construct:function(){arguments.callee.base.call(this);
this.__onscroll=qx.lang.Function.bindEvent(this._onscroll,
this);
},
events:{"scroll":$[4]},
members:{_applyElement:function($0,
$1){arguments.callee.base.call(this,
$0,
$1);
if($0){if(qx.core.Variant.isSet($[1],
$[20])){$0.attachEvent($[387],
this.__onscroll);
}else{$0.addEventListener($[40],
this.__onscroll,
false);
}}},
_onscroll:function($0){this.createDispatchEvent($[40]);
qx.event.handler.EventHandler.stopDomEvent($0);
}},
destruct:function(){var $0=this.getElement();
if($0){if(qx.core.Variant.isSet($[1],
$[20])){$0.detachEvent($[387],
this.__onscroll);
}else{$0.removeEventListener($[40],
this.__onscroll,
false);
}delete this.__onscroll;
}}});




/* ID: qx.ui.table.pane.CellEvent */
qx.Class.define($[150],
{extend:qx.event.type.MouseEvent,
construct:function($0,
$1){arguments.callee.base.call(this,
$[734]+qx.lang.String.toFirstUp($1.getType()),
$1.getDomEvent(),
$1.getDomTarget(),
$1.getTarget(),
$1.getOriginalTarget(),
$1.getRelatedTarget());
console.debug('evento '+this.getType());
this._scroller=$0;
},
properties:{row:{_fast:true,
readOnly:true},
column:{_fast:true,
readOnly:true}},
members:{_computeRow:function(){if(this._row==null){this._row=this._scroller._getRowForPagePos(this.getPageX(),
this.getPageY());
}return this._row;
},
_computeColumn:function(){if(this._column==null){this._column=this._scroller._getColumnForPageX(this.getPageX());
}return this._column;
}}});




/* ID: qx.ui.resizer.MResizable */
qx.Mixin.define($[1256],
{construct:function($0){this._frame=new qx.ui.basic.Terminator;
this._frame.setAppearance($[1530]);
this.addEventListener($[18],
this._onmousedown);
this.addEventListener($[39],
this._onmouseup);
this.addEventListener($[135],
this._onmousemove);
},
properties:{resizableWest:{check:$[2],
init:true,
apply:$[219]},
resizableNorth:{check:$[2],
init:true,
apply:$[219]},
resizableEast:{check:$[2],
init:true,
apply:$[219]},
resizableSouth:{check:$[2],
init:true,
apply:$[219]},
resizable:{group:[$[722],
$[663],
$[1897],
$[1322]],
mode:$[111]},
resizeMethod:{init:$[93],
check:[$[259],
$[533],
$[93],
$[151]],
event:$[857]}},
members:{isResizable:function(){return this.getResizableWest()||this.getResizableEast()||this.getResizableNorth()||this.getResizableSouth();
},
getResizable:function(){return this.isResizable();
},
_applyResizable:function($0,
$1){},
_onmousedown:function($0){if(this._resizeNorth||this._resizeSouth||this._resizeWest||this._resizeEast){this.setCapture(true);
this.getTopLevelWidget().setGlobalCursor(this.getCursor());
var $1=this.getElement();
var $2=this._getResizeParent();
var $3=$2.getElement();
var $4=qx.html.Location.getPageAreaLeft($3);
var $5=qx.html.Location.getPageAreaTop($3);
var $6=qx.html.Location.getPageAreaRight($3);
var $7=qx.html.Location.getPageAreaBottom($3);
switch(this.getResizeMethod()){case $[151]:this.setOpacity(0.5);
break;
case $[93]:var $8=this._frame;
if($8.getParent()!=$2){$8.setParent($2);
qx.ui.core.Widget.flushGlobalQueues();
}$8._renderRuntimeLeft(qx.html.Location.getPageBoxLeft($1)-$4);
$8._renderRuntimeTop(qx.html.Location.getPageBoxTop($1)-$5);
$8._renderRuntimeWidth(qx.html.Dimension.getBoxWidth($1));
$8._renderRuntimeHeight(qx.html.Dimension.getBoxHeight($1));
$8.setZIndex(this.getZIndex()+1);
break;
}var $9=this._resizeSession={};
var $a=this._getMinSizeReference();
if(this._resizeWest){$9.boxWidth=qx.html.Dimension.getBoxWidth($1);
$9.boxRight=qx.html.Location.getPageBoxRight($1);
}
if(this._resizeWest||this._resizeEast){$9.boxLeft=qx.html.Location.getPageBoxLeft($1);
$9.parentAreaOffsetLeft=$4;
$9.parentAreaOffsetRight=$6;
$9.minWidth=$a.getMinWidthValue();
$9.maxWidth=$a.getMaxWidthValue();
}
if(this._resizeNorth){$9.boxHeight=qx.html.Dimension.getBoxHeight($1);
$9.boxBottom=qx.html.Location.getPageBoxBottom($1);
}
if(this._resizeNorth||this._resizeSouth){$9.boxTop=qx.html.Location.getPageBoxTop($1);
$9.parentAreaOffsetTop=$5;
$9.parentAreaOffsetBottom=$7;
$9.minHeight=$a.getMinHeightValue();
$9.maxHeight=$a.getMaxHeightValue();
}}else{delete this._resizeSession;
}$0.stopPropagation();
},
_onmouseup:function($0){var $1=this._resizeSession;
if($1){this.setCapture(false);
this.getTopLevelWidget().setGlobalCursor(null);
switch(this.getResizeMethod()){case $[93]:var $2=this._frame;
if(!($2&&$2.getParent())){break;
}case $[533]:if($1.lastLeft!=null){this.setLeft($1.lastLeft);
}
if($1.lastTop!=null){this.setTop($1.lastTop);
}
if($1.lastWidth!=null){this._changeWidth($1.lastWidth);
}
if($1.lastHeight!=null){this._changeHeight($1.lastHeight);
}
if(this.getResizeMethod()==$[93]){this._frame.setParent(null);
}break;
case $[151]:this.setOpacity(null);
break;
}delete this._resizeSession;
}$0.stopPropagation();
},
_near:function($0,
$1){return $1>($0-5)&&$1<($0+5);
},
_onmousemove:function($0){if(this._disableResize){return;
}var $1=this._resizeSession;
if($1){if(this._resizeWest){$1.lastWidth=qx.lang.Number.limit($1.boxWidth+$1.boxLeft-Math.max($0.getPageX(),
$1.parentAreaOffsetLeft),
$1.minWidth,
$1.maxWidth);
$1.lastLeft=$1.boxRight-$1.lastWidth-$1.parentAreaOffsetLeft;
}else if(this._resizeEast){$1.lastWidth=qx.lang.Number.limit(Math.min($0.getPageX(),
$1.parentAreaOffsetRight)-$1.boxLeft,
$1.minWidth,
$1.maxWidth);
}
if(this._resizeNorth){$1.lastHeight=qx.lang.Number.limit($1.boxHeight+$1.boxTop-Math.max($0.getPageY(),
$1.parentAreaOffsetTop),
$1.minHeight,
$1.maxHeight);
$1.lastTop=$1.boxBottom-$1.lastHeight-$1.parentAreaOffsetTop;
}else if(this._resizeSouth){$1.lastHeight=qx.lang.Number.limit(Math.min($0.getPageY(),
$1.parentAreaOffsetBottom)-$1.boxTop,
$1.minHeight,
$1.maxHeight);
}
switch(this.getResizeMethod()){case $[259]:case $[151]:if(this._resizeWest||this._resizeEast){this.setWidth($1.lastWidth);
if(this._resizeWest){this.setLeft($1.lastLeft);
}}
if(this._resizeNorth||this._resizeSouth){this.setHeight($1.lastHeight);
if(this._resizeNorth){this.setTop($1.lastTop);
}}break;
default:var $2=this.getResizeMethod()==$[93]?this._frame:this;
if(this._resizeWest||this._resizeEast){$2._renderRuntimeWidth($1.lastWidth);
if(this._resizeWest){$2._renderRuntimeLeft($1.lastLeft);
}}
if(this._resizeNorth||this._resizeSouth){$2._renderRuntimeHeight($1.lastHeight);
if(this._resizeNorth){$2._renderRuntimeTop($1.lastTop);
}}}}else{var $3=$[0];
var $4=this.getElement();
this._resizeNorth=this._resizeSouth=this._resizeWest=this._resizeEast=false;
if(this._near(qx.html.Location.getPageBoxTop($4),
$0.getPageY())){if(this.getResizableNorth()){$3=$[779];
this._resizeNorth=true;
}}else if(this._near(qx.html.Location.getPageBoxBottom($4),
$0.getPageY())){if(this.getResizableSouth()){$3=$[346];
this._resizeSouth=true;
}}
if(this._near(qx.html.Location.getPageBoxLeft($4),
$0.getPageX())){if(this.getResizableWest()){$3+=$[1642];
this._resizeWest=true;
}}else if(this._near(qx.html.Location.getPageBoxRight($4),
$0.getPageX())){if(this.getResizableEast()){$3+=$[1666];
this._resizeEast=true;
}}
if(this._resizeNorth||this._resizeSouth||this._resizeWest||this._resizeEast){this.setCursor($3+$[1728]);
}else{this.resetCursor();
}}$0.stopPropagation();
}},
destruct:function(){this._disposeObjects($[592]);
}});




/* ID: qx.ui.resizer.IResizable */
qx.Interface.define($[1188],
{members:{_changeWidth:function($0){return true;
},
_changeHeight:function($0){return true;
},
_getResizeParent:function(){return true;
},
_getMinSizeReference:function(){return true;
}}});




/* ID: qx.ui.resizer.ResizablePopup */
qx.Class.define($[1702],
{extend:qx.ui.popup.Popup,
include:qx.ui.resizer.MResizable,
implement:qx.ui.resizer.IResizable,
construct:function(){arguments.callee.base.call(this);
this.initMinWidth();
this.initMinHeight();
this.initWidth();
this.initHeight();
},
properties:{appearance:{refine:true,
init:$[576]},
minWidth:{refine:true,
init:$[3]},
minHeight:{refine:true,
init:$[3]},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]}},
members:{_changeWidth:function($0){this.setWidth($0);
},
_changeHeight:function($0){this.setHeight($0);
},
_getResizeParent:function(){return this.getParent();
},
_getMinSizeReference:function(){return this;
}}});




/* ID: qx.ui.window.Window */
qx.Class.define($[593],
{extend:qx.ui.resizer.ResizablePopup,
construct:function($0,
$1,
$2){arguments.callee.base.call(this);
this.setWindowManager($2||qx.ui.window.Window.getDefaultWindowManager());
var $3=this._layout=new qx.ui.layout.VerticalBoxLayout;
$3.setEdge(0);
this.add($3);
var $4=this._captionBar=new qx.ui.layout.HorizontalBoxLayout;
$4.setAppearance($[1167]);
$4.setHeight($[3]);
$4.setOverflow($[21]);
$3.add($4);
var $5=this._captionIcon=new qx.ui.basic.Image;
$5.setAppearance($[1279]);
$4.add($5);
var $6=this._captionTitle=new qx.ui.basic.Label($0);
$6.setAppearance($[1894]);
$6.setSelectable(false);
$4.add($6);
var $7=this._captionFlex=new qx.ui.basic.HorizontalSpacer;
$4.add($7);
var $8=this._minimizeButton=new qx.ui.form.Button;
$8.setAppearance($[1764]);
$8.setTabIndex(-1);
$8.addEventListener($[117],
this._onminimizebuttonclick,
this);
$8.addEventListener($[18],
this._onbuttonmousedown,
this);
$4.add($8);
var $9=this._restoreButton=new qx.ui.form.Button;
$9.setAppearance($[984]);
$9.setTabIndex(-1);
$9.addEventListener($[117],
this._onrestorebuttonclick,
this);
$9.addEventListener($[18],
this._onbuttonmousedown,
this);
var $a=this._maximizeButton=new qx.ui.form.Button;
$a.setAppearance($[1418]);
$a.setTabIndex(-1);
$a.addEventListener($[117],
this._onmaximizebuttonclick,
this);
$a.addEventListener($[18],
this._onbuttonmousedown,
this);
$4.add($a);
var $b=this._closeButton=new qx.ui.form.Button;
$b.setAppearance($[1941]);
$b.setTabIndex(-1);
$b.addEventListener($[117],
this._onclosebuttonclick,
this);
$b.addEventListener($[18],
this._onbuttonmousedown,
this);
$4.add($b);
var $c=this._pane=new qx.ui.layout.CanvasLayout;
$c.setHeight($[87]);
$c.setOverflow($[21]);
$3.add($c);
var $d=this._statusBar=new qx.ui.layout.HorizontalBoxLayout;
$d.setAppearance($[1111]);
$d.setHeight($[3]);
var $e=this._statusText=new qx.ui.basic.Label($[293]);
$e.setAppearance($[1626]);
$e.setSelectable(false);
$d.add($e);
if($0!=null){this.setCaption($0);
}
if($1!=null){this.setIcon($1);
}this.setAutoHide(false);
this.addEventListener($[18],
this._onwindowmousedown);
this.addEventListener($[99],
this._onwindowclick);
$4.addEventListener($[18],
this._oncaptionmousedown,
this);
$4.addEventListener($[39],
this._oncaptionmouseup,
this);
$4.addEventListener($[135],
this._oncaptionmousemove,
this);
$4.addEventListener($[152],
this._oncaptiondblblick,
this);
this.remapChildrenHandlingTo(this._pane);
},
statics:{getDefaultWindowManager:function(){if(!qx.ui.window.Window._defaultWindowManager){qx.ui.window.Window._defaultWindowManager=new qx.ui.window.Manager;
}return qx.ui.window.Window._defaultWindowManager;
}},
properties:{appearance:{refine:true,
init:$[1069]},
windowManager:{check:$[595],
event:$[1657]},
active:{check:$[2],
init:false,
apply:$[648],
event:$[1730]},
modal:{check:$[2],
init:false,
apply:$[1855],
event:$[1106]},
mode:{check:[$[243],
$[77]],
init:null,
nullable:true,
apply:$[2047],
event:$[1360]},
opener:{check:$[112]},
caption:{apply:$[1282],
event:$[1665],
dispose:true},
icon:{check:$[9],
nullable:true,
apply:$[287],
event:$[925]},
status:{check:$[9],
init:$[293],
apply:$[1356],
event:$[1716]},
showClose:{check:$[2],
init:true,
apply:$[1220]},
showMaximize:{check:$[2],
init:true,
apply:$[1300]},
showMinimize:{check:$[2],
init:true,
apply:$[1772]},
showStatusbar:{check:$[2],
init:false,
apply:$[1382]},
allowClose:{check:$[2],
init:true,
apply:$[678]},
allowMaximize:{check:$[2],
init:true,
apply:$[1387]},
allowMinimize:{check:$[2],
init:true,
apply:$[1797]},
showCaption:{check:$[2],
init:true,
apply:$[1733]},
showIcon:{check:$[2],
init:true,
apply:$[1774]},
moveable:{check:$[2],
init:true,
event:$[1708]},
moveMethod:{check:[$[259],
$[93],
$[151]],
init:$[259],
event:$[1125]}},
members:{getPane:function(){return this._pane;
},
getCaptionBar:function(){return this._captionBar;
},
getStatusBar:function(){return this._statusBar;
},
close:function(){this.hide();
},
open:function($0){if($0!=null){this.setOpener($0);
}
if(this.getCentered()){this.centerToBrowser();
}this.show();
},
focus:function(){this.setActive(true);
},
blur:function(){this.setActive(false);
},
maximize:function(){this.setMode($[77]);
},
minimize:function(){this.setMode($[243]);
},
restore:function(){this.setMode(null);
},
_beforeAppear:function(){qx.ui.layout.CanvasLayout.prototype._beforeAppear.call(this);
qx.ui.popup.PopupManager.getInstance().update();
qx.event.handler.EventHandler.getInstance().setFocusRoot(this);
this.getWindowManager().add(this);
this._makeActive();
},
_beforeDisappear:function(){qx.ui.layout.CanvasLayout.prototype._beforeDisappear.call(this);
var $0=qx.event.handler.EventHandler.getInstance().getFocusRoot();
if($0==this||this.contains($0)){qx.event.handler.EventHandler.getInstance().setFocusRoot(null);
}var $1=qx.event.handler.EventHandler.getInstance().getCaptureWidget();
if($1&&this.contains($1)){$1.setCapture(false);
}this.getWindowManager().remove(this);
this._makeInactive();
},
_minZIndex:1e5,
_sendTo:function(){var $0=qx.lang.Object.getValues(this.getWindowManager().getAll()).sort(qx.util.Compare.byZIndex);
var $1=$0.length;
var $2=this._minZIndex;
for(var $3=0;$3<$1;$3++){$0[$3].setZIndex($2++);
}},
_applyActive:function($0,
$1){if($1){if(this.getFocused()){this.setFocused(false);
}
if(this.getWindowManager().getActiveWindow()==this){this.getWindowManager().setActiveWindow(null);
}this.removeState($[70]);
this._captionBar.removeState($[70]);
this._minimizeButton.removeState($[70]);
this._restoreButton.removeState($[70]);
this._maximizeButton.removeState($[70]);
this._closeButton.removeState($[70]);
}else{if(!this.getFocusedChild()){this.setFocused(true);
}this.getWindowManager().setActiveWindow(this);
this.bringToFront();
this.addState($[70]);
this._captionBar.addState($[70]);
this._minimizeButton.addState($[70]);
this._restoreButton.addState($[70]);
this._maximizeButton.addState($[70]);
this._closeButton.addState($[70]);
}},
_applyModal:function($0,
$1){if(this._initialLayoutDone&&this.getVisibility()&&this.getDisplay()){var $2=this.getTopLevelWidget();
$0?$2.block(this):$2.release(this);
}},
_applyAllowClose:function($0,
$1){this._closeButtonManager();
},
_applyAllowMaximize:function($0,
$1){this._maximizeButtonManager();
},
_applyAllowMinimize:function($0,
$1){this._minimizeButtonManager();
},
_applyMode:function($0,
$1){switch($0){case $[243]:this._disableResize=true;
this._minimize();
break;
case $[77]:this._disableResize=true;
this._maximize();
break;
default:delete this._disableResize;
switch($1){case $[77]:this._restoreFromMaximized();
break;
case $[243]:this._restoreFromMinimized();
break;
}}},
_applyShowCaption:function($0,
$1){if($0){this._captionBar.addAt(this._captionTitle,
this.getShowIcon()?1:0);
}else{this._captionBar.remove(this._captionTitle);
}},
_applyShowIcon:function($0,
$1){if($0){this._captionBar.addAtBegin(this._captionIcon);
}else{this._captionBar.remove(this._captionIcon);
}},
_applyShowStatusbar:function($0,
$1){if($0){this._layout.addAtEnd(this._statusBar);
}else{this._layout.remove(this._statusBar);
}},
_applyShowClose:function($0,
$1){if($0){this._captionBar.addAtEnd(this._closeButton);
}else{this._captionBar.remove(this._closeButton);
}},
_applyShowMaximize:function($0,
$1){if($0){var $2=this.getMode()==$[77]?this._restoreButton:this._maximizeButton;
if(this.getShowMinimize()){this._captionBar.addAfter($2,
this._minimizeButton);
}else{this._captionBar.addAfter($2,
this._captionFlex);
}}else{this._captionBar.remove(this._maximizeButton);
this._captionBar.remove(this._restoreButton);
}},
_applyShowMinimize:function($0,
$1){if($0){this._captionBar.addAfter(this._minimizeButton,
this._captionFlex);
}else{this._captionBar.remove(this._minimizeButton);
}},
_minimizeButtonManager:function(){this.getAllowMinimize()===false?this._minimizeButton.setEnabled(false):this._minimizeButton.resetEnabled();
},
_closeButtonManager:function(){this.getAllowClose()===false?this._closeButton.setEnabled(false):this._closeButton.resetEnabled();
},
_maximizeButtonManager:function(){var $0=this.getAllowMaximize()&&this.getResizable()&&this._computedMaxWidthTypeNull&&this._computedMaxHeightTypeNull;
if(this._maximizeButton){$0===false?this._maximizeButton.setEnabled(false):this._maximizeButton.resetEnabled();
}
if(this._restoreButton){$0===false?this._restoreButton.setEnabled(false):this._restoreButton.resetEnabled();
}},
_applyStatus:function($0,
$1){this._statusText.setText($0);
},
_applyMaxWidth:function($0,
$1){arguments.callee.base.call(this);
this._maximizeButtonManager();
},
_applyMaxHeight:function($0,
$1){arguments.callee.base.call(this);
this._maximizeButtonManager();
},
_applyResizable:function($0,
$1){this._maximizeButtonManager();
},
_applyCaption:function($0,
$1){this._captionTitle.setText($0);
},
_applyIcon:function($0,
$1){this._captionIcon.setSource($0);
},
_minimize:function(){this.blur();
this.hide();
},
_restoreFromMaximized:function(){this.setLeft(this._previousLeft?this._previousLeft:null);
this.setWidth(this._previousWidth?this._previousWidth:null);
this.setRight(this._previousRight?this._previousRight:null);
this.setTop(this._previousTop?this._previousTop:null);
this.setHeight(this._previousHeight?this._previousHeight:null);
this.setBottom(this._previousBottom?this._previousBottom:null);
this.removeState($[77]);
if(this.getShowMaximize()){var $0=this._captionBar;
var $1=$0.indexOf(this._restoreButton);
$0.remove(this._restoreButton);
$0.addAt(this._maximizeButton,
$1);
}this.focus();
},
_restoreFromMinimized:function(){if(this.hasState($[77])){this.setMode($[77]);
}this.show();
this.focus();
},
_maximize:function(){if(this.hasState($[77])){return;
}this._previousLeft=this.getLeft();
this._previousWidth=this.getWidth();
this._previousRight=this.getRight();
this._previousTop=this.getTop();
this._previousHeight=this.getHeight();
this._previousBottom=this.getBottom();
this.setWidth(null);
this.setLeft(0);
this.setRight(0);
this.setHeight(null);
this.setTop(0);
this.setBottom(0);
this.addState($[77]);
if(this.getShowMaximize()){var $0=this._captionBar;
var $1=$0.indexOf(this._maximizeButton);
$0.remove(this._maximizeButton);
$0.addAt(this._restoreButton,
$1);
}this.focus();
},
_onwindowclick:function($0){$0.stopPropagation();
},
_onwindowmousedown:function($0){this.focus();
},
_onbuttonmousedown:function($0){$0.stopPropagation();
},
_onminimizebuttonclick:function($0){this.minimize();
this._minimizeButton.removeState($[31]);
this._minimizeButton.removeState($[55]);
this._minimizeButton.removeState($[64]);
$0.stopPropagation();
},
_onrestorebuttonclick:function($0){this.restore();
this._restoreButton.removeState($[31]);
this._restoreButton.removeState($[55]);
this._restoreButton.removeState($[64]);
$0.stopPropagation();
},
_onmaximizebuttonclick:function($0){this.maximize();
this._maximizeButton.removeState($[31]);
this._maximizeButton.removeState($[55]);
this._maximizeButton.removeState($[64]);
$0.stopPropagation();
},
_onclosebuttonclick:function($0){this.close();
this._closeButton.removeState($[31]);
this._closeButton.removeState($[55]);
this._closeButton.removeState($[64]);
$0.stopPropagation();
},
_oncaptionmousedown:function($0){if(!$0.isLeftButtonPressed()||!this.getMoveable()||this.getMode()!=null){return;
}this._captionBar.setCapture(true);
var $1=this.getElement();
var $2=this.getParent();
var $3=$2.getElement();
var $4=qx.html.Location.getPageAreaLeft($3);
var $5=qx.html.Location.getPageAreaTop($3);
var $6=qx.html.Location.getPageAreaRight($3);
var $7=qx.html.Location.getPageAreaBottom($3);
this._dragSession={offsetX:$0.getPageX()-qx.bom.element.Location.getLeft($1)+$4,
offsetY:$0.getPageY()-qx.bom.element.Location.getTop($1)+$5,
parentAvailableAreaLeft:$4+5,
parentAvailableAreaTop:$5+5,
parentAvailableAreaRight:$6-5,
parentAvailableAreaBottom:$7-5};
switch(this.getMoveMethod()){case $[151]:this.setOpacity(0.5);
break;
case $[93]:var $8=this._frame;
if($8.getParent()!=this.getParent()){$8.setParent(this.getParent());
qx.ui.core.Widget.flushGlobalQueues();
}$8._renderRuntimeLeft(qx.bom.element.Location.getLeft($1)-$4);
$8._renderRuntimeTop(qx.bom.element.Location.getTop($1)-$5);
$8._renderRuntimeWidth(qx.html.Dimension.getBoxWidth($1));
$8._renderRuntimeHeight(qx.html.Dimension.getBoxHeight($1));
$8.setZIndex(this.getZIndex()+1);
break;
}},
_oncaptionmouseup:function($0){var $1=this._dragSession;
if(!$1){return;
}this._captionBar.setCapture(false);
if($1.lastX!=null){this.setLeft($1.lastX);
}
if($1.lastY!=null){this.setTop($1.lastY);
}switch(this.getMoveMethod()){case $[151]:this.setOpacity(null);
break;
case $[93]:this._frame.setParent(null);
break;
}delete this._dragSession;
},
_oncaptionmousemove:function($0){var $1=this._dragSession;
if(!$1||!this._captionBar.getCapture()){return;
}if(!qx.lang.Number.isBetweenRange($0.getPageX(),
$1.parentAvailableAreaLeft,
$1.parentAvailableAreaRight)||!qx.lang.Number.isBetweenRange($0.getPageY(),
$1.parentAvailableAreaTop,
$1.parentAvailableAreaBottom)){return;
}var $2=this.getMoveMethod()==$[93]?this._frame:this;
$2._renderRuntimeLeft($1.lastX=$0.getPageX()-$1.offsetX);
$2._renderRuntimeTop($1.lastY=$0.getPageY()-$1.offsetY);
},
_oncaptiondblblick:function($0){if(!this._maximizeButton.getEnabled()){return;
}return this.getMode()==$[77]?this.restore():this.maximize();
}},
destruct:function(){this._disposeObjects($[394],
$[850],
$[1720],
$[1742],
$[1927],
$[1513],
$[1476],
$[1173],
$[1100],
$[1363],
$[465],
$[1471]);
}});




/* ID: qx.ui.window.Manager */
qx.Class.define($[595],
{extend:qx.util.manager.Object,
properties:{activeWindow:{check:$[97],
nullable:true,
apply:$[847]}},
members:{_applyActiveWindow:function($0,
$1){qx.ui.popup.PopupManager.getInstance().update();
if($1){$1.setActive(false);
}
if($0){$0.setActive(true);
}
if($1&&$1.getModal()){$1.getTopLevelWidget().release($1);
}
if($0&&$0.getModal()){$0.getTopLevelWidget().block($0);
}},
update:function(){var $0,
$1;
var $2=this.getAll();
for(var $1 in $2){$0=$2[$1];
if(!$0.getAutoHide()){continue;
}$0.hide();
}},
compareWindows:function($0,
$1){switch($0.getWindowManager().getActiveWindow()){case $0:return 1;
case $1:return -1;
}return $0.getZIndex()-$1.getZIndex();
},
add:function($0){arguments.callee.base.call(this,
$0);
this.setActiveWindow($0);
},
remove:function($0){arguments.callee.base.call(this,
$0);
if(this.getActiveWindow()==$0){var $1=[];
for(var $2 in this._objects){$1.push(this._objects[$2]);
}var $3=$1.length;
if($3==0){this.setActiveWindow(null);
}else if($3==1){this.setActiveWindow($1[0]);
}else if($3>1){$1.sort(this.compareWindows);
this.setActiveWindow($1[$3-1]);
}}}}});




/* ID: qx.ui.table.pane.Model */
qx.Class.define($[638],
{extend:qx.core.Target,
construct:function($0){arguments.callee.base.call(this);
$0.addEventListener($[563],
this._onColVisibilityChanged,
this);
this._tableColumnModel=$0;
},
events:{"modelChanged":$[4]},
statics:{EVENT_TYPE_MODEL_CHANGED:"modelChanged"},
properties:{firstColumnX:{check:$[6],
init:0,
apply:$[867]},
maxColumnCount:{check:$[12],
init:-1,
apply:$[652]}},
members:{_applyFirstColumnX:function($0,
$1){this._columnCount=null;
this.createDispatchEvent(qx.ui.table.pane.Model.EVENT_TYPE_MODEL_CHANGED);
},
_applyMaxColumnCount:function($0,
$1){this._columnCount=null;
this.createDispatchEvent(qx.ui.table.pane.Model.EVENT_TYPE_MODEL_CHANGED);
},
_onColVisibilityChanged:function($0){this._columnCount=null;
this.createDispatchEvent(qx.ui.table.pane.Model.EVENT_TYPE_MODEL_CHANGED);
},
getColumnCount:function(){if(this._columnCount==null){var $0=this.getFirstColumnX();
var $1=this.getMaxColumnCount();
var $2=this._tableColumnModel.getVisibleColumnCount();
if($1==-1||($0+$1)>$2){this._columnCount=$2-$0;
}else{this._columnCount=$1;
}}return this._columnCount;
},
getColumnAtX:function($0){var $1=this.getFirstColumnX();
return this._tableColumnModel.getVisibleColumnAtX($1+$0);
},
getX:function($0){var $1=this.getFirstColumnX();
var $2=this.getMaxColumnCount();
var $3=this._tableColumnModel.getVisibleX($0)-$1;
if($3>=0&&($2==-1||$3<$2)){return $3;
}else{return -1;
}},
getColumnLeft:function($0){var $1=0;
var $2=this.getColumnCount();
for(var $3=0;$3<$2;$3++){var $4=this.getColumnAtX($3);
if($4==$0){return $1;
}$1+=this._tableColumnModel.getColumnWidth($4);
}return -1;
},
getTotalWidth:function(){var $0=0;
var $1=this.getColumnCount();
for(var $2=0;$2<$1;$2++){var $3=this.getColumnAtX($2);
$0+=this._tableColumnModel.getColumnWidth($3);
}return $0;
}},
destruct:function(){this._disposeObjects($[1713]);
}});




/* ID: qx.ui.table.ITableModel */
qx.Interface.define($[627],
{events:{"dataChanged":$[42],
"metaDataChanged":$[42]},
statics:{EVENT_TYPE_DATA_CHANGED:"dataChanged",
EVENT_TYPE_META_DATA_CHANGED:"metaDataChanged"},
members:{getRowCount:function(){return true;
},
getRowData:function($0){return true;
},
getColumnCount:function(){return true;
},
getColumnId:function($0){return true;
},
getColumnIndexById:function($0){return true;
},
getColumnName:function($0){return true;
},
isColumnEditable:function($0){return true;
},
isColumnSortable:function($0){return true;
},
sortByColumn:function($0,
$1){return true;
},
getSortColumnIndex:function(){return true;
},
isSortAscending:function(){return true;
},
prefetchRows:function($0,
$1){return true;
},
getValue:function($0,
$1){return true;
},
getValueById:function($0,
$1){return true;
},
setValue:function($0,
$1,
$2){return true;
},
setValueById:function($0,
$1,
$2){return true;
}}});




/* ID: qx.ui.menu.Menu */
qx.Class.define($[175],
{extend:qx.ui.popup.Popup,
construct:function(){arguments.callee.base.call(this);
var $0=this._layout=new qx.ui.menu.Layout;
$0.setEdge(0);
this.add($0);
this.initOpenInterval();
this.initCloseInterval();
this.addEventListener($[86],
this._onmouseover);
this.addEventListener($[135],
this._onmouseover);
this.addEventListener($[113],
this._onmouseout);
this.addEventListener($[45],
this._onkeydown);
this.addEventListener($[57],
this._onkeypress);
this.remapChildrenHandlingTo(this._layout);
this.initWidth();
this.initHeight();
},
properties:{appearance:{refine:true,
init:$[582]},
width:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
iconContentGap:{check:$[6],
themeable:true,
init:4},
labelShortcutGap:{check:$[6],
themeable:true,
init:10},
contentArrowGap:{check:$[6],
themeable:true,
init:8},
contentNonIconPadding:{check:$[6],
themeable:true,
init:20},
contentNonArrowPadding:{check:$[6],
themeable:true,
init:8},
hoverItem:{check:$[112],
nullable:true,
apply:$[1235]},
openItem:{check:$[112],
nullable:true,
apply:$[1914]},
opener:{check:$[112],
nullable:true},
parentMenu:{check:$[175],
nullable:true},
fastReopen:{check:$[2],
init:false},
openInterval:{check:$[6],
themeable:true,
init:250,
apply:$[1067]},
closeInterval:{check:$[6],
themeable:true,
init:250,
apply:$[1179]},
subMenuHorizontalOffset:{check:$[6],
themeable:true,
init:-3},
subMenuVerticalOffset:{check:$[6],
themeable:true,
init:-2},
indentShortcuts:{check:$[2],
init:true},
maxIconWidth:{_cached:true},
maxLabelWidth:{_cached:true},
maxLabelWidthIncShortcut:{_cached:true},
maxShortcutWidth:{_cached:true},
maxArrowWidth:{_cached:true},
maxContentWidth:{_cached:true},
iconPosition:{_cached:true,
defaultValue:0},
labelPosition:{_cached:true},
shortcutPosition:{_cached:true},
arrowPosition:{_cached:true},
menuButtonNeededWidth:{_cached:true}},
members:{_remappingChildTable:[$[422],
$[444],
$[461],
$[559],
$[354],
$[611],
$[538],
$[369],
$[358],
$[1891],
$[971],
$[1976],
$[1238]],
_isFocusRoot:false,
getLayout:function(){return this._layout;
},
isSubElement:function($0,
$1){if(($0.getParent()===this._layout)||((!$1)&&($0===this))){return true;
}
for(var $2=this._layout.getChildren(),
$3=$2.length,
$4=0;$4<$3;$4++){if($2[$4].getMenu&&$2[$4].getMenu()&&$2[$4].getMenu().isSubElement($0,
$1)){return true;
}}return false;
},
_beforeAppear:function(){qx.ui.layout.CanvasLayout.prototype._beforeAppear.call(this);
qx.ui.menu.Manager.getInstance().add(this);
this.bringToFront();
this._makeActive();
},
_beforeDisappear:function(){qx.ui.layout.CanvasLayout.prototype._beforeDisappear.call(this);
qx.ui.menu.Manager.getInstance().remove(this);
this._makeInactive();
this.setHoverItem(null);
this.setOpenItem(null);
var $0=this.getOpener();
if($0){$0.removeState($[31]);
}},
_applyOpenInterval:function($0,
$1){if(!this._openTimer){this._openTimer=new qx.client.Timer($0);
this._openTimer.addEventListener($[67],
this._onopentimer,
this);
}else{this._openTimer.setInterval($0);
}},
_applyCloseInterval:function($0,
$1){if(!this._closeTimer){this._closeTimer=new qx.client.Timer(this.getCloseInterval());
this._closeTimer.addEventListener($[67],
this._onclosetimer,
this);
}else{this._closeTimer.setInterval($0);
}},
_applyHoverItem:function($0,
$1){if($1){$1.removeState($[64]);
}
if($0){$0.addState($[64]);
}},
_applyOpenItem:function($0,
$1){var $2=false;
if($1){var $3=$1.getMenu();
if($3){$3.setParentMenu(null);
$3.setOpener(null);
$3.hide();
}}
if($0){var $4=$0.getMenu();
if($4){$4.setOpener($0);
$4.setParentMenu(this);
var $5=$0.getElement();
var $6=this.getElement();
$4.setTop(qx.bom.element.Location.getTop($5)+this.getSubMenuVerticalOffset());
$4.setLeft(qx.bom.element.Location.getLeft($6)+qx.html.Dimension.getBoxWidth($6)+this.getSubMenuHorizontalOffset());
$4.show();
}}},
_computeMaxIconWidth:function(){var $0=this.getLayout().getChildren(),
$1=$0.length,
$2,
$3=0;
for(var $4=0;$4<$1;$4++){$2=$0[$4];
if($2.hasIcon()){$3=Math.max($3,
16);
}}return $3;
},
_computeMaxLabelWidth:function(){var $0=this.getLayout().getChildren(),
$1=$0.length,
$2,
$3=0;
for(var $4=0;$4<$1;$4++){$2=$0[$4];
if($2.hasLabel()){$3=Math.max($3,
$2.getLabelObject().getPreferredBoxWidth());
}}return $3;
},
_computeMaxLabelWidthIncShortcut:function(){var $0=this.getLayout().getChildren(),
$1=$0.length,
$2,
$3=0;
for(var $4=0;$4<$1;$4++){$2=$0[$4];
if($2.hasLabel()&&$2.hasShortcut()){$3=Math.max($3,
$2.getLabelObject().getPreferredBoxWidth());
}}return $3;
},
_computeMaxShortcutWidth:function(){var $0=this.getLayout().getChildren(),
$1=$0.length,
$2,
$3=0;
for(var $4=0;$4<$1;$4++){$2=$0[$4];
if($2.hasShortcut()){$3=Math.max($3,
$2.getShortcutObject().getPreferredBoxWidth());
}}return $3;
},
_computeMaxArrowWidth:function(){var $0=this.getLayout().getChildren(),
$1=$0.length,
$2,
$3=0;
for(var $4=0;$4<$1;$4++){$2=$0[$4];
if($2.hasMenu()){$3=Math.max($3,
4);
}}return $3;
},
_computeMaxContentWidth:function(){var $0;
var $1=this.getMaxLabelWidth();
var $2=this.getMaxShortcutWidth();
if(this.getIndentShortcuts()){var $3=$2+this.getMaxLabelWidthIncShortcut();
if($2>0){$3+=this.getLabelShortcutGap();
}$0=Math.max($1,
$3);
}else{$0=$1+$2;
if($1>0&&$2>0){$0+=this.getLabelShortcutGap();
}}return $0;
},
_computeIconPosition:function(){return 0;
},
_computeLabelPosition:function(){var $0=this.getMaxIconWidth();
return $0>0?$0+this.getIconContentGap():this.getContentNonIconPadding();
},
_computeShortcutPosition:function(){return this.getLabelPosition()+this.getMaxContentWidth()-this.getMaxShortcutWidth();
},
_computeArrowPosition:function(){var $0=this.getMaxContentWidth();
return this.getLabelPosition()+($0>0?$0+this.getContentArrowGap():$0);
},
_invalidateMaxIconWidth:function(){this._cachedMaxIconWidth=null;
this._invalidateLabelPosition();
this._invalidateMenuButtonNeededWidth();
},
_invalidateMaxLabelWidth:function(){this._cachedMaxLabelWidth=null;
this._invalidateShortcutPosition();
this._invalidateMaxLabelWidthIncShortcut();
this._invalidateMaxContentWidth();
this._invalidateMenuButtonNeededWidth();
},
_invalidateMaxShortcutWidth:function(){this._cachedMaxShortcutWidth=null;
this._invalidateArrowPosition();
this._invalidateMaxContentWidth();
this._invalidateMenuButtonNeededWidth();
},
_invalidateMaxLabelWidth:function(){this._cachedMaxArrowWidth=null;
this._invalidateMenuButtonNeededWidth();
},
_invalidateLabelPosition:function(){this._cachedLabelPosition=null;
this._invalidateShortcutPosition();
},
_invalidateShortcutPosition:function(){this._cachedShortcutPosition=null;
this._invalidateArrowPosition();
},
_computeMenuButtonNeededWidth:function(){var $0=0;
var $1=this.getMaxIconWidth();
var $2=this.getMaxContentWidth();
var $3=this.getMaxArrowWidth();
if($1>0){$0+=$1;
}else{$0+=this.getContentNonIconPadding();
}
if($2>0){if($1>0){$0+=this.getIconContentGap();
}$0+=$2;
}
if($3>0){if($1>0||$2>0){$0+=this.getContentArrowGap();
}$0+=$3;
}else{$0+=this.getContentNonArrowPadding();
}return $0;
},
_onmouseover:function($0){var $1=this.getParentMenu();
if($1){$1._closeTimer.stop();
var $2=this.getOpener();
if($2){$1.setHoverItem($2);
}}var $3=$0.getTarget();
if($3==this){this._openTimer.stop();
this._closeTimer.start();
this.setHoverItem(null);
return;
}var $4=this.getOpenItem();
if($4){this.setHoverItem($3);
this._openTimer.stop();
if($3.hasMenu()){if(this.getFastReopen()){this.setOpenItem($3);
this._closeTimer.stop();
}else{this._openTimer.start();
}}else{this._closeTimer.start();
}}else{this.setHoverItem($3);
this._openTimer.stop();
if($3.hasMenu()){this._openTimer.start();
}}},
_onmouseout:function($0){this._openTimer.stop();
var $1=$0.getTarget();
if($1!=this&&$1.hasMenu()){this._closeTimer.start();
}this.setHoverItem(null);
},
_onopentimer:function($0){this._openTimer.stop();
var $1=this.getHoverItem();
if($1&&$1.hasMenu()){this.setOpenItem($1);
}},
_onclosetimer:function($0){this._closeTimer.stop();
this.setOpenItem(null);
},
_onkeydown:function($0){if($0.getKeyIdentifier()==$[110]){this._onkeydown_enter($0);
}$0.preventDefault();
},
_onkeypress:function($0){switch($0.getKeyIdentifier()){case $[116]:this._onkeypress_up($0);
break;
case $[155]:this._onkeypress_down($0);
break;
case $[147]:this._onkeypress_left($0);
break;
case $[148]:this._onkeypress_right($0);
break;
default:return;
}$0.preventDefault();
},
_onkeypress_up:function($0){var $1=this.getHoverItem();
var $2=$1?$1.isFirstChild()?this.getLastActiveChild():$1.getPreviousActiveSibling([qx.ui.menu.Separator]):this.getLastActiveChild();
this.setHoverItem($2);
},
_onkeypress_down:function($0){var $1=this.getHoverItem();
var $2=$1?$1.isLastChild()?this.getFirstActiveChild():$1.getNextActiveSibling([qx.ui.menu.Separator]):this.getFirstActiveChild();
this.setHoverItem($2);
},
_onkeypress_left:function($0){var $1=this.getOpener();
if($1 instanceof qx.ui.menu.Button){var $2=this.getOpener().getParentMenu();
$2.setOpenItem(null);
$2.setHoverItem($1);
$2._makeActive();
}else if($1 instanceof qx.ui.toolbar.MenuButton){var $3=$1.getParentToolBar();
this.getFocusRoot().setActiveChild($3);
$3._onkeypress($0);
}},
_onkeypress_right:function($0){var $1=this.getHoverItem();
if($1){var $2=$1.getMenu();
if($2){this.setOpenItem($1);
$2.setHoverItem($2.getFirstActiveChild());
return;
}}else if(!this.getOpenItem()){var $3=this.getLayout().getFirstActiveChild();
if($3){$3.hasMenu()?this.setOpenItem($3):this.setHoverItem($3);
}}var $4=this.getOpener();
if($4 instanceof qx.ui.toolbar.MenuButton){var $5=$4.getParentToolBar();
this.getFocusRoot().setActiveChild($5);
$5._onkeypress($0);
}else if($4 instanceof qx.ui.menu.Button&&$1){var $6=$4.getParentMenu();
while($6&&$6 instanceof qx.ui.menu.Menu){$4=$6.getOpener();
if($4 instanceof qx.ui.menu.Button){$6=$4.getParentMenu();
}else{if($4){$6=$4.getParent();
}break;
}}
if($6 instanceof qx.ui.toolbar.Part){$6=$6.getParent();
}
if($6 instanceof qx.ui.toolbar.ToolBar){this.getFocusRoot().setActiveChild($6);
$6._onkeypress($0);
}}},
_onkeydown_enter:function($0){var $1=this.getHoverItem();
if($1){$1.execute();
}qx.ui.menu.Manager.getInstance().update();
}},
destruct:function(){this.hide();
this._disposeObjects($[931],
$[859],
$[394]);
}});




/* ID: qx.ui.menu.Layout */
qx.Class.define($[1707],
{extend:qx.ui.layout.VerticalBoxLayout,
properties:{anonymous:{refine:true,
init:true},
appearance:{refine:true,
init:$[693]}},
members:{_createLayoutImpl:function(){return new qx.ui.menu.MenuLayoutImpl(this);
}}});




/* ID: qx.ui.menu.MenuLayoutImpl */
qx.Class.define($[778],
{extend:qx.ui.layout.impl.VerticalBoxLayoutImpl,
construct:function($0){arguments.callee.base.call(this,
$0);
this.setEnableFlexSupport(false);
},
members:{updateChildrenOnJobQueueFlush:function($0){var $1=this.getWidget();
var $2,
$3;
if($0.preferredInnerWidth){var $2=$1.getChildren(),
$4=$2.length,
$3;
var $5,
$6;
for(var $7=0;$7<$4;$7++){$3=$2[$7];
$5=$3.getChildren();
$6=$5.length;
for(var $8=0;$8<$6;$8++){$5[$8].addToLayoutChanges($[107]);
}}}return arguments.callee.base.call(this,
$0);
}}});




/* ID: qx.ui.menu.Manager */
qx.Class.define($[166],
{type:$[24],
extend:qx.util.manager.Object,
construct:function(){arguments.callee.base.call(this);
},
members:{update:function($0,
$1){var $2,
$3;
var $4=this.getAll();
for($3 in $4){$2=$4[$3];
if(!$2.getAutoHide()){continue;
}
if($0&&$0.getMenu&&$0.getMenu()){continue;
}if(!$0){$2.hide();
continue;
}var $5=$1==$[18];
var $6=$1==$[39];
if($2.getOpener()!==
$0&&
($0&&
(!$2.isSubElement($0)&&$5)||
($2.isSubElement($0,
true)&&$6)||(!$5&&!$6))){$2.hide();
continue;
}}}}});




/* ID: qx.ui.menu.Separator */
qx.Class.define($[744],
{extend:qx.ui.layout.CanvasLayout,
construct:function(){arguments.callee.base.call(this);
this.initHeight();
this.setStyleProperty($[222],
$[56]);
this.setStyleProperty($[1837],
$[56]);
this._line=new qx.ui.basic.Terminator;
this._line.setAnonymous(true);
this._line.setAppearance($[1641]);
this.add(this._line);
this.addEventListener($[18],
this._onmousedown);
},
properties:{height:{refine:true,
init:$[3]},
appearance:{refine:true,
init:$[1601]}},
members:{hasIcon:qx.lang.Function.returnFalse,
hasLabel:qx.lang.Function.returnFalse,
hasShortcut:qx.lang.Function.returnFalse,
hasMenu:qx.lang.Function.returnFalse,
_onmousedown:function($0){$0.stopPropagation();
}},
destruct:function(){this._disposeObjects($[1857]);
}});




/* ID: qx.ui.menu.Button */
qx.Class.define($[1643],
{extend:qx.ui.layout.HorizontalBoxLayout,
construct:function($0,
$1,
$2,
$3){arguments.callee.base.call(this);
var $4=this._iconObject=new qx.ui.basic.Image;
$4.setWidth(16);
$4.setAnonymous(true);
var $5=this._labelObject=new qx.ui.basic.Label;
$5.setAnonymous(true);
$5.setSelectable(false);
var $6=this._shortcutObject=new qx.ui.basic.Label;
$6.setAnonymous(true);
$6.setSelectable(false);
var $7=this._arrowObject=new qx.ui.basic.Image;
$7.setAppearance($[643]);
$7.setAnonymous(true);
if($0!=null){this.setLabel($0);
}
if($1!=null){this.setIcon($1);
}
if($2!=null){this.setCommand($2);
qx.locale.Manager.getInstance().addEventListener($[308],
function($8){this._applyCommand($2,
$2);
},
this);
}
if($3!=null){this.setMenu($3);
}this.initMinWidth();
this.initHeight();
this.addEventListener($[39],
this._onmouseup);
},
properties:{allowStretchX:{refine:true,
init:true},
appearance:{refine:true,
init:$[314]},
minWidth:{refine:true,
init:$[3]},
height:{refine:true,
init:$[3]},
icon:{check:$[9],
apply:$[287],
nullable:true,
themeable:true},
label:{apply:$[382],
nullable:true,
dispose:true},
menu:{check:$[175],
nullable:true,
apply:$[526]}},
members:{_hasIcon:false,
_hasLabel:false,
_hasShortcut:false,
_hasMenu:false,
hasIcon:function(){return this._hasIcon;
},
hasLabel:function(){return this._hasLabel;
},
hasShortcut:function(){return this._hasShortcut;
},
hasMenu:function(){return this._hasMenu;
},
getIconObject:function(){return this._iconObject;
},
getLabelObject:function(){return this._labelObject;
},
getShortcutObject:function(){return this._shortcutObject;
},
getArrowObject:function(){return this._arrowObject;
},
getParentMenu:function(){var $0=this.getParent();
if($0){$0=$0.getParent();
if($0&&$0 instanceof qx.ui.menu.Menu){return $0;
}}return null;
},
_createLayoutImpl:function(){return new qx.ui.menu.ButtonLayoutImpl(this);
},
_applyIcon:function($0,
$1){this._iconObject.setSource($0);
if($0&&$0!==$[0]){this._hasIcon=true;
if(!$1||$1===$[0]){this.addAtBegin(this._iconObject);
}}else{this._hasIcon=false;
this.remove(this._iconObject);
}},
_applyLabel:function($0,
$1){this._labelObject.setText($0);
if($0&&$0!==$[0]){this._hasLabel=true;
if(!$1||$1===$[0]){this.addAt(this._labelObject,
this.getFirstChild()==this._iconObject?1:0);
}}else{this._hasLabel=false;
this.remove(this._labelObject);
}},
_applyCommand:function($0,
$1){var $2=$0?$0.toString():$[0];
this._shortcutObject.setText($2);
if(qx.util.Validation.isValidString($2)){this._hasShortcut=true;
var $3=$1?$1.toString():$[0];
if(qx.util.Validation.isInvalidString($3)){if(this.getLastChild()==this._arrowObject){this.addBefore(this._shortcutObject,
this._arrowObject);
}else{this.addAtEnd(this._shortcutObject);
}}}else{this._hasShortcut=false;
this.remove(this._shortcutObject);
}},
_applyMenu:function($0,
$1){if($0){this._hasMenu=true;
if(qx.util.Validation.isInvalidObject($1)){this.addAtEnd(this._arrowObject);
}}else{this._hasMenu=false;
this.remove(this._arrowObject);
}},
_onmouseup:function($0){this.execute();
}},
destruct:function(){this._disposeObjects($[553],
$[348],
$[1948],
$[890]);
}});




/* ID: qx.ui.menu.ButtonLayoutImpl */
qx.Class.define($[1617],
{extend:qx.ui.layout.impl.HorizontalBoxLayoutImpl,
construct:function($0){arguments.callee.base.call(this,
$0);
this.setEnableFlexSupport(false);
},
members:{computeChildrenNeededWidth:function(){var $0=this.getWidget();
var $1=$0.getParent().getParent();
return $1.getMenuButtonNeededWidth();
},
updateSelfOnChildOuterWidthChange:function($0){var $1=this.getWidget();
var $2=$1.getParent().getParent();
switch($0){case $1._iconObject:$2._invalidateMaxIconWidth();
break;
case $1._labelObject:$2._invalidateMaxLabelWidth();
break;
case $1._shortcutObject:$2._invalidateMaxShortcutWidth();
break;
case $1._arrowObject:$2._invalidateMaxArrowWidth();
break;
}return arguments.callee.base.call(this,
$0);
},
layoutChild_locationX:function($0,
$1){var $2=this.getWidget();
var $3=$2.getParent().getParent();
var $4=null;
switch($0){case $2._iconObject:$4=$3.getIconPosition();
break;
case $2._labelObject:$4=$3.getLabelPosition();
break;
case $2._shortcutObject:$4=$3.getShortcutPosition();
break;
case $2._arrowObject:$4=$3.getArrowPosition();
break;
}
if($4!=null){$4+=$2.getPaddingLeft();
$0._renderRuntimeLeft($4);
}}}});




/* ID: qx.ui.toolbar.Button */
qx.Class.define($[1955],
{extend:qx.ui.form.Button,
properties:{tabIndex:{refine:true,
init:-1},
appearance:{refine:true,
init:$[1883]},
show:{refine:true,
init:$[127]},
height:{refine:true,
init:null},
allowStretchY:{refine:true,
init:true}},
members:{_onkeydown:qx.lang.Function.returnTrue,
_onkeyup:qx.lang.Function.returnTrue}});




/* ID: qx.ui.toolbar.MenuButton */
qx.Class.define($[1718],
{extend:qx.ui.toolbar.Button,
construct:function($0,
$1,
$2,
$3,
$4,
$5){arguments.callee.base.call(this,
$0,
$2,
$3,
$4,
$5);
if($1!=null){this.setMenu($1);
}},
properties:{menu:{check:$[175],
nullable:true,
apply:$[526],
event:$[1875]},
direction:{check:[$[401],
$[279]],
init:$[279],
event:$[1957]}},
members:{getParentToolBar:function(){var $0=this.getParent();
if($0 instanceof qx.ui.toolbar.Part){$0=$0.getParent();
}return $0 instanceof qx.ui.toolbar.ToolBar?$0:null;
},
_showMenu:function($0){var $1=this.getMenu();
if($1){var $2=$1.getParent();
var $3=$2.getElement();
var $4=this.getElement();
var $5=qx.html.Dimension.getBoxHeight($4);
var $6=qx.bom.element.Location.getLeft($3);
var $7=qx.bom.element.Location.getLeft($4);
var $8=qx.html.Scroll.getLeftSum($4);
$1.setLeft($7-$6-$8);
var $9=qx.html.Scroll.getTopSum($4);
switch(this.getDirection()){case $[401]:var $a=qx.html.Dimension.getInnerHeight(document.body);
var $b=qx.bom.element.Location.getBottom($3);
var $c=qx.bom.element.Location.getBottom($4);
$1.setBottom($5+($a-$c)-($a-$b)-$9);
$1.setTop(null);
break;
case $[279]:var $d=qx.bom.element.Location.getTop($4);
$1.setTop($d+$5-$9);
$1.setBottom(null);
break;
}this.addState($[31]);
if($0){$1.setHoverItem($1.getFirstActiveChild());
}$1.show();
}},
_hideMenu:function(){var $0=this.getMenu();
if($0){$0.hide();
}},
_applyMenu:function($0,
$1){if($1){$1.setOpener(null);
$1.removeEventListener($[210],
this._onmenuappear,
this);
$1.removeEventListener($[176],
this._onmenudisappear,
this);
}
if($0){$0.setOpener(this);
$0.addEventListener($[210],
this._onmenuappear,
this);
$0.addEventListener($[176],
this._onmenudisappear,
this);
}},
_onmousedown:function($0){if($0.getTarget()!=this||!$0.isLeftButtonPressed()){return;
}this.hasState($[31])?this._hideMenu():this._showMenu();
},
_onmouseup:function($0){},
_onmouseout:function($0){if($0.getTarget()!=this){return;
}this.removeState($[64]);
},
_onmouseover:function($0){var $1=this.getParentToolBar();
if($1){var $2=this.getMenu();
switch($1.getOpenMenu()){case null:case $2:break;
default:qx.ui.menu.Manager.getInstance().update();
this._showMenu();
}}return arguments.callee.base.call(this,
$0);
},
_onmenuappear:function($0){var $1=this.getParentToolBar();
if(!$1){return;
}var $2=this.getMenu();
$1.setOpenMenu($2);
},
_onmenudisappear:function($0){var $1=this.getParentToolBar();
if(!$1){return;
}var $2=this.getMenu();
if($1.getOpenMenu()==$2){$1.setOpenMenu(null);
}}}});




/* ID: qx.ui.toolbar.Part */
qx.Class.define($[1042],
{extend:qx.ui.layout.HorizontalBoxLayout,
construct:function(){arguments.callee.base.call(this);
this._handle=new qx.ui.toolbar.PartHandle;
this.add(this._handle);
this.initWidth();
},
properties:{appearance:{refine:true,
init:$[1430]},
width:{refine:true,
init:$[3]},
show:{init:$[127],
check:[$[141],
$[180],
$[169],
$[11]],
nullable:true,
inheritable:true,
event:$[294]}},
destruct:function(){this._disposeObjects($[1007]);
}});




/* ID: qx.ui.toolbar.PartHandle */
qx.Class.define($[1792],
{extend:qx.ui.layout.CanvasLayout,
construct:function(){arguments.callee.base.call(this);
var $0=new qx.ui.basic.Terminator;
$0.setAppearance($[914]);
this.add($0);
},
properties:{appearance:{refine:true,
init:$[1272]}}});




/* ID: qx.ui.toolbar.ToolBar */
qx.Class.define($[1414],
{extend:qx.ui.layout.HorizontalBoxLayout,
construct:function(){arguments.callee.base.call(this);
this.addEventListener($[57],
this._onkeypress);
this.initHeight();
},
properties:{appearance:{refine:true,
init:$[506]},
height:{refine:true,
init:$[3]},
openMenu:{check:$[175],
event:$[2020],
nullable:true},
show:{init:$[141],
check:[$[141],
$[180],
$[169],
$[11]],
nullable:true,
inheritable:true,
event:$[294]}},
members:{getAllButtons:function(){var $0=this.getChildren();
var $1=$0.length;
var $2=[];
var $3;
for(var $4=0;$4<$1;$4++){$3=$0[$4];
if($3 instanceof qx.ui.toolbar.MenuButton){$2.push($3);
}else if($3 instanceof qx.ui.toolbar.Part){$2=$2.concat($3.getChildren());
}}return $2;
},
_onkeypress:function($0){switch($0.getKeyIdentifier()){case $[147]:return this._onkeypress_left();
case $[148]:return this._onkeypress_right();
}},
_onkeypress_left:function(){var $0=this.getOpenMenu();
if(!$0){return;
}var $1=$0.getOpener();
if(!$1){return;
}var $2=this.getAllButtons();
var $3=$2.length;
var $4=$2.indexOf($1);
var $5;
var $6=null;
for(var $7=$4-1;$7>=0;$7--){$5=$2[$7];
if($5 instanceof qx.ui.toolbar.MenuButton&&$5.getEnabled()){$6=$5;
break;
}}if(!$6){for(var $7=$3-1;$7>$4;$7--){$5=$2[$7];
if($5 instanceof qx.ui.toolbar.MenuButton&&$5.getEnabled()){$6=$5;
break;
}}}
if($6){qx.ui.menu.Manager.getInstance().update();
$6._showMenu(true);
}},
_onkeypress_right:function(){var $0=this.getOpenMenu();
if(!$0){return;
}var $1=$0.getOpener();
if(!$1){return;
}var $2=this.getAllButtons();
var $3=$2.length;
var $4=$2.indexOf($1);
var $5;
var $6=null;
for(var $7=$4+1;$7<$3;$7++){$5=$2[$7];
if($5 instanceof qx.ui.toolbar.MenuButton&&$5.getEnabled()){$6=$5;
break;
}}if(!$6){for(var $7=0;$7<$4;$7++){$5=$2[$7];
if($5 instanceof qx.ui.toolbar.MenuButton&&$5.getEnabled()){$6=$5;
break;
}}}
if($6){qx.ui.menu.Manager.getInstance().update();
$6._showMenu(true);
}}}});




/* ID: qx.ui.menu.CheckBox */
qx.Class.define($[662],
{extend:qx.ui.menu.Button,
construct:function($0,
$1,
$2){arguments.callee.base.call(this,
$0,
null,
$1);
if($2!=null){this.setChecked($2);
}},
properties:{appearance:{refine:true,
init:$[969]},
name:{check:$[9]},
value:{check:$[9],
event:$[190]},
checked:{check:$[2],
init:false,
apply:$[721]}},
members:{_applyChecked:function($0,
$1){$0===true?this.addState($[356]):this.removeState($[356]);
},
execute:function(){this._processExecute();
arguments.callee.base.call(this);
},
_processExecute:function(){this.toggleChecked();
}}});




/* ID: Tr.ui.TraceTable */
qx.Class.define($[854],
{extend:qx.ui.table.Table,
construct:function(){var $0=new qx.ui.table.model.Simple();
this.__tableModel=$0;
$0.setColumns([this.tr($[1306]),
this.tr($[589]),
this.tr($[1743]),
this.tr($[1014]),
this.tr($[1789]),
this.tr($[1139]),
this.tr($[1575]),
this.tr($[927]),
this.tr($[1524]),
this.tr($[1232])]);
var $1={tableColumnModel:function($2){return new qx.ui.table.columnmodel.Resize($2);
}};
with(this){base(arguments,
$0,
$1);
set({width:$[302],
height:$[2014],
border:$[164],
showCellFocusIndicator:false,
statusBarVisible:false});
}var $3=this.getTableColumnModel();
this.__tcm=$3;
$3.setDataCellRenderer(0,
new Tr.ui.Cellrenderer(1));
$3.setDataCellRenderer(3,
new Tr.ui.Cellrenderer(0,
$[1882]));
$3.setDataCellRenderer(4,
new Tr.ui.Cellrenderer(0));
var $4=new Tr.ui.Cellrenderer(1);
for(var $5=5;$5<10;$5++){$3.setDataCellRenderer($5,
$4);
}var $6=$3.getBehavior();
$6.set(0,
{width:$[1216]});
$6.set(1,
{width:$[749]});
$6.set(2,
{width:$[1312]});
for(var $5=3;$5<10;$5++){$6.set($5,
{width:$[881]});
}qx.event.message.Bus.subscribe($[615],
this.__handle_tr,
this);
},
members:{__make_empty_row:function(){return ([undefined,
undefined,
undefined,
0,
0,
undefined,
undefined,
undefined,
undefined,
undefined,
0,
0,
0]);
},
__stop_table:function(){var $0=this.__tableModel;
for(var $1=0;$1<10;$1++){$0.setColumnSortable($1,
true);
}qx.event.message.Bus.dispatch($[139],
$[215]);
this.__handle=undefined;
},
__handle_tr:function($0){var $1=this;
var $2=0,
$3=1,
$4=2,
$5=3,
$6=4,
$7=5,
$8=6,
$9=7,
$a=8,
$b=9,
$c=10,
$d=11,
$e=12;
var $f;
$f=function($g,
$h,
$i){if($h==null){if($1.__handle==undefined){qx.event.message.Bus.dispatch($[139],
$[410]);
}$1.__handle=$g[$[428]];
var $j=$1.__tableModel;
var $k=$g[$[143]].length;
var $l=$1.__data;
var $m=0;
for(var $n=0;$n<$k;$n++){$m=0;
var $o=$g[$[143]][$n][0];
if($o==$[1661]){$m=$g[$[143]][$n][1];
continue;
}else if($o==$[1390]){qx.event.message.Bus.dispatch($[532],
$g[$[143]][$n][1]);
continue;
}var $p=$g[$[143]][$n][1];
var $q=$g[$[143]][$n][2];
var $r=$g[$[143]][$n][3];
var $s=0;
var $t=$l.length;
while(true){if($s==$t)break;
if(Math.floor($l[$s][0])>$o)break;
if(Math.floor($l[$s][0])==$o){if($q==undefined)break;
if($q==$l[$s][2])break;
}$s++;
}
if($s==$t||Math.floor($l[$s][0])>$o){if($s>0&&Math.floor($l[$s-1][0])==$o){$o=$l[$s-1][0]+0.1;
}$l.splice($s,
0,
$1.__make_empty_row());
$l[$s][0]=$o;
}var $u=$l[$s];
if($u[$3]==undefined&&$p!=undefined){$u[$3]=$p;
}
if($u[$4]==undefined&&$q!=undefined){$u[$4]=$q;
}$u[$6]++;
$u[$7]=$r;
if($r!=undefined){var $v=$u[$9];
if($v==undefined||$v>$r){$u[$9]=$r;
}var $w=$u[$a];
if($w==undefined||$w<$r){$u[$a]=$r;
}$u[$d]+=$r;
var $x=$u[$d];
$u[$c]++;
var $y=$u[$c];
var $z=$u[$e]+$r*$r;
$u[$e]=$z;
$u[$8]=$u[$d]/$u[$c];
$u[$b]=Math.sqrt(($y*$z-$x*$x)/($y*($y-1)));
}$u[$5]=(($u[$6]-$u[$c])/$u[$6])*100;
}$j.setData($l);
if($g[$[1550]]){var $A=function(){Tr.Server.getInstance().callAsync($f,
$[577],
{handle:$g[$[428]],
point:$g[$[1609]]});
};
qx.client.Timer.once($A,
$1,
$m*1000);
}else{$1.__stop_table();
}}else{alert($h);
$1.__stop_table();
}};
var $B=function($l,
$h,
$i){if($h==null){qx.event.message.Bus.dispatch($[139],
$[215]);
}else{alert($h);
}};
var $C=$0.getData();
switch($C[$[181]]){case $[331]:qx.event.message.Bus.dispatch($[139],
$[521]);
Tr.Server.getInstance().callAsync($B,
$[1465],
this.__handle);
break;
case $[286]:this.__data=[];
this.__tableModel.setData(this.__data);
this.__delay=$C[$[418]];
for(var $n=0;$n<10;$n++){this.__tableModel.setColumnSortable($n,
false);
}qx.event.message.Bus.dispatch($[139],
$[496]);
Tr.Server.getInstance().callAsync($f,
$[577],
{host:$C[$[1523]],
rounds:$C[$[737]],
delay:$C[$[418]]});
break;
default:alert('Unknown Command '+$C['action']);
}}}});




/* ID: qx.ui.table.model.Abstract */
qx.Class.define($[666],
{type:$[82],
extend:qx.core.Target,
implement:qx.ui.table.ITableModel,
events:{"dataChanged":$[42],
"metaDataChanged":$[42]},
construct:function(){arguments.callee.base.call(this);
this._columnIdArr=[];
this._columnNameArr=[];
this._columnIndexMap={};
},
members:{getRowCount:function(){throw new Error("getRowCount is abstract");
},
getRowData:function($0){return null;
},
isColumnEditable:function($0){return false;
},
isColumnSortable:function($0){return false;
},
sortByColumn:function($0,
$1){},
getSortColumnIndex:function(){return -1;
},
isSortAscending:function(){return true;
},
prefetchRows:function($0,
$1){},
getValue:function($0,
$1){throw new Error("getValue is abstract");
},
getValueById:function($0,
$1){return this.getValue(this.getColumnIndexById($0),
$1);
},
setValue:function($0,
$1,
$2){throw new Error("setValue is abstract");
},
setValueById:function($0,
$1,
$2){return this.setValue(this.getColumnIndexById($0),
$1,
$2);
},
getColumnCount:function(){return this._columnIdArr.length;
},
getColumnIndexById:function($0){return this._columnIndexMap[$0];
},
getColumnId:function($0){return this._columnIdArr[$0];
},
getColumnName:function($0){return this._columnNameArr[$0];
},
setColumnIds:function($0){this._columnIdArr=$0;
this._columnIndexMap={};
for(var $1=0;$1<$0.length;$1++){this._columnIndexMap[$0[$1]]=$1;
}this._columnNameArr=new Array($0.length);
if(!this._internalChange){this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
setColumnNamesByIndex:function($0){if(this._columnIdArr.length!=$0.length){throw new Error("this._columnIdArr and columnNameArr have different length: "+this._columnIdArr.length+" != "+$0.length);
}this._columnNameArr=$0;
this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setColumnNamesById:function($0){this._columnNameArr=new Array(this._columnIdArr.length);
for(var $1=0;$1<this._columnIdArr.length;++$1){this._columnNameArr[$1]=$0[this._columnIdArr[$1]];
}},
setColumns:function($0,
$1){if($1==null){$1=$0;
}
if($1.length!=$0.length){throw new Error("columnIdArr and columnNameArr have different length: "+$1.length+" != "+$0.length);
}this._internalChange=true;
this.setColumnIds($1);
this._internalChange=false;
this.setColumnNamesByIndex($0);
}},
destruct:function(){this._disposeFields($[1152],
$[1354],
$[822]);
}});




/* ID: qx.ui.table.model.Simple */
qx.Class.define($[1758],
{extend:qx.ui.table.model.Abstract,
construct:function(){arguments.callee.base.call(this);
this._rowArr=[];
this._sortColumnIndex=-1;
this._sortAscending;
this._sortMethods=[];
this._editableColArr=null;
},
statics:{_defaultSortComparatorAscending:function($0,
$1){var $2=$0[arguments.callee.columnIndex];
var $3=$1[arguments.callee.columnIndex];
return ($2>$3)?1:(($2==$3)?0:-1);
},
_defaultSortComparatorDescending:function($0,
$1){var $2=$0[arguments.callee.columnIndex];
var $3=$1[arguments.callee.columnIndex];
return ($2<$3)?1:(($2==$3)?0:-1);
}},
members:{getRowData:function($0){var $1=this._rowArr[$0];
if($1==null||$1.originalData==null){return $1;
}else{return $1.originalData;
}},
getRowDataAsMap:function($0){var $1=this._rowArr[$0];
var $2={};
for(var $3=0;$3<this.getColumnCount();$3++){$2[this.getColumnId($3)]=$1[$3];
}return $2;
},
setEditable:function($0){this._editableColArr=[];
for(var $1=0;$1<this.getColumnCount();$1++){this._editableColArr[$1]=$0;
}this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setColumnEditable:function($0,
$1){if($1!=this.isColumnEditable($0)){if(this._editableColArr==null){this._editableColArr=[];
}this._editableColArr[$0]=$1;
this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
isColumnEditable:function($0){return this._editableColArr?(this._editableColArr[$0]==true):false;
},
setColumnSortable:function($0,
$1){if($1!=this.isColumnSortable($0)){if(this._sortableColArr==null){this._sortableColArr=[];
}this._sortableColArr[$0]=$1;
this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
isColumnSortable:function($0){return this._sortableColArr?(this._sortableColArr[$0]==true):true;
},
sortByColumn:function($0,
$1){var $2;
var $3=this._sortMethods[$0];
if($3){$2=($1?$3.ascending:$3.descending);
}else{$2=($1?qx.ui.table.model.Simple._defaultSortComparatorAscending:qx.ui.table.model.Simple._defaultSortComparatorDescending);
}$2.columnIndex=$0;
this._rowArr.sort($2);
this._sortColumnIndex=$0;
this._sortAscending=$1;
this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
},
setSortMethods:function($0,
$1){this._sortMethods[$0]=$1;
},
_clearSorting:function(){if(this._sortColumnIndex!=-1){this._sortColumnIndex=-1;
this._sortAscending=true;
this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_META_DATA_CHANGED);
}},
getSortColumnIndex:function(){return this._sortColumnIndex;
},
isSortAscending:function(){return this._sortAscending;
},
getRowCount:function(){return this._rowArr.length;
},
getValue:function($0,
$1){if($1<0||$1>=this._rowArr.length){throw new Error("this._rowArr out of bounds: "+$1+" (0.."+this._rowArr.length+")");
}return this._rowArr[$1][$0];
},
setValue:function($0,
$1,
$2){if(this._rowArr[$1][$0]!=$2){this._rowArr[$1][$0]=$2;
if(this.hasEventListeners(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED)){var $3={firstRow:$1,
lastRow:$1,
firstColumn:$0,
lastColumn:$0};
this.createDispatchDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
$3);
}
if($0==this._sortColumnIndex){this._clearSorting();
}}},
setData:function($0,
$1){this._rowArr=$0;
if(this.hasEventListeners(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED)){this.createDispatchEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED);
}
if($1){this._clearSorting();
}},
getData:function(){return this._rowArr;
},
setDataAsMapArray:function($0,
$1,
$2){this.setData(this._mapArray2RowArr($0,
$1),
$2);
},
addRows:function($0,
$1){if($1==null){$1=this._rowArr.length;
}$0.splice(0,
0,
$1,
0);
Array.prototype.splice.apply(this._rowArr,
$0);
var $2={firstRow:$1,
lastRow:this._rowArr.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.createDispatchDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
$2);
this._clearSorting();
},
addRowsAsMapArray:function($0,
$1,
$2){this.addRows(this._mapArray2RowArr($0,
$2),
$1);
},
removeRows:function($0,
$1){this._rowArr.splice($0,
$1);
var $2={firstRow:$0,
lastRow:this._rowArr.length-1,
firstColumn:0,
lastColumn:this.getColumnCount()-1};
this.createDispatchDataEvent(qx.ui.table.ITableModel.EVENT_TYPE_DATA_CHANGED,
$2);
this._clearSorting();
},
_mapArray2RowArr:function($0,
$1){var $2=$0.length;
var $3=this.getColumnCount();
var $4=new Array($2);
var $5;
var $6;
for(var $7=0;$7<$2;++$7){$5=[];
if($1){$5.originalData=$0[$7];
}
for(var $6=0;$6<$3;++$6){$5[$6]=$0[$7][this.getColumnId($6)];
}$4[$7]=$5;
}return $4;
}},
destruct:function(){this._disposeFields($[1437],
$[1587],
$[713]);
}});




/* ID: qx.ui.table.columnmodel.Resize */
qx.Class.define($[1548],
{extend:qx.ui.table.columnmodel.Basic,
construct:function(){arguments.callee.base.call(this);
this._bInProgress=false;
this._bAppeared=false;
},
properties:{behavior:{check:$[392],
init:null,
nullable:true,
apply:$[981],
event:$[897]}},
members:{_applyBehavior:function($0,
$1){if($1!=null){$1.dispose();
$1=null;
}this.getBehavior()._setNumColumns(this._columnDataArr.length);
},
init:function($0,
$1){arguments.callee.base.call(this,
$0);
if(this.getBehavior()==null){this.setBehavior(new qx.ui.table.columnmodel.resizebehavior.Default());
}this._table=$1;
$1.addEventListener($[210],
this._onappear,
this);
$1.addEventListener($[519],
this._ontablewidthchanged,
this);
$1.addEventListener($[527],
this._onverticalscrollbarchanged,
this);
this.addEventListener($[236],
this._oncolumnwidthchanged,
this);
this.addEventListener($[224],
this._onvisibilitychanged,
this);
this._table.addEventListener($[374],
this._addResetColumnWidthButton,
this);
this.getBehavior()._setNumColumns($0);
},
_addResetColumnWidthButton:function($0){var $1=$0.getData();
var $2=$1.menu;
var $3;
var $4=qx.io.Alias;
var $5=$4.getInstance().resolve($[1187]);
$3=new qx.ui.menu.Separator();
$2.add($3);
$3=new qx.ui.menu.Button($[1884],
$5);
$2.add($3);
$3.addEventListener($[117],
this._onappear,
this);
},
_onappear:function($0){if(this._bInProgress){return ;
}this._bInProgress=true;
{};
this.getBehavior().onAppear(this,
$0);
qx.client.Timer.once(function(){if(!this._table.getDisposed()){this._table._updateScrollerWidths();
this._table._updateScrollBarVisibility();
}},
this,
0);
this._bInProgress=false;
this._bAppeared=true;
},
_ontablewidthchanged:function($0){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{};
this.getBehavior().onTableWidthChanged(this,
$0);
this._bInProgress=false;
},
_onverticalscrollbarchanged:function($0){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{};
this.getBehavior().onVerticalScrollBarChanged(this,
$0);
qx.client.Timer.once(function(){if(!this._table.getDisposed()){this._table._updateScrollerWidths();
this._table._updateScrollBarVisibility();
}},
this,
0);
this._bInProgress=false;
},
_oncolumnwidthchanged:function($0){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{};
this.getBehavior().onColumnWidthChanged(this,
$0);
this._bInProgress=false;
},
_onvisibilitychanged:function($0){if(this._bInProgress||!this._bAppeared){return ;
}this._bInProgress=true;
{};
this.getBehavior().onVisibilityChanged(this,
$0);
this._bInProgress=false;
}},
settings:{"qx.tableResizeDebug":false},
destruct:function(){this._disposeFields($[363]);
}});




/* ID: qx.ui.table.columnmodel.resizebehavior.Abstract */
qx.Class.define($[392],
{type:$[82],
extend:qx.core.Object,
construct:function(){arguments.callee.base.call(this);
this._resizeColumnData=[];
},
members:{_setNumColumns:function($0){throw new Error("_setNumColumns is abstract");
},
onAppear:function($0,
$1){throw new Error("onAppear is abstract");
},
onTableWidthChanged:function($0,
$1){throw new Error("onTableWidthChanged is abstract");
},
onVerticalScrollBarChanged:function($0,
$1){throw new Error("onVerticalScrollBarChanged is abstract");
},
onColumnWidthChanged:function($0,
$1){throw new Error("onColumnWidthChanged is abstract");
},
onVisibilityChanged:function($0,
$1){throw new Error("onVisibilityChanged is abstract");
},
_getAvailableWidth:function($0){var $1=$0._table.getElement();
var $2=qx.html.Dimension.getInnerWidth($1)-2;
var $3=$0._table._getPaneScrollerArr();
var $4=$3[$3.length-1];
$0._table._updateScrollBarVisibility();
if($0._table.getColumnVisibilityButtonVisible()||($4._verScrollBar.getVisibility()&&$4._verScrollBar.getWidth()==$[3])){return {width:$2-qx.ui.core.Widget.SCROLLBAR_SIZE,
extraWidth:0};
}return {width:$2-qx.ui.core.Widget.SCROLLBAR_SIZE,
extraWidth:qx.ui.core.Widget.SCROLLBAR_SIZE};
}},
destruct:function(){this._disposeFields($[415]);
}});




/* ID: qx.ui.table.columnmodel.resizebehavior.Default */
qx.Class.define($[729],
{extend:qx.ui.table.columnmodel.resizebehavior.Abstract,
construct:function(){arguments.callee.base.call(this);
},
statics:{MIN_WIDTH:10},
properties:{newResizeBehaviorColumnData:{check:$[68],
init:function($0){return new qx.ui.table.columnmodel.resizebehavior.ColumnData();
}}},
members:{setWidth:function($0,
$1){if($0>=this._resizeColumnData.length){throw new Error("Column number out of range");
}this._resizeColumnData[$0].setWidth($1);
},
setMinWidth:function($0,
$1){if($0>=this._resizeColumnData.length){throw new Error("Column number out of range");
}this._resizeColumnData[$0].setMinWidth($1);
},
setMaxWidth:function($0,
$1){if($0>=this._resizeColumnData.length){throw new Error("Column number out of range");
}this._resizeColumnData[$0].setMaxWidth($1);
},
set:function($0,
$1){for(var $2 in $1){switch($2){case $[26]:this.setWidth($0,
$1[$2]);
break;
case $[65]:this.setMinWidth($0,
$1[$2]);
break;
case $[66]:this.setMaxWidth($0,
$1[$2]);
break;
default:throw new Error("Unknown property: "+$2);
}}},
onAppear:function($0,
$1){this._width=this._getAvailableWidth($0);
this._computeColumnsFlexWidth($0,
$1);
},
onTableWidthChanged:function($0,
$1){this._computeColumnsFlexWidth($0,
$1);
},
onVerticalScrollBarChanged:function($0,
$1){this._computeColumnsFlexWidth($0,
$1);
},
onColumnWidthChanged:function($0,
$1){this._extendNextColumn($0,
$1);
},
onVisibilityChanged:function($0,
$1){this._extendLastColumn($0,
$1);
},
_setNumColumns:function($0){if($0<=this._resizeColumnData.length){this._resizeColumnData.splice($0);
return;
}for(var $1=this._resizeColumnData.length;$1<$0;$1++){this._resizeColumnData[$1]=this.getNewResizeBehaviorColumnData()();
this._resizeColumnData[$1]._columnNumber=$1;
}},
_computeColumnsFlexWidth:function($0,
$1){{};
var $2=$0._visibleColumnArr;
var $3=$2.length;
var $4;
var $5=[];
var $6=0;
var $7;
var $8=this._getAvailableWidth($0);
var $9=$8.width;
var $a=$8.extraWidth;
for($7=0;$7<$3;$7++){$4=this._resizeColumnData[$2[$7]];
if($4._computedWidthTypeAuto){$4._computedWidthTypeAuto=false;
$4._computedWidthTypeFlex=true;
$4._computedWidthParsed=1;
}if($4._computedWidthTypeFlex){$5.push($4);
}else if($4._computedWidthTypePercent){$4._computedWidthPercentValue=Math.round($9*($4._computedWidthParsed/100));
$6+=$4._computedWidthPercentValue;
}else{$6+=$4.getWidth();
}}{};
var $b=$9-$6;
var $c=$5.length;
var $d=0;
for($7=0;$7<$c;$7++){$d+=$5[$7]._computedWidthParsed;
}var $e=$b/$d;
bSomethingChanged=true;
for($c=$5.length;bSomethingChanged&&$c>0;$c=$5.length){bSomethingChanged=false;
for($7=$c-1;$7>=0;$7--){$4=$5[$7];
computedFlexibleWidth=$4._computedWidthFlexValue=$4._computedWidthParsed*$e;
var $f=$4.getMinWidthValue();
var $g=$4.getMaxWidthValue();
if($f&&computedFlexibleWidth<$f){$4._computedWidthFlexValue=Math.round($f);
$6+=$4._computedWidthFlexValue;
qx.lang.Array.removeAt($5,
$7);
bSomethingChanged=true;
$4=null;
}else if($g&&computedFlexibleWidth>$g){$4._computedWidthFlexValue=Math.round($g);
$6+=$4._computedWidthFlexValue;
qx.lang.Array.removeAt($5,
$7);
bSomethingChanged=true;
$4=null;
}}}if($5.length>0){$d=0;
for($7=0;$7<$c;$7++){$d+=$5[$7]._computedWidthParsed;
}$b=$9-$6;
$e=$b/$d;
if($b<=0){for($7=0;$7<$c;$7++){$4=$5[$7];
computedFlexibleWidth=$4._computedWidthFlexValue=(qx.ui.table.columnmodel.resizebehavior.Default.MIN_WIDTH*$5[$7]._computedWidthParsed);
$4._computedWidthFlexValue=Math.round(computedFlexibleWidth);
$6+=$4._computedWidthFlexValue;
}}else{for($7=0;$7<$c;$7++){$4=$5[$7];
computedFlexibleWidth=$4._computedWidthFlexValue=$4._computedWidthParsed*$e;
if(computedFlexibleWidth<qx.ui.table.columnmodel.resizebehavior.Default.MIN_WIDTH){computedFlexibleWidth=qx.ui.table.columnmodel.resizebehavior.Default.MIN_WIDTH;
}$4._computedWidthFlexValue=Math.round(computedFlexibleWidth);
$6+=$4._computedWidthFlexValue;
}}}if($4!=null&&$b>0){$4._computedWidthFlexValue+=$9-$6;
}for($7=0;$7<$3;$7++){var $h;
$4=this._resizeColumnData[$2[$7]];
if($4._computedWidthTypeFlex){$h=$4._computedWidthFlexValue;
}else if($4._computedWidthTypePercent){$h=$4._computedWidthPercentValue;
}else{$h=$4.getWidth();
}if($7==$3-1){$h+=$a;
}$0.setColumnWidth($2[$7],
$h);
{};
}},
_extendNextColumn:function($0,
$1){var $2=$1.getData();
var $3=$0._visibleColumnArr;
var $4=this._getAvailableWidth($0);
var $5=$4.width;
var $6=$4.extraWidth;
var $7=$3.length;
if($2.newWidth>$2.oldWidth){return ;
}var $8;
var $9;
var $a=0;
for($8=0;$8<$7;$8++){$a+=$0.getColumnWidth($3[$8]);
}if($a<$5){for($8=0;$8<$3.length;$8++){if($3[$8]==$2.col){$9=$3[$8+1];
break;
}}
if($9){var $b=$0.getColumnWidth($9);
var $c=($5-($a-$0.getColumnWidth($9)));
$0.setColumnWidth($9,
$c);
}}},
_extendLastColumn:function($0,
$1){var $2=$1.getData();
if($2.visible){return;
}var $3=$0._visibleColumnArr;
var $4=this._getAvailableWidth($0);
var $5=$4.width;
var $6=$4.extraWidth;
var $7=$3.length;
var $8;
var $9;
var $a=0;
for($8=0;$8<$7;$8++){$a+=$0.getColumnWidth($3[$8]);
}if($a<$5){$9=$3[$3.length-1];
var $b=$0.getColumnWidth($9);
var $c=($5-($a-$0.getColumnWidth($9)));
$0.setColumnWidth($9,
$c);
}}},
destruct:function(){this._disposeFields($[415],
$[1086]);
}});




/* ID: qx.ui.table.columnmodel.resizebehavior.ColumnData */
qx.Class.define($[1827],
{extend:qx.ui.core.Widget,
construct:function(){arguments.callee.base.call(this);
this.setWidth($[87]);
}});




/* ID: qx.ui.table.cellrenderer.Conditional */
qx.Class.define($[1751],
{extend:qx.ui.table.cellrenderer.Default,
construct:function($0,
$1,
$2,
$3){arguments.callee.base.call(this);
this.numericAllowed=[$[477],
$[501],
$[473],
$[619],
$[631],
$[462]];
this.betweenAllowed=[$[602],
$[414]];
this.Conditions=[];
this._defaultTextAlign=$0||$[0];
this._defaultColor=$1||$[0];
this._defaultFontStyle=$2||$[0];
this._defaultFontWeight=$3||$[0];
},
members:{__applyFormatting:function($0,
$1){if($0[1]!=null){$1[$[2006]]=$0[1];
}
if($0[2]!=null){$1[$[324]]=$0[2];
}
if($0[3]!=null){$1[$[696]]=$0[3];
}
if($0[4]!=null){$1[$[1110]]=$0[4];
}},
addNumericCondition:function($0,
$1,
$2,
$3,
$4,
$5,
$6){var $7=null;
if(qx.lang.Array.contains(this.numericAllowed,
$0)){if($1!=null){$7=[$0,
$2,
$3,
$4,
$5,
$1,
$6];
}}
if($7!=null){this.Conditions.push($7);
}else{throw new Error("Condition not recognized or value is null!");
}},
addBetweenCondition:function($0,
$1,
$2,
$3,
$4,
$5,
$6,
$7){if(qx.lang.Array.contains(this.betweenAllowed,
$0)){if($1!=null&&$2!=null){var $8=[$0,
$3,
$4,
$5,
$6,
$1,
$2,
$7];
}}
if($8!=null){this.Conditions.push($8);
}else{throw new Error("Condition not recognized or value1/value2 is null!");
}},
addRegex:function($0,
$1,
$2,
$3,
$4,
$5){if($0!=null){var $6=[$[565],
$1,
$2,
$3,
$4,
$0,
$5];
}
if($6!=null){this.Conditions.push($6);
}else{throw new Error("regex cannot be null!");
}},
_getCellStyle:function($0){var $1=$0.table.getTableModel();
var $2;
var $3;
var $4;
var $5={"text-align":this._defaultTextAlign,
"color":this._defaultColor,
"font-style":this._defaultFontStyle,
"font-weight":this._defaultFontWeight};
for($2 in this.Conditions){$3=false;
if(qx.lang.Array.contains(this.numericAllowed,
this.Conditions[$2][0])){if(this.Conditions[$2][6]==null){$4=$0.value;
}else{$4=$1.getValueById(this.Conditions[$2][6],
$0.row);
}
switch(this.Conditions[$2][0]){case $[477]:if($4==this.Conditions[$2][5]){$3=true;
}break;
case $[501]:if($4!=this.Conditions[$2][5]){$3=true;
}break;
case $[473]:if($4>this.Conditions[$2][5]){$3=true;
}break;
case $[619]:if($4<this.Conditions[$2][5]){$3=true;
}break;
case $[631]:if($4>=this.Conditions[$2][5]){$3=true;
}break;
case $[462]:if($4<=this.Conditions[$2][5]){$3=true;
}break;
}}else if(qx.lang.Array.contains(this.betweenAllowed,
this.Conditions[$2][0])){if(this.Conditions[$2][7]==null){$4=$0.value;
}else{$4=$1.getValueById(this.Conditions[$2][7],
$0.row);
}
switch(this.Conditions[$2][0]){case $[602]:if($4>=this.Conditions[$2][5]&&$4<=this.Conditions[$2][6]){$3=true;
}break;
case $[414]:if($4<this.Conditions[$2][5]&&$4>this.Conditions[$2][6]){$3=true;
}break;
}}else if(this.Conditions[$2][0]==$[565]){if(this.Conditions[$2][6]==null){$4=$0.value;
}else{$4=$1.getValueById(this.Conditions[$2][6],
$0.row);
}var $6=new RegExp(this.Conditions[$2][5],
$[1353]);
$3=$6.test($4);
}if($3==true){this.__applyFormatting(this.Conditions[$2],
$5);
}}var $7=[];
for(var $8 in $5){$7.push($8,
$[50],
$5[$8],
$[75]);
}return $7.join($[0]);
}}});




/* ID: qx.ui.table.cellrenderer.Number */
qx.Class.define($[835],
{extend:qx.ui.table.cellrenderer.Conditional,
construct:function($0,
$1,
$2,
$3){arguments.callee.base.call(this,
$0,
$1,
$2,
$3);
this.initNumberFormat();
},
properties:{numberFormat:{check:$[391],
init:null,
apply:$[917]}},
members:{_applyNumberFormat:function($0,
$1){var $2;
if($0){$2=function($3){if($3.value||$3.value==0){return $0.format($3.value);
}else{return $[0];
}};
}else{$2=function($3){return $3.value==0?$[56]:($3.value||$[0]);
};
}this._getContentHtml=$2;
},
_getCellClass:function($0){return $[752];
}}});




/* ID: Tr.ui.Cellrenderer */
qx.Class.define($[689],
{extend:qx.ui.table.cellrenderer.Number,
construct:function($0,
$1,
$2){if($0==undefined){$0=0;
}arguments.callee.base.call(this);
var $3=new qx.util.format.NumberFormat();
$3.set({maximumFractionDigits:$0,
minimumFractionDigits:$0});
if($1!=undefined){$3.setPostfix($1);
}
if($2!=undefined){$3.setPrefix($2);
}this.setNumberFormat($3);
}});




/* ID: Tr.ui.Footer */
qx.Class.define($[1355],
{extend:qx.ui.layout.HorizontalBoxLayout,
construct:function($0,
$1){arguments.callee.base.call(this);
this.set({horizontalChildrenAlign:$[1338],
height:$[129]});
var $2=new qx.ui.form.Button($0);
$2.set({textColor:$[450],
backgroundColor:null,
font:qx.ui.core.Font.fromString($[1698]),
border:null});
$2.addEventListener($[319],
function($3){var $4=new qx.client.NativeWindow($1);
$4.set({width:1000,
height:800});
$4.open();
});
this.add($2);
}});




/* ID: qx.client.NativeWindow */
qx.Class.define($[337],
{extend:qx.core.Target,
construct:function($0,
$1){arguments.callee.base.call(this);
this._timer=new qx.client.Timer(100);
this._timer.addEventListener($[67],
this._oninterval,
this);
if($0!=null){this.setUrl($0);
}
if($1!=null){this.setName($1);
}},
events:{"load":$[4],
"close":$[4]},
properties:{open:{check:$[2],
init:false,
apply:$[802]},
width:{check:$[12],
init:400,
apply:$[635]},
height:{check:$[12],
init:250,
apply:$[635]},
left:{check:$[12],
init:100,
apply:$[411]},
top:{check:$[12],
init:200,
apply:$[411]},
modal:{check:$[2],
init:false},
dependent:{check:$[2],
init:true},
url:{check:$[9],
apply:$[1828],
init:$[1267]},
name:{check:$[9],
apply:$[924],
init:$[0]},
status:{check:$[9],
init:$[293]},
showStatusbar:{check:$[2],
init:false},
showMenubar:{check:$[2],
init:false},
showLocation:{check:$[2],
init:false},
showToolbar:{check:$[2],
init:false},
resizable:{check:$[2],
init:true},
allowScrollbars:{check:$[2],
init:true},
location:{group:[$[13],
$[14]]},
dimension:{group:[$[26],
$[32]]}},
members:{_loaded:false,
_applyPosition:function($0,
$1){if(!this.isClosed()){try{this._window.moveTo(this.getLeft(),
this.getTop());
}catch(ex){this.error("Cross-Domain Scripting problem: Could not move window!",
ex);
}}},
_applyDimension:function($0,
$1){if(!this.isClosed()){try{this._window.resizeTo(this.getWidth(),
this.getHeight());
}catch(ex){this.error("Cross-Domain Scripting problem: Could not resize window!",
ex);
}}},
_applyName:function($0,
$1){if(!this.isClosed()){this._window.name=$0;
}},
_applyUrl:function($0,
$1){if(!this.isClosed()){this._window.location.replace($0!=null?$0:($[1180]+$[145]));
}},
_applyOpen:function($0,
$1){$0?this._open():this._close();
},
isClosed:function(){var $0=true;
if(this._window){try{$0=this._window.closed;
}catch(ex){}}return $0;
},
open:function(){this.setOpen(true);
},
close:function(){this.setOpen(false);
},
isLoaded:function(){return this._loaded;
},
_open:function(){var $0=[];
if(this.getWidth()!=null){$0.push($[26]);
$0.push($[33]);
$0.push(this.getWidth());
$0.push($[17]);
}
if(this.getHeight()!=null){$0.push($[32]);
$0.push($[33]);
$0.push(this.getHeight());
$0.push($[17]);
}
if(this.getLeft()!=null){$0.push($[13]);
$0.push($[33]);
$0.push(this.getLeft());
$0.push($[17]);
}
if(this.getTop()!=null){$0.push($[23]);
$0.push($[33]);
$0.push(this.getTop());
$0.push($[17]);
}$0.push($[1533]);
$0.push($[33]);
$0.push(this.getDependent()?$[125]:$[121]);
$0.push($[17]);
$0.push($[1082]);
$0.push($[33]);
$0.push(this.getResizable()?$[125]:$[121]);
$0.push($[17]);
$0.push($[682]);
$0.push($[33]);
$0.push(this.getShowStatusbar()?$[125]:$[121]);
$0.push($[17]);
$0.push($[1417]);
$0.push($[33]);
$0.push(this.getShowLocation()?$[125]:$[121]);
$0.push($[17]);
$0.push($[855]);
$0.push($[33]);
$0.push(this.getShowMenubar()?$[125]:$[121]);
$0.push($[17]);
$0.push($[506]);
$0.push($[33]);
$0.push(this.getShowToolbar()?$[125]:$[121]);
$0.push($[17]);
$0.push($[785]);
$0.push($[33]);
$0.push(this.getAllowScrollbars()?$[125]:$[121]);
$0.push($[17]);
$0.push($[758]);
$0.push($[33]);
$0.push(this.getModal()?$[125]:$[121]);
$0.push($[17]);
if(this.getName()!=null){this.setName($[853]+this.toHashCode());
}this._window=window.open(this.getUrl(),
this.getName(),
$0.join($[0]));
if(this.isClosed()){this.error("Window could not be opened. It seems, there is a popup blocker active!");
}else{try{this._window._native=this;
this._window.onload=this._onload;
}catch(ex){}this._timer.start();
if(this.getModal()){qx.ui.core.ClientDocument.getInstance().block(this);
}}},
_close:function(){if(!this._window){return;
}this._timer.stop();
if(this.getModal()){qx.ui.core.ClientDocument.getInstance().release(this);
}if(!this.isClosed()){this._window.close();
}
try{this._window._native=null;
this._window.onload=null;
}catch(ex){}this._window=null;
this._loaded=false;
this.createDispatchEvent($[1536]);
},
centerToScreen:function(){this._centerHelper((screen.width-this.getWidth())/2,
(screen.height-this.getHeight())/2);
},
centerToScreenArea:function(){this._centerHelper((screen.availWidth-this.getWidth())/2,
(screen.availHeight-this.getHeight())/2);
},
centerToOpener:function(){this._centerHelper(((qx.html.Window.getInnerWidth(window)-this.getWidth())/2)+qx.html.Location.getScreenBoxLeft(window.document.body),
((qx.html.Window.getInnerHeight(window)-this.getHeight())/2)+qx.html.Location.getScreenBoxTop(window.document.body));
},
_centerHelper:function($0,
$1){this.setLeft($0);
this.setTop($1);
if(!this.isClosed()){this.focus();
}},
focus:function(){if(!this.isClosed()){this._window.focus();
}},
blur:function(){if(!this.isClosed()){this._window.blur();
}},
_oninterval:function($0){if(this.isClosed()){this.setOpen(false);
}else if(!this._loaded){try{if(this._window.document&&this._window.document.readyState==$[793]){this._loaded=true;
this.createDispatchEvent($[94]);
}}catch(ex){}}},
_onload:function($0){var $1=this._native;
if(!$1._loaded){$1._loaded=true;
$1.createDispatchEvent($[94]);
}}},
destruct:function(){if(this.getDependent()){this.close();
}this._disposeObjects($[202]);
if(this._window){try{this._window._native=null;
this._window.onload=null;
}catch(ex){}this._window=null;
}}});




/* ID: qx.html.Window */
qx.Class.define($[1448],
{statics:{getInnerWidth:qx.core.Variant.select($[1],
{"mshtml":function($0){if($0.document.documentElement&&$0.document.documentElement.clientWidth){return $0.document.documentElement.clientWidth;
}else if($0.document.body){return $0.document.body.clientWidth;
}return 0;
},
"default":function($0){return $0.innerWidth;
}}),
getInnerHeight:qx.core.Variant.select($[1],
{"mshtml":function($0){if($0.document.documentElement&&$0.document.documentElement.clientHeight){return $0.document.documentElement.clientHeight;
}else if($0.document.body){return $0.document.body.clientHeight;
}return 0;
},
"default":function($0){return $0.innerHeight;
}}),
getScrollLeft:qx.core.Variant.select($[1],
{"mshtml":function($0){if($0.document.documentElement&&$0.document.documentElement.scrollLeft){return $0.document.documentElement.scrollLeft;
}else if($0.document.body){return $0.document.body.scrollTop;
}return 0;
},
"default":function($0){return $0.document.body.scrollLeft;
}}),
getScrollTop:qx.core.Variant.select($[1],
{"mshtml":function($0){if($0.document.documentElement&&$0.document.documentElement.scrollTop){return $0.document.documentElement.scrollTop;
}else if($0.document.body){return $0.document.body.scrollTop;
}return 0;
},
"default":function($0){return $0.document.body.scrollTop;
}})}});




/* ID: qx.locale.Locale */
qx.Class.define($[2027],
{statics:{define:function($0,
$1){qx.locale.Manager.getInstance().addTranslationFromClass($0,
$1);
}}});




/* ID: qx.locale.data.C */
qx.locale.Locale.define("qx.locale.data.C",
{cldr_alternateQuotationEnd:"”",
cldr_alternateQuotationStart:"“",
cldr_am:"am",
cldr_date_format_full:"EEEE, MMMM d, yyyy",
cldr_date_format_long:"MMMM d, yyyy",
cldr_date_format_medium:"MMM d, yyyy",
cldr_date_format_short:"M/d/yy",
cldr_date_time_format_HHmm:$[2033],
cldr_date_time_format_HHmmss:$[296],
cldr_date_time_format_MMMMd:"MMMM d",
cldr_date_time_format_Md:"M/d",
cldr_date_time_format_mmss:"mm:ss",
cldr_date_time_format_yyMM:"MM/yy",
cldr_date_time_format_yyQQQQ:"QQQQ yy",
cldr_date_time_format_yyyyMMM:"MMM yyyy",
cldr_day_abbreviated_fri:"Fri",
cldr_day_abbreviated_mon:"Mon",
cldr_day_abbreviated_sat:"Sat",
cldr_day_abbreviated_sun:"Sun",
cldr_day_abbreviated_thu:"Thu",
cldr_day_abbreviated_tue:"Tue",
cldr_day_abbreviated_wed:"Wed",
cldr_day_narrow_fri:"F",
cldr_day_narrow_mon:$[1442],
cldr_day_narrow_sat:$[1024],
cldr_day_narrow_sun:$[1024],
cldr_day_narrow_thu:"T",
cldr_day_narrow_tue:"T",
cldr_day_narrow_wed:"W",
cldr_day_wide_fri:"Friday",
cldr_day_wide_mon:"Monday",
cldr_day_wide_sat:"Saturday",
cldr_day_wide_sun:"Sunday",
cldr_day_wide_thu:"Thursday",
cldr_day_wide_tue:"Tuesday",
cldr_day_wide_wed:"Wednesday",
cldr_month_abbreviated_1:"Jan",
cldr_month_abbreviated_10:"Oct",
cldr_month_abbreviated_11:"Nov",
cldr_month_abbreviated_12:"Dec",
cldr_month_abbreviated_2:"Feb",
cldr_month_abbreviated_3:"Mar",
cldr_month_abbreviated_4:"Apr",
cldr_month_abbreviated_5:"May",
cldr_month_abbreviated_6:"Jun",
cldr_month_abbreviated_7:"Jul",
cldr_month_abbreviated_8:"Aug",
cldr_month_abbreviated_9:"Sep",
cldr_month_narrow_1:"J",
cldr_month_narrow_10:$[1298],
cldr_month_narrow_11:"N",
cldr_month_narrow_12:"D",
cldr_month_narrow_2:"F",
cldr_month_narrow_3:$[1442],
cldr_month_narrow_4:$[205],
cldr_month_narrow_5:$[1442],
cldr_month_narrow_6:"J",
cldr_month_narrow_7:"J",
cldr_month_narrow_8:$[205],
cldr_month_narrow_9:$[1024],
cldr_month_wide_1:"January",
cldr_month_wide_10:"October",
cldr_month_wide_11:"November",
cldr_month_wide_12:"December",
cldr_month_wide_2:"February",
cldr_month_wide_3:"March",
cldr_month_wide_4:"April",
cldr_month_wide_5:"May",
cldr_month_wide_6:"June",
cldr_month_wide_7:"July",
cldr_month_wide_8:"August",
cldr_month_wide_9:"September",
cldr_number_decimal_separator:$[47],
cldr_number_group_separator:$[17],
cldr_pm:"pm",
cldr_quotationEnd:"’",
cldr_quotationStart:"‘",
cldr_time_format_full:"h:mm:ss a v",
cldr_time_format_long:"h:mm:ss a z",
cldr_time_format_medium:"h:mm:ss a",
cldr_time_format_short:"h:mm a"});




/* ID: qx.locale.data.en */
qx.locale.Locale.define("qx.locale.data.en",
{cldr_date_format_full:"EEEE, MMMM d, yyyy",
cldr_date_format_long:"MMMM d, yyyy",
cldr_date_format_medium:"MMM d, yyyy",
cldr_date_format_short:"M/d/yy",
cldr_date_time_format_HHmm:$[2033],
cldr_date_time_format_HHmmss:$[296],
cldr_date_time_format_MMMMd:"MMMM d",
cldr_date_time_format_Md:"M/d",
cldr_date_time_format_mmss:"mm:ss",
cldr_date_time_format_yyMM:"MM/yy",
cldr_date_time_format_yyQQQQ:"QQQQ yy",
cldr_date_time_format_yyyyMMM:"MMM yyyy",
cldr_day_abbreviated_fri:"Fri",
cldr_day_abbreviated_mon:"Mon",
cldr_day_abbreviated_sat:"Sat",
cldr_day_abbreviated_sun:"Sun",
cldr_day_abbreviated_thu:"Thu",
cldr_day_abbreviated_tue:"Tue",
cldr_day_abbreviated_wed:"Wed",
cldr_day_narrow_fri:"F",
cldr_day_narrow_mon:$[1442],
cldr_day_narrow_sat:$[1024],
cldr_day_narrow_sun:$[1024],
cldr_day_narrow_thu:"T",
cldr_day_narrow_tue:"T",
cldr_day_narrow_wed:"W",
cldr_day_wide_fri:"Friday",
cldr_day_wide_mon:"Monday",
cldr_day_wide_sat:"Saturday",
cldr_day_wide_sun:"Sunday",
cldr_day_wide_thu:"Thursday",
cldr_day_wide_tue:"Tuesday",
cldr_day_wide_wed:"Wednesday",
cldr_month_abbreviated_1:"Jan",
cldr_month_abbreviated_10:"Oct",
cldr_month_abbreviated_11:"Nov",
cldr_month_abbreviated_12:"Dec",
cldr_month_abbreviated_2:"Feb",
cldr_month_abbreviated_3:"Mar",
cldr_month_abbreviated_4:"Apr",
cldr_month_abbreviated_5:"May",
cldr_month_abbreviated_6:"Jun",
cldr_month_abbreviated_7:"Jul",
cldr_month_abbreviated_8:"Aug",
cldr_month_abbreviated_9:"Sep",
cldr_month_narrow_1:"J",
cldr_month_narrow_10:$[1298],
cldr_month_narrow_11:"N",
cldr_month_narrow_12:"D",
cldr_month_narrow_2:"F",
cldr_month_narrow_3:$[1442],
cldr_month_narrow_4:$[205],
cldr_month_narrow_5:$[1442],
cldr_month_narrow_6:"J",
cldr_month_narrow_7:"J",
cldr_month_narrow_8:$[205],
cldr_month_narrow_9:$[1024],
cldr_month_wide_1:"January",
cldr_month_wide_10:"October",
cldr_month_wide_11:"November",
cldr_month_wide_12:"December",
cldr_month_wide_2:"February",
cldr_month_wide_3:"March",
cldr_month_wide_4:"April",
cldr_month_wide_5:"May",
cldr_month_wide_6:"June",
cldr_month_wide_7:"July",
cldr_month_wide_8:"August",
cldr_month_wide_9:"September",
cldr_time_format_full:"h:mm:ss a v",
cldr_time_format_long:"h:mm:ss a z",
cldr_time_format_medium:"h:mm:ss a",
cldr_time_format_short:"h:mm a"});




/* ID: qx.locale.data.de */
qx.locale.Locale.define("qx.locale.data.de",
{cldr_alternateQuotationEnd:"“",
cldr_alternateQuotationStart:"„",
cldr_am:"vorm.",
cldr_date_format_full:"EEEE, d. MMMM yyyy",
cldr_date_format_long:"d. MMMM yyyy",
cldr_date_format_medium:"dd.MM.yyyy",
cldr_date_format_short:"dd.MM.yy",
cldr_date_time_format_HHmm:$[2033],
cldr_date_time_format_HHmmss:$[296],
cldr_date_time_format_MMMMd:"d. MMMM",
cldr_date_time_format_MMdd:"dd.MM",
cldr_date_time_format_hhmm:"hh:mm a",
cldr_date_time_format_hhmmss:"hh:mm:ss a",
cldr_date_time_format_yyMM:"MM.yy",
cldr_date_time_format_yyQQQQ:"QQQQ yy",
cldr_date_time_format_yyyyMMMM:"MMMM yyyy",
cldr_day_abbreviated_fri:"Fr",
cldr_day_abbreviated_mon:"Mo",
cldr_day_abbreviated_sat:"Sa",
cldr_day_abbreviated_sun:"So",
cldr_day_abbreviated_thu:"Do",
cldr_day_abbreviated_tue:"Di",
cldr_day_abbreviated_wed:"Mi",
cldr_day_narrow_fri:"F",
cldr_day_narrow_mon:$[1442],
cldr_day_narrow_sat:$[1024],
cldr_day_narrow_sun:$[1024],
cldr_day_narrow_thu:"D",
cldr_day_narrow_tue:"D",
cldr_day_narrow_wed:$[1442],
cldr_day_wide_fri:"Freitag",
cldr_day_wide_mon:"Montag",
cldr_day_wide_sat:"Samstag",
cldr_day_wide_sun:"Sonntag",
cldr_day_wide_thu:"Donnerstag",
cldr_day_wide_tue:"Dienstag",
cldr_day_wide_wed:"Mittwoch",
cldr_month_abbreviated_1:"Jan",
cldr_month_abbreviated_10:"Okt",
cldr_month_abbreviated_11:"Nov",
cldr_month_abbreviated_12:"Dez",
cldr_month_abbreviated_2:"Feb",
cldr_month_abbreviated_3:"Mrz",
cldr_month_abbreviated_4:"Apr",
cldr_month_abbreviated_5:"Mai",
cldr_month_abbreviated_6:"Jun",
cldr_month_abbreviated_7:"Jul",
cldr_month_abbreviated_8:"Aug",
cldr_month_abbreviated_9:"Sep",
cldr_month_narrow_1:"J",
cldr_month_narrow_10:$[1298],
cldr_month_narrow_11:"N",
cldr_month_narrow_12:"D",
cldr_month_narrow_2:"F",
cldr_month_narrow_3:$[1442],
cldr_month_narrow_4:$[205],
cldr_month_narrow_5:$[1442],
cldr_month_narrow_6:"J",
cldr_month_narrow_7:"J",
cldr_month_narrow_8:$[205],
cldr_month_narrow_9:$[1024],
cldr_month_wide_1:"Januar",
cldr_month_wide_10:"Oktober",
cldr_month_wide_11:"November",
cldr_month_wide_12:"Dezember",
cldr_month_wide_2:"Februar",
cldr_month_wide_3:"März",
cldr_month_wide_4:"April",
cldr_month_wide_5:"Mai",
cldr_month_wide_6:"Juni",
cldr_month_wide_7:"Juli",
cldr_month_wide_8:"August",
cldr_month_wide_9:"September",
cldr_number_decimal_separator:$[17],
cldr_number_group_separator:$[47],
cldr_number_percent_format:"#,##0 %",
cldr_pm:"nachm.",
cldr_quotationEnd:"‘",
cldr_quotationStart:"‚",
cldr_time_format_full:"H:mm' Uhr 'z"});




/* ID: qx.locale.data.fr */
qx.locale.Locale.define("qx.locale.data.fr",
{cldr_alternateQuotationEnd:"”",
cldr_alternateQuotationStart:"“",
cldr_date_format_full:"EEEE d MMMM yyyy",
cldr_date_format_long:"d MMMM yyyy",
cldr_date_format_medium:"d MMM yy",
cldr_date_format_short:"dd/MM/yy",
cldr_date_time_format_HHmm:$[2033],
cldr_date_time_format_HHmmss:$[296],
cldr_date_time_format_MMMMd:"d MMMM",
cldr_date_time_format_MMdd:"dd/MM",
cldr_date_time_format_hhmm:"hh:mm a",
cldr_date_time_format_hhmmss:"hh:mm:ss a",
cldr_date_time_format_yyMM:"MM/yy",
cldr_date_time_format_yyQQQQ:"QQQQ yy",
cldr_date_time_format_yyyyMMMM:"MMMM yyyy",
cldr_day_abbreviated_fri:"ven.",
cldr_day_abbreviated_mon:"lun.",
cldr_day_abbreviated_sat:"sam.",
cldr_day_abbreviated_sun:"dim.",
cldr_day_abbreviated_thu:"jeu.",
cldr_day_abbreviated_tue:"mar.",
cldr_day_abbreviated_wed:"mer.",
cldr_day_narrow_fri:"V",
cldr_day_narrow_mon:"L",
cldr_day_narrow_sat:$[1024],
cldr_day_narrow_sun:"D",
cldr_day_narrow_thu:"J",
cldr_day_narrow_tue:$[1442],
cldr_day_narrow_wed:$[1442],
cldr_day_wide_fri:"vendredi",
cldr_day_wide_mon:"lundi",
cldr_day_wide_sat:"samedi",
cldr_day_wide_sun:"dimanche",
cldr_day_wide_thu:"jeudi",
cldr_day_wide_tue:"mardi",
cldr_day_wide_wed:"mercredi",
cldr_month_abbreviated_1:"janv.",
cldr_month_abbreviated_10:"oct.",
cldr_month_abbreviated_11:"nov.",
cldr_month_abbreviated_12:"déc.",
cldr_month_abbreviated_2:"févr.",
cldr_month_abbreviated_3:"mars",
cldr_month_abbreviated_4:"avr.",
cldr_month_abbreviated_5:"mai",
cldr_month_abbreviated_6:"juin",
cldr_month_abbreviated_7:"juil.",
cldr_month_abbreviated_8:"août",
cldr_month_abbreviated_9:"sept.",
cldr_month_narrow_1:"J",
cldr_month_narrow_10:$[1298],
cldr_month_narrow_11:"N",
cldr_month_narrow_12:"D",
cldr_month_narrow_2:"F",
cldr_month_narrow_3:$[1442],
cldr_month_narrow_4:$[205],
cldr_month_narrow_5:$[1442],
cldr_month_narrow_6:"J",
cldr_month_narrow_7:"J",
cldr_month_narrow_8:$[205],
cldr_month_narrow_9:$[1024],
cldr_month_wide_1:"janvier",
cldr_month_wide_10:"octobre",
cldr_month_wide_11:"novembre",
cldr_month_wide_12:"décembre",
cldr_month_wide_2:"février",
cldr_month_wide_3:"mars",
cldr_month_wide_4:"avril",
cldr_month_wide_5:"mai",
cldr_month_wide_6:"juin",
cldr_month_wide_7:"juillet",
cldr_month_wide_8:"août",
cldr_month_wide_9:"septembre",
cldr_number_decimal_separator:$[17],
cldr_number_group_separator:" ",
cldr_number_percent_format:"#,##0 %",
cldr_quotationEnd:"»",
cldr_quotationStart:"«",
cldr_time_format_full:"HH' h 'mm z"});




/* ID: qx.locale.translation.C */
qx.locale.Locale.define("qx.locale.translation.C",
{});




/* ID: qx.locale.translation.en */
qx.locale.Locale.define("qx.locale.translation.en",
{});




/* ID: qx.locale.translation.de */
qx.locale.Locale.define("qx.locale.translation.de",
{"key_short_Meta":$[1373],
"key_short_Scroll":"Rollen",
"key_full_NumLock":$[192],
"key_full_Left":"Pfeil links",
"Choose a date":"Datum auswählen",
"key_short_Control":"Strg",
"key_short_Home":"Pos1",
"Hex":"Hex",
"key_short_Space":"Leer",
"key_full_PageUp":"Bild hoch",
"key_short_Shift":"Umschalt",
"key_full_Control":"Steuerung",
"RGB":"RGB",
"key_short_Up":"Hoch",
"Details":"Details",
"Last year":"Vorheriges Jahr",
"key_full_Insert":"Einfügen",
"key_short_Apps":"Kontext",
"Open ColorSelector":"Öffne Farbauswahl",
"key_short_Backspace":"Rück",
"key_short_Alt":$[560],
"key_full_Shift":"Umschalttaste",
"Description":"Beschreibung",
"key_full_Space":"Leertaste",
"key_short_PageDown":"Bild runter",
"Presets":"Voreinstellungen",
"key_full_Up":"Pfeil hoch",
"key_short_CapsLock":"Feststell",
"key_full_Backspace":"Rücktaste",
"key_full_Tab":"Tabulator",
"key_full_End":"Ende",
"key_short_Escape":"Esc",
"key_short_Tab":$[253],
"key_full_Apps":"Kontextmenü",
"key_full_Delete":"Entfernen",
"Case sensitive":"Groß-/Kleinschreibung",
"HSB":"HSB",
"Search":"Suchen",
"key_short_PageUp":"Bild hoch",
"Next month":"Nächster Monat",
"key_short_Win":$[1405],
"key_full_Enter":$[110],
"key_full_Alt":$[560],
"key_short_Pause":$[650],
"key_short_Down":"Runter",
"key_full_Win":"Windowstaste",
"key_short_Right":"Rechts ",
"key_short_NumLock":"Num",
"key_full_Escape":$[245],
"Automatic":"Automatisch",
"ID":"ID",
"key_short_Enter":$[110],
"Last month":"Vorheriger Monat",
"key_full_Right":"Pfeil rechts",
"OK":"OK",
"key_full_PageDown":"Bild runter ",
"key_full_Pause":$[650],
"key_full_CapsLock":"Feststelltaste",
"Color Selector":"Farbauswahl",
"Search next occurrence":"Weiter suchen",
"Preview (Old/New)":"Vorschau (alt/neu)",
"key_short_Left":"Links",
"Search items in list":"Liste durchsuchen",
"key_short_End":"Ende",
"key_full_Meta":$[1373],
"key_full_Home":"Position 1",
"Cancel":"Abbruch",
"key_full_Scroll":"Rollen",
"Next year":"Nächstes Jahr",
"key_short_Delete":"Entf",
"key_short_Insert":"Einfg",
"key_full_Down":"Pfeil runter"});




/* ID: qx.locale.translation.fr */
qx.locale.Locale.define("qx.locale.translation.fr",
{"Open ColorSelector":"Ouvrir le sélecteur de couleurs",
"Search":"Chercher",
"Presets":"Pré-réglages",
"OK":"OK",
"HSB":"TSL",
"Preview (Old/New)":"Aperçu (Nouveau/Ancien)",
"Color Selector":"Sélecteur de couleur",
"Choose a date":"Choisissez une date",
"Hex":"HEX",
"RGB":"RVB",
"Next month":"Mois suivant",
"Details":"Détails",
"Cancel":"Annuller",
"Last month":"Mois précédant",
"Last year":"Année précédente",
"Next year":"Année suivante",
"Automatic":"Automatique"});




/* ID: Tr.translation.C */
qx.locale.Locale.define("Tr.translation.C",
{});




/* ID: Tr.translation.en */
qx.locale.Locale.define("Tr.translation.en",
{"Last [ms]":$[1139],
"Worst [ms]":$[1524],
"SmokeTrace is part of the SmokePing suite created by Tobi Oetiker, Copyright 2008.":$[710],
"Avg [ms]":$[1575],
"Ip":$[1743],
"Stop":$[1223],
"Best [ms]":$[927],
"Delay":$[958],
"Stopping":$[1637],
"Host":$[589],
"StDev [ms]":$[1232],
"Hop":$[1306],
"Go":$[1910],
"Loss [%]":$[1014],
"Starting":$[965],
"Rounds":$[1960],
"Sent":$[1789]});




/* ID: Tr.translation.de */
qx.locale.Locale.define("Tr.translation.de",
{"Last [ms]":"Letzte [ms]",
"Worst [ms]":"Unten [ms]",
"SmokeTrace is part of the SmokePing suite created by Tobi Oetiker, Copyright 2008.":"SmokeTrace ist Teil der SmokePing Suite, einem Produkt von Tobi Oetiker, Copyright 2008.",
"Avg [ms]":"Durch [ms]",
"Ip":$[1743],
"Stop":$[1223],
"Best [ms]":"Oben [ms]",
"Delay":"Verzögerung",
"Stopping":"Stoppt",
"Host":$[589],
"StDev [ms]":"StdAbw [ms]",
"Hop":"Sprung",
"Go":"Start",
"Loss [%]":"Verlust [%]",
"Starting":"Startet",
"Rounds":"Runden",
"Sent":"Gesendet"});




/* ID: Tr.translation.fr */
qx.locale.Locale.define("Tr.translation.fr",
{});

